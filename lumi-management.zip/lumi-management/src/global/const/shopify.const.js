// shopify 下所有商店
export const Stores = [
  {
    label: 'Lumist at UC Davis',
    describe: 'lumist-at-uc-davis.myshopify.com',
    value: 'ucDavis',
    download: "https://cdn.lumiclass.com/cms/paypal/UCD+Shopify.csv"
  },
  {
    label: 'Lumist at Berkeley',
    describe: 'lumistatberkeley.myshopify.com',
    value: 'berkeley',
    download: "https://cdn.lumiclass.com/cms/paypal/Berkeley+Shopify.csv"
  },
  {
    label: 'Lumist at UCI',
    describe: 'lumistatuci.myshopify.com',
    value: 'uci',
    download: "https://cdn.lumiclass.com/cms/paypal/UCI+Shopify.csv"
  },
  {
    label: 'Lumist at UCLA',
    describe: 'lumistucla.myshopify.com',
    value: 'ucla',
    download: "https://cdn.lumiclass.com/cms/paypal/UCLA+Shopify.csv"
  },
  {
    label: 'Lumist at UCSD',
    describe: 'lumist-at-ucsd.myshopify.com',
    value: 'ucSd',
    download: "https://cdn.lumiclass.com/cms/paypal/UCSD+Shopify.csv"
  },
];

// shopify 统计数据时间选项
export const TimeFilters = [
  {
    label: 'Today',
    describe: 'Compared to the daily average over the last 7 days',
    value: 'today',
  },
  {
    label: 'Last 7 days',
    describe: 'Compared to the previous 7 days',
    value: 'last_7_days',
  },
  {
    label: 'Last 30 days',
    describe: 'Compared to the previous 30 days',
    value: 'last_30_days',
  },
];


// 订单状态
export const OrderStatus = [
  { label: 'Open', value: 'open' },
  { label: 'Archived', value: 'closed' },
  { label: 'Canceled', value: 'cancelled' },
];

// 支付状态
export const PaymentStatus = [
  { label: 'Authorized', value: 'authorized' },
  { label: 'Paid', value: 'paid' },
  { label: 'Partially refunded', value: 'partially_refunded' },
  { label: 'Partially paid', value: 'partially_paid' },
  { label: 'Pending', value: 'pending' },
  { label: 'Refunded', value: 'refunded' },
  { label: 'Unpaid', value: 'unpaid' },
  { label: 'Voided', value: 'voided' },
  { label: 'Expired', value: 'expired' },
];

// 订单视图分类
export const SearchViews = [
  { label: 'All', value: 0 },
  { label: 'Unfulfilled', value: 1, params: { status: OrderStatus[0].value, fulfillmentStatus: ['unfulfilled','partial'].join(' ')} },
  { label: 'Unpaid', value: 2, params: { status: OrderStatus[0].value, financialStatus: PaymentStatus[6].value } },
  { label: 'Open', value: 3 , params: { status: OrderStatus[0].value }},
  { label: 'Closed', value: 4 , params: { status: OrderStatus[1].value }},
];
