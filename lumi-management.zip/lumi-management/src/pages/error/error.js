import React, { Component } from 'react';
import Style from './error.module.less';

class Personal extends Component {
    constructor() {
        super();
        this.state = {
            userName: '',//获取用户名
            department: [],//获取用户部门
        }
    }
    render() {
        return (
            <div className={Style.wrap}>
                很抱歉，您没有该访问权限
            </div>
        )
    }
}

export default Personal