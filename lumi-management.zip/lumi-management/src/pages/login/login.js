import React, { Component, Fragment } from 'react';
import fun from '../../utils/funSum.js';
import api from '../../utils/api';

class Login extends Component {
  componentDidMount() {
    let token = fun.getItem('token')
      ? `token=${JSON.parse(fun.getItem('token'))}`
      : '';
    let redirectUrl = encodeURIComponent(`${window.location.origin}/#/admin/personal`);
    window.location.href = `${api.loginUrl}?${token}&redirectUrl=${redirectUrl}`;
  }
  render() {
    return <Fragment></Fragment>;
  }
}

export default Login;
