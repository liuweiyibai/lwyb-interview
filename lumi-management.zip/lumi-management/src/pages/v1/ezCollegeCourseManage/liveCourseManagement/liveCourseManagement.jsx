import React, {Fragment} from "react";
import { connect } from "react-redux";
import { Button, Select, Tooltip, message, Spin, Table ,Dropdown, Menu, Modal } from "antd";
import api from "../../../../utils/api.js";
import momenttz from 'moment-timezone';
import { LoadingOutlined, ExclamationCircleOutlined, createFromIconfontCN } from "@ant-design/icons";
import CASManagementModal from '../components/CASManagementModal/CASModal';
import Style from "./liveCourseManagement.module.less";
import BindCypress from "../components/bindCypress/bindCypress";

const { Option } = Select;
const { confirm } = Modal;
const IconFont = createFromIconfontCN({
  scriptUrl: ['//at.alicdn.com/t/font_2364058_63mrgbhgxwa.js']
})

class LiveCourseManagement extends React.Component {
  state = {
    loading: false,
    isTeacher: false,
    campusList: [],
    mentorList: [],
    courseList: [], // 下拉框课程name数据
    assignTypeList: [],
    sectionList: [],
    selectCampusValue: null,
    selectMentorValue: null,
    selectCourseNameValue: null,
    selectAssignTypeValue: null,
    isShowDeleteBtn: false,
    isShowTableCheckBox: false,
    page: 1,
    pageSize: 10,
    total: 0,
    isModalVisible: false,
    modalType: 'add',  // 要打开的弹框的类型 - add / copy / edit
    selectedItemCaIds: [], // 选中的caid数组
    defaultModalSelectedValue: {
    },
    modalData: {},
    dataSource: [
      // {
      //   assignType: 1,
      //   assignTypeDisplay: 'Weekly Course',
      //   campusId: 1,
      //   courseCode: "hyqcode",
      //   courseName: "hyqname",
      //   enrollCount: 15,
      //   grade: 3,
      //   gradeDisplay: "Year 3",
      //   id: 10164,
      //   major: 7,
      //   majorDisplay: "BR",
      //   mentorId: 4169,
      //   mentorName: "UTSG",
      //   professor: "hyq",
      //   status: 1,
      //   statusDisplay: "Inactive",
      //   term: 2,
      //   termDisplay: "SUMMER",
      //   year: 2020,
      // }
    ]
  };

  columns = [
    {
      title: 'CASID',
      dataIndex: 'casId',
      key: 'casId',
      align: "left",
      width: 100,
      sorter: {
        compare: (a, b) => a.casId - b.casId,
        multiple: 2,
      },
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'Course Name',
      dataIndex: 'courseName',
      key: 'courseName',
      align: "left",
      className: Style.tableMinWidth,
      sorter: {
        compare: (a, b) => a.courseName.localeCompare(b.courseName),
        multiple: 1,
      },
      render: (v, record) => {
        return (
          <Tooltip placement="top" title={`${record.courseCode} (${record.year}) ${record.termDisplay}-${record.assignTypeDisplay}`}>
            <div className={Style.courseName}>{`${record.courseCode} (${record.year}) ${record.termDisplay}-${record.assignTypeDisplay}`}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Year',
      dataIndex: 'year',
      key: 'year',
      align: "left",
      width: 70,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'Type',
      dataIndex: 'assignTypeDisplay',
      key: 'assignTypeDisplay',
      align: "left",
      width: 135,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'Section',
      dataIndex: 'sectionDisplay',
      key: 'sectionDisplay',
      align: "left",
      className: Style.tableMinWidth,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            <div className={Style.courseName}>{v}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Start Time',
      dataIndex: 'startTime',
      key: 'startTime',
      align: "left",
      width: 200,
      className: Style.tableMinWidth,
      render: (v) => {
        return (
          <Tooltip placement="top" title={this.getCAS_TableTime(v)} mouseEnterDelay={0.3}>
            <div className={Style.courseName}>{this.getCAS_TableTime(v)}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Course Duration',
      dataIndex: 'duration',
      key: 'duration',
      align: "left",
      width: 150,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v+'mins'} mouseEnterDelay={0.3}>
            {v}mins
          </Tooltip>
        );
      },
    },
    {
      title: '',
      dataIndex: `id`,
      key: `id`,
      align: "center",
      width: 46,
      render: (v, record) => {
        if (this.state.isShowDeleteBtn) return '';
        return (
          <Dropdown overlay={this.editMenu(v,record)} placement="bottomRight">
            <Button className={Style.itemEditBtn} type='link'><IconFont type='icongengduo' /></Button>
          </Dropdown>
        );
      },
    }
  ];

  rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      // console.log(`selectedRowKeys:`,selectedRowKeys, 'selectedRows: ', selectedRows);
      this.setState({selectedItemCaIds: selectedRowKeys});
    },
  };

  editMenu = (v, record) =>{
    return (
      <Menu>
        <Menu.Item onClick={()=>{
            this.setState({
              defaultModalSelectedValue: record,
            }, () => {this.openModal('edit')})
          }}
        >
          <span>重新编辑</span>
        </Menu.Item>
        <Menu.Item onClick={()=>{
            this.setState({
              defaultModalSelectedValue: record,
            }, () => {this.openModal('copy')})
          }}
        >
          <span>复制</span>
        </Menu.Item>
      </Menu>
    )
  };

  openModal = (modalType) => {
    this.setState({
      isModalVisible: true,
      modalType,
    })
  }

  closeModal = () => {
    this.setState({
      isModalVisible: false,
    })
  }

  componentDidMount() {
    this.getCampus();
  }

  getCAS_TableTime = (time_str) => {
    let time = momenttz.tz(time_str, "America/New_York").format("YYYY/MM/DD hh:mmA"); // 表格中显示的时候是按照美东时间显示的
    // let time = moment(time_str).format("YYYY/MM/DD hh:mmA");
    time = time.replace(/上午|凌晨|早上/g, 'AM');
    time = time.replace(/中午|下午|晚上/g, 'PM');
    return time;
  }

  // 获取校区列表
  getCampus = () => {
    this.setState({ loading: true }, () => {
      api
        .getEduCampus()
        .then((res) => {
          if (res.code === 0) {
            this.setState({ campusList: res.data, loading: false });
          } else {
            if (res.ret === 60001) {
              this.setState({ isTeacher: true });
              res.message = res.msg;
            }
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
    });
  };

  // 获取当前学校下的老师
  getSchoolTeachers = () => {
    api
        .getEZA_SchoolTeachers(this.state.selectCampusValue)
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            this.setState({ 
              mentorList: res.data || [] 
            });
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
  }

  // 获取学校下面 - 下拉框课程列表 - 名字
  getCourseNameList = () => {
    return new Promise(resolve => {
      this.setState({loading: true}, async () => {
        await api.getEZA_CA_CourseList({campusId: this.state.selectCampusValue, mentorId: this.state.selectMentorValue, page: 1, pageSize: 1000}).then(res => {
          // console.log(res);
          resolve();
          if (res.code === 0) {
            this.setState({loading: false, courseList: this.state.selectCampusValue === null ? [] : this.uniqueCourseId(res.data)});
          } else {
            return Promise.reject(res);
          }
        }).catch(err => {
          message.error(err.message);
          this.setState({ loading: false });
        })
      })
    })
  }

  // 课程列表去重
  uniqueCourseId = (data) => {
    const _data = data;
    for (let i = 0; i < _data.length; i++) {
      for (let j = i+1; j < _data.length; j++) {
        if (_data[i].courseId === _data[j].courseId) {
          _data.splice(j, 1);
          j--;
        }
      }
    }
    return _data;
  }

  // 获取学校下的assignType
  getCampusOptions = () => {
    this.setState({loading: true}, () => {
      api.getEZA_CampusOptions(this.state.selectCampusValue).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false, assignTypeList: res.data.assignType || [], sectionList: res.data.section || []});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  // 获取学校下 所有符合条件的课程数据
  getCourseList = () => {
    // console.log(this.state.selectYearValue);
    if (!this.state.selectCampusValue) return; 
    this.setState({loading: true}, () => {
      api.getEZA_CAS_CourseList({
        campusId: this.state.selectCampusValue,
        assignType: this.state.selectAssignTypeValue,
        mentorId: this.state.selectMentorValue,
        courseId: this.state.selectCourseNameValue,
        page: this.state.page,
        pageSize: this.state.pageSize,
      }).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false, dataSource: res.data});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      });
      // 获取数据的数量
      this.getCourseListTotalCount();
    })
  }

  // 获取学校下 所有符合条件的课程数据 - 数量
  getCourseListTotalCount = () => {
    this.setState({loading: true}, () => {
      api.getEZA_CAS_CourseListTotalCount({
        campusId: this.state.selectCampusValue,
        assignType: this.state.selectAssignTypeValue,
        mentorId: this.state.selectMentorValue,
        courseId: this.state.selectCourseNameValue,
        page: this.state.page,
        pageSize: this.state.pageSize,
      }).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false, total: res.data});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  // 选学校
  clickCampusItem = (value, option) => {
    this.setState({ selectCampusValue: value, selectMentorValue: null, selectCourseNameValue: null, selectAssignTypeValue: null, page: 1, mentorList: [], courseList: [], assignTypeList: [], sectionList: [] }, async() =>{
      // await this.getCourseNameList(); // 课程名字列表数据比较多
      this.getSchoolTeachers();
      this.getCampusOptions();
      this.getCourseList();
    });
  }
  // 选老师
  clickMentorItem = (value, option) => {
    this.setState({ selectMentorValue: value, selectCourseNameValue: null, page: 1 }, () =>{
      this.getCourseNameList();
      this.getCourseList();
    });
  }
  // 选课程
  clickCourseNameItem = (value, option) => {
    this.setState({ selectCourseNameValue: value, page: 1 }, () => {
      this.getCourseList();
    });
  }
  // 选 assign type
  clickAssignTypeItem = (value, option) => {
    this.setState({ selectAssignTypeValue: value, page: 1 }, () => {
      this.getCourseList();
    });
  }

  // 批量删除CAS
  deleteCAS = () => {
    // console.log(this.state.selectedItemCaIds);
    this.setState({loading: true}, () => {
      // api.deleteEZA_CAS_Course(this.state.selectedItemCaIds).then(res => {
      api.deleteEZA_CAS_Course({ids: this.state.selectedItemCaIds}).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false});
          message.success('删除成功');
          this.getCourseList();
          this.cancelEditBtnClick();
        } else {
          this.showDeleteFailConfirm();
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  editBtnClick = () => {
    this.setState({isShowDeleteBtn: true, isShowTableCheckBox: true});
  }

  cancelEditBtnClick = () => {
    this.setState({isShowDeleteBtn: false, isShowTableCheckBox: false, selectedItemCaIds: []});
  }

  changePage = (page, pageSize) => {
    this.setState({page, pageSize}, () => {
      this.getCourseList();
    })
  }

  showDeleteConfirm = () => {
    confirm({
      title: '确定要删除直播课么？',
      icon: <ExclamationCircleOutlined style={{color: '#F2423D'}}/>,
      content: '删除后将无法恢复，确定要删除么？',
      okText: '确定',
      okType: 'danger',
      className: Style['EZA-CAS-Management-Confirm'],
      cancelText: '取消',
      onOk: () => {
        this.deleteCAS();
      },
      onCancel: () => {

      },
    });
  }

  showDeleteFailConfirm = () => {
    Modal.warning({
      title: '存在已开课的直播课，无法删除',
      content: '',
      okText: '好的',
      className: Style['EZA-CAS-Management-Confirm-2'],
    });
  }

  render() {
    const { assignTypeList, selectAssignTypeValue, isModalVisible, page, total, isShowTableCheckBox, dataSource, isShowDeleteBtn, courseList, mentorList, selectCampusValue, campusList, selectCourseNameValue, selectMentorValue } = this.state;
    const { columns, rowSelection } = this;
    return (
      <Spin
        spinning={this.state.loading}
        indicator={<LoadingOutlined />}
        tip="请稍候..."
        size="large"
      >
        {
          this.props.isTeacher ? (
              <BindCypress refresh={()=>{
                this.getCampus();}
              }/>
          ):(
            <div className={Style.EZALiveCourseManagementWrap}>
                <div className={Style.topBar}>
                  <div className={Style.left}>
                    {/* 校园下拉框 */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 126 }}
                        allowClear
                        placeholder="Campus"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickCampusItem(v, o)}
                        value={selectCampusValue}
                        onClear={() => {
                          this.setState({
                            selectCampusValue: null,
                            selectMentorValue: null,
                            selectCourseNameValue: null,
                            selectAssignTypeValue: null,
                            mentorList: [],
                            courseList: [],
                            assignTypeList: [],
                            dataSource: [],
                            page: 1,
                            total: 0,
                          });
                        }}
                    >
                      {campusList.map(campus => {
                        return (
                            <Option
                                key={campus.id}
                                value={campus.id}
                                campusname={campus.campusName}
                                title={campus.campusName}
                            >
                              <Tooltip
                                  placement="top"
                                  title={campus.campusName}
                                  mouseEnterDelay="0.5"
                              >
                                {campus.campusName}
                              </Tooltip>
                            </Option>
                        );
                      })}
                    </Select>
                    {/* Mentor */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 125 }}
                        allowClear
                        placeholder="Mentor"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickMentorItem(v, o)}
                        value={selectMentorValue}
                        onClear={() => {
                          this.setState({
                            selectMentorValue: null,
                            selectCourseNameValue: null,
                            courseList: [],
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      {
                        mentorList.map(mentor => {
                          return (
                              <Option
                                  key={mentor.mentorId}
                                  value={mentor.mentorId}
                                  title={mentor.mentorName}
                              >
                                <Tooltip
                                    placement="top"
                                    title={mentor.mentorName}
                                    mouseEnterDelay="0.5"
                                >
                                  {mentor.mentorName}
                                </Tooltip>
                              </Option>
                          )
                        })
                      }
                    </Select>
                    {/* Course Name */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 266 }}
                        allowClear
                        placeholder="Course Name"
                        className={Style.selectBox}
                        dropdownMatchSelectWidth={400}
                        onSelect={(v, o) => this.clickCourseNameItem(v, o)}
                        value={selectCourseNameValue}
                        onClear={() => {
                          this.setState({
                            selectCourseNameValue: null,
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      {
                        courseList.map(course => {
                          return (
                              <Option
                                  key={course.courseId}
                                  value={course.courseId}
                                  // title={`${course.courseCode} (${course.year}) ${course.termDisplay}-${course.assignTypeDisplay}`}
                                  title={course.courseName}
                              >
                                <Tooltip
                                    placement="top"
                                    // title={`${course.courseCode} (${course.year}) ${course.termDisplay}-${course.assignTypeDisplay}`}
                                    title={course.courseName}
                                    mouseEnterDelay="0.5"
                                >
                                  {/* {`${course.courseCode} (${course.year}) ${course.termDisplay}-${course.assignTypeDisplay}`} */}
                                  {course.courseName}
                                </Tooltip>
                              </Option>
                          )
                        })
                      }
                    </Select>
                    {/* Assignment Type */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 170 }}
                        allowClear
                        placeholder="Assignment Type"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickAssignTypeItem(v, o)}
                        value={selectAssignTypeValue}
                        onClear={() => {
                          this.setState({
                            selectAssignTypeValue: null,
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      {
                        assignTypeList.map(assign => {
                          return (
                              <Option
                                  key={assign.id}
                                  value={assign.id}
                                  title={assign.name}
                              >
                                <Tooltip
                                    placement="top"
                                    title={assign.name}
                                    mouseEnterDelay="0.5"
                                >
                                  {assign.name}
                                </Tooltip>
                              </Option>
                          )
                        })
                      }
                    </Select>
                  </div>
                  <div className={Style.right}>
                    {
                      isShowDeleteBtn ? (
                          <Fragment>
                            <Button danger ghost className={Style.inactiveBtn} disabled={this.state.selectedItemCaIds.length === 0} onClick={this.showDeleteConfirm}>Delete</Button>
                            <Button type="link" className={Style.activeCancelBtn} onClick={this.cancelEditBtnClick}>Cancel</Button>
                          </Fragment>
                      ):(
                          <Fragment>
                            <Button type="link" onClick={this.editBtnClick}>编辑</Button>
                            <Button type="primary" className={Style.addBtn} disabled={!selectCampusValue} onClick={()=>{this.openModal('add')}}>Add</Button>
                          </Fragment>
                      )
                    }
                  </div>
                </div>
                <div className={Style.main}>
                  <Table rowSelection={isShowTableCheckBox?rowSelection:null} tableLayout='fixed' dataSource={dataSource} columns={columns} rowKey={(record)=>record.id} className={Style.mainTable} pagination={{total: total, current: page, onChange: this.changePage}}/>
                </div>
              </div>
          )
        }
        <CASManagementModal isModalVisible={isModalVisible} closeModal={this.closeModal} refreshPage={this.getCourseList} modalType={this.state.modalType} assignTypeList={assignTypeList} sectionList={this.state.sectionList} campusId={selectCampusValue} mentorList={mentorList} defaultModalSelectedValue={this.state.defaultModalSelectedValue}/>
      </Spin>
    );
  }
}

export default connect((store) => store)(LiveCourseManagement);
