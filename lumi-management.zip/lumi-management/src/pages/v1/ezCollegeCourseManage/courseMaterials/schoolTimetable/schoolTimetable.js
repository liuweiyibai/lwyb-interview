import React, { Component, Fragment } from 'react';
import { Spin, Button, Popconfirm, Input, Upload, message, Divider, Modal as ModalAnt, Progress } from 'antd';
import { LoadingOutlined, DeleteOutlined, VerticalAlignBottomOutlined, createFromIconfontCN, DiffOutlined, MinusOutlined, PlusOutlined, EditOutlined, ReloadOutlined } from '@ant-design/icons';
import Style from './schoolTimetable.module.less';
import api from '../../../../../utils/api.js';
import Modal from '../../../../../components/modalOfTree/modalOfTree.js';
import Sortable from 'sortablejs';
import moment from 'moment';
const { Search } = Input;
const IconFont = createFromIconfontCN({
    scriptUrl: [
        '//at.alicdn.com/t/font_2364058_z28o7cj678h.js'
    ]
})

class SchoolTimetable extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            caId: '',
            weekId: '',
            optionId: '',
            lessonName: 'week',
            partList: [],
            partID: '',//点击上传链接所属part id
            search: '',//搜索框 input的值
            showUploadModal: false,//显示上传链接弹框
            showTimeSetModal: false, // 显示次数设置框
            isShowShareModal: false, // 显示分享弹框
            urlName: '',//input 链接名称
            url: '',//input url
            academyCloudFront: '',
            lumiCloudFront: '',
            timeInputValue: '',
            timeInputPlaceholder: '未设置',
            currentTimeInputParams: {},
            replayIsNull: false, // 回放是否为空
            currentClickMaterialType: 0, // 当前点击的物料类型 0 普通物料 1 回放
            renameInputValue: '',
            isShowRenameModal: false,
            currentRenameItem: {}, // 当前要重命名的index  信息
            isShowUploadModal: false,
            uploadPercent: 0,
            isUploadModalBtnClick: false,
            uploadProgressBarStatus: 'active',
            progressBarColor: '#ff8800',
            shareVideoStr: '', // 分享视频复制的内容
            shareUrlStr: '', // 分享视频 - URL
            sharePasswordStr: '', // 分享视频 - 密码
            shareTitleStr: '', // 要分享的课程的标题
            shareItemNow: {}, // 正在分享的 item 的信息，为了刷新用
        };
    }
    componentDidMount () {
        this.setState({ caId: this.props.location.search.split('=')[1] }, () => {
            this.getLessonInfo({ caId: this.state.caId, keyword: null });
        });
    }
    componentWillUnmount () {
        this.setState = () => {
            return;
        };
    }
    getLessonInfo = (params) => {
        this.setState({ loading: true }, () => {
            api.getEduLessonInfo(params)
                .then((res) => {
                    //  console.log(res)
                    // 将物料中的回放数据上移
                    let result = this.handleLessonInfoDataWithReplay(res.data);
                    // this.setState({ loading: false, partList: res.data, academyCloudFront: res.academyCloudFront, lumiCloudFront: res.lumiCloudFront }, () => {
                    this.setState({ loading: false, partList: result, academyCloudFront: res.academyCloudFront, lumiCloudFront: res.lumiCloudFront }, () => {
                        this.state.partList && this.state.partList.forEach((item, index) => {
                            item.courseOptions.forEach((item0, index0) => {
                                // item0.materials.forEach((item1,index1)=>{
                                if (item0.materials && item0.materials.length > 0) {
                                    new Sortable(this.refs[`partContent${index}${index0}`], {
                                        swapThreshold: 1,//交换区阈值
                                        animation: 150,//排序动画时间
                                        ghostClass: 'blue-background-class',
                                        onEnd: (evt) => {
                                            // console.log(evt)
                                            let ids = Array.from(evt.to.childNodes).map((item) => {
                                                return item.getAttribute('data-id')
                                            })
                                            this.sort({ ids });
                                        },
                                    })
                                }
                                // })
                            })
                        })
                    });
                })
                .catch((err) => {
                    console.log(err);
                    message.error(err.msg||'请尝试刷新');
                    this.setState({ loading: false });
                })
        })
    }
    sort = (params) => {
        this.setState({ loading: true }, () => {
            api.sortEDULessonMaterials(params)
                .then((res) => {
                    if (res.code === 0) {
                        // this.getLessonInfo({caId:this.state.caId,keyword:this.state.search});
                        this.setState({ loading: false });
                    } else {
                        return Promise.reject(res);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    search = (value) => {
        // console.log(value);
        this.setState({ loading: true, search: value }, () => {
            this.getLessonInfo({ caId: this.state.caId, keyword: value });
        });
    }
    deletePart = (el, el1) => {
        // console.log(el,el1);
        this.setState({ loading: true }, () => {
            api.deleteEDULessonMaterial({ id: el1.id })
                .then((res) => {
                    // console.log(res)
                    if (res.code === 0) {
                        this.getLessonInfo({ caId: this.state.caId, keyword: this.state.search });
                    } else {
                        return Promise.reject(res)
                    }
                })
                .catch((err) => {
                    console.log(err)
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    getUrlName = (e) => {
        this.setState({ urlName: e.target.value });
    }
    getUrl = (e) => {
        this.setState({ url: e.target.value });
    }
    //上传资料
    uploadFile = (item, item1, info) => {
        // console.log(item,item1,info)
        // console.log(info.file.name.split('.')[info.file.name.split('.').length - 1],info.file.name.split('.').pop())
        let pictureType = info.file.name.split('.').pop().toLowerCase();
        if (pictureType !== 'pdf' && pictureType !== 'zip' && pictureType !== 'mp4') {
            message.warning('非可上传的文件类型！');
            return;
        }
        this.setState({ loading: true }, async () => {
            // if (pictureType === 'pdf') {
            //     let formData = new FormData();
            //     formData.append('file', info.file);
            //     let data0 = await api.uploadPFDToAddWatermark(formData);
            //     if (data0.ret !== 20000) {
            //         message.error(data0.msg);
            //         throw new Error(data0.msg);
            //     }
            //     let data0_1 = await api.uploadEDUFile({ maxView: 99999, caId: item.caId, type: 'pdf', weekId: item.weekId, name: info.file.name, s3Link: data0.result, optionId: item1.optionId });
            //     if (data0_1.code !== 0) {
            //         message.error(data0_1.msg);
            //         throw new Error(data0_1.msg);
            //     }
            //     this.getLessonInfo({ caId: this.state.caId, keyword: this.state.search });
            //     return
            // }
            let data;
            try {
                const type = pictureType === 'pdf' || pictureType === 'zip' ? 6 : 5;
                //获取预签名
                data = await api.getAddress({ fileName: '.' + info.file.name.split('.').pop(), type: type });
                if (data.ret !== 20000) {
                    message.error(data.msg);
                    throw new Error(JSON.stringify(data));
                }
            } catch (err) {
                message.error(JSON.parse(err.message).msg || '未知错误');
                this.setState({ loading: false });
                throw err;
            }
            if (data.ret === 20000) {
                try {
                    if (pictureType === 'pdf') {
                        // await api.uploadAWS(data.result.url, info.file, { headers: { 'Content-Type': 'application/pdf' } });
                        await this.ajaxUpload(data.result.url, info.file, pictureType);
                    } else {
                        // let data2 = await api.uploadAWS(data.result.url, info.file);
                        // console.log('---上传aws---', data2);
                        // await api.uploadAWS(data.result.url, info.file);
                        await this.ajaxUpload(data.result.url, info.file);
                    }
                } catch (err) {
                    message.error(err.msg, 3);
                    this.setState({ loading: false });
                    return;
                }
                try {
                    const type = info.file.name.split('.').pop().toLowerCase() === 'mp4' ? 'video' : info.file.name.split('.').pop().toLowerCase();
                    let data2 = await api.uploadEDUFile({ maxView: 99999, caId: item.caId, type: type, weekId: item.weekId, name: info.file.name, s3Link: data.result.key, optionId: item1.optionId });
                    if (pictureType === 'mp4') {
                        let arr = info.file.name.split('.');
                        arr.pop();
                        let fileName = arr.join('');
                        let data3 = await api.uploadEDUVideoFile({ fileName: fileName, key: data.result.key, type: 4 });
                        if (data3.ret !== 20000) {
                            message.error(data3.msg);
                            throw new Error(JSON.stringify(data3));
                        }
                    }
                    if (data2.code !== 0) {
                        message.error(data2.msg);
                        throw new Error(JSON.stringify(data2));
                    }
                    this.setState({
                        uploadProgressBarStatus: 'success',
                        isUploadModalBtnClick: true,
                        progressBarColor: '#87d068',
                        uploadPercent: 100,
                    });
                    this.getLessonInfo({ caId: this.state.caId, keyword: this.state.search });
                } catch (err) {
                    this.setState({ loading: false, isUploadModalBtnClick: true, uploadProgressBarStatus: 'exception', progressBarColor:'#f04f46'});
                    try {
                        let _err =  JSON.parse(err.message).msg;
                        message.error(_err || '未知错误');
                    } catch (e) {
                        message.error(err.toString() || '未知错误');
                    }
                    // throw err;
                }
            }
        })
    }

    ajaxUpload = (awsUrl, file, type) => {
        return new Promise((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.upload.onloadstart = () => {
                message.success('开始上传');
                this.setState({isShowUploadModal: true, loading: false});
            }
            xhr.upload.onabort = () => {
                xhr.abort();
                this.setState({
                    uploadProgressBarStatus: 'exception',
                    isUploadModalBtnClick: true,
                    progressBarColor:'#f04f46',
                }, () => {
                    reject({msg: '上传中断'});
                });
            }
            xhr.upload.onprogress = (e) => {
                // console.log(e);
                let loaded = e.loaded;
                let total = e.total;
                let percent = Math.round(loaded / total * 100);
                percent = percent >= 99 ? 99: percent;
                this.setState({
                    uploadPercent: percent,
                });
            }
            xhr.onerror = () => {
                this.setState({
                    uploadProgressBarStatus: 'exception',
                    isUploadModalBtnClick: true,
                    progressBarColor:'#f04f46',
                });
                reject({msg: '上传失败'});
            }
            xhr.onload = () => {
                resolve();
            }
            xhr.open('put', awsUrl, true);
            // 上传 pdf 的时候
            if (type === 'pdf') {
                xhr.setRequestHeader('Content-Type', 'application/pdf');
            }
            xhr.send(file);
        })
    }

    //点击上传链接 确定
    uploadLink = () => {
        this.setState({ loading: true }, () => {
            api.uploadEDUFile({ maxView: 99999, caId: this.state.caId, type: 'txt', name: this.state.urlName, s3Link: this.state.url, weekId: this.state.weekId, optionId: this.state.optionId })
                .then((res) => {
                    if (res.code === 0) {
                        this.getLessonInfo({ caId: this.state.caId, keyword: this.state.search });
                        this.close();
                    } else {
                        return Promise.reject(res);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.close();
                })
        })
    }
    close = () => {
        this.setState({ showUploadModal: false, urlName: '', url: '', loading: false });
    }

    changeInputValue = (type) => {
        if (type === 'add') {
            if (+this.state.timeInputValue >= 99999) return;
            this.setState({
                timeInputValue: +this.state.timeInputValue + 1,
            })
        } else if (type === 'sub') {
            if (+this.state.timeInputValue <= 1) return;
            this.setState({
                timeInputValue: +this.state.timeInputValue - 1,
            })
        }
    }

    setTimeInputValue = (e) => {
        let v = e.target.value;
        v = (v + '').replace(/[^0-9]/g, '');
        v = +v;
        if (v > 99999 || v === '0') { // 0 也不能输入
            return;
        }
        this.setState({ timeInputValue: v })
    }

    // 将物料中的回放数据上移 - 便于渲染提、取
    handleLessonInfoDataWithReplay = (data) => {
        let result = data;
        result.forEach(item => {
            item.courseOptions && item.courseOptions.forEach(item1 => {
                item1.materials && item1.materials.forEach(item2 => {
                    if (item2.type === 'replay') {
                        item1.replayTimeInfo = item2;
                    }
                })
            })
        })
        return result;
    }

    updateMaterialViewCount = (params) => {
        if (this.state.replayIsNull && this.state.currentClickMaterialType === 1) { // 当前点击的是回放 & 未设置次数 -- 走新增物料接口
            this.setState({ loading: true }, () => {
                api.uploadEDUFile({ ...params, type: 'replay' })
                    .then((res) => {
                        if (res.code === 0) {
                            this.setState({ loading: false });
                            message.success('修改成功');
                            this.getLessonInfo({ caId: this.state.caId, keyword: null });
                        } else {
                            return Promise.reject(res);
                        }
                    })
                    .catch((err) => {
                        message.error(err.msg);
                        this.close();
                    })
            })
            return;
        }
        this.setState({ loading: true }, () => { // 更新物料信息接口
            api.updateMaterialViewCount(params)
                .then((res) => {
                    // console.log(res);
                    if (res.code === 0) {
                        this.setState({ loading: false });
                        message.success('修改成功');
                        this.getLessonInfo({ caId: this.state.caId, keyword: null });
                    } else {
                        return Promise.reject(res);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }

    showRenameModal = (index, index1, index2) => {
        const _partList = this.state.partList;
        this.setState({
            isShowRenameModal: true,
            currentRenameItem: {
                caId: _partList[index].caId,
                weekId: _partList[index].weekId,
                id: _partList[index].courseOptions[index1].materials[index2].id,
                optionId: _partList[index].courseOptions[index1].optionId,
            },
            renameInputValue: _partList[index].courseOptions[index1].materials[index2].name,
        });
    }

    updateMaterialName = () => {
        this.setState({ loading: true }, () => {
            api.updateMaterialViewCount({ ...this.state.currentRenameItem, name: this.state.renameInputValue }).then(res => {
                if (res.code === 0) {
                    this.setState({ loading: false, isShowRenameModal: false });
                    message.success('更新成功');
                    this.getLessonInfo({ caId: this.state.caId, keyword: null });
                } else {
                    return Promise.reject(res);
                }
            }).catch(err => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }

    goReplayVideoRoom = (weekId, optionId) => {
        const w = window.open('about:blank');
        w.location.href = `/#/admin/v1/ezCollegeCourseManage/courseMaterials/videoRoom?type=0&weekId=${weekId}&optionId=${optionId}`;
    }

    goVideoRoom = (id) => {
        const w = window.open('about:blank');
        w.location.href = `/#/admin/v1/ezCollegeCourseManage/courseMaterials/videoRoom?type=1&id=${id}`;
    }

    openPDF = (href, name) => {
        this.materialDownload(href, name);
    }

    materialDownload = async (href, name) => {
        let that = this;
        try {
            let x = new XMLHttpRequest();
            x.open("GET", href, true);
            x.responseType = 'blob';
            x.onload = function (e) {
                that.download(x.response, 'application/pdf;chartset=UTF-8', name);
            }
            x.send();
        } catch (e) {
            console.log('下载失败');
        }
    }
    download = (res, type, filename) => {
        // 创建blob对象，解析流数据
        const blob = new Blob([res], {
            // 如何后端没返回下载文件类型，则需要手动设置：type: 'application/pdf;chartset=UTF-8' 表示下载文档为pdf，如果是word则设置为msword，excel为excel
            type: type
        })
        const a = document.createElement('a');
        // 兼容webkix浏览器，处理webkit浏览器中href自动添加blob前缀，默认在浏览器打开而不是下载
        const URL = window.URL || window.webkitURL;
        // 根据解析后的blob对象创建URL 对象
        const herf = URL.createObjectURL(blob);
        // 下载链接
        a.href = herf;
        a.target = "_blank";
        // 下载文件名,如果后端没有返回，可以自己写a.download = '文件.pdf'
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        // 在内存中移除URL 对象
        window.URL.revokeObjectURL(herf);
    }

    // 切换分享视频 Modal
    switchShareModal = (val = false) => {
        this.setState({isShowShareModal: val});
    }

    // 分享视频
    onShareVideo = (optionId, item) => {
        // console.log('--', optionId, item)
        let weekId, name;
        if (typeof optionId === 'undefined' || typeof item === 'undefined') { // 如果没有传参的时候
            optionId = this.state.shareItemNow.optionId;
            weekId = this.state.shareItemNow.weekId;
            name = this.state.shareItemNow.name;
        } else {
            weekId = item.weekId;
            name = item.name;
            this.setState({
                shareItemNow: {optionId, weekId, name}
            })
        }

        // let shareStr = sessionStorage.EZAshareVideoStr + ` - ${name}`; // 取出上级页面带过来的数据
        let shareStr = localStorage.getItem('EZAshareVideoStr') + ` - ${name}` // 取出上级页面带过来的数据

        this.setState({loading: true}, () => {
            api.createVideoShare({optionId, weekId, type: 1}).then(res => {
                console.log(res);
                if (res.code === 0) {
                    const env = process.env.NODE_ENV;
                    const _url = res.data.url;
                    const _password = res.data.password;
                    let _shareUrl = env === 'production' ? `https://academy.easy-group.cn/share-video/${_url}` : `https://dev-academy.easy-group.cn/share-video/${_url}`;
                    const _shareVideoUrl = shareStr + ` 地址：${_shareUrl} 密码：${_password}`; // 最后复制到剪贴板中的字符串
                    this.setState({
                        shareUrlStr: _shareUrl, // 分享链接
                        sharePasswordStr: _password, // 密码
                        shareVideoStr: _shareVideoUrl, // 全部内容
                        shareTitleStr: shareStr, // 课程名
                        loading: false,
                        isShowShareModal: true,
                    })
                } else {
                    if (res.code === 400000) {
                        res.message = '操作太快，休息一下';
                    }
                    return Promise.reject(res);
                }
            }).catch(err => {
                message.error(err.message || '分享失败');
                this.setState({loading: false});
            })
        })
    }

    clearShareInfo = () => {
        this.setState({
            shareVideoStr: '', // 分享视频复制的内容
            shareUrlStr: '', // 分享视频 - URL
            sharePasswordStr: '', // 分享视频 - 密码
            shareTitleStr: '', // 要分享的课程的标题
            shareItemNow: {}, // 正在分享的 item 的信息，为了刷新用
        })
    }

    onShareModalCancel = () => {
        this.switchShareModal(false);
        this.clearShareInfo();
    }

    onShareCopy = () => {
        // console.log(this.state.shareVideoStr);
        const input = document.createElement('textarea');
        document.body.appendChild(input);
        input.style.position = 'absolute';
        input.style.left = '-9999px';
        input.value = this.state.shareVideoStr;
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
        message.success('复制成功');
        this.switchShareModal(false);
    }

    // 回放视频下载
    downloadReplayVideo = (weekId, optionId) => {
        // console.log(weekId, optionId);
        this.setState({ loading: true}, () => {
            api.getReplayInfo({weekId, optionId}).then(res => {
                if (res.code === 0) {
                    this.setState({ loading: false });
                    // console.log(res.data);
                    const url = 'https://cdn.lumiclass.com/' + res.data.url;
                    // window.open(url, '_blank');
                    const a = document.createElement('a');
                    a.href = url;
                    a.click();
                    
                } else {
                    return Promise.reject(res);
                }
                }).catch(err => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }


    render () {
        return (
            <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                <div className={Style.head}>
                    <div className={Style.title}>课程表</div>
                    <Search className={Style.searchInput} placeholder='请输入课程名称或资料名称' onSearch={this.search} enterButton></Search>
                </div>
                {/* <div className={Style.lessonName}>{this.state.lessonName}</div> */}
                {this.state.partList && this.state.partList.map((item, index) => {
                    return (
                        <div className={Style.partWrap} key={index}>
                            <div className={Style.partTop}>
                                {/* <div className={Style.PartTopLeft}> */}
                                {/* <div className={Style.line}> */}
                                {/* <span className={Style.num}>{index+1}</span> */}
                                <div className={Style.title}>{item.name}</div>
                                {/* </div> */}
                                {/* </div> */}
                            </div>

                            <div className={Style.partContent}>
                                {item.courseOptions && item.courseOptions.length > 0 ? item.courseOptions.map((item1, index1) => {
                                    return (
                                        <div key={index1} className={Style.partContentWrap}>
                                            <div className={Style.partContentTitle}>
                                                <div className={Style.left}>
                                                    <span className={Style.num}>{index1 + 1}</span>
                                                    <div className={Style.optionName}>{item1.optionName ? item1.optionName : '请联系学务老师更新课程名字'}</div>
                                                </div>
                                                <div>
                                                    <Button type='link' icon={<DiffOutlined />} className={Style.linkBtn} onClick={() => {
                                                        this.setState({ showTimeSetModal: true, timeInputValue: '', currentClickMaterialType: 1 });
                                                        if (item1.replayTimeInfo) { // 如果有数据，将默认值取出来
                                                            this.setState({ timeInputValue: item1.replayTimeInfo.maxView, replayIsNull: false })
                                                        } else { // 如果没有数据的话做个标记
                                                            this.setState({ replayIsNull: true });
                                                        }
                                                        const params = {
                                                            caId: item.caId,
                                                            weekId: item.weekId,
                                                            optionId: item1.optionId,
                                                            name: '回放',
                                                            s3Link: '',
                                                            ...item1.replayTimeInfo,
                                                        }
                                                        this.setState({ currentTimeInputParams: params });
                                                    }}
                                                    >回放次数设置</Button>
                                                    <Button className={Style.btn} onClick={() => this.onShareVideo(item1.optionId, item)}>分享视频</Button>
                                                    {
                                                        item1.liveInfo && item1.liveInfo.flag === 4 && (
                                                            <Fragment>
                                                                <Button className={Style.btn} onClick={() => { this.goReplayVideoRoom(item.weekId, item1.optionId) }}>查看回放</Button>
                                                                <Button className={Style.btn} onClick={() => { this.downloadReplayVideo(item.weekId, item1.optionId) }}>回放下载</Button>
                                                            </Fragment>
                                                        )
                                                    }
                                                    <Upload
                                                        beforeUpload={() => false}
                                                        onChange={(file) => { this.uploadFile(item, item1, file); }}
                                                        showUploadList={false}
                                                    >
                                                        <Button className={Style.btn}>上传资料</Button>
                                                    </Upload>
                                                    <Button className={Style.btn} onClick={() => this.setState({ showUploadModal: true, caId: item.caId, weekId: item.weekId, optionId: item1.optionId })}>上传链接</Button>
                                                </div>
                                            </div>
                                            <div className={Style.time}>
                                                {item1.startTime || item1.endTime ? ((item1.startTime ? moment(item1.startTime).format('MM/DD HH:mm:ss') : '') + ' - ' + (item1.endTime ? moment(item1.endTime).format('MM/DD HH:mm:ss') : '')) : '请联系学务老师更新课程时间'}
                                            </div>
                                            <div ref={`partContent${index}${index1}`}>
                                                {item1.materials && item1.materials.length > 0 ? item1.materials.map((item2, index2) => {
                                                    if (item2.type === 'replay') { // 回放类型的物料不显示  并 数据上提
                                                        return '';
                                                    }
                                                    const href = item2.s3Link.split('/')[0] === 'academy' ? this.state.lumiCloudFront + item2.s3Link : this.state.academyCloudFront + item2.s3Link;
                                                    return (
                                                        <div className={Style.partMaterial} key={index2} data-id={item2.id}>
                                                            <div className={Style.partMaterialLeft}>
                                                                <IconFont type='icontuodong' className={Style.dragIcon}></IconFont>
                                                                {item2.type === 'pdf' ? <IconFont type='iconpdf' className={Style.icon}></IconFont> : item2.type === 'txt' ? <IconFont type='iconlianjie' className={Style.icon}></IconFont> : item2.type === 'video' ? <IconFont type='iconshipin' className={Style.icon}></IconFont> : item2.type === 'zip' ? <IconFont type='iconzip' className={Style.icon}></IconFont> : item2.type === 'image' ? <IconFont type='icontupian' className={Style.icon}></IconFont> : <IconFont type='iconweizhi' className={Style.icon}></IconFont>}
                                                                <div className={Style.partMaterialName}>
                                                                    {item2.type === 'txt' ? <a className={Style.aLink} href={item2.s3Link} rel="noopener noreferrer" target="_blank">{item2.name}</a> : item2.name}
                                                                </div>
                                                            </div>
                                                            <div className={Style.partBtn}>
                                                                <Button type="link" icon={<EditOutlined />} className={Style.linkBtn} onClick={() => { this.showRenameModal(index, index1, index2) }}>重命名</Button>
                                                                <Button type='link' icon={<DiffOutlined />} className={Style.linkBtn} onClick={() => {
                                                                    this.setState({ showTimeSetModal: true, timeInputValue: '', currentClickMaterialType: 0 });
                                                                    if (item2.maxView) {
                                                                        this.setState({
                                                                            timeInputValue: +item2.maxView
                                                                        })
                                                                    }
                                                                    const params = {
                                                                        caId: item.caId,
                                                                        weekId: item.weekId,
                                                                        optionId: item1.optionId,
                                                                        ...item2,
                                                                    }
                                                                    this.setState({ currentTimeInputParams: params });
                                                                }}
                                                                >次数设置</Button>
                                                                {item2.type === 'pdf' ? <Button type='text' icon={<VerticalAlignBottomOutlined />} onClick={() => { this.openPDF(href, item2.name) }}>下载</Button> : item2.type === 'zip' || item2.type === 'image' ? <Button type='text' icon={<VerticalAlignBottomOutlined />} href={href} download>下载</Button>
                                                                    : item2.type === 'txt' ? <Button type='text' href={item2.s3Link} rel="noopener noreferrer" target="_blank"><IconFont type='icondakai'></IconFont>打开</Button>
                                                                        : item2.type === 'video' ? <Button type="text" onClick={() => this.goVideoRoom(item2.id)}><IconFont type='icondakai'></IconFont>播放</Button>
                                                                            : ''
                                                                }
                                                                <Popconfirm placement="top" title="确认要删除吗？" onConfirm={() => { this.deletePart(item, item2) }} okText="确定" cancelText="取消">
                                                                    <Button type='text' icon={<DeleteOutlined />}>删除</Button>
                                                                </Popconfirm>
                                                            </div>
                                                        </div>
                                                    )
                                                }) : <div className={Style.noMaterials}>暂无资料</div>}
                                            </div>
                                        </div>
                                    )
                                }) : <div className={Style.noCourseOption}>尚未添加课程信息</div>}
                            </div>
                            <Divider />
                        </div>
                    )
                })}
                {this.state.showUploadModal ? <Modal title='上传链接' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={this.state.urlName === '' || this.state.url === ''} onClick={() => { this.uploadLink(); }}>确定</Button>]}>
                    <Input placeholder='请输入链接名称' className={Style.input} onChange={this.getUrlName}></Input>
                    <Input placeholder='请输入URL' className={Style.input} onChange={this.getUrl}></Input>
                </Modal> : ''}
                <ModalAnt className={Style.timeModal} visible={this.state.showTimeSetModal} closable={false} maskClosable={true} width={444}
                    cancelButtonProps={{ type: 'link', className: 'timeSetModalCancelBtn' }}
                    okButtonProps={{ className: 'timeSetModalOkBtn', disabled: ['', 0, '0'].includes(this.state.timeInputValue) }}
                    onOk={() => {
                        this.setState({ showTimeSetModal: false });
                        this.updateMaterialViewCount({
                            ...this.state.currentTimeInputParams,
                            maxView: this.state.timeInputValue,
                        });
                    }}
                    onCancel={() => { this.setState({ showTimeSetModal: false }) }}
                >
                    <div className={Style.timeSetModalTitle}>浏览次数设置</div>
                    <div className={Style.timeSetModalInputBox}>
                        <Button className={Style.btn} icon={<MinusOutlined />} type="link" onClick={() => { this.changeInputValue('sub') }} />
                        <Input bordered={false} placeholder={this.state.timeInputPlaceholder} className={Style.numberInput} value={this.state.timeInputValue} onChange={(e) => { this.setTimeInputValue(e) }} onBlur={() => {
                            if (!(/[0-9]/g.test(this.state.timeInputValue)) || +this.state.timeInputValue === 0) {
                                this.setState({
                                    timeInputValue: 1
                                })
                            }
                        }}
                        />
                        <Button className={Style.btn} icon={<PlusOutlined />} type="link" onClick={() => { this.changeInputValue('add') }} />
                    </div>
                </ModalAnt>
                <ModalAnt
                    className={Style.renameModal}
                    visible={this.state.isShowRenameModal}
                    onCancel={() => {
                        this.setState({
                            isShowRenameModal: false,
                            currentRenameItem: {},
                            renameInputValue: '',
                        })
                    }}
                    getContainer={false}
                    title="重命名"
                    onOk={() => {
                        this.updateMaterialName();
                    }}
                >
                    <Input value={this.state.renameInputValue} onChange={(e) => {
                        this.setState({
                            renameInputValue: e.target.value,
                        })
                    }}
                    />
                </ModalAnt>
                <ModalAnt
                    className={Style.EZAUpLoadProgressModal}
                    visible={this.state.isShowUploadModal}
                    getContainer={false}
                    title="资料上传"
                    closable={false}
                    footer={null}
                >
                    <Progress percent={this.state.uploadPercent} status={this.state.uploadProgressBarStatus} strokeColor={this.state.progressBarColor}/>
                    {this.state.uploadProgressBarStatus === 'exception' &&  <div className={Style.errDiv}>上传失败</div>}
                    <div className={Style.footer}>
                        <Button onClick={()=>{
                                this.setState({
                                    isShowUploadModal: false,
                                    uploadPercent: 0,
                                    isUploadModalBtnClick: false,
                                    uploadProgressBarStatus: 'active',
                                    progressBarColor: '#ff8800',
                                });
                            }} disabled={!this.state.isUploadModalBtnClick}
                        >确认</Button>
                    </div>
                </ModalAnt>
                <ModalAnt
                    className={Style.EZAShareModal}
                    visible={this.state.isShowShareModal}
                    getContainer={false}
                    title="分享视频"
                    closable={false}
                    footer={null}
                    centered={true}
                >
                    <div className={Style.tipBox}>
                        <p>内部资源，谨慎分享，如有泄露，严肃处理。</p>
                        <p>复制链接即可分享：{this.state.shareTitleStr}</p>
                    </div>
                    <div className={Style.content}>
                        <div className={Style.inputBox}>
                            <div className={Style.inputLeftText}>链接</div>
                            <div className={Style.link}>{this.state.shareUrlStr}</div>
                            <div className={Style.refreshIcon} onClick={() => this.onShareVideo()}><ReloadOutlined /></div>
                        </div>
                        <div className={Style.passwordText}>密码保护：{this.state.sharePasswordStr}</div>
                    </div>
                    <div className={Style.footer}>
                        <Button className={Style.cancelBtn} type='link' onClick={() => this.onShareModalCancel()}>取消</Button>
                        <Button type='primary' onClick={this.onShareCopy}>复制链接及密码</Button>
                    </div>
                </ModalAnt>
            </Spin>
        )
    }
}

export default SchoolTimetable;