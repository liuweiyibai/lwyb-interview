import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Spin, message, Button, Input, InputNumber, Divider, Select, Tooltip, Empty } from 'antd';
import { LoadingOutlined, PlusCircleFilled } from '@ant-design/icons';
import Style from './courseMaterials.module.less';
import api from '../../../../utils/api.js';
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import actionCreator from '../../../../store/actionCeator.js';
const { Option } = Select;

const { TextArea } = Input;

class EDUCourseMaterials extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showModal: false,
            showBindModal: false,
            accountNumber: '',
            password: '',
            errorMsg: '',
            courseList: [],
            chooseCourseEl: '',
            title: '',
            courseId: '',//left选中的course
            lessonList: [],
            courseAllInfo: [],
            keyword: '',
            lessonNum: '',
            lessonInfo: '',
            campusList: [],
            mentorList: [],
            // 保存各个下拉框的值
            campusSelectValue: null,
            mentorSelectValue: null,
        }
    }
    componentDidMount () {
        if (this.props.history && this.props.history.StorageNavigation && this.props.history.StorageNavigation.Measures) {
            this.setState({
                ...this.props.history.StorageNavigation.Measures
            })
        }
        // this.getEduCourseAllInfo();
        this.getCampus();
    }
    componentWillUnmount () {
        this.setState = () => {
            return;
        };
        this.props.history.StorageNavigation = { ...this.props.history.StorageNavigation, Measures: this.state }
    }
    getCampus = () => {
        // 获取校区列表
        this.setState({ loading: true }, () => {
            api.getEduCampus().then((res) => {
                if (res.code === 0) {
                    this.setState({ campusList: res.data, loading: false });
                } else {
                    if (res.ret === 60001) {
                        this.setState({ isTeacher: true });
                        res.message = res.msg;
                    }
                    return Promise.reject(res);
                }
            })
                .catch((err) => {
                    message.error(err.message);
                    this.setState({ loading: false });
                });
        });
    };

    getMentors = (campusId, option) => {
        // 获取导师列表
        this.setState(
            {
                loading: true,
                campusSelectValue: option.value,
                mentorList: [], // 清空后边的下拉框
                mentorSelectValue: null,
            },
            () => {
                api
                    .getEduCampusMentors({}, {}, campusId)
                    .then((res) => {
                        // console.log(res);
                        if (res.code === 0) {
                            const data = res.data.map((v) => {
                                v.campusId = campusId;
                                return v;
                            });
                            this.setState({ mentorList: data, loading: false });
                        } else {
                            return Promise.reject(res);
                        }
                    })
                    .catch((err) => {
                        message.error(err.message);
                        this.setState({ loading: false });
                    });
            }
        );
    };
    getEduCourseAllInfo = (val, opt) => { // 选中下拉框之后获取数据，其他地方也可以调用
        this.setState({ loading: true, mentorSelectValue: (opt && opt.value) || this.state.mentorSelectValue }, () => {
            api.getEduCourseInfo({ campusId: (opt && opt.campusid) || this.state.campusSelectValue, mentorId: (opt && opt.value) || this.state.mentorSelectValue })
                .then((res) => {
                    if (res.code === 0) {
                        // console.log(res);
                        let data = res.data ? res.data : [];
                        // console.log(data);
                        data = data.map(item => {
                            item.checked = false;
                            return item;
                        })
                        let lessonList = [], courseId, title;
                        if (data.length > 0) {
                            data[0].checked = true;
                            lessonList = data[0].courseAssignments;
                            courseId = data[0].ciId;
                            title = data[0].courseName;
                        }
                        this.setState({ loading: false, courseAllInfo: data, lessonList, courseId, title });
                        // 如果有选中某个侧边菜单项的时候，刷新数据之后，模拟点击一下
                        if (this.state.chooseCourseEl !== '') {
                            this.chooseCourse(this.state.chooseCourseEl);
                        }
                    } else {
                        if (res.ret === 60001) {
                            this.setState({ isTeacher: true });
                        }
                        return Promise.reject(res);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //选择课程 左侧
    chooseCourse = (el) => {
        let lessonList = [];
        let arr = this.state.courseAllInfo.map(item => {
            if (item.ciId === el.ciId) {
                item.checked = true;
                lessonList = item.courseAssignments;
            } else {
                item.checked = false;
            }
            return item;
        })
        // console.log(lessonList)
        this.setState({ courseList: arr, courseId: el.ciId, lessonList, title: el.courseName, chooseCourseEl: el });
    }
    //点击添加封面
    addKeyword = (item, e) => {
        //阻止冒泡
        e.stopPropagation();
        // console.log(item);
        this.setState({ showModal: true, lessonInfo: item, keyword: item.courseCover ? item.courseCover.tag1 : '', lessonNum: item.courseCover ? item.courseCover.tag2 : '' });
    }
    chooseLesson = (el) => {
        localStorage.setItem('EZAshareVideoStr', `${this.state.title} - ${el.assignName}`);
        // console.log(el,this.state.courseId)
        // return;
        // this.props.history.push(`/admin/v1/ezCollegeCourseManage/courseMaterials/schoolTimetable?courseId=${this.state.courseId}`);
        this.props.history.push(`/admin/v1/ezCollegeCourseManage/courseMaterials/schoolTimetable?courseId=${el.caId}`);
    }
    getKeyword = (e) => {
        this.setState({ keyword: e.target.value });
    }
    getLessonNum = (value) => {
        this.setState({ lessonNum: value });
    }
    //确定添加关键字
    submitKeyword = () => {
        this.setState({ loading: true }, () => {
            api.addKeyword({ caId: this.state.lessonInfo.caId, tag1: this.state.keyword, tag2: this.state.lessonNum })
                .then((res) => {
                    // console.log(res);
                    if (res.code === 0) {
                        this.getEduCourseAllInfo();
                        // [zyd] 21-05-07 下边的代码注释了，因为无法保证正好获取完数据
                        // //确保在获取完数据后执行
                        // let num = setInterval(()=>{
                        //     if(this.state.loading) return;
                        //     let arr;
                        //     this.state.courseAllInfo.forEach((item)=>{
                        //         if(item.ciId === this.state.courseId){
                        //             arr = item.courseAssignments;
                        //         }else{
                        //             arr = [];
                        //         }
                        //     })
                        //     clearInterval(num);
                        //     this.setState({lessonList:arr,showModal:false,keyword:'',lessonNum:''});
                        // },500);
                        this.setState({ showModal: false, keyword: '', lessonNum: '' });
                        // this.chooseCourse(this.state.chooseCourseEl);
                        // this.close();
                    } else {
                        return Promise.reject(res);
                    }
                })
                .catch((err) => {
                    // console.log(err);
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    close = () => {
        this.setState({ showModal: false, showBindModal: false, keyword: '', lessonNum: '', errorMsg: '' });
    }
    //
    getAccountNumber = (e) => {
        this.setState({ accountNumber: e.target.value });
    }
    //
    getPassword = (e) => {
        this.setState({ password: e.target.value });
    }
    //绑定导师账号
    bind = (params) => {
        this.setState({ loading: true }, () => {
            api.bindEDUTeacher(params)
                .then((res) => {
                    if (res.ret === 20000) {
                        this.setState({ loading: false, showBindModal: false, isTeacher: false });
                        message.success(res.msg);
                        let isTeacher = actionCreator.saveIsTeacher(false);
                        this.props.dispatch(isTeacher);
                        this.getEduCourseAllInfo();
                    } else {
                        return Promise.reject(res);
                    }
                })
                .catch((err) => {
                    // message.error(err.msg);
                    this.setState({ loading: false, errorMsg: err.msg });
                })
        })
    }
    render () {
        const { campusSelectValue, mentorSelectValue, campusList, mentorList } = this.state;

        return (
            <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                {this.props.isTeacher ? <div className={Style.bindWrap}>
                    <div className={Style.bindContent}>
                        <span className={Style.btn}></span>
                        <div className={Style.text}>请先绑定Cypress帐号</div>
                        <Button type="primary" className={Style.bind} onClick={() => { this.setState({ showBindModal: true }); }}>前往绑定</Button>
                    </div>
                </div> : <div className={Style.box}>
                        <div className={Style.left}>
                            <div className={Style.leftTopSelectBox}>
                                <Select
                                    showSearch
                                    optionFilterProp="title"
                                    style={{ width: 259 }}
                                    height={44}
                                    allowClear
                                    placeholder="请选择校区"
                                    className={Style.schoolSelect}
                                    onSelect={(v, o) => this.getMentors(v, o)}
                                    value={campusSelectValue}
                                    onClear={() => {
                                        this.setState({
                                            campusSelectValue: null,
                                            mentorList: [],
                                            mentorSelectValue: null,
                                        });
                                    }}
                                >
                                    {campusList.map((v, i) => (
                                        <Option
                                            key={v.id}
                                            value={v.id}
                                            campusname={v.campusName}
                                            title={v.campusName}
                                        >
                                            <Tooltip placement='top' title={v.campusName} mouseEnterDelay='0.5'>
                                                {v.campusName}
                                            </Tooltip>
                                        </Option>
                                    ))}
                                </Select>
                                <br />
                                <Select
                                    showSearch
                                    optionFilterProp="mentorname"
                                    style={{ width: 259, marginTop: 10 }}
                                    height={44}
                                    allowClear
                                    placeholder="请选择导师"
                                    className={Style.schoolSelect}
                                    onSelect={(v, o) => this.getEduCourseAllInfo(v, o)}
                                    value={mentorSelectValue}
                                    onClear={() => {
                                        this.setState({
                                            mentorSelectValue: null,
                                        });
                                    }}
                                >
                                    {mentorList.map((v, i) => (
                                        <Option
                                            key={v.mentorId}
                                            value={v.mentorId}
                                            campusid={v.campusId}
                                            mentorname={v.mentorName}
                                            title={v.mentorName}
                                        >
                                            <Tooltip placement='top' title={v.mentorName} mouseEnterDelay='0.5'>
                                                {v.mentorName}
                                            </Tooltip>
                                        </Option>
                                    ))}
                                </Select>
                            </div>
                            {
                                this.state.courseAllInfo.length > 0 ? <p className={Style.title}>课程列表</p> : ''
                            }
                            {this.state.courseAllInfo.map((item, index) => {
                                return (
                                    <div className={Style.leftItem} key={index} onClick={() => { this.chooseCourse(item); }} style={item.checked ? { 'borderLeft': '3px solid #ff8800', 'color': '#ff8800', 'paddingLeft': '7px', 'background': 'linear-gradient(to right, #fef7ea, #fffdfb)' } : {}}>{item.courseName}</div>
                                )
                            })}
                        </div>
                        <Divider type='vertical' className={Style.divider} />
                        {
                            this.state.courseAllInfo.length === 0 ? <Empty description={<div style={{ color: '#949499', fontSize: 16 }}>请选择校区与导师</div>} style={{ width: '100%', marginTop: '10vh' }} /> : ''
                        }
                        <div className={Style.right}>
                            <h2>{this.state.title}</h2>
                            <div className={Style.lessonWrap}>
                                {this.state.courseId !== '' ? this.state.lessonList.map((item, index) => {
                                    return (
                                        <div className={Style.lesson} key={index} onClick={() => { this.chooseLesson(item) }}>
                                            <div className={Style.hoverFa}>
                                                {!(item.courseCover && item.courseCover.tag1 && item.courseCover.tag2 && item.courseCover.tag1 !== '' && item.courseCover.tag2 !== '') ? <div className={Style.image} onClick={(e) => { this.addKeyword(item, e) }}>
                                                    <div className={Style.text}><PlusCircleFilled className={Style.textIcon} />&nbsp;添加封面</div>
                                                </div> : <div className={`${Style.image} ${Style.bgimage}`} onClick={(e) => { this.addKeyword(item, e) }}>
                                                        <div className={Style.tag1}>{item.courseCover.tag1}</div>
                                                        <div className={Style.tag2}>{item.courseCover.tag2}</div>
                                                    </div>}
                                                {/* hover */}
                                                {(item.courseCover && item.courseCover.tag1 && item.courseCover.tag2 && item.courseCover.tag1 !== '' && item.courseCover.tag2 !== '') ? <div className={Style.addKeywordHidden} onClick={(e) => { this.addKeyword(item, e) }}><PlusCircleFilled className={Style.icon} />添加封面</div> : ''}
                                            </div>
                                            {(item.courseCover && item.courseCover.tag1 && item.courseCover.tag2 && item.courseCover.tag1 !== '' && item.courseCover.tag2 !== '') ? <div className={Style.line}></div> : ''}

                                            <div className={Style.hover}>
                                                <div className={Style.title}>
                                                    <span className={Style.identification}>{item.campusName}</span>
                                                    <span>{item.assignName}</span>
                                                </div>
                                                <div className={Style.name}>导师：{item.mentorName}</div>
                                            </div>
                                        </div>
                                    )
                                }) : ''}
                            </div>
                        </div>
                    </div>}
                {this.state.showModal ? <Modal close={this.close} title='添加封面' actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.submitKeyword}>确定</Button>]}>
                    <div className={Style.modalTitle}>关键词<span className={Style.red}>*</span></div>
                    <div className={Style.tips}>关键词将展示在课程封面上，请保证精炼。</div>
                    <TextArea showCount={true} maxLength={20} rows={2} placeholder='请输入关键词' value={this.state.keyword} onChange={this.getKeyword} />
                    <div className={Style.modalTitle}>数字</div>
                    <div className={Style.tips}>关键词与其他课程相同时，可通过数字区分。</div>
                    <InputNumber className={Style.input} maxLength={2} placeholder='请输入数字' value={this.state.lessonNum} onChange={this.getLessonNum} />
                </Modal> : ''}
                {this.state.showBindModal ? <Modal title='绑定Cypress帐号' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={this.state.accountNumber === '' || this.state.password === ''} onClick={() => { this.bind({ account: this.state.accountNumber, pwd: this.state.password }); }}>确定</Button>]}>
                    <Input placeholder='请输入账号' className={Style.bindInput} onChange={this.getAccountNumber} style={this.state.errorMsg ? { border: '1px solid #DE350B' } : {}}></Input>
                    <Input placeholder='请输入密码' type='password' className={Style.bindInput} onChange={this.getPassword} style={this.state.errorMsg ? { border: '1px solid #DE350B' } : {}}></Input>
                    {this.state.errorMsg ? <div className={Style.errorMsg}>{this.state.errorMsg}</div> : <div className={Style.block}></div>}
                </Modal> : ''}
            </Spin>
        )
    }
}

export default connect(store => store)(EDUCourseMaterials);