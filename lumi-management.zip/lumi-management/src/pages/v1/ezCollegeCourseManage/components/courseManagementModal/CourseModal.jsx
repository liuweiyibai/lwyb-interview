import React from "react";
import { connect } from "react-redux";
import api from "../../../../../utils/api.js";
import { Modal, Select, Tooltip, message, AutoComplete, Input, Spin } from "antd";
import Style from "./CourseModal.module.less";

const { Option } = Select;

class CourseManagementModal extends React.Component {
  state = {
    isModalVisible: false,
    modalType: 'add', // 弹框的状态类型 - add / copy / edit
    modalTitle: "创建 Course Assignment",
    selectCampusValue: null,
    selectCourseNameValue: '',
    selectCourseCodeValue: '',
    assignTypeValue: null,
    mentorValue: null,
    yearValue: null,
    termValue: null,
    gradeValue: null,
    majorValue: null,
    campusList: [],
    codeList: [],
    nameList: [],
    yearList: [],
    assignTypeList: [],
    termList: [],
    gradeList: [],
    majorList: [],
    mentorList: [],
    professorValue: null,
    schoolEnrollValue: null,
    loading: false,
    caId: null, // 修改CA的时候需要的参数
  };

  componentDidMount() {

  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    // console.log(nextProps);
    // 如果首次打开Modal的时候需要获取一下下拉框的数据
    if (this.state.isModalVisible === false && nextProps.isModalVisible === true) {
        this.getCampusOptions();
        this.getSchoolTeachers();
    }
    // 如果是 edit & copy 状态，获取预填写数据
    if (nextProps.modalType !== 'add') {
      const _prop = nextProps.defaultModalSelectedValue;
      // console.log(_prop);
      this.setState({
        selectCourseNameValue: _prop.courseName,
        selectCourseCodeValue: _prop.courseCode,
        assignTypeValue: _prop.assignType,
        mentorValue: _prop.mentorId,
        termValue: _prop.term,
        gradeValue: _prop.grade,
        majorValue: _prop.major,
        professorValue: _prop.professor,
        schoolEnrollValue: _prop.enrollCount,
        caId: _prop.id,
        yearValue: _prop.year,
      })
    }
    // 如果是复制的话， 在course name 之前加上Copy-
    // if (nextProps.modalType === 'copy') {
    //   this.setState({
    //     selectCourseNameValue: 'Copy-' + nextProps.defaultModalSelectedValue.courseName,
    //   })
    // }
    if (nextProps.modalType === 'add') { // 如果是 新增的话 （ADD 按钮）清空之前选的数据
      this.setState({
        selectCourseNameValue: '',
        selectCourseCodeValue: '',
        assignTypeValue: null,
        mentorValue: null,
        termValue: null,
        gradeValue: null,
        majorValue: null,
        professorValue: null,
        schoolEnrollValue: null,
        caId: null,
        yearValue: nextProps.defaultYear || new Date().getFullYear(),
      })
    }
    this.setState({
      campusList: nextProps.campusList,
      yearList: nextProps.yearList,
      nameList: this.getCourseNameOption(nextProps.courseNameList, "name"),
      codeList: this.getCourseNameOption(nextProps.courseNameList, "code"),
      isModalVisible: nextProps.isModalVisible || false,
      selectCampusValue: nextProps.defaultCampus,
      modalType: nextProps.modalType,
      modalTitle: this.handleModalTitle(nextProps.modalType),
    });
    // console.log(nextProps.defaultYear);
  }

  handleModalTitle = (type) => {
    if (type === 'edit') {
      return "编辑 Course Assignment";
    }
    return "创建 Course Assignment";
  }

  handleOk = () => {
    let result = {
      assignType: this.state.assignTypeValue, // number
      campusId: this.state.selectCampusValue, // number
      courseCode: this.state.selectCourseCodeValue || null, // string
      courseName: this.state.selectCourseNameValue || null, // string
      enrollCount: this.state.schoolEnrollValue || null,
      grade: this.state.gradeValue,
      major: this.state.majorValue,
      mentorId: this.state.mentorValue,
      professor: this.state.professorValue || null, // string
      term: this.state.termValue,
      year: this.state.yearValue,
    }
    if (this.state.modalType === 'edit') {
      this.updateCourse(result);
    } else {
      this.addCourse(result);
    }
  };

  handleCancel = () => {
    // this.setState({ isModalVisible: false });
    if (this.state.loading) return;
    this.props.closeModal();
    this.clearModalData();
  };

  canOKBtnClick = () => {
    let result = {
      assignType: this.state.assignTypeValue, // number
      campusId: this.state.selectCampusValue, // number
      courseCode: this.state.selectCourseCodeValue || null, // string
      courseName: this.state.selectCourseNameValue || null, // string
      enrollCount: this.state.schoolEnrollValue || null,
      grade: this.state.gradeValue,
      major: this.state.majorValue,
      mentorId: this.state.mentorValue,
      professor: this.state.professorValue || null, // string
      term: this.state.termValue,
      year: this.state.yearValue,
    }
    if (
      result.assignType === null ||
      result.campusId === null ||
      result.courseCode === null ||
      result.courseName === null ||
      result.grade === null ||
      result.major === null ||
      result.mentorId === null ||
      result.term === null ||
      result.year === null
    ) {
      return false;
    }
    return true;
  }

  clearModalData = () => {
    this.setState({
      selectCampusValue: null,
      selectCourseNameValue: '',
      selectCourseCodeValue: '',
      assignTypeValue: null,
      mentorValue: null,
      yearValue: null,
      termValue: null,
      gradeValue: null,
      majorValue: null,
      professorValue: null,
      schoolEnrollValue: null,
      loading: false,
      codeList: [],
      nameList: [],
      assignTypeList: [],
      termList: [],
      gradeList: [],
      majorList: [],
      mentorList: [],
    })
  }

  // 获取学校下面 - 下拉框课程列表 - 名字
  getCourseNameList = () => {
    return new Promise((resolve) => {
      this.setState({ loading: true }, async () => {
        await api
          .getEZA_CA_CourseNameList(this.state.selectCampusValue)
          .then((res) => {
            // console.log(res);
            resolve();
            if (res.code === 0) {
              this.setState({
                loading: false,
                nameList:
                  this.state.selectCampusValue === null
                    ? []
                    : this.getCourseNameOption(res.data, "name"),
                codeList: this.getCourseNameOption(res.data, "code"),
              });
            } else {
              return Promise.reject(res);
            }
          })
          .catch((err) => {
            message.error(err.message);
            this.setState({ loading: false });
          });
      });
    });
  };

  // 从数据总取出课程名称 & code
  getCourseNameOption = (data, type) => {
    const arr = [];
    let _temp = [];
    // 先去重
    if (type === "name") {
      data.forEach((v) => {
        _temp.push(v.name);
      });
    } else {
      data.forEach((v) => {
        _temp.push(v.code);
      });
    }
    _temp = Array.from(new Set(_temp));

    // 构建数据
    _temp.forEach((v) => {
      arr.push({ value: v });
    });
    return arr;
  };

  // 获取学校下的配置
  getCampusOptions = () => {
    this.setState({ loading: true }, () => {
      api
        .getEZA_CampusOptions(this.state.selectCampusValue)
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            this.setState({ 
              loading: false, 
              assignTypeList: res.data.assignType || [], 
              termList: res.data.term || [], 
              gradeList: res.data.grade || [], 
              majorList: res.data.major || [], 
            });
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
    });
  };

  // 获取当前学校下的老师
  getSchoolTeachers = () => {
    api
        .getEZA_SchoolTeachers(this.state.selectCampusValue)
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            this.setState({ 
              mentorList: res.data || [] 
            });
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
  }

  // 添加课程分配
  addCourse = (params) => {
    this.setState({loading: true}, () => {
      api
        .createEZA_CA_Course(params)
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            this.setState({ loading: false}, ()=>{ message.success('创建成功'); this.handleCancel();this.props.refreshPage();});
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
    })
  }

  // 修改课程分配
  updateCourse = (params) => {
    this.setState({loading: true}, () => {
      api
        .updateEZA_CA_Course(this.state.caId, params)
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            this.setState({ loading: false}, ()=>{ message.success('更新成功'); this.handleCancel();this.props.refreshPage();});
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
    })
  }

  // 选学校
  clickCampusItem = (value, option) => {
    this.setState(
      { selectCampusValue: value, 
        selectCourseNameValue: '', 
        selectCourseCodeValue: '',
        mentorValue: null,
        assignTypeValue: null,
        termValue: null,
        gradeValue: null,
        majorValue: null, 
      },
      async () => {
        await this.getCourseNameList(); // 课程名字列表数据比较多
        this.getCampusOptions();
        this.getSchoolTeachers();
      }
    );
  };

  // 选课程
  clickCourseNameItem = (value) => {
    // console.log(value);
    const reg = /[^A-Za-z0-9\s]/g;
    let _val = value;
    if (reg.test(_val)) {
      _val = _val.replace(reg, '');
    }
    this.setState({ selectCourseNameValue: _val || '' });
    // console.log(_val);
  };

  // 选Course Code
  clickCourseCodeItem = (value) => {
    // console.log(value);
    const reg = /[^A-Za-z0-9\s]/g;
    let _val = value;
    if (reg.test(_val)) {
      _val = _val.replace(reg, '');
    }
    this.setState({ selectCourseCodeValue: _val || '' });
    // console.log(this.state.selectCourseCodeValue);
  };
  
  // 输入框professor
  getProfessorValue = (e) => {
    let value = e.target.value;
    const reg = /[^A-Za-z\s]/g;
    if (reg.test(value)) {
      value = value.replace(reg, '');
    }
    this.setState({professorValue: value});
  }

  // 输入框 School Enroll
  getSchoolEnroll = (e) => {
    let value = e.target.value;
    const reg = /[^0-9]/g;
    if (reg.test(value)) {
      value = value.replace(reg, '');
    }
    this.setState({schoolEnrollValue: +value || ''});
  }

  render() {
    const {
      nameList,
      codeList,
      isModalVisible,
      modalTitle,
      selectCampusValue,
      campusList,
      yearList,
      assignTypeList,
      termList,
      gradeList,
      majorList,
      mentorList,
      professorValue,
      schoolEnrollValue,
      selectCourseNameValue,
      selectCourseCodeValue,
      loading,
      assignTypeValue,
      termValue,
      gradeValue,
      majorValue,
      mentorValue,
      yearValue,
    } = this.state;
    const { handleOk, handleCancel } = this;

    return (
      <div className={Style.EZA_CourseManagementModalWrap}>
        <Modal
          title={modalTitle}
          visible={isModalVisible}
          onOk={handleOk}
          onCancel={handleCancel}
          okButtonProps={{disabled: !this.canOKBtnClick()}}
          className={Style.EZA_CourseManagementModal}
          width={680}
          cancelButtonProps={{ type: "link", style: { color: "#949499" } }}
        >
          <Spin spinning={loading}  size='large'>
            {/* 选择校园 & Course Code */}
            <div className={Style.row}>
              {/* 校园下拉框 */}
              <div>
                <div className={Style.selectBoxTitle}>Campus</div>
                <Select
                  showSearch
                  optionFilterProp="title"
                  allowClear
                  placeholder="请选择Campus"
                  style={{ width: 304 }}
                  className={Style.selectBox}
                  onSelect={(v, o) => this.clickCampusItem(v, o)}
                  value={selectCampusValue}
                  onClear={() => {
                    this.setState({
                      selectCampusValue: null,
                      selectCourseNameValue: '',
                      selectCourseCodeValue: '',
                      mentorValue: null,
                      assignTypeValue: null,
                      termValue: null,
                      gradeValue: null,
                      majorValue: null,
                      codeList: [],
                      nameList: [],
                      assignTypeList: [],
                      termList: [],
                      gradeList: [],
                      majorList: [],
                      mentorList: [],
                    });
                  }}
                >
                  {campusList.map((campus) => {
                    return (
                      <Option
                        key={campus.id}
                        value={campus.id}
                        campusname={campus.campusName}
                        title={campus.campusName}
                      >
                        <Tooltip
                          placement="top"
                          title={campus.campusName}
                          mouseEnterDelay="0.5"
                        >
                          {campus.campusName}
                        </Tooltip>
                      </Option>
                    );
                  })}
                </Select>
              </div>
              {/* Course Code */}
              <div>
                <div className={Style.selectBoxTitle}>Course Code</div>
                <AutoComplete
                  options={codeList}
                  allowClear
                  style={{
                    width: 304,
                  }}
                  filterOption="title"
                  placeholder="请输入Course Code"
                  value={selectCourseCodeValue}
                  onChange={this.clickCourseCodeItem}
                />
              </div>
            </div>
            {/* 选择Course Name */}
            <div className={Style.row}>
              <div>
                <div className={Style.selectBoxTitle}>Course Name</div>
                <AutoComplete
                  options={nameList}
                  allowClear
                  style={{
                    width: 632,
                  }}
                  filterOption="title"
                  placeholder="请输入Course Name"
                  value={selectCourseNameValue}
                  onChange={this.clickCourseNameItem}
                />
              </div>
            </div>
            {/* 选择 Year & AssignType */}
            <div className={Style.row}>
              <div>
                <div>
                  <div className={Style.selectBoxTitle}>Year</div>
                </div>
                <Select
                  style={{ width: 195 }}
                  placeholder='请选择Year'
                  value={yearValue}
                  onSelect={(v)=>{this.setState({yearValue: +v})}}
                >
                  {yearList.map((v) => (
                    <Option key={v.id} value={+v.id}>
                      {v.id}
                    </Option>
                  ))}
                </Select>
              </div>
              <div>
                <div>
                  <div className={Style.selectBoxTitle}>Assignment Type</div>
                </div>
                <Select
                  style={{ width: 413 }}
                  optionFilterProp='title'
                  placeholder='请选择Assignment Type'
                  value={assignTypeValue}
                  onChange={v=>{this.setState({assignTypeValue: v})}}
                >
                  {assignTypeList.map((v) => (
                    <Option key={v.id} value={v.id}>
                      {v.name}
                    </Option>
                  ))}
                </Select>
              </div>
            </div>
            {/* 选择 term & grade & major */}
            <div className={Style.row}>
              <div>
                <div>
                  <div className={Style.selectBoxTitle}>Term</div>
                </div>
                <Select
                  style={{ width: 195 }}
                  placeholder='请选择Term'
                  onSelect={(v)=>{this.setState({termValue: v})}}
                  value={termValue}
                >
                  {termList.map((v) => (
                    <Option key={v.id} value={v.id}>
                      {v.name}
                    </Option>
                  ))}
                </Select>
              </div>
              <div>
                <div>
                  <div className={Style.selectBoxTitle}>Grade</div>
                </div>
                <Select
                  style={{ width: 195 }}
                  placeholder='请选择Grade'
                  onSelect={(v)=>{this.setState({gradeValue: v})}}
                  value={gradeValue}
                >
                  {gradeList.map((v) => (
                    <Option key={v.id} value={v.id}>
                      {v.name}
                    </Option>
                  ))}
                </Select>
              </div>
              <div>
                <div>
                  <div className={Style.selectBoxTitle}>Major</div>
                </div>
                <Select
                  style={{ width: 195 }}
                  placeholder='请选择Major'
                  onSelect={(v)=>{this.setState({majorValue: v})}}
                  value={majorValue}
                >
                  {majorList.map((v) => (
                    <Option key={v.id} value={v.id}>
                      {v.name}
                    </Option>
                  ))}
                </Select>
              </div>
            </div>
            {/* 选择mentor & professor & school */}
            <div className={Style.row}>
              <div>
                <div>
                  <div className={Style.selectBoxTitle}>Mentor</div>
                </div>
                <Select
                  style={{ width: 195 }}
                  placeholder='请选择Mentor'
                  optionFilterProp='title'
                  showSearch
                  value={mentorValue}
                  onChange={v=>{this.setState({mentorValue: v})}}
                >
                  {mentorList.map((v) => (
                    <Option key={v.mentorId} value={v.mentorId} title={`${v.mentorId} - ${v.mentorName}`}>
                      {`${v.mentorId} - ${v.mentorName}`}
                    </Option>
                  ))}
                </Select>
              </div>
              <div>
                <div><div className={Style.selectBoxTitle}>Professor</div></div>
                <Input style={{width: 195}} placeholder="请输入Professor"  allowClear onChange={this.getProfessorValue} value={professorValue}/>
              </div>
              <div>
                <div><div className={Style.selectBoxTitle}>School Enroll</div></div>
                <Input style={{width: 195}} placeholder="请输入School Enroll"  allowClear onChange={this.getSchoolEnroll} value={schoolEnrollValue}/>
              </div>
            </div>
          </Spin>
        </Modal>
      </div>
    );
  }
}

export default connect((store) => store)(CourseManagementModal);
