import React from "react";
import { connect } from "react-redux";
import api from "../../../../../utils/api.js";
import { Modal, Select, Tooltip, message, Input, Spin, Cascader, DatePicker } from "antd";
import Style from "./CASModal.module.less";
import momenttz from 'moment-timezone';

const { Option } = Select;

class CourseManagementModal extends React.Component {
  state = {
    isModalVisible: false,
    modalType: 'add', // 弹框的状态类型 - add / copy / edit
    modalTitle: "创建 Course Assignment Section",
    mentorList: [],
    sectionList: [],
    campusId: null,
    cascadeSelectValue: [], // 是长度为2的数组 [mentorId, caid]
    selectSectionValue: null,
    casId: null,
    dateString: '',
    startTime: null,
    duration: '',
    loading: false,
    isDisableCascade: false, // 编辑的时候不允许修改分配
    copyCanClick: 0, // 打开复制弹框的时候需要先编辑一下才能点击确定 0 不能 1 能
    id: null, // 当前编辑的item
  };

  componentDidMount() {

  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    // console.log(nextProps);
    // 如果是 edit & copy 状态，获取预填写数据
    if (nextProps.modalType !== 'add') {
      const _prop = nextProps.defaultModalSelectedValue;
      this.setState({
        duration: _prop.duration,
        selectSectionValue: _prop.sectionId,
        // startTime: moment(_prop.startTime),
        startTime: momenttz.tz(_prop.startTime, "America/New_York"),
        // dateString: moment(_prop.startTime).format('YYYY-MM-DD hh:mm:ss'),
        dateString: momenttz.tz(_prop.startTime, "America/New_York").format('YYYY-MM-DD hh:mm:ss'),
        id: _prop.id,
        cascadeSelectValue: [_prop.mentorId, _prop.caId],
        casId: _prop.casId,
      });
    }
    if (nextProps.modalType === 'add') { // 如果是 新增的话 （ADD 按钮）清空之前选的数据
      this.setState({
        cascadeSelectValue: [],
        selectSectionValue: null,
        dateString: '',
        startTime: null,
        duration: '',
      })
    }
    this.setState({
      isModalVisible: nextProps.isModalVisible || false,
      modalType: nextProps.modalType,
      modalTitle: this.handleModalTitle(nextProps.modalType),
      sectionList: nextProps.sectionList,
      campusId: nextProps.campusId,
      mentorList: this.getCascadeMentorOption(nextProps.mentorList), // 从主页面上把教师列表拿过来
    });
    // 如果是从表格过来的需要初始化级联选择框的数据
    if (nextProps.modalType !== 'add') {
      this.setState({}, () => {
        for (let i = 0; i < this.state.mentorList.length; i++) {
          if (this.state.mentorList[i].value === this.state.cascadeSelectValue[0]) {
            this.getCascade_CA_List(this.state.mentorList[i], this.state.campusId, this.state.cascadeSelectValue[0]);
          }
        }
      })
    }
    if (nextProps.modalType === 'edit') {
      this.setState({isDisableCascade: true});
    } else {
      this.setState({isDisableCascade: false});
    }
  }

  // 生成Assignment 级联选择框 的导师数据选项
  getCascadeMentorOption = (data) => {
    let _data = [];
    data.forEach(v => {
      _data.push({
        value: v.mentorId,
        label: v.mentorName,
        isLeaf: false,
      })
    });
    return _data;
  }

  handleModalTitle = (type) => {
    if (type === 'edit') {
      return "编辑 Course Assignment Section";
    }
    return "创建 Course Assignment Section";
  }

  handleOk = () => {
    let result = {
      caId: this.state.cascadeSelectValue[1],
      campusId: this.state.campusId,
      casId: this.state.casId,
      duration: this.state.duration,
      sectionId: this.state.selectSectionValue,
      startTime: this.state.dateString,
    }
    // console.log(result);
    if (this.state.modalType === 'edit') {
      this.updateCourse(result);
    } else {
      this.addCourse(result);
    }
  };

  handleCancel = () => {
    // this.setState({ isModalVisible: false });
    if (this.state.loading) return;
    this.props.closeModal();
    this.clearModalData();
  };

  canOKBtnClick = () => {
    if (this.state.modalType === 'copy' && this.state.copyCanClick === 0) return false; // 如果是复制完了没有编辑过，直接返回false
    let result = {
      caId: this.state.cascadeSelectValue[1],
      campusId: this.state.campusId,
      casId: this.state.casId,
      duration: this.state.duration,
      sectionId: this.state.selectSectionValue,
      startTime: this.state.dateString,
    }
    // console.log(result);
    if (
        result.caId === undefined ||
        result.campusId === null ||
        result.duration === '' ||
        result.sectionId === null ||
        result.startTime === ''
    ) {
      return false;
    }
    return true;
  }

  clearModalData = () => {
    this.setState({
      sectionList: [],
      campusId: null,
      cascadeSelectValue: [],
      selectSectionValue: null,
      casId: null,
      dateString: '',
      duration: '',
      copyCanClick: 0,
    })
  }

  // 生成 Assignment children 数组数据
  assignmentCascadeLoadData = (selectedOption) => {
    // console.log(selectedOption);
    const targetOption = selectedOption[selectedOption.length - 1];
    targetOption.loading = true;
    this.getCascade_CA_List(targetOption, this.state.campusId, targetOption.value);
  }

  getAssignmentCascadeChildrenArr = (data) => {
    let _data = [];
    data.forEach(v => {
      _data.push({
        label: `${v.courseCode} (${v.year}) ${v.termDisplay}-${v.assignTypeDisplay}`,
        value: v.id, // caid
      })
    });
    return _data;
  }

  // 获取校区下 老师下 分配列表 （弹框中的级联数据）
  getCascade_CA_List = (targetOption, campusId, mentorId) => {
    this.setState({loading: true}, () => {
      api.getEZA_CA_CourseList({campusId, mentorId, page: 1, pageSize: 1000}).then(res => {
        // console.log(res);
        if (res.code === 0) {
          targetOption.loading = false;
          targetOption.children = this.getAssignmentCascadeChildrenArr(res.data);
          this.setState({loading: false});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({loading: false});
      })
    })
  }

  // 添加CAS
  addCourse = (params) => {
    this.setState({loading: true}, () => {
      api
          .createEZA_CAS_Course(params)
          .then((res) => {
            // console.log(res);
            if (res.code === 0) {
              this.setState({loading: false}, () => {
                message.success('创建成功');
                this.handleCancel();
                this.props.refreshPage();
              });
            } else {
              return Promise.reject(res);
            }
          })
          .catch((err) => {
            message.error(err.message);
            this.setState({loading: false});
          });
    })
  }

  // 修改CAS
  updateCourse = (params) => {
    this.setState({loading: true}, () => {
      api
          .updateEZA_CAS_Course(this.state.id, params)
          .then((res) => {
            // console.log(res);
            if (res.code === 0) {
              this.setState({loading: false}, () => {
                message.success('更新成功');
                this.handleCancel();
                this.props.refreshPage();
              });
            } else {
              return Promise.reject(res);
            }
          })
          .catch((err) => {
            message.error(err.message);
            this.setState({loading: false});
          });
    })
  }

  // 判断复制完了有没有编辑过的状态
  changeCopyCanClickStatus = () => {
    if (this.state.modalType === 'copy' && this.state.copyCanClick === 0) {
      this.setState({
        copyCanClick: 1,
      })
    }
  }

  // 选级联选择框
  changeCascadeSelect = (val, selectedOption) => {
    // console.log(val, selectedOption);
    this.setState({cascadeSelectValue: val});
    this.changeCopyCanClickStatus();
  }

  // 选section
  clickSectionItem = (value, option) => {
    this.setState(
        {
          selectSectionValue: value,
        }
    );
    this.changeCopyCanClickStatus();
  };

  // 开始时间
  changeBeginTime = (momentTime, dateString) => {
    // console.log(dateString);
    this.setState({
      startTime: momentTime,
      dateString,
    })
    this.changeCopyCanClickStatus();
  }

  // 输入时长
  changeDurationTime = (e) => {
    this.changeCopyCanClickStatus();
    let value = e.target.value;
    const reg = /[^0-9]/g;
    if (reg.test(value)) { // 去除非数字
      value = value.replace(reg, '');
    }
    if (value !== '') { // 不为空的时候对数字进行处理
      if (value.length <= 3) { // 长度 < 3 的时候处理
        value = Number(value);
        if (value > 999) {
          value = 999;
        } else if (value < 1) {
          value = 1;
        }
      } else { // > 3的时候直接返回
        return;
      }
    }

    this.setState({duration: +value || ''});
  }

  render() {
    const {
      isModalVisible,
      modalTitle,
      loading,
      mentorList,
      sectionList,
      cascadeSelectValue,
      selectSectionValue,
      duration,
    } = this.state;
    const {handleOk, handleCancel} = this;

    return (
        <div className={Style.EZA_CourseManagementModalWrap}>
          <Modal
              title={modalTitle}
              visible={isModalVisible}
              onOk={handleOk}
              onCancel={handleCancel}
              okButtonProps={{disabled: !this.canOKBtnClick()}}
              className={Style.EZA_CourseManagementModal}
              width={680}
              cancelButtonProps={{type: "link", style: {color: "#949499"}}}
          >
            <Spin spinning={loading} size='large'>
              <div className={Style.row}>
                <div>
                  <div className={Style.selectBoxTitle}>Mentor - Course Assignment</div>
                  <Cascader options={mentorList} style={{width: 632}} disabled={this.state.isDisableCascade} loadData={this.assignmentCascadeLoadData} onChange={this.changeCascadeSelect} changeOnSelect value={cascadeSelectValue}/>
                </div>
              </div>
              {/* Section 选择下拉框 */}
              <div className={Style.row}>
                <div>
                  <div className={Style.selectBoxTitle}>Section Name</div>
                  <Select
                      showSearch
                      optionFilterProp="title"
                      allowClear
                      placeholder="请选择 Section Name"
                      style={{width: 632}}
                      className={Style.selectBox}
                      onSelect={(v, o) => this.clickSectionItem(v, o)}
                      value={selectSectionValue}
                      onClear={() => {
                        this.setState({
                          selectSectionValue: null
                        });
                      }}
                  >
                    {sectionList.map((section) => {
                      return (
                          <Option
                              key={section.id}
                              value={section.id}
                              campusname={section.name}
                              title={section.name}
                          >
                            <Tooltip
                                placement="top"
                                title={section.name}
                                mouseEnterDelay="0.5"
                            >
                              {section.name}
                            </Tooltip>
                          </Option>
                      );
                    })}
                  </Select>
                </div>
              </div>
              <div className={Style.row}>
                <div>
                  <div className={Style.selectBoxTitle}>开始时间（美东时间）</div>
                  <DatePicker showTime onChange={this.changeBeginTime} style={{width: 304}} placeholder="请选择开始时间"
                              value={this.state.startTime}/>
                </div>
                <div>
                  <div className={Style.selectBoxTitle}>课程时长</div>
                  <Input suffix="mins" style={{width: 304}} onChange={this.changeDurationTime} value={duration}
                         placeholder="请输入时长"/>
                </div>
              </div>
            </Spin>
          </Modal>
        </div>
    );
  }
}

export default connect((store) => store)(CourseManagementModal);
