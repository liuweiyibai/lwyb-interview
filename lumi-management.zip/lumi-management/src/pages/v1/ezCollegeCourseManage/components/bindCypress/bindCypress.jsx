import React, {useState} from 'react';
import { connect } from 'react-redux';
import {Button, Input, Modal as ModalAnt, Spin, message} from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import Style from './bindCypress.module.less';
import api from "../../../../../utils/api";
import actionCreator from "../../../../../store/actionCeator";

const BindCypress = (props) => {

  let [loading, setLoading] = useState(false);
  let [showBindModal, setShowBindModal] = useState(false);
  let [accountNumber, setAccountNumber] = useState('');
  let [password, setPassword] = useState('');
  let [errorMsg, setErrorMsg] = useState('');

  const closeModal = ()=>{
    if (loading) return;
    setShowBindModal(false);
    setErrorMsg('');
  }

  const bind = (params) => {
    setLoading(true);
    api.bindEDUTeacher(params)
        .then((res)=>{
          if(res.ret === 20000){
            message.success(res.msg);
            setLoading(false);
            setShowBindModal(false);
            props.refresh && props.refresh();
            let isTeacher = actionCreator.saveIsTeacher(false);
            props.dispatch(isTeacher);
          }else{
            return Promise.reject(res);
          }
        })
        .catch((err)=>{
          setLoading(false);
          setErrorMsg(err.msg);
        })
  }

  return (

        <div className={Style.BindCypressWrap}>
          <div className={Style.bindWrap}>
            <div className={Style.bindContent}>
              <span className={Style.btn}></span>
              <div className={Style.text}>请先绑定Cypress帐号</div>
              <Button type="primary" className={Style.bind} onClick={()=>{setShowBindModal(true);}}>前往绑定</Button>
            </div>
          </div>

          <ModalAnt title="绑定Cypress帐号" visible={showBindModal} onCancel={closeModal} className={Style['EZA-BindCypressModal']}
                    cancelButtonProps={{className: "modalCancelBtn", type: 'link'}}
                    okButtonProps={{disabled: accountNumber === '' || password === ''}}
                    onOk={()=>{
                      if (loading) return;
                      bind({account: accountNumber,pwd: password});
                    }}
          >
            <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
              <Input
                  placeholder='请输入账号'
                  className={`${Style.bindInput}`}
                  onChange={(e)=>{setAccountNumber(e.target.value);}}
                  style={errorMsg ? {border:'1px solid #DE350B'} : {}}
                  allowClear
              />
              <Input
                  placeholder='请输入密码'
                  type='password'
                  className={`${Style.bindInput} ${Style.marginTop}`}
                  onChange={(e)=>{setPassword(e.target.value);}}
                  style={errorMsg ? {border:'1px solid #DE350B'} : {}}
                  allowClear
              />
              {errorMsg ? <div className={Style.errorMsg}>{errorMsg}</div> : <div className={Style.block}></div>}
            </Spin>
          </ModalAnt>
        </div>
  )
}

export default connect(store => store)(BindCypress);