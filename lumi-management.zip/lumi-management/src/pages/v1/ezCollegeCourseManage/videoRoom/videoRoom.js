import React, {useEffect, useRef, useState} from 'react';
import {Spin, message} from 'antd';
import {LoadingOutlined} from '@ant-design/icons';
import api from '../../../../utils/api';
import {Player} from 'bitmovin-player';
import {UIFactory} from 'bitmovin-player-ui';
import 'bitmovin-player/bitmovinplayer-ui.css';
import Style from './videoRoom.module.less';

const VideoRoom = (props) => {
  let [config] = useState({
    key: 'b70c8c06-a86e-42be-911b-fd05299ea1c8',
    playback: {
      autoplay: false,
      muted: false,
    },
    tweaks: {
      max_retries: Infinity,
      retry_delay: 1000,
      max_buffer_level: 120,
      fairplay_ignore_duplicate_init_data_key_errors: true,
      disable_retry_for_response_status: {
        media: [401, 403]
      }
    },
    ui: false,
  });
  let [loading, setLoading] = useState(false);
  let [videoInfo, setVideoInfo] = useState({});
  let [isShowTip, setIsShowTip] = useState(false);
  let bitVideoRef = useRef();
  let player = null;

  useEffect(() => {
    const {type, weekId, optionId, id} = getUrlParams();
    if (+type === 0) {
      getReplayInfo({weekId, optionId});
    } else {
      getVideoInfo(id);
    }
  }, []);

  useEffect(() => {
    player && player.destroy();
    if (videoInfo.videoPlayback) {
      setIsShowTip(false);
      initVideo();
    } else {
      setIsShowTip(true);
    }
  }, [videoInfo]) // eslint-disable-line react-hooks/exhaustive-deps

  const getUrlParams = () => {
    const url = window.location.href;
    const result = {};

    if (!url.includes('?')) return result;

    let _temp = url.split('?')[1];
    if (_temp.includes('&')) {
      _temp.split('&').forEach(item => {
        const key = item.split('=')[0];
        result[key] = item.split('=')[1];
      })
    } else {
      const key = _temp.split('=')[0];
      result[key] = _temp.split('=')[1];
    }

    return result;
  }

  const getReplayInfo = ({weekId, optionId}) => {
    setLoading(true);
    api.getReplayInfo({weekId, optionId}).then(res => {
      if (res.code === 0) {
        setLoading(false);
        setVideoInfo(res.data);
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.msg);
      setLoading(false);
    })
  }

  const getVideoInfo = (id) => {
    setLoading(true);
    api.getMaterialInfo(id).then(res => {
      if (res.code === 0) {
        setLoading(false);
        setVideoInfo(res.data);
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.msg);
      setLoading(false);
    })
  }

  const createSource = (videoSources) => {
    const source = {
      title: ``,
      description: "",
      dash: videoSources["videoPlayback"]["videoMpd"],
      hls: videoSources["videoPlayback"]["videoM3u8"],
      drm: {
        widevine: {
          LA_URL: videoSources["videoPlayback"]["wideVineUrl"].replace('http://', 'https://'),
          licenseRequestRetryDelay: 5000,
          maxLicenseRequestRetries: Infinity
        },
        fairplay: {
          LA_URL: videoSources["videoPlayback"]["fairPlayUrl"].replace('http://', 'https://'),
          certificateURL: videoSources["videoPlayback"]["fairCertificateUrl"],
          prepareContentId: (contentId) => {
            const uri = contentId;
            var uriParts = uri.split('://', 1);
            const protocol = uriParts[0].slice(-3);
            uriParts = uri.split(';', 2);
            contentId = uriParts.length > 1 ? uriParts[1] : '';
            return protocol.toLowerCase() === 'skd' ? contentId : '';
          },
          prepareLicenseAsync: (ckc) => {
            return new Promise((resolve, reject) => {
              const reader = new FileReader();
              reader.addEventListener('loadend', () => {
                const array = new Uint8Array(reader.result);
                resolve(array);
              });
              reader.addEventListener('error', () => {
                reject(reader.error);
              });
              reader.readAsArrayBuffer(ckc);
            });
          },
          prepareMessage: (event, session) => {
            return new Blob([event.message], {type: 'application/octet-binary'});
          },
          headers: {
            'content-type': 'application/octet-stream',
          },
          useUint16InitData: true,
          licenseResponseType: 'blob'
        },
        playready: {
          LA_URL: videoSources["videoPlayback"]["wideVineUrl"].replace('http://', 'https://')
        },
      }
    };
    return source
  }

  const initVideo = () => {
    player = new Player(
        bitVideoRef.current,
        config
    );

    UIFactory.buildDefaultUI(player);
    setTimeout(() => {
      if (videoInfo && videoInfo.videoPlayback) {
        const source = createSource(videoInfo);
        player.load(source).then(x => {
          /*
          * 设置设置菜单为中文: 目前只改了清晰度和倍速， 下拉框没有改成功
          * */
          const qualityLabel = document.body.querySelector('#bmpui-id-130'); // 清晰度
          const speedLabel = document.body.querySelector('#bmpui-id-133'); // 倍速
          qualityLabel && (qualityLabel.innerHTML = '清晰度');
          speedLabel && (speedLabel.innerHTML = '倍 速');
        }, reason => {
          console.log('ErrorwhilecreatingBitmovinPlayerinstance');
        });
      }
    }, 0);
    initKeyDownEvent();
  }

  const initKeyDownEvent = () => {
    document.onkeydown = (event) => {
      let e = event || window.event;
      let currentTime = player.getCurrentTime();
      let totalTime = player.getDuration();

      if (e && e.keyCode === 37) {
        if (currentTime - 1 >= 0) {
          player.seek(currentTime-1);
        } else {
          player.seek(0.2);
        }
      }

      if (e && e.keyCode === 39) {
        if (currentTime + 1 < totalTime-0.2) {
          player.seek(currentTime+1);
        }
      }
    }
  }


  return (
      <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
        <div className={Style['EZA-videoRoomWrap']}>
          <div id="bitmovin-player" ref={bitVideoRef}/>
          {
            isShowTip && (
                <div className={Style.tipBox}>
                  视频上传可能遇到了问题，请重新上传<br/>或联系开发人员处理
                </div>
            )
          }
        </div>
      </Spin>
  )
}

export default VideoRoom;