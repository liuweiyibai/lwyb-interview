import React,{Component, Fragment} from 'react';
import { connect } from 'react-redux';
import { Spin, Input, Table,  Checkbox, Button, Divider, Pagination, Select, message, Tooltip } from 'antd';
import { LoadingOutlined, SearchOutlined } from '@ant-design/icons';
import Style from './courseLive.module.less';
import fun from '../../../../utils/funSum.js';
import api from '../../../../utils/api.js';
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import actionCreator from '../../../../store/actionCeator.js';

const { Option } = Select;
class CourseLive extends Component{
    constructor(){
        super();
        this.state={
            loading:false,
            showBindModal:false,
            courseId:'',
            courseName:'',
            courseTeacher:'',
            courseTeacherId:'',
            accountNumber:'',
            checked:1,
            password:'',
            errorMsg:'',
            teacherList:[],
            dataSource:[],//
            total:0,//
            page:1,//
            pageSize:10,//
        }
    }
    columns = [
        fun.getColumnItem('课程ID','id',88),
        fun.getColumnItem('课程名称','name','topLeft'),
        {
            title: '学科',
            dataIndex:'subjectName',
            width:136,
            align: 'center',
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName ? subjectName : '-'}
                </Tooltip>
            ),
        },
        fun.getColumnTimeItem('开始时间（美东时间）','liveAt'),
        {
            title: '课程时长',
            dataIndex:'liveDuration',
            width:135,
            align: 'center',
            render: liveDuration => (
                <Tooltip placement="top" title={`${liveDuration} min`}>
                    {liveDuration} min
                </Tooltip>
            ),
        },
        fun.getColumnItem('授课老师','teacherName',168),
    ]
    componentDidMount(){
        this.getCourseList({id:null,idisplayLength:this.state.pageSize,idisplayStart:0,name:null,ciStatus:1,subId:null});
        this.getEDUTeacherList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    getCourseList = (params)=>{
        this.setState({loading:true},()=>{
            api.getEduLiveCourseList(params)
            .then((res)=>{
                if(res.ret === 20000){
                    this.setState({ dataSource:res.result.data, total:res.result.total, loading:false });
                }else{
                    if(res.ret === 60001){
                        this.setState({isTeacher:true});
                    }
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    getEDUTeacherList = ()=>{
        this.setState({loading:true},()=>{
            api.getEDUTeacherList()
            .then((res)=>{
                // console.log(res)
                if(res.ret === 20000){
                    this.setState({teacherList:res.result,loading:false});
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    //
    getCourseId = (e)=>{
        this.setState({courseId:e.target.value});
    }
    //
    getCourseName = (e)=>{
        this.setState({courseName:e.target.value});
    }
    //
    getCourseTeacher = (value, option)=>{
        if (value && option) {
            this.setState({ courseTeacher: value, courseTeacherId: option.key });
        } else {
            this.setState({ courseTeacher: null, courseTeacherId: '' });
        }
        this.refs.selectTeacher.blur();
    }
    //是否显示历史课程
    checkChange = (e)=>{
        this.setState({checked:Number(!e.target.checked)});
    }
    search = ()=>{
        this.setState({loading:true},()=>{
            this.getCourseList({id:this.state.courseId,idisplayLength:this.state.pageSize,idisplayStart:0,name:this.state.courseName,ciStatus:this.state.checked,teacherId:this.state.courseTeacherId,subId:null});
        });
    }
    paginationChange = (page,pageSize)=>{
        this.setState({page,pageSize},()=>{
            this.getCourseList({id:this.state.courseId,idisplayLength:this.state.pageSize,idisplayStart:this.state.page-1,name:this.state.courseName,ciStatus:this.state.checked,teacherId:this.state.courseTeacherId,subId:null});
        });
    }
    close = ()=>{
        this.setState({showBindModal:false,errorMsg:''});
    }
    //
    getAccountNumber = (e)=>{
        this.setState({accountNumber:e.target.value});
    }
    //
    getPassword = (e)=>{
        this.setState({password:e.target.value});
    }
    //绑定导师账号
    bind = (params)=>{
        this.setState({loading:true},()=>{
            api.bindEDUTeacher(params)
            .then((res)=>{
                if(res.ret === 20000){
                    message.success(res.msg);
                    let isTeacher = actionCreator.saveIsTeacher(false);
                    this.props.dispatch(isTeacher);
                    this.getCourseList({id:null,idisplayLength:this.state.pageSize,idisplayStart:0,name:null,ciStatus:1,subId:null});
                    this.setState({loading:false,showBindModal:false,isTeacher:false});
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                // message.error(err.msg);
                this.setState({loading:false,errorMsg:err.msg});
            })
        })
    }
    render(){
        return(
            <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                {this.props.isTeacher ? <div className={Style.bindWrap}>
                    <div className={Style.bindContent}>
                        <span className={Style.btn}></span>
                        <div className={Style.text}>请先绑定Cypress帐号</div>
                        <Button type="primary" className={Style.bind} onClick={()=>{this.setState({showBindModal:true});}}>前往绑定</Button>
                    </div>
                </div> : <Fragment>
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <div className={Style.inputWrap}>
                                <span>课程ID：</span>
                                <Input className={Style.input} onChange={this.getCourseId}></Input>
                            </div>
                            <div className={Style.inputWrap}>
                                <span>课程名称：</span>
                                <Input className={Style.input} onChange={this.getCourseName}></Input>
                            </div>
                            {/* <div className={Style.inputWrap}>
                                <span>课程学科：</span>
                                <Select className={Style.input}></Select>
                            </div> */}
                            <div className={Style.inputWrap}>
                                <span>课程老师：</span>
                                <Select className={Style.input} ref='selectTeacher' onChange={this.getCourseTeacher} allowClear>
                                    {this.state.teacherList.map((item)=>{
                                        return <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                    })}
                                </Select>
                            </div>
                            <Checkbox className={Style.checkBox} onChange={this.checkChange}>显示历史课程</Checkbox>
                        </div>
                        <Button type="primary" icon={<SearchOutlined />} onClick={this.search} >查询</Button>
                    </div>
                    <Divider />
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        // bordered
                        pagination={false}
                    ></Table>
                    <Pagination className={Style.pagination} showQuickJumper showSizeChanger total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange}></Pagination>
                </Fragment>}
                {this.state.showBindModal ? <Modal title='绑定Cypress帐号' close={this.close} actions={[<Button onClick={this.close}>取消</Button>,<Button type='primary' disabled={this.state.accountNumber === '' || this.state.password === ''} onClick={()=>{this.bind({account:this.state.accountNumber,pwd:this.state.password});}}>确定</Button>]}>
                    <Input placeholder='请输入账号' className={Style.bindInput} onChange={this.getAccountNumber} style={this.state.errorMsg ? {border:'1px solid #DE350B'} : {}}></Input>
                    <Input placeholder='请输入密码' type='password' className={Style.bindInput} onChange={this.getPassword} style={this.state.errorMsg ? {border:'1px solid #DE350B'} : {}}></Input>
                    {this.state.errorMsg ? <div className={Style.errorMsg}>{this.state.errorMsg}</div> : <div className={Style.block}></div>}
                </Modal> : ''}
            </Spin>
        )
    }
}

export default connect(store => store)(CourseLive);