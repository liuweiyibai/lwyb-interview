import React, {Fragment} from "react";
import { connect } from "react-redux";
import { Button, Select, Tooltip, message, Spin, Table ,Dropdown, Menu, Modal } from "antd";
import api from "../../../../utils/api.js";
import BindCypress from "../components/bindCypress/bindCypress";
import { LoadingOutlined, createFromIconfontCN } from "@ant-design/icons";
import MyCourseManagementModal from '../components/courseManagementModal/CourseModal';
import Style from "./courseManagement.module.less";

const { Option } = Select;
const {confirm} = Modal;

const IconFont = createFromIconfontCN({
  scriptUrl: ['//at.alicdn.com/t/font_2364058_63mrgbhgxwa.js']
})

class CourseManagement extends React.Component {
  state = {
    loading: false,
    isTeacher: false,
    campusList: [],
    termsList: [],
    courseList: [], // 下拉框课程数据
    yearList: [],
    selectCampusValue: null,
    selectTermValue: null,
    selectCourseNameValue: null,
    selectCAStatusValue: null,
    selectYearValue: null,
    isShowActiveBtn: false,
    isShowTableCheckBox: false,
    page: 1,
    pageSize: 10,
    total: 0,
    isModalVisible: false,
    modalType: 'add',  // 要打开的弹框的类型 - add / copy / edit
    selectedItemCaIds: [], // 选中的caid数组
    defaultModalSelectedValue: {
      assignType: null,
      courseCode: "",
      courseName: "",
      enrollCount: '',
      grade: null,
      caId: 0,
      major: null,
      mentorId: null,
      professor: '',
      status: 0,
      term: 0,
    },
    modalData: {},
    dataSource: [
      // {
      //   assignType: 1,
      //   assignTypeDisplay: 'Weekly Course',
      //   campusId: 1,
      //   courseCode: "hyqcode",
      //   courseName: "hyqname",
      //   enrollCount: 15,
      //   grade: 3,
      //   gradeDisplay: "Year 3",
      //   id: 10164,
      //   major: 7,
      //   majorDisplay: "BR",
      //   mentorId: 4169,
      //   mentorName: "UTSG",
      //   professor: "hyq",
      //   status: 1,
      //   statusDisplay: "Inactive",
      //   term: 2,
      //   termDisplay: "SUMMER",
      //   year: 2020,
      // }
    ]
  };

  columns = [
    {
      title: 'CAID',
      dataIndex: 'id',
      key: 'id',
      align: "center",
      width: 80,
      sorter: {
        compare: (a, b) => a.id - b.id,
        multiple: 2,
      },
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'CA Status',
      dataIndex: 'status',
      key: 'status',
      align: "left",
      width: 95,
      render: (v) => {
        let tag = v === 0 ? 'Active' : 'Inactive';
        return (
          <Tooltip placement="top" title={tag} mouseEnterDelay={0.3}>
            <span className={`${Style.dot} ${v===0? Style.dotGreen:''}`}></span>{tag}
          </Tooltip>
        );
      },
    },
    {
      title: 'Course Name',
      dataIndex: 'courseName',
      key: 'courseName',
      align: "center",
      className: Style.tableMinWidth,
      width: 210,
      sorter: {
        compare: (a, b) => a.courseName.localeCompare(b.courseName),
        multiple: 1,
      },
      render: (v) => {
        return (
          <Tooltip placement="top" title={v}>
            <div className={Style.courseName}>{v}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Year',
      dataIndex: 'year',
      key: 'year',
      align: "center",
      width: 70,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'Type',
      dataIndex: 'assignTypeDisplay',
      key: 'assignTypeDisplay',
      align: "center",
      width: 125,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            <div className={Style.courseName}>{v}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Professor',
      dataIndex: 'professor',
      key: 'professor',
      align: "center",
      className: Style.tableMinWidth,
      width: 90,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            <div className={Style.courseName}>{v}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Mentor',
      dataIndex: 'mentorName',
      key: 'mentorId',
      align: "center",
      className: Style.tableMinWidth,
      width: 90,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            <div className={Style.courseName}>{v}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Term',
      dataIndex: 'termDisplay',
      key: 'term',
      align: "center",
      width: 88,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            <div className={Style.courseName}>{v}</div>
          </Tooltip>
        );
      },
    },
    {
      title: 'Grade',
      dataIndex: 'gradeDisplay',
      key: 'grade',
      align: "center",
      width: 78,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'Major ',
      dataIndex: 'majorDisplay',
      key: 'major',
      align: "center",
      width: 88,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: 'School Enroll',
      dataIndex: 'enrollCount',
      key: 'enrollCount',
      align: "center",
      width: 110,
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.3}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: '',
      dataIndex: `id`,
      key: `id`,
      align: "center",
      width: 36,
      render: (v, record) => {
        if (this.state.isShowActiveBtn) return '';
        return (
          // <div><EllipsisOutlined /></div>
          <Dropdown overlay={this.editMenu(v,record)} placement="bottomRight">
            <Button className={Style.itemEditBtn} type='link'><IconFont type='icongengduo' /></Button>
          </Dropdown>
        );
      },
    }
  ];

  rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      // console.log(`selectedRowKeys:`,selectedRowKeys, 'selectedRows: ', selectedRows);
      this.setState({selectedItemCaIds: selectedRowKeys});
    },
  };

  editMenu = (v, record) =>{
    return (
      <Menu>
        <Menu.Item onClick={()=>{
            this.setState({
              defaultModalSelectedValue: record,
            }, () => {this.openModal('edit')})
          }}
        >
          <span>重新编辑</span>
        </Menu.Item>
        <Menu.Item onClick={()=>{
            this.setState({
              defaultModalSelectedValue: record,
            }, () => {this.openModal('copy')})
          }}
        >
          <span>复制</span>
        </Menu.Item>
      </Menu>
    )
  };

  openModal = (modalType) => {
    this.setState({
      isModalVisible: true,
      modalType,
    })
  }

  closeModal = () => {
    this.setState({
      isModalVisible: false,
    })
  }

  componentDidMount() {
    this.getCampus();
    this.getYearList();
  }


  getYearList = (startYear = 2018) => {
    const currentYear = new Date().getFullYear();
    const yearList = [];
    for (let i = startYear; i <= currentYear + 1; i++) {
      yearList.push({id: i});
    }
    this.setState({yearList, selectYearValue: currentYear});
  }

  // 获取校区列表
  getCampus = () => {
    this.setState({ loading: true }, () => {
      api
        .getEduCampus()
        .then((res) => {
          if (res.code === 0) {
            this.setState({ campusList: res.data, loading: false });
          } else {
            if (res.ret === 60001) {
              this.setState({ isTeacher: true });
              res.message = res.msg;
            }
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
    });
  };

  // 获取学校下 所有符合条件的课程数据
  getCourseList = () => {
    // console.log(this.state.selectYearValue);
    if (!this.state.selectCampusValue) return; 
    this.setState({loading: true}, () => {
      api.getEZA_CA_CourseList({
        campusId: this.state.selectCampusValue,
        term: this.state.selectTermValue,
        courseId: this.state.selectCourseNameValue,
        status: this.state.selectCAStatusValue,
        year: this.state.selectYearValue,
        page: this.state.page,
        pageSize: this.state.pageSize,
      }).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false, dataSource: res.data});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      });
      // 获取数据的数量
      this.getCourseListTotalCount();
    })
  }

  // 获取学校下 所有符合条件的课程数据 - 数量
  getCourseListTotalCount = () => {
    this.setState({loading: true}, () => {
      api.getEZA_CA_CourseListTotalCount({
        campusId: this.state.selectCampusValue,
        term: this.state.selectTermValue,
        courseId: this.state.selectCourseNameValue,
        status: this.state.selectCAStatusValue,
        year: this.state.selectYearValue,
        page: this.state.page,
        pageSize: this.state.pageSize,
      }).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false, total: res.data});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  // 获取学校下面 - 下拉框课程列表 - 名字
  getCourseNameList = () => {
    return new Promise(resolve => {
      this.setState({loading: true}, async () => {
        await api.getEZA_CA_CourseNameList(this.state.selectCampusValue).then(res => {
          // console.log(res);
          resolve();
          if (res.code === 0) {
            this.setState({loading: false, courseList: this.state.selectCampusValue === null ? [] : res.data});
          } else {
            return Promise.reject(res);
          }
        }).catch(err => {
          message.error(err.message);
          this.setState({ loading: false });
        })
      })
    })
  }

  // 获取学校下的学期
  getCampusOptions = () => {
    this.setState({loading: true}, () => {
      api.getEZA_CampusOptions(this.state.selectCampusValue).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false, termsList: res.data.term || []});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  // 获取课程单条数据详情
  getCourseDetail = () => {
    this.setState({loading: true}, () => {
      api.getEZA_CA_CourseDetail(10141).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false});
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  createChangeActiveStatusData = (caIdsArr, activeType) => { // 0 active 1 inactive
    let _arr = [];
    caIdsArr.forEach(v => {
      _arr.push({
        id: v,
        status: activeType,
      })
    });
    return _arr;
  }

  // 批量修改激活状态  0 active 1 inactive
  updateCourseActiveStatus = (type) => { // type - number
    // 先处理选中的数据
    const statusParam = this.createChangeActiveStatusData(this.state.selectedItemCaIds, type);

    this.setState({loading: true}, () => {
      // api.updateEZA_CA_CourseActiveStatus({statusReq: statusParam}).then(res => {
      api.updateEZA_CA_CourseActiveStatus(statusParam).then(res => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({loading: false});
          message.success(`${type === 0 ? 'Active 成功': 'Inactive 成功'}`);
          this.getCourseList(); // 刷新页面数据
          this.cancelEditBtnClick(); // 关闭编辑状态
        } else {
          return Promise.reject(res);
        }
      }).catch(err => {
        message.error(err.message);
        this.setState({ loading: false });
      })
    })
  }

  // 选学校
  clickCampusItem = (value, option) => {
    this.setState({ selectCampusValue: value, selectTermValue: null, selectCourseNameValue: null, page: 1 }, async() =>{ 
      await this.getCourseNameList(); // 课程名字列表数据比较多
      this.getCampusOptions();
      this.getCourseList();
    });
  }
  // 选学期
  clickTermsItem = (value, option) => {
    this.setState({ selectTermValue: value, selectCourseNameValue: null, page: 1 }, () =>{ 
      this.getCourseList();
    });
  }
  // 选课程
  clickCourseNameItem = (value, option) => {
    this.setState({ selectCourseNameValue: value, page: 1 }, () => {
      this.getCourseList();
    });
  }
  // 选状态
  clickCAStatusItem = (value, option) => {
    this.setState({ selectCAStatusValue: value, page: 1 }, () => {
      this.getCourseList();
    });
  }
  // 选年份
  clickYearItem = (value, option) => {
    this.setState({selectYearValue: value, page: 1}, () => {
      this.getCourseList();
    });
  }

  editBtnClick = () => {
    this.setState({isShowActiveBtn: true, isShowTableCheckBox: true});
  }

  cancelEditBtnClick = () => {
    this.setState({isShowActiveBtn: false, isShowTableCheckBox: false, selectedItemCaIds: []});
  }

  changePage = (page, pageSize) => {
    this.setState({page, pageSize}, () => {
      this.getCourseList();
    })
  }

  showConfirm = (type) => {
    if (type === 'active') {
      confirm({
        title: '确定要Active课程么？',
        okText: '确定',
        okType: 'primary',
        icon: null,
        className: Style['EZA-CAS-Management-Confirm'],
        cancelText: '取消',
        onOk: () => {
          this.updateCourseActiveStatus(0)
        },
        onCancel: () => {
        },
      });
      return;
    } else {
      confirm({
        title: '确定要Inactive课程么？',
        okText: '确定',
        okType: 'primary',
        icon: null,
        className: Style['EZA-CAS-Management-Confirm'],
        cancelText: '取消',
        onOk: () => {
          this.updateCourseActiveStatus(1)
        },
        onCancel: () => {
        },
      });
    }
  }

  render() {
    const { isModalVisible, page, total, isShowTableCheckBox, dataSource, yearList, isShowActiveBtn, selectYearValue, courseList, termsList, selectCampusValue, campusList, selectCAStatusValue, selectCourseNameValue, selectTermValue } = this.state;
    const { columns, rowSelection } = this;
    return (
      <Spin
        spinning={this.state.loading}
        indicator={<LoadingOutlined />}
        tip="请稍候..."
        size="large"
      >
        {
          this.props.isTeacher ? (
              <BindCypress refresh={()=>{
                this.getCampus();
                this.getYearList();}
              }/>
          ):(
              <div className={Style.EZACourseManagementWrap}>
                <div className={Style.topBar}>
                  <div className={Style.left}>
                    {/* 校园下拉框 */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 126 }}
                        allowClear
                        placeholder="Campus"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickCampusItem(v, o)}
                        value={selectCampusValue}
                        onClear={() => {
                          this.setState({
                            selectCampusValue: null,
                            selectTermValue: null,
                            selectCourseNameValue: null,
                            termsList: [],
                            courseList: [],
                            dataSource: [],
                            page: 1,
                            total: 0,
                          });
                        }}
                    >
                      {campusList.map(campus => {
                        return (
                            <Option
                                key={campus.id}
                                value={campus.id}
                                campusname={campus.campusName}
                                title={campus.campusName}
                            >
                              <Tooltip
                                  placement="top"
                                  title={campus.campusName}
                                  mouseEnterDelay="0.5"
                              >
                                {campus.campusName}
                              </Tooltip>
                            </Option>
                        );
                      })}
                    </Select>
                    {/* Term */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 115 }}
                        allowClear
                        placeholder="Term"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickTermsItem(v, o)}
                        value={selectTermValue}
                        onClear={() => {
                          this.setState({
                            selectTermValue: null,
                            selectCourseNameValue: null,
                            courseList: [],
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      {
                        termsList.map(term => {
                          return (
                              <Option
                                  key={term.id}
                                  value={term.id}
                                  title={term.name}
                              >
                                <Tooltip
                                    placement="top"
                                    title={term.name}
                                    mouseEnterDelay="0.5"
                                >
                                  {term.name}
                                </Tooltip>
                              </Option>
                          )
                        })
                      }
                    </Select>
                    {/* Course Name */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 266 }}
                        allowClear
                        placeholder="Course Name"
                        className={Style.selectBox}
                        dropdownMatchSelectWidth={400}
                        onSelect={(v, o) => this.clickCourseNameItem(v, o)}
                        value={selectCourseNameValue}
                        onClear={() => {
                          this.setState({
                            selectCourseNameValue: null,
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      {
                        courseList.map(course => {
                          return (
                              <Option
                                  key={course.id}
                                  value={course.id}
                                  // title={`${course.courseCode} (${course.year}) ${course.termDisplay}-${course.assignTypeDisplay}`}
                                  title={course.name}
                              >
                                <Tooltip
                                    placement="top"
                                    // title={`${course.courseCode} (${course.year}) ${course.termDisplay}-${course.assignTypeDisplay}`}
                                    title={course.name}
                                    mouseEnterDelay="0.5"
                                >
                                  {/* {`${course.courseCode} (${course.year}) ${course.termDisplay}-${course.assignTypeDisplay}`} */}
                                  {course.name}
                                </Tooltip>
                              </Option>
                          )
                        })
                      }
                    </Select>
                    {/* CA Status */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 134 }}
                        allowClear
                        placeholder="CA Status"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickCAStatusItem(v, o)}
                        value={selectCAStatusValue}
                        onClear={() => {
                          this.setState({
                            selectCAStatusValue: null,
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      <Option
                          key={0}
                          value={0}
                          title='Active'
                      >
                        <Tooltip
                            placement="top"
                            title='Active'
                            mouseEnterDelay="0.5"
                        >
                          Active
                        </Tooltip>
                      </Option>
                      <Option
                          key={1}
                          value={1}
                          title='Inactive'
                      >
                        <Tooltip
                            placement="top"
                            title='Inactive'
                            mouseEnterDelay="0.5"
                        >
                          Inactive
                        </Tooltip>
                      </Option>
                    </Select>
                    {/* Year */}
                    <Select
                        showSearch
                        optionFilterProp="title"
                        style={{ width: 100 }}
                        allowClear
                        placeholder="Year"
                        className={Style.selectBox}
                        onSelect={(v, o) => this.clickYearItem(v, o)}
                        value={selectYearValue}
                        onClear={() => {
                          this.setState({
                            selectYearValue: null,
                            page: 1,
                          }, ()=>{this.getCourseList();});
                        }}
                    >
                      {
                        yearList.map(year => {
                          return (
                              <Option
                                  key={year.id}
                                  value={year.id}
                                  title={year.id}
                              >
                                <Tooltip
                                    placement="top"
                                    title={year.id}
                                    mouseEnterDelay="0.5"
                                >
                                  {year.id}
                                </Tooltip>
                              </Option>
                          )
                        })
                      }
                    </Select>
                  </div>
                  <div className={Style.right}>
                    {
                      isShowActiveBtn ? (
                          <Fragment>
                            <Button type="primary" ghost className={Style.inactiveBtn} disabled={this.state.selectedItemCaIds.length === 0} onClick={()=>{this.showConfirm('active')}}>Active</Button>
                            <Button type="primary" ghost className={Style.inactiveBtn} disabled={this.state.selectedItemCaIds.length === 0} onClick={()=>{this.showConfirm('inactive')}}>Inactive</Button>
                            <Button type="link" className={Style.activeCancelBtn} onClick={this.cancelEditBtnClick}>Cancel</Button>
                          </Fragment>
                      ):(
                          <Fragment>
                            <Button type="link" onClick={this.editBtnClick}>编辑</Button>
                            <Button type="primary" className={Style.addBtn} disabled={!selectCampusValue} onClick={()=>{this.openModal('add')}}>Add</Button>
                          </Fragment>
                      )
                    }
                  </div>
                </div>
                <div className={Style.main}>
                  <Table rowSelection={isShowTableCheckBox?rowSelection:null} tableLayout='fixed' dataSource={dataSource} columns={columns} rowKey={(record)=>record.id} className={Style.mainTable} pagination={{total: total, current: page, onChange: this.changePage}}/>
                </div>
              </div>
          )
        }
        <MyCourseManagementModal defaultYear={selectYearValue} defaultCampus={selectCampusValue} campusList={campusList} yearList={yearList} courseNameList={courseList} isModalVisible={isModalVisible} closeModal={this.closeModal} refreshPage={this.getCourseList} modalType={this.state.modalType} defaultModalSelectedValue={this.state.defaultModalSelectedValue}/>
      </Spin>
    );
  }
}

export default connect((store) => store)(CourseManagement);
