import React, { Component, Fragment } from 'react';
import { Spin, Input, Button, Select, Table, Upload, Divider, Pagination, message, Popconfirm, Badge, Tooltip } from 'antd';
import { FolderOpenOutlined, LoadingOutlined, SearchOutlined, EditOutlined, DeleteOutlined, UploadOutlined, CloseCircleOutlined } from '@ant-design/icons';
import Style from './topicExplanationVideo.module.less';
import 'katex/dist/katex.min.css';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import moment from 'moment';
const { TextArea } = Input;
const { Option } = Select

class TopicExplanationVideo extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,//页面loading
            showModal: false,//显示上传弹框
            editModal: false,//编辑弹框
            showVideoModal: false,
            //查询列
            fileList: [],//文件列表
            videoID: '',//视频id input
            videoName: '',//视频名称 input
            videoTopicID: '',//视频题目id
            subjectSel: '',//学科 sel
            subjectList: [],//学科下拉菜单列表
            videoUrl: '',//视频的URL
            //table
            dataSource: [],//题目讲解视频列表数据
            modalDataSource: [],//编辑视频信息列表
            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 1,//总条数
            rowInfo: {},//点击行的数据
            //编辑弹框
            editVideoName: '',//视频名称
            videoReword: '',//备注textarea
            topicsList: '',//关联题目
            editPage: 1,//关联题目列表 页码
            editPageSize: 5,//关联题目列表 条数
            editTotal: '',//关联题目列表 总条数
            topicList: [],//关联题目列表,
            showTopicID: '',//搜索题目ID和题目内容
            showISBN: '',//搜索isbn
            showTopicName: '',//搜索教材名称
            teachingMaterialList: [],//教材名称下拉列表
        }
    }
    columns = [
        {
            title: '视频ID',
            align: 'center',
            render: (record) => {
                return (
                    <div>
                        <Button type='link' onClick={() => { this.videoPreview(record) }}>{record.id}</Button>
                    </div>
                )
            }
        },
        {
            title: '视频名称',
            dataIndex: 'videoName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: videoName => {
                return (
                    <Tooltip placement="top" title={videoName}>
                        {videoName}
                    </Tooltip>
                )
            },
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            ),
        },
        {
            title: '关联题目',
            align: 'center',
            render: (record) => {
                return (
                    <Button type='link' onClick={() => { window.open(api.pageURL + `/admin/v1/questionBankManage/preview?id=${record.tid}`); }}>{record.tid ? record.tid : ''}</Button>
                )
            }
        },
        {
            title: '上传时间',
            align: 'center',
            width: '200px',
            render: (record) => {
                let date = moment(new Date(new Date(record.createdAt).getTime() + 28800000)).format('YYYY/MM/DD HH:mm:ss');
                return (
                    <div>
                        {date}
                    </div>
                )
            }
        },
        {
            title: '操作',
            align: 'center',
            width: '220px',
            render: (record) => {
                return (
                    <div>
                        <Button onClick={() => { this.edit(record) }} icon={<EditOutlined />} style={{ marginRight: '10px' }} type='primary'>编辑</Button>
                        <Popconfirm title="确定要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.confirm(record) }}>
                            <Button icon={<DeleteOutlined />} type='primary'>删除</Button>
                        </Popconfirm>
                    </div>
                )
            }
        },
    ]
    modalColumns = [
        {
            title: '题目ID',
            dataIndex: 'id',
            align: 'center',
            width: '80px',
            render: id => {
                return (
                    <Tooltip placement="topLeft" title={id}>
                        {id}
                    </Tooltip>
                )
            },
        },
        {
            title: '题号',
            dataIndex: 'path',
            align: 'center',
            width: '100px',
            ellipsis: true,
            render: path => {
                return (
                    <Tooltip placement="topLeft" title={path}>
                        {path}
                    </Tooltip>
                )
            },
        },
        {
            title: 'ISBN',
            dataIndex: 'bookIsbn',
            align: 'center',
            width: '100px',
            ellipsis: true,
            render: bookIsbn => {
                return (
                    <Tooltip placement="topLeft" title={bookIsbn}>
                        {bookIsbn}
                    </Tooltip>
                )
            },
        },
        {
            title: '教材名称',
            dataIndex: 'bookTitle',
            align: 'center',
            width: '100px',
            ellipsis: true,
            render: bookTitle => {
                return (
                    <Tooltip placement="topLeft" title={bookTitle}>
                        {bookTitle}
                    </Tooltip>
                )
            },
        },
        {
            title: '题干内容',
            dataIndex: 'content',
            align: 'center',
            width: '100px',
            ellipsis: true,
            render: content => {
                return (
                    <Tooltip placement="topLeft" title={content}>
                        {content}
                    </Tooltip>
                )
            },
        },
        {
            title: '操作',
            align: 'center',
            width: '100px',
            render: (record) => {
                return (
                    <div>
                        <Button type='primary' onClick={() => { this.connectVideo(record) }}>关联本视频</Button>
                    </div>
                )
            }
        }
    ]
    componentDidMount() {
        this.getTeachingMaterialList();
        this.getSubjectList();
        this.getTopicVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取教材下拉列表
    getTeachingMaterialList = () => {
        this.setState({ loading: true }, () => {
            api.getTeachingMaterialList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ teachingMaterialList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取题目讲解视频列表
    getTopicVideoList = (params) => {
        this.setState({ loading: true }, () => {
            api.getTopicVideoList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    //点击显示上传文件弹框
    showModal = () => {
        this.setState({ showModal: true });
    }
    //关闭弹框
    close = () => {
        if (this.state.showVideoModal) {
            let videoDom = document.getElementById('video');
            videoDom.pause();
        }
        this.setState({ showModal: false, editModal: false, showVideoModal: false, modalDataSource: [], editPage: 1, editPageSize: 5, editTotal: 0, fileList: [], showISBN: '', showTopicID: '', showTopicName: '' });
    }
    //文件上传状态改变时
    handleChange = ({ fileList }) => {
        for (let item of fileList) {
            let pictureType = item.name.split('.')[item.name.split('.').length - 1]
            if (pictureType !== 'mp4' && pictureType !== 'mov') {
                message.warning('只支持 mp4 mov 文件！');
                this.setState({ fileList: [] });
                return;
            }
        }
        this.setState({ fileList });
    }
    //确认上传
    submit = async () => {
        if (this.state.fileList.length <= 0) {
            message.error('请至少选择一个文件！');
            return;
        } else if (this.state.fileList.length >= 30) {
            message.error('一次上传数量不能超过30个！');
            return;
        }
        this.setState({ showDel: false, btnLoading: true });
        for (let item of this.state.fileList) {
            //获取aws上传地址
            await api.getAddress({ fileName: '.' + item.originFileObj.name.split('.')[1] })
                .then(async (data) => {
                    if (data.ret === 20000) {
                        let url = data.result.key;
                        //往aws上传视频
                        await api.uploadAWS(data.result.url, item.originFileObj)
                            .then(async (res) => {
                                //上传aws成功后通知服务端
                                let data2 = await api.notice({ fileName: item.originFileObj.name, key: url, type: 1 });
                                if (data2.ret === 20000) {
                                    message.success(item.originFileObj.name + '上传成功');
                                } else {
                                    return Promise.reject(data);
                                }
                            })
                            .catch((err) => {
                                message.error(err.msg);
                            })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                })
        }
        this.getTopicVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        this.setState({ showDel: true, btnLoading: false, showModal: false, fileList: [] });
    }
    //获取视频id input
    getVideoID = (e) => {
        this.setState({ videoID: e.target.value });
    }
    //获取视频名称 input
    getVideoName = (e) => {
        this.setState({ videoName: e.target.value });
    }
    //获取视频题目id input
    getVideoTopicID = (e) => {
        this.setState({ videoTopicID: e.target.value });
    }
    //获取学科select
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur()
            this.setState({ subjectSel: option.key });
        } else {
            this.setState({ subjectSel: '' });
        }
    }
    //查询btn
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getTopicVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, id: this.state.videoID, tid: this.state.videoTopicID, videoName: this.state.videoName, subId: this.state.subjectSel, loading: true, });
        })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getTopicVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, id: this.state.videoID, tid: this.state.videoTopicID, videoName: this.state.videoName, subId: this.state.subjectSel });
        });
    }
    //视频弹框
    //点击视频ID 显示弹框
    videoPreview = (record) => {
        this.setState({ showVideoModal: true, rowInfo: record });
    }
    //编辑弹框
    //编辑
    edit = (record) => {
        this.setState({ rowInfo: record, editModal: true, editVideoName: record.videoName, topicsList: (record.tid !== 0 ? record.tid : ''), videoReword: record.remark });
    }
    //关联题目列表删除
    tagClose = () => {
        this.setState({ topicsList: '' });
    }
    //获取编辑视频名称
    getEditVideoName = (e) => {
        this.setState({ editVideoName: e.target.value });
    }
    //获取备注textarea
    getReword = (e) => {
        this.setState({ videoReword: e.target.value });
    }
    //获取弹框中搜索输入的题目ID和内容
    getShowTopicID = (e) => {
        this.setState({ showTopicID: e.target.value })
    }
    //获取弹框中搜索输入的isbn
    getShowISBN = (e) => {
        this.setState({ showISBN: e.target.value })
    }
    //获取弹框中搜索输入的教材名称
    getShowTopicName = (value, option) => {
        if (value && option) {
            this.setState({ showTopicName: option.key });
        } else {
            this.setState({ showTopicName: '' });
        }
    }
    //弹框中搜索题目
    searchTopic = () => {
        this.setState({ loading: true }, () => {
            api.searchTopic({ iDisplayStart: this.state.editPage - 1, iDisplayLength: this.state.editPageSize, content: this.state.showTopicID, bookTitle: this.state.showTopicName, bookIsbn: this.state.showISBN, })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ modalDataSource: data.result.data, editTotal: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //弹框中搜索按钮搜索题目
    getSearch = () => {
        this.setState({ editPage: 1 }, () => {
            this.searchTopic();
        })
    }
    //编辑搜索题目分页
    editPaginationChange = (page, pageSize) => {
        this.setState({ editPage: page, editPageSize: pageSize }, () => {
            this.searchTopic();
        })
    }
    //关联本视频
    connectVideo = (record) => {
        if (this.state.topicsList !== '') {
            message.error('此视频已有关联题目，请先删除后再关联！');
            return;
        } else {
            this.setState({ topicsList: record.id });
        }
    }
    //编辑确定
    submitEdit = () => {
        this.setState({ loading: true }, () => {
            api.topicEditSubmit({ id: this.state.rowInfo.id, videoName: this.state.editVideoName, remark: this.state.videoReword, tid: (this.state.topicsList === '' ? 0 : this.state.topicsList) })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success('编辑成功！');
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.setState({ editModal: false, modalDataSource: [] });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    //删除
    confirm = (record) => {
        this.setState({ loading: true }, () => {
            api.delTopicVideo('/v1/video/explain/del/' + record.id)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.paginationChange(this.state.page, this.state.pageSize);
                        message.success(data.msg);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>
                        <Button icon={<FolderOpenOutlined />} onClick={this.showModal} type='primary'>视频上传</Button>
                        <div className={Style.leftWrap}>
                            <div className={Style.box}>
                                <span className={Style.span}>视频ID：</span>
                                <Input placeholder='输入视频ID查询' className={Style.input} onChange={this.getVideoID} />
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>视频名称：</span>
                                <Input placeholder='输入视频名称查询' className={Style.input} onChange={this.getVideoName} />
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>题目ID：</span>
                                <Input placeholder='输入题目ID查询' className={Style.input} onChange={this.getVideoTopicID} />
                            </div>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>学科：</span>
                                <Select placeholder='全部' ref='subject' className={Style.input} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </div>
                        <Button icon={<SearchOutlined />} type='primary' onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination hideOnSinglePage showQuickJumper className={Style.pagination} total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {this.state.showModal ? <Modal close={this.close} title='上传视频' loading={this.state.btnLoading} actions={[<Button onClick={this.close} disabled={this.state.btnLoading}>取消</Button>, <Button type='primary' onClick={this.submit} loading={this.state.btnLoading}>确认上传</Button>]}>
                        <div className={Style.modal}>
                            <div className={Style.contentTop}>请选择本地视频文件，支持常见的视频格式，可以批量上传</div>
                            <Upload
                                accept='.mp4,.mov'
                                beforeUpload={() => false}
                                onChange={this.handleChange}
                                fileList={this.state.fileList}
                                disabled={this.state.btnLoading}
                                multiple={true}
                            >
                                <Button icon={<UploadOutlined />} disabled={this.state.btnLoading}>选择文件</Button>
                            </Upload>
                        </div>
                    </Modal> : ''}
                    {this.state.showVideoModal ? <Modal title='播放视频' close={this.close}>
                        <div >
                            <video id='video' src={this.state.rowInfo.videoUrl} width='700px' height='500px' autoPlay="autoplay" controls="controls"></video>
                        </div>
                    </Modal> : ''}
                    {this.state.editModal ? <Modal title='编辑视频信息' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.submitEdit}>确定</Button>]}>
                        <div className={Style.editWrap}>
                            <div className={Style.item}>
                                <span className={Style.name}>视频名称：</span>
                                <Input placeholder='请输入视频名称' className={Style.input} value={this.state.editVideoName} onChange={this.getEditVideoName} />
                            </div>
                            <div className={Style.item}>
                                <span className={Style.name}>备注：</span>
                                <TextArea placeholder='请输入备注' className={Style.input} maxLength='500' value={this.state.videoReword} onChange={this.getReword} /><br />
                                <span className={Style.spanRight}>已输入{this.state.videoReword.length}/200字</span>
                            </div>
                            <div className={Style.item}>
                                <span className={Style.nameConnect}>关联题目：</span>
                                {this.state.topicsList ? <span onClick={() => { this.tagClose() }}>
                                    <Badge count={<CloseCircleOutlined style={{ borderRadius: '50%', background: '#ffffff', cursor: 'pointer' }} />}>
                                        <Button type='primary' >{this.state.topicsList}</Button>
                                    </Badge>
                                </span> : ''}
                                <div className={Style.searchModal}>
                                    <div className={Style.left}>
                                        <div className={Style.boxInput}>
                                            <Input placeholder='请输入题目ID或题干内容' className={Style.input} value={this.state.showTopicID} onChange={this.getShowTopicID}></Input>
                                        </div>
                                        <div className={Style.box}>
                                            <span className={Style.span}>教材名称：</span>
                                            <Select placeholder='全部' className={Style.input} onChange={this.getShowTopicName} optionLabelProp="label" showSearch={true} allowClear={true}>
                                                {this.state.teachingMaterialList.map((item) => {
                                                    return (
                                                        <Option key={item.bookTitle} value={item.bookTitle}>  <Tooltip placement="topLeft" title={item.bookTitle}>
                                                            {item.bookTitle}
                                                        </Tooltip>
                                                        </Option>
                                                    )
                                                })}
                                            </Select>
                                        </div>
                                        <div className={Style.box}>
                                            <span className={Style.spanISBN}>ISBN：</span>
                                            <Input placeholder='请输入ISBN' className={Style.input} value={this.state.showISBN} onChange={this.getShowISBN}></Input>
                                        </div>
                                    </div>
                                    <div className={Style.button}>
                                        <Button type='primary' onClick={this.getSearch}>查询</Button>
                                    </div>
                                </div>
                            </div>
                            <Table
                                dataSource={this.state.modalDataSource}
                                columns={this.modalColumns}
                                rowKey={dataSource => dataSource.id}
                                pagination={false}
                            >
                            </Table>
                            <Pagination className={Style.pagination} total={this.state.editTotal} current={this.state.editPage} pageSize={this.state.editPageSize} onChange={this.editPaginationChange} hideOnSinglePage={true} showTotal={total => `Total ${total} items`} />
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment >
        )
    }
}

export default TopicExplanationVideo;