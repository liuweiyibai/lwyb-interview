import React, { Component, Fragment } from 'react';
import { Spin, Table, message, Tooltip } from 'antd';
import { LoadingOutlined, } from '@ant-design/icons';
import api from '../../../../utils/api';

class VideoDataStatistics extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,//页面loading
            dataSource: [],//列表数据
        };
    }
    columns = [
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            render: subjectName => {
                return (
                    <Tooltip placement="top" title={subjectName}>
                        {subjectName}
                    </Tooltip>
                )
            }
        },
        {
            title: '知识点视频',
            dataIndex: 'videoKnowledgeCount',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: videoKnowledgeCount => {
                return (
                    <Tooltip placement="top" title={videoKnowledgeCount}>
                        {videoKnowledgeCount}
                    </Tooltip>
                )
            },
        },
        {
            title: '题目讲解视频',
            dataIndex: 'videoExplainCount',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: videoExplainCount => (
                <Tooltip placement="top" title={videoExplainCount}>
                    {videoExplainCount}
                </Tooltip>
            ),
        },
        {
            title: '录播课视频',
            dataIndex: 'videoRecordingCount',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: videoRecordingCount => (
                <Tooltip placement="top" title={videoRecordingCount}>
                    {videoRecordingCount}
                </Tooltip>
            ),
        },
    ]
    componentDidMount() {
        this.getVideoDataStatistics();
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    //获取视频数据统计列表
    getVideoDataStatistics = () => {
        this.setState({ loading: true }, () => {
            api.getVideoDataStatistics()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }

    render() {
        return (
            <Fragment >
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.subjectName}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                </Spin>
            </Fragment>
        )
    }
}

export default VideoDataStatistics;