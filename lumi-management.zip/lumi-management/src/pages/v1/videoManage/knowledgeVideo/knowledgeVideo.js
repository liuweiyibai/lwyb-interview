import React, { Component, Fragment } from 'react';
import { Upload, Button, Spin, Divider, Input, Select, Table, Pagination, message, Popconfirm, Tooltip } from 'antd';
import { FolderOpenOutlined, LoadingOutlined, SearchOutlined, EditOutlined, DeleteOutlined, UploadOutlined } from '@ant-design/icons';
import Style from './knowledgeVideo.module.less';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import moment from 'moment';
const { Option } = Select;
const { TextArea } = Input;

class KnowledgeVideo extends Component {
    constructor() {
        super();
        this.state = {
            showModal: false,//上传视频弹框
            showDel: true,//是否可以删除选择的视频文件
            showLookUpModal: false,
            showVideoModal: false,
            btnLoading: false,//视频上传弹框中的关闭、取消、确认上传button的loading
            editModal: false,//编辑视频信息弹框
            loading: false,//页面loading
            spinTip: '请稍候...',
            percent: '',//进度条百分比
            //查询区域
            fileList: [],//上传文件列表
            subjectList: [],//学科列表
            firKnowledgeList: [],//一级知识点列表
            secKnowledgeList: [],//二级知识点列表
            videoID: '',//视频id
            videoName: '',//视频名称
            videoUrl: '',//视频的URL
            subjectSel: '',//学科 下拉id
            subjectName: null,//所选学科名
            firPointSel: '',//一级知识点 下拉所选id
            firPointName: null,//一级知识点名
            secPointSel: '',//二级知识点 下拉所选id
            secPointName: null,//二级知识点名
            //table
            dataSource: [],//列表数据
            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 1,//总条数
            rowInfo: {},//点击行的数据
            //编辑弹框
            videoEditName: '',//视频名字
            videoIntroduction: '',//视频简介textarea字数
            remark: '',//获取点击行的备注
            videoReword: '',//备注textarea字数
            editSubjectSel: '',//编辑 弹框所选学科key值id
            editSubjectName: null,//弹框获取列表学科名字
            editFirPointSel: '',//编辑 所选一级知识点id
            editFirPointName: null,//弹框获取列表一级知识点名字
            editSecPointSel: '',//编辑 所选二级知识点id
            editSecPointName: null,//弹框获取列表二级知识点名字
            editFirKnowledgeList: [],//编辑 一级知识点列表
            editSecKnowledgeList: [],//编辑 二级知识点列表
        };
    }
    columns = [
        {
            title: '视频ID',
            align: 'center',
            width: '80px',
            render: (record) => {
                return (
                    <div>
                        <Button type='link' onClick={() => { this.videoPreview(record) }}>{record.id}</Button>
                    </div>
                )
            }
        },
        {
            title: '视频名称',
            dataIndex: 'name',
            align: 'center',
            width: '180px',
            ellipsis: {
                showTitle: false,
            },
            render: name => {
                return (
                    <Tooltip placement="top" title={name}>
                        {name}
                    </Tooltip>
                )
            },
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            ),
            width: '100px'
        },
        {
            title: '关联备考课',
            align: 'center',
            render: record => {
                return (
                    <div>
                        {Array.isArray(record.title) && record.title.length > 0 ? <Button type='link' onClick={() => { this.lookUp(record) }}>查看</Button> : '无'}
                    </div>
                )
            }
        },
        {
            title: '一级知识点',
            dataIndex: 'levelFirstName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: levelFirstName => (
                <Tooltip placement="top" title={levelFirstName}>
                    {levelFirstName}
                </Tooltip>
            ),
        },
        {
            title: '二级知识点',
            dataIndex: 'levelSecondName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: levelSecondName => (
                <Tooltip placement="top" title={levelSecondName}>
                    {levelSecondName}
                </Tooltip>
            ),
        },
        {
            title: '上传时间',
            align: 'center',
            width: '200px',
            render: (record) => {
                let date = moment(new Date(new Date(record.createdAt).getTime() + 28800000)).format("YYYY/MM/DD HH:mm:ss");
                return (
                    <div>
                        {date}
                    </div>
                )
            }
        },
        {
            title: '操作',
            align: 'center',
            width: '250px',
            render: (record) => {
                return (
                    <div>
                        <Button onClick={() => { this.edit(record) }} icon={<EditOutlined />} style={{ marginRight: '10px' }} type='primary'>编辑</Button>
                        <Popconfirm title="确定要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.confirm(record) }}>
                            <Button icon={<DeleteOutlined />} type='primary'>删除</Button>
                        </Popconfirm>
                    </div>
                )
            }
        },
    ]
    componentDidMount() {
        this.getSubjectList();
        this.getVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, videoType: 0 });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取学科列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取知识点视频列表
    getVideoList = (params) => {
        this.setState({ loading: true }, () => {
            api.getVideoList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }

    //查询列
    //点击视频上传btn显示弹框
    showModal = () => {
        this.setState({ showModal: true });
    }
    //关闭所有弹框
    close = () => {
        if (this.state.showVideoModal) {
            let videoDom = document.getElementById('video');
            videoDom.pause();
        }
        this.setState({ showModal: false, editModal: false, showLookUpModal: false, showVideoModal: false, fileList: [] });
    }
    //上传文件改变时的状态
    handleChange = ({ fileList }) => {
        for (let item of fileList) {
            let pictureType = item.name.split('.')[item.name.split('.').length - 1]
            if (pictureType !== 'mp4' && pictureType !== 'mov') {
                message.warning('只支持 mp4 mov 文件！');
                this.setState({ fileList: [] });
                return;
            }
        }
        this.setState({ fileList });
        // let url = window.URL.createObjectURL(fileList[0].originFileObj)
        // var video = document.createElement('video');
        // video.src = url;
        // video.currentTime = 0.016;
        // // 在用户重新定位视频的播放位置后执行 JavaScript 
        // video.onseeked = function () {
        //     //创建video
        //     let canvas = document.createElement('canvas');
        //     canvas.height = video.videoHeight;
        //     canvas.width = video.videoWidth;
        //     // 获得视频的第一帧
        //     canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
        //     // 将图片转成base64
        //     let baseImageURL = canvas.toDataURL();
        //     //将base64转化为file
        //     let arr = baseImageURL.split(',')
        //     let mime = arr[0].match(/:(.*?);/)[1]
        //     let bstr = atob(arr[1]);
        //     let n = bstr.length;
        //     let u8arr = new Uint8Array(n);
        //     while (n--) {
        //         u8arr[n] = bstr.charCodeAt(n);
        //     }
        //     let imgFile = new File([u8arr], '', { type: mime })
        // };
    }
    //确认上传视频
    submit = async () => {
        if (this.state.fileList.length <= 0) {
            message.error('请至少选择一个文件！');
            return;
        } else if (this.state.fileList.length > 30) {
            message.error('一次上传数量不能超过30个！');
            return;
        }
        // this.state.fileList.forEach((item,index)=>{
        //     if(item.originFileObj.name.split('.')[item.originFileObj.name.split('.').length - 1] !== 'mp4' || item.originFileObj.name.split('.')[item.originFileObj.name.split('.').length - 1] !== 'mov'){
        //         message.error('只能上传mp4或者mov格式的文件！');
        //         return;
        //     }
        // })
        this.setState({ showDel: false, btnLoading: true });//进度条
        for (let item of this.state.fileList) {
            //获取aws上传地址
            await api.getAddress({ fileName: '.' + item.originFileObj.name.split('.')[item.originFileObj.name.split('.').length - 1] })
                .then(async (data) => {
                    if (data.ret === 20000) {
                        let url = data.result.key;
                        //往aws上传视频
                        // await api.uploadAWS(data.result.url,formData)
                        //获取上传进度百分比
                        // await this.$axios.put(
                        //     data.result.url,
                        //     item.originFileObj,
                        //     {
                        //         // headers: {'Content-Type': 'multipart/form-data'},
                        //         onUploadProgress:(progressEvent)=>{ 
                        //             let complete = (progressEvent.loaded / progressEvent.total * 100 | 0)+'%';
                        //             this.setState({percent:complete,spinTip:`已上传${complete}`});
                        //         }
                        //     }
                        // )
                        //over
                        await api.uploadAWS(data.result.url, item.originFileObj)
                            .then(async (res) => {
                                //上传aws成功后通知服务端
                                let data2 = await api.notice({ fileName: item.originFileObj.name, key: url, type: 2 });
                                if (data2.ret === 20000) {
                                    message.success(item.originFileObj.name + '上传成功');
                                } else {
                                    return Promise.reject(res);
                                }
                            })
                            .catch((err) => {
                                message.error(err.msg);
                            })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                })
        }
        this.getVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, videoType: 0 });
        // this.setState({showDel:true,btnLoading:false,showModal:false,percent:'',spinTip:'请稍后...',loading:false});//进度条
        this.setState({ showDel: true, btnLoading: false, showModal: false, fileList: [] });
    }
    //获取input视频id查询
    getVideoID = (e) => {
        this.setState({ videoID: e.target.value });
    }
    //获取input视频名称查询
    getVideoName = (e) => {
        this.setState({ videoName: e.target.value });
    }
    //获取学科下拉所选value
    getSubject = (value, option) => {
        if (value && option) {
            this.setState({ subjectSel: option.key, subjectName: value, firPointSel: '', firPointName: null, secPointSel: '', secPointName: null, firKnowledgeList: [], secKnowledgeList: [], loading: true }, () => {
                api.getFirstKnowledge('/v1/graph/get/level/first/' + option.key)
                    .then((data) => {
                        if (data.ret === 20000) {
                            this.refs.Subject.blur();
                            this.setState({ firKnowledgeList: data.result, loading: false });
                        } else {
                            return Promise.reject(data);
                        }
                    })
                    .catch((err) => {
                        message.error(err.msg);
                        this.setState({ loading: false });
                    })
            });
        } else {
            this.setState({ subjectSel: '', subjectName: null, firPointSel: '', firPointName: null, secPointSel: '', secPointName: null, firKnowledgeList: [], secKnowledgeList: [] })
        }
    }
    //获取下拉所选一级知识点value
    getFirstPoint = (value, option) => {
        if (value && option) {
            this.setState({ firPointSel: option.key, firPointName: value, secPointSel: '', secKnowledgeList: [], loading: true }, () => {
                api.getSecondKnowledge('/v1/graph/get/level/second/' + option.key)
                    .then((data) => {
                        if (data.ret === 20000) {
                            this.refs.firPoint.blur();
                            this.setState({ secKnowledgeList: data.result, loading: false });
                        } else {
                            return Promise.reject(data);
                        }
                    })
                    .catch((err) => {
                        message.error(err.msg);
                        this.setState({ loading: false });
                    })
            });
        } else {
            this.setState({ firPointSel: '', firPointName: null, secPointSel: '', secPointName: null, secKnowledgeList: [] });
        }
    }
    //获取下拉所选二级知识点value
    getSecondPoint = (value, option) => {
        if (value && option) {
            this.refs.secondPoint.blur();
            this.setState({ secPointSel: option.key, secPointName: value });
        } else {
            this.setState({ secPointSel: '', secPointName: null });
        }
    }
    //查询按钮
    search = () => {
        this.getVideoList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.videoID, videoName: this.state.videoName, subId: this.state.subjectSel, fid: this.state.firPointSel, sid: this.state.secPointSel, videoType: 0 });
    }
    //分页器
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getVideoList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, id: this.state.videoID, videoName: this.state.videoName, subId: this.state.subjectSel, fid: this.state.firPointSel, sid: this.state.secPointSel, videoType: 0 });
        });
    }
    //视频弹框
    //点击视频ID 显示弹框
    videoPreview = (record) => {
        this.setState({ showVideoModal: true, rowInfo: record })
    }
    //编辑弹框
    //列表操作 编辑
    edit = (record) => {
        this.setState({ loading: true, editModal: true, rowInfo: record, videoEditName: record.videoName, videoIntroduction: record.description, videoReword: record.remark, editSubjectName: record.subjectName, editFirPointName: record.levelFirstName, editSecPointName: record.levelSecondName, remark: record.remark, editSubjectSel: record.subId, editFirPointSel: record.fid, editSecPointSel: record.sid }, () => {
            this.getFirstKnowledgeList(this.state.editSubjectSel);
            this.getSecondKnowledgeList(this.state.editFirPointSel);
        })

    }
    //弹框获取一级知识点列表
    getFirstKnowledgeList = (key) => {
        api.getFirstKnowledge('/v1/graph/get/level/first/' + key)
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ editFirKnowledgeList: data.result, loading: false })
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
    }
    //弹框获取二级知识点列表
    getSecondKnowledgeList = (key) => {
        api.getSecondKnowledge('/v1/graph/get/level/second/' + key)
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ editSecKnowledgeList: data.result, loading: false });
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
    }
    //获取视频名称
    getVideoEditName = (e) => {
        this.setState({ videoEditName: e.target.value });
    }
    //获取视频简介textarea
    getVideoIntroduction = (e) => {
        this.setState({ videoIntroduction: e.target.value });
    }
    //获取备注textarea
    getReword = (e) => {
        this.setState({ videoReword: e.target.value });
    }
    //获取下拉所选学科同时获取一级知识点列表
    getEditSubject = (value, option) => {
        if (value && option) {
            this.setState({ editSubjectSel: option.key, editSubjectName: value, editFirPointSel: '', editFirPointName: null, editSecPointSel: '', editSecPointName: null, editFirKnowledgeList: [], editSecKnowledgeList: [], loading: true }, () => {
                this.getFirstKnowledgeList(option.key);
            });
        } else {
            this.setState({ editSubjectSel: '', editSubjectName: null, editFirPointSel: '', editFirPointName: null, editSecPointSel: '', editSecPointName: null, editFirKnowledgeList: [], editSecKnowledgeList: [] })
        }
    }
    //获取下拉所选一级知识点同时获取二级知识点列表
    getEditFirstPoint = (value, option) => {
        if (value && option) {
            this.setState({ editFirPointSel: option.key, editFirPointName: value, editSecPointSel: '', editSecPointName: null, editSecKnowledgeList: [], loading: true }, () => {
                this.getSecondKnowledgeList(option.key);
            });
        } else {
            this.setState({ editFirPointSel: '', editFirPointName: null, editSecPointSel: '', editSecPointName: null, editSecKnowledgeList: [] })
        }
    }
    //获取二级知识点下拉所选学科
    getEditSecondPoint = (value, option) => {
        if (value && option) {
            this.setState({ editSecPointSel: option.key, editSecPointName: value })
        } else {
            this.setState({ editSecPointSel: '', editSecPointName: null })
        }
    }
    //点击查看
    lookUp = (record) => {
        this.setState({ titleList: record.title, showLookUpModal: true });
    }
    //点击关联备考课名 跳转
    goPage = (item) => {
        window.open(api.pageURL + `/admin/v1/testPrepareCourseManage/courseOutline?id=${item.id}`);
    }
    //编辑弹框 确认
    editSubmit = () => {
        this.setState({ loading: true }, () => {
            api.editKnowledgeVideo({ videoName: this.state.videoEditName, description: this.state.videoIntroduction, remark: this.state.videoReword, id: this.state.rowInfo.id, subId: this.state.editSubjectSel, fid: this.state.editFirPointSel, sid: this.state.editSecPointSel })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.setState({ editModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //确认删除popconfig
    confirm = (record) => {
        this.setState({ loading: true }, () => {
            api.delKnowledgeVideo('/v1/video/knowledge/del/' + record.id)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    render() {
        return (
            <Fragment >
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip={this.state.spinTip} size="large">
                    <div className={Style.topWrap}>
                        <div className={Style.firWrap}>
                            <Button icon={<FolderOpenOutlined />} onClick={this.showModal} type='primary'>视频上传</Button>
                            {this.state.showModal ? <Modal close={this.close} title='上传视频' loading={this.state.btnLoading} actions={[<Button onClick={this.close} disabled={this.state.btnLoading}>取消</Button>, <Button type='primary' onClick={this.submit} loading={this.state.btnLoading}>确认上传</Button>]}>
                                <div className={Style.modal}>
                                    <div className={Style.contentTop}>请选择本地视频文件，支持常见的视频格式，可以批量上传（不超过30个）</div>
                                    <Upload
                                        accept='.mp4,.mov'
                                        beforeUpload={()=>false}
                                        onChange={this.handleChange}
                                        fileList={this.state.fileList}
                                        disabled={this.state.btnLoading}
                                        multiple={true}
                                    >
                                        <Button icon={<UploadOutlined />} disabled={this.state.btnLoading}>选择文件</Button>
                                    </Upload>
                                </div>
                            </Modal> : ''}
                            <Divider type="vertical" className={Style.divider} />
                        </div>
                        <div className={Style.selWrap_1}>
                            <Input placeholder='输入视频ID查询' className={Style.input} onChange={this.getVideoID} />
                            <Input placeholder='输入名称查询' className={Style.input} onChange={this.getVideoName} />
                            <div className={Style.boxSubject}>
                                <span className={Style.span}>学科：</span>
                                <Select placeholder='全部' ref='Subject' className={Style.select} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>一级知识点：</span>
                                <Select placeholder='全部' ref='firPoint' className={Style.select} value={this.state.firPointName} onChange={this.getFirstPoint} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.firKnowledgeList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.levelFirstName}>{item.levelFirstName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>二级知识点：</span>
                                <Select placeholder='全部' ref='secondPoint' className={Style.select} value={this.state.secPointName} onChange={this.getSecondPoint} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.secKnowledgeList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.levelSecondName}>{item.levelSecondName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </div>
                        <Button icon={<SearchOutlined />} type='primary' onClick={this.search} >查询</Button>
                    </div>
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {this.state.showVideoModal ? <Modal title='播放视频' close={this.close}>
                        <div >
                            <video id='video' src={this.state.rowInfo.videoUrl} width='700px' height='500px' autoPlay="autoplay" controls="controls"></video>
                        </div>
                    </Modal> : ''}
                    {this.state.showLookUpModal ? <Modal title='关联备考课' close={this.close}>
                        <div className={Style.titleList}>
                            {this.state.titleList.map((item, index) => {
                                return (
                                    <Button type='link' className={Style.title} key={index} onClick={() => { this.goPage(item) }}>{item.title}</Button>
                                )
                            })}
                        </div>
                    </Modal> : ''}
                    {this.state.editModal ? <Modal title='编辑视频信息' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.editSubmit}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>视频名称：</span>
                                <Input className={Style.input} placeholder='请输入视频名称' value={this.state.videoEditName} onChange={this.getVideoEditName} />
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>视频简介：</span>
                                <TextArea className={Style.input} placeholder='请输入视频简介' maxLength='500' value={this.state.videoIntroduction} onChange={this.getVideoIntroduction} /><br />
                                <span className={Style.spanRight}>已输入{this.state.videoIntroduction.length}/500字</span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>备注：</span>
                                <TextArea className={Style.input} placeholder='请输入备注' maxLength='200' value={this.state.videoReword} onChange={this.getReword} defaultValue={this.state.remark} /><br />
                                <span className={Style.spanRight}>已输入{this.state.videoReword.length}/200字</span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>所属学科：</span>
                                <Select placeholder='全部' className={Style.sel} onChange={this.getEditSubject} value={this.state.editSubjectName} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>1级知识点：</span>
                                <Select placeholder='全部' className={Style.sel} onChange={this.getEditFirstPoint} value={this.state.editFirPointName} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.editFirKnowledgeList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.levelFirstName}>{item.levelFirstName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>2级知识点：</span>
                                <Select placeholder='全部' className={Style.sel} onChange={this.getEditSecondPoint} value={this.state.editSecPointName} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.editSecKnowledgeList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.levelSecondName}>{item.levelSecondName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default KnowledgeVideo;