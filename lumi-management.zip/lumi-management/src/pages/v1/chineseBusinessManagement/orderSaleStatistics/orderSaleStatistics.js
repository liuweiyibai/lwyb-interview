import React, { Component, Fragment } from 'react'
import { Spin, Select, DatePicker, Button, Divider, Table, message, Tooltip, Pagination } from 'antd'
import moment from 'moment-timezone';
import Style from './orderSaleStatistics.module.less';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum';

const { Option } = Select;
const { RangePicker } = DatePicker;

class OrderSaleStatistics extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            // 查询项
            productTypeList: [],//商品类型列表
            productType: null,//商品类型
            productTypeId: '',//商品类型ID
            salerList: [],//销售列表
            salerName: null,//销售
            salerNameId: '',//销售ID
            businessLine: null,//业务线
            businessLineID: '',//业务线ID
            startPayTime: moment.tz(new Date(), 'Asia/Shanghai').startOf('month').format('YYYY-MM-DD'),//开始支付时间
            endPayTime: moment.tz(new Date(), 'Asia/Shanghai').format('YYYY-MM-DD'),//结束支付时间
            // 订单总额
            sumChineseReceiveOrderPrice: 0,//订单总额
            // 收款链接弹框
            showReceiveLinkModal: false, // 收款链接弹框
            receiveLinkURL: '',//收款链接
            cloudFront: '',//二维码图片前缀
            qrcode: '',//二维码图片

            dataSource: [],
            page: 1,
            pageSize: 10,
            total: '',
        }
    }
    column = [
        {
            title: '订单号',
            dataIndex: 'orderNo',
            width: '220px',
            align: 'center',
            fixed: 'left',
            ellipsis: {
                showTitle: false,
            },
            render: orderNo => {
                return (
                    <Tooltip placement="top" title={orderNo}>
                        {orderNo}
                    </Tooltip>
                )
            }
        },
        {
            title: '商品类型',
            dataIndex: 'name',
            width: '190px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: name => {
                return (
                    <Tooltip placement="top" title={name}>
                        {name}
                    </Tooltip>
                )
            }
        },
        {
            title: '商品名称',
            dataIndex: 'productName',
            width: '90px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: productName => {
                return (
                    <Tooltip placement="top" title={productName}>
                        {productName}
                    </Tooltip>
                )
            }
        },
        {
            title: '商品价格（RMB）',
            dataIndex: 'price',
            width: '110px',
            align: 'center',
            render: price => {
                return (
                    <Tooltip placement="top" title={Number(Number(price) / 100).toFixed(2)}>
                        {Number(Number(price) / 100).toFixed(2)}
                    </Tooltip>
                )
            }
        },
        {
            title: '付款人',
            dataIndex: 'payer',
            width: '90px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payer => {
                return (
                    <Tooltip placement="top" title={payer}>
                        {payer}
                    </Tooltip>
                )
            }
        },
        {
            title: '付款人微信号',
            dataIndex: 'payerWechat',
            width: '150px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payerWechat => {
                return (
                    <Tooltip placement="top" title={payerWechat}>
                        {payerWechat}
                    </Tooltip>
                )
            }
        },
        {
            title: '业务线',
            dataIndex: 'businessLine',
            width: '150px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: businessLine => {
                return (
                    <Tooltip placement="top" title={businessLine === 'USA' ? '美国' : businessLine === 'UK' ? "英国" : businessLine === 'AUS' ? "澳洲" : businessLine === 'CAR' ? "Career" : null}>
                        {businessLine === 'USA' ? '美国' : businessLine === 'UK' ? "英国" : businessLine === 'AUS' ? "澳洲" : businessLine === 'CAR' ? "Career" : null}
                    </Tooltip>
                )
            }
        },
        {
            title: '支付时间',
            dataIndex: 'payAt',
            width: '180px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payAt => {
                let date = payAt ? moment(new Date(new Date(payAt).getTime() + 28800000)).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '支付方式',
            dataIndex: 'payType',
            align: 'center',
            width: '90px',
            render: payType => {
                return (
                    <Tooltip placement="top" title={payType === 1 ? '微信' : payType === 2 ? '支付宝' : ''}>
                        {payType === 1 ? '微信' : payType === 2 ? '支付宝' : ''}
                    </Tooltip>
                )
            }
        },
        {
            title: '创建时间',
            dataIndex: 'createdAt',
            width: '180px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: createdAt => {
                let date = createdAt ? moment(new Date(new Date(createdAt).getTime() + 28800000)).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '销售人',
            dataIndex: 'cratedByName',
            align: 'center',
            render: cratedByName => {
                return (
                    <Tooltip placement="top" title={cratedByName}>
                        {cratedByName}
                    </Tooltip>
                )
            }
        },
        {
            title: '订单状态',
            dataIndex: 'orderStatus',
            align: 'center',
            render: orderStatus => {
                return (
                    <Tooltip placement="top" title={orderStatus === 0 ? '待支付' : orderStatus === 1 ? '已支付' : orderStatus === 4 ? '已超时' : orderStatus === 3 ? '支付失败' : ''}>
                        {orderStatus === 0 ? '待支付' : orderStatus === 1 ? '已支付' : orderStatus === 4 ? '已超时' : orderStatus === 3 ? '支付失败' : ''}
                    </Tooltip>
                )
            }
        },
        // {
        //     title: '操作项',
        //     width: '200px',
        //     align: 'center',
        //     fixed: 'right',
        //     render: record => {
        //         return (
        //             <div>
        //                 <Button type='primary' onClick={() => { this.receiveLinkModal(record) }}>收款链接</Button>
        //             </div>
        //         )
        //     }
        // },
    ]
    componentDidMount() {
        this.getSalerList();
        this.getChineseProductTypeList();
        this.getChineseReceiveList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    // 获取订单列表
    getChineseReceiveList = () => {
        this.setState({ loading: true }, () => {
            api.getChineseReceiveList({
                businessLine: parseInt(this.state.businessLineID),
                createdBy: this.state.salerNameId,
                end: this.state.endPayTime,
                idisplayLength: this.state.pageSize,
                idisplayStart: this.state.page - 1,
                orderStatus: 1,
                productId: this.state.productTypeId,
                start: this.state.startPayTime,
            }).then((res) => {
                if (res.ret === 20000) {
                    this.setState({ loading: false, dataSource: res.result.data, total: res.result.total })
                    this.getSumChineseReceiveOrderPrice();
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 获取销售下拉列表
    getSalerList = () => {
        this.setState({ loading: true }, () => {
            api.getSupplyChainManageList({
                roleIds: '17,18'
            }).then((res) => {
                if (res.ret === 20000) {
                    this.setState({ loading: false, salerList: res.result })
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 导出订单列表
    exportChineseReceiveOrder = () => {
        this.setState({ loading: true }, () => {
            api.exportChineseReceiveOrder({
                createdBy: this.state.salerNameId,
                end: this.state.endPayTime,
                idisplayLength: '',
                idisplayStart: '',
                orderStatus: 1,
                productId: this.state.productTypeId,
                start: this.state.startPayTime,
            }, { responseType: 'arraybuffer' }).then(
                async (response) => {
                    let parse_result = await fun.ab2str(response);
                    if (parse_result === false) {
                        fun.download(response, `销售成单详情-${moment(new Date()).format('YYYYMMDD')}.xlsx`);
                        this.setState({ loading: false });
                        message.success('导出成功！');
                    } else {
                        if (parse_result.ret === 20000) {
                            message.success(parse_result.msg);
                            this.setState({ loading: false });
                        } else {
                            return Promise.reject(parse_result);
                        }
                    }
                }).catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 收款链接弹框
    receiveLinkModal = (record) => {
        this.setState({
            showReceiveLinkModal: true, receiveLinkURL: record.payUrl, cloudFront: record.cloudFront, qrcode: record.qrcode,
        })
    }
    // 获取商品类型列表
    getChineseProductTypeList = () => {
        this.setState({ loading: true }, () => {
            api.getChineseProductTypeList().then((res) => {
                if (res.ret === 20000) {
                    let productTypeList = res.result.filter((item, index) => {
                        return item.deleted === 0
                    })
                    this.setState({ loading: false, productTypeList: productTypeList })
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 改变业务线
    changeBusinessLine = (value, option) => {
        if (value && option) {
            this.refs.businessLine.blur();
            this.setState({ businessLine: value, businessLineID: option.key }, () => {
                fun.setItem('businessLine', { businessLine: value, businessLineID: option.key })
            });
        } else {
            this.setState({ businessLine: null, businessLineID: '' });
        }
    }
    // 订单总金额
    getSumChineseReceiveOrderPrice = () => {
        this.setState({ loading: true }, () => {
            api.sumChineseReceiveOrderPrice({
                businessLine: this.state.businessLineID,
                createdBy: this.state.salerNameId,
                end: this.state.endPayTime,
                idisplayLength: this.state.pageSize,
                idisplayStart: this.state.page - 1,
                orderStatus: 1,
                productId: this.state.productTypeId,
                start: this.state.startPayTime,
            }).then((res) => {
                if (res.ret === 20000) {
                    this.setState({ sumChineseReceiveOrderPrice: Number(Number(res.result) / 100).toFixed(2), loading: false });
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 改变商品类型
    changeProductType = (value, option) => {
        if (value && option) {
            this.refs.productType.blur();
            this.setState({ productType: value, productTypeId: option.key });
        } else {
            this.setState({ productType: null, productTypeId: '' });
        }
    }
    // 改变销售
    changeSaler = (value, option) => {
        if (value && option) {
            this.refs.salerName.blur();
            this.setState({ salerName: value, salerNameId: option.key });
        } else {
            this.setState({ salerName: null, salerNameId: '' });
        }
    }
    // 改变支付时间
    chanegPayTime = (date, dateString) => {
        this.refs.startPayTime.blur();
        if (date && dateString) {
            let startAt = date[0] ? moment(date[0]).format('YYYY-MM-DD') : '';
            let endAt = date[1] ? moment(date[1]).format('YYYY-MM-DD') : '';
            this.setState({ startPayTime: startAt, endPayTime: endAt });
        }
        else {
            this.setState({ startPayTime: null, endPayTime: null });
        }
    }
    //复制收款链接
    copyReceiveLink = () => {
        let input = document.createElement('input');
        input.value = this.state.receiveLinkURL;
        input.setAttribute('display', 'none');
        document.body.appendChild(input);
        input.select();
        document.execCommand("Copy");
        document.body.removeChild(input);
        message.success("链接复制成功");
    }
    // 查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getChineseReceiveList();
        })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getChineseReceiveList();
        })
    }
    // 关闭弹框
    close = () => {
        this.setState({
            // 收款链接弹框
            showReceiveLinkModal: false, // 收款链接弹框
            receiveLinkURL: '',//收款链接
            cloudFront: '',//二维码图片前缀
            qrcode: '',//二维码图片
        })
    }
    render() {
        return (
            <Fragment>
                <Spin tip='请稍后...' spinning={this.state.loading}>
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <div className={Style.box}>
                                <span className={Style.span}>商品类型：</span>
                                <Select value={this.state.productType} ref='productType' className={Style.selectType} placeholder='全部' allowClear onChange={this.changeProductType}>
                                    {this.state.productTypeList.map((item) => {
                                        return (
                                            <Option value={item.name} key={item.id}>{item.name}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>销售：</span>
                                <Select value={this.state.salerName} ref='salerName' className={Style.select} placeholder='全部' allowClear onChange={this.changeSaler}>
                                    {this.state.salerList.map((item) => {
                                        return (
                                            <Option value={item.userName} key={item.userId}>{item.userName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>业务线：</span>
                                <Select value={this.state.businessLine} ref='businessLine' placeholder='全部' className={Style.select} allowClear onChange={this.changeBusinessLine}>
                                    <Option value={'美国'} key={1}>美国</Option>
                                    <Option value={'英国'} key={2}>英国</Option>
                                    <Option value={'澳洲'} key={3}>澳洲</Option>
                                    <Option value={'Career'} key={4}>Career</Option>
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>创建时间：</span>
                                {/* <RangePicker onChange={this.chanegPayTime} className={Style.selectTime} ref='startPayTime' defaultValue={[moment().startOf('month'), moment(new Date(), 'YYYY-MM-DD')]}
                                    disabledDate={(date) => {
                                        return date > moment().startOf(1, 'day')
                                    }} /> */}
                                <RangePicker className={Style.selectTime} onChange={this.chanegPayTime} ref='startPayTime' defaultValue={[moment.tz(new Date(), 'Asia/Shanghai').startOf('month'), moment.tz(new Date(), 'Asia/Shanghai')]}
                                    disabledDate={(date) => {
                                        return date > moment.tz(new Date(), 'Asia/Shanghai').startOf(1, 'day')
                                    }}
                                />
                            </div>
                        </div>
                        <div className={Style.rightWrap}>
                            <Button className={Style.right} type='primary' onClick={this.search}>查询</Button>
                            <Button className={Style.right} type='primary' onClick={this.exportChineseReceiveOrder}>导出</Button>
                        </div>
                    </div>
                    <Divider />
                    <div className={Style.title}>
                        符合条件的已支付订单<span className={Style.inner}>共{this.state.total}个</span>，订单总额RMB<span className={Style.inner}>¥{this.state.sumChineseReceiveOrderPrice}元</span>
                    </div>
                    <Table
                        columns={this.column}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                        scroll={{ x: 1800 }}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} ></Pagination>
                    {/* 收款链接 */}
                    {/* {this.state.showReceiveLinkModal ? <Modal title='收款链接' close={this.close}>
                        <div className={Style.receiveLinkWrap}>
                            <div className={Style.box}>
                                <span className={Style.span}>收款链接：</span>
                                <span>{this.state.receiveLinkURL}</span>
                                <Button type='link' className={Style.button} onClick={this.copyReceiveLink}>复制链接</Button>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>二维码：</span>
                                <div className={Style.imgWrap}>
                                    <img src={this.state.cloudFront + this.state.qrcode} alt='img' className={Style.img} />
                                </div>
                            </div>
                        </div>
                    </Modal> : ''} */}
                </Spin>
            </Fragment>
        );
    }
}
export default OrderSaleStatistics;