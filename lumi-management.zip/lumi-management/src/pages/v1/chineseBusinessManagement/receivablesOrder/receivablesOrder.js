import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Spin, Select, DatePicker, Button, Divider, Table, Input, InputNumber, Tooltip, message, Pagination, Popconfirm } from 'antd';
import { LoadingOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import moment from 'moment-timezone';
// import moment from 'moment';
import Style from './receivablesOrder.module.less';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum';
import imgAll from '../../../../asset/modal.jpeg';
import imgCar from '../../../../asset/modalCar.jpeg';

const { Option } = Select;
const { RangePicker } = DatePicker;
const { TextArea } = Input;

class ReceivablesOrder extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            // 查询项
            productTypeList: [],//商品类型列表
            productType: null,//商品类型
            productTypeId: '',//商品类型ID
            orderStatus: null,//订单状态
            orderStatusId: '',//订单状态ID
            startPayTime: moment.tz(new Date(), 'Asia/Shanghai').startOf('month').format('YYYY-MM-DD'),//开始支付时间
            endPayTime: moment.tz(new Date(), 'Asia/Shanghai').format('YYYY-MM-DD'),//结束支付时间
            // endPayTime: '',
            // 创建收款订单弹框
            showCreateReceiveOrderModal: false,//创建收款订单弹框
            payName: '',//支付人
            payWeChatNum: '',//支付人微信号
            businessLine: null,//业务线
            businessLineID: '',//业务线ID
            orderProductType: null,//商品类型
            orderProductTypeId: '',//商品类型ID
            productName: '',//商品名称
            productPrice: null,//商品价格
            orderRemark: '',//订单备注
            // 编辑收款订单弹框
            showEditReceiveOrderModal: false,//编辑收款订单弹框
            editReceiveOrderId: null,//编辑的订单
            // 维护商品类型弹框
            showKeepProductTypeModal: false, // 维护商品类型弹框
            addKeepProductTypeModal: false,//新增商品类型
            // 收款链接弹框
            showReceiveLinkModal: false, // 收款链接弹框
            receiveLinkURL: '',//收款链接
            cloudFront: '',//二维码图片前缀
            qrcode: '',//二维码图片
            status: 'default',

            dataSource: [],
            page: 1,
            pageSize: 10,
            total: '',
        }
    }
    column = [
        {
            title: '订单号',
            dataIndex: 'orderNo',
            width: '220px',
            align: 'center',
            fixed: 'left',
            ellipsis: {
                showTitle: false,
            },
            render: orderNo => {
                return (
                    <Tooltip placement="top" title={orderNo}>
                        {orderNo}
                    </Tooltip>
                )
            }
        },
        {
            title: '商品类型',
            dataIndex: 'name',
            width: '190px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: name => {
                return (
                    <Tooltip placement="top" title={name}>
                        {name}
                    </Tooltip>
                )
            }
        },
        {
            title: '商品名称',
            dataIndex: 'productName',
            width: '90px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: productName => {
                return (
                    <Tooltip placement="top" title={productName}>
                        {productName}
                    </Tooltip>
                )
            }
        },
        {
            title: '商品价格（RMB）',
            dataIndex: 'price',
            width: '110px',
            align: 'center',
            render: price => {
                return (
                    <Tooltip placement="top" title={Number(Number(price) / 100).toFixed(2)}>
                        {Number(Number(price) / 100).toFixed(2)}
                    </Tooltip>
                )
            }
        },
        {
            title: '付款人',
            dataIndex: 'payer',
            width: '90px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payer => {
                return (
                    <Tooltip placement="top" title={payer}>
                        {payer}
                    </Tooltip>
                )
            }
        },
        {
            title: '付款人微信号',
            dataIndex: 'payerWechat',
            width: '150px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payerWechat => {
                return (
                    <Tooltip placement="top" title={payerWechat}>
                        {payerWechat}
                    </Tooltip>
                )
            }
        },
        {
            title: '支付时间',
            dataIndex: 'payAt',
            width: '180px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payAt => {
                let date = payAt ? moment(new Date(new Date(payAt).getTime() + 28800000)).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '支付方式',
            dataIndex: 'payType',
            align: 'center',
            width: '90px',
            render: payType => {
                return (
                    <Tooltip placement="top" title={payType === 1 ? '微信' : payType === 2 ? '支付宝' : ''}>
                        {payType === 1 ? '微信' : payType === 2 ? '支付宝' : ''}
                    </Tooltip>
                )
            }
        },
        {
            title: '创建时间(BJ)',
            dataIndex: 'createdAt',
            width: '180px',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: createdAt => {
                let date = createdAt ? moment(new Date(createdAt).getTime() + 28800000).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '销售人',
            dataIndex: 'cratedByName',
            align: 'center',
            render: cratedByName => {
                return (
                    <Tooltip placement="top" title={cratedByName}>
                        {cratedByName}
                    </Tooltip>
                )
            }
        },
        {
            title: '订单状态',
            dataIndex: 'orderStatus',
            align: 'center',
            render: orderStatus => {
                return (
                    <Tooltip placement="top" title={orderStatus === 0 ? '待支付' : orderStatus === 1 ? '已支付' : orderStatus === 4 ? '已超时' : orderStatus === 3 ? '支付失败' : ''}>
                        {orderStatus === 0 ? '待支付' : orderStatus === 1 ? '已支付' : orderStatus === 4 ? '已超时' : orderStatus === 3 ? '支付失败' : ''}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            width: '200px',
            align: 'center',
            fixed: 'right',
            render: record => {
                return (
                    <div>
                        <Button type='primary' className={Style.buttonLeft} onClick={() => { this.editReceiveOrder(record) }}>编辑</Button>
                        <Button type='primary' onClick={() => { this.receiveLinkModal(record) }}>收款链接</Button>
                    </div>
                )
            }
        },
    ]
    productTypeColumn = [
        {
            title: '商品类型',
            dataIndex: 'name',
            render: name => {
                return (
                    <Tooltip>{name}</Tooltip>
                )
            }
        },
        {
            title: '操作',
            render: (record) => {
                return (
                    record.deleted === 1 ? <Button type='primary' disabled={record.deleted === 1}>已删除 </Button> : <Popconfirm title="确定要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.deleteProductType(record) }}>
                        <Button type='primary' disabled={record.deleted === 1}>删除</Button>
                    </Popconfirm>
                )
            }
        }
    ]
    componentDidMount() {
        this.getChineseProductTypeList();
        this.getChineseReceiveList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    // 获取订单列表
    getChineseReceiveList = () => {
        this.setState({ loading: true }, () => {
            api.getChineseReceiveList({
                createdBy: this.props.userid,
                idisplayLength: this.state.pageSize,
                idisplayStart: this.state.page - 1,
                orderStatus: this.state.orderStatusId,
                productId: this.state.productTypeId,
                start: this.state.startPayTime ,
                end: this.state.endPayTime,
            }).then((res) => {
                if (res.ret === 20000) {
                    this.setState({ loading: false, dataSource: res.result.data, total: res.result.total })
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 获取商品类型列表
    getChineseProductTypeList = () => {
        this.setState({ loading: true }, () => {
            api.getChineseProductTypeList().then((res) => {
                if (res.ret === 20000) {
                    this.setState({ loading: false, productTypeList: res.result })
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 删除商品类型
    deleteProductType = (record) => {
        this.setState({ loading: true }, () => {
            api.deleteChineseProductType({
                id: record.id
            }).then((res) => {
                if (res.ret === 20000) {
                    message.success(res.msg);
                    this.getChineseProductTypeList();
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 改变商品类型
    changeProductType = (value, option) => {
        if (value && option) {
            this.refs.productType.blur();
            this.setState({ productType: value, productTypeId: option.key });
        } else {
            this.setState({ productType: null, productTypeId: '' });
        }
    }
    // 改变订单类型
    changeOrderStatus = (value, option) => {
        if (value && option) {
            this.refs.orderStatus.blur();
            this.setState({ orderStatus: value, orderStatusId: option.key });
        } else {
            this.setState({ orderStatus: null, orderStatusId: '' });
        }
    }
    // 改变支付时间
    chanegPayTime = (time, timeString) => {
        this.refs.startPayTime.blur();
        this.setState({ startPayTime: timeString[0] ? timeString[0] : null, endPayTime: timeString[1] ? timeString[1] : null });
    }
    // 显示创建收款订单弹框
    createReceiveOrder = () => {
        let obj = fun.getItem('businessLine');
        obj = JSON.parse(obj);
        this.setState({ showCreateReceiveOrderModal: true, businessLine: obj ? obj.businessLine : null, businessLineID: obj ? obj.businessLineID : null })
    }
    // 显示编辑收款订单弹框
    editReceiveOrder = (record) => {
        this.setState({
            showEditReceiveOrderModal: true,
            editReceiveOrderId: record.id,
            payName: record.payer,
            payWeChatNum: record.payerWechat,
            productPrice: Number(Number(record.price) / 100).toFixed(2),
            orderProductTypeId: record.id,
            orderProductType: record.name,
            productName: record.productName,
            orderRemark: record.remark,
            businessLine: record.businessLine === 'USA' ? '美国' : record.businessLine === 'UK' ? "英国" : record.businessLine === 'AUS' ? "澳洲" : record.businessLine === 'CAR' ? "Career" : null,
            businessLineID: record.businessLine === 'USA' ? 1 : record.businessLine === 'UK' ? 2 : record.businessLine === 'AUS' ? 3 : record.businessLine === 'CAR' ? 4 : null
        })
    }
    // 改变输入框的值
    changeInputValue = (e, type) => {
        let obj = {};
        obj[type] = e.target.value;
        this.setState(obj);
    }
    // 改变输入框的值
    changeValue = (e, type) => {
        let obj = {};
        obj[type] = e;
        this.setState(obj);
    }
    // 改变输入框的值
    changePrice = (e, type) => {
        let obj = {};
        obj[type] = parseInt(e).toString();
        this.setState(obj);
    }
    // 改变订单商品类型
    changeOrderProductType = (value, option) => {
        if (value && option) {
            this.refs.orderProductType.blur();
            this.setState({ orderProductType: value, orderProductTypeId: option.key });
        } else {
            this.setState({ orderProductType: null, orderProductTypeId: '' });
        }
    }
    // 改变业务线
    changeBusinessLine = (value, option) => {
        if (value && option) {
            this.refs.businessLine.blur();
            this.setState({ businessLine: value, businessLineID: option.key }, () => {
                fun.setItem('businessLine', { businessLine: value, businessLineID: option.key })
            });
        } else {
            this.setState({ businessLine: null, businessLineID: '' });
        }
    }
    // 显示维护商品类型弹框
    keepProductTypeModal = () => {
        if (this.props.powerArr.indexOf(18) !== -1) {
            this.setState({ showKeepProductTypeModal: true })
        } else {
            message.error('无操作权限！')
        }
    }
    // 新增商品类型
    addKeepProductTypeModalClick = () => {
        this.setState({ addKeepProductTypeModal: true })
    }
    // 新增商品类型确定
    addKeepProductTypeSubmit = () => {
        this.setState({ loading: true }, () => {
            api.createChineseProductType({
                name: this.state.addKeepProductTypeName
            }).then((res) => {
                if (res.ret === 20000) {
                    message.success(res.msg);
                    this.setState({ addKeepProductTypeName: '', addKeepProductTypeModal: false });
                    this.getChineseProductTypeList();
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 取消新增商品
    cancelAddKeepProductTypeModal = () => {
        this.setState({ addKeepProductTypeModal: false, addKeepProductTypeName: '', })
    }
    // 创建订单
    createChineseReceiveOrder = () => {
        this.setState({ loading: true }, () => {
            api.createChineseReceiveOrder({
                orderDesc: "",
                payType: '',
                payer: this.state.payName,
                payerWechat: this.state.payWeChatNum,
                price: this.state.productPrice * 100,
                productId: this.state.orderProductTypeId,
                productName: this.state.productName,
                remark: this.state.orderRemark,
                businessLine: this.state.businessLineID
            }).then((res) => {
                if (res.ret === 20000) {
                    message.success(res.msg);
                    this.setState({ dataSource: res.result.data });
                    this.close();
                    this.getChineseReceiveList();
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 编辑订单
    editChineseReceiveOrder = () => {
        this.setState({ loading: true }, () => {
            api.editChineseReceiveOrder({
                id: this.state.editReceiveOrderId,
                payer: this.state.payName,
                payerWechat: this.state.payWeChatNum,
                remark: this.state.orderRemark
            }).then((res) => {
                if (res.ret === 20000) {
                    message.success(res.msg);
                    this.setState({ dataSource: res.result.data });
                    this.close();
                    this.getChineseReceiveList();
                } else {
                    return Promise.reject(res);
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // 收款链接弹框
    receiveLinkModal = (record) => {
        this.setState({ loading: true }, () => {

            let formData = new FormData();
            formData.append('url', record.cloudFront + record.qrcode);
            api.changeInternetPic(formData).then((res) => {
                let qrCodeImg = new Image();
                qrCodeImg.src = 'data:image/jpg;base64,' + res;
                let canvas = this.refs.canvas;
                canvas.width = 844;
                canvas.height = 1500;
                const ctx = canvas.getContext('2d');
                let bottomImg = new Image();
                if (record.businessLine === "CAR") {
                    bottomImg.src = imgCar;
                } else {
                    bottomImg.src = imgAll;
                }
                bottomImg.onload = () => {
                    ctx.drawImage(bottomImg, 0, 0, 844, 1500);
                    ctx.drawImage(qrCodeImg, 200, 878, 450, 450);
                    let imgurl = canvas.toDataURL()
                    this.setState({ loading: false, qrcode: imgurl });
                }
            }).catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
        this.setState({
            showReceiveLinkModal: true, receiveLinkURL: record.payUrl, cloudFront: record.cloudFront, qrcode: record.qrcode,
        })
    }
    //复制收款链接
    copyReceiveLink = () => {
        let input = document.createElement('input');
        input.value = this.state.receiveLinkURL;
        input.setAttribute('display', 'none');
        document.body.appendChild(input);
        input.select();
        document.execCommand("Copy");
        document.body.removeChild(input);
        message.success("链接复制成功");
    }
    // 查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getChineseReceiveList();
        })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getChineseReceiveList();
        })
    }
    // 关闭弹框
    close = () => {
        this.setState({
            // 创建收款订单弹框
            showCreateReceiveOrderModal: false,//创建收款订单弹框
            payName: '',//支付人
            payWeChatNum: '',//支付人微信号
            businessLine: null,//业务线
            businessLineID: '',//业务线ID
            orderProductType: null,//商品类型
            orderProductTypeId: '',//商品类型ID
            productName: '',//商品名称
            productPrice: null,//商品价格
            orderRemark: '',//订单备注
            // 编辑收款订单弹框
            showEditReceiveOrderModal: false,//编辑收款订单弹框
            editReceiveOrderId: null,//编辑的订单
            // 维护商品类型弹框
            showKeepProductTypeModal: false, // 维护商品类型弹框
            addKeepProductTypeModal: false,//新增商品类型
            // 收款链接弹框
            showReceiveLinkModal: false, // 收款链接弹框
            receiveLinkURL: '',//收款链接
            cloudFront: '',//二维码图片前缀
            qrcode: '',//二维码图片
        })
    }
    touchStart = () => {
        this.pressTime = setTimeout(() => {
            var a = document.createElement('a');
            a.href = this.state.qrcode;
            a.download = this.state.qrcode.replace(/(.*\/)*([^.]+.*)/ig, "$2").split("?")[0];
            a.click();
            // var e = document.createEvent('MouseEvents');
            // e.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            // a.dispatchEvent(e);
            // this.state.qrcode.revokeObjectURL(url);
            this.setState({
                status: this.state.status === 'marked' ? 'default' : 'marked'
            });
        }, '1000');
    }
    handleTouchEnd = () => {
        clearTimeout(this.pressTime);
    }
    render() {
        let reviewDisabled = this.state.payName.length === 0 || this.state.orderProductType === null || this.state.productName.length === 0 || this.state.productPrice === null || Number(this.state.productPrice) === 0 || this.state.businessLine === null;
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍后...' size='large'>
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <div className={Style.box}>
                                <span className={Style.span}>商品类型：</span>
                                <Select value={this.state.productType} ref='productType' className={Style.selectType} placeholder='全部' allowClear onChange={this.changeProductType}>
                                    {this.state.productTypeList.filter((item) => {
                                        return item.deleted === 0
                                    }).map((item) => {
                                        return (
                                            <Option value={item.name} key={item.id}><Tooltip title={item.name}>{item.name}</Tooltip></Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>订单状态：</span>
                                <Select value={this.state.orderStatus} ref='orderStatus' className={Style.select} placeholder='全部' allowClear onChange={this.changeOrderStatus}>
                                    <Option value={'待支付'} key={0}>待支付</Option>
                                    <Option value={'已支付'} key={1}>已支付</Option>
                                    <Option value={'支付失败'} key={3}>支付失败</Option>
                                    <Option value={'已超时'} key={4}>已超时</Option>
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>创建时间(BJ)：</span>
                                <RangePicker className={Style.selectTime} onChange={this.chanegPayTime} ref='startPayTime' defaultValue={[moment.tz(new Date(), 'Asia/Shanghai').startOf('month'), moment.tz(new Date(), 'Asia/Shanghai')]}
                                    disabledDate={(date) => {
                                        return date > moment.tz(new Date(), 'Asia/Shanghai').startOf(1, 'day')
                                    }}
                                />
                            </div>
                        </div>
                        <Button className={Style.right} type='primary' onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <div className={Style.buttonList}>
                        <Button type='primary' className={Style.button} onClick={this.createReceiveOrder}>创建收款订单</Button>
                        <Button type='primary' className={Style.button} onClick={this.keepProductTypeModal}>维护商品类型</Button>
                        <Button type='link' className={Style.button} onClick={() => {
                            if (this.props.powerArr.indexOf(18) !== -1) {
                                this.props.history.push(`/admin/v1/chineseBusinessManagement/orderSaleStatistics`)
                            } else {
                                message.error('无查看权限!')
                            }
                        }}>销售成单统计</Button>
                    </div>
                    <Table
                        columns={this.column}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                        scroll={{ x: 1700 }}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} ></Pagination>
                    {/* 新增/编辑收款订单弹框 */}
                    {this.state.showCreateReceiveOrderModal || this.state.showEditReceiveOrderModal ? <Modal title={this.state.showCreateReceiveOrderModal ? '创建收款订单' : this.state.showEditReceiveOrderModal ? '编辑收款订单' : ''} close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.state.showCreateReceiveOrderModal ? this.createChineseReceiveOrder : this.state.showEditReceiveOrderModal ? this.editChineseReceiveOrder : this.createChineseReceiveOrder} disabled={reviewDisabled}>{this.state.showCreateReceiveOrderModal ? '创建' : this.state.showEditReceiveOrderModal ? '编辑' : '创建'}</Button>]}>
                        <div className={Style.hint}><ExclamationCircleOutlined className={Style.icon} />订单有效期6小时，创建后尽快将收款链接发给用户</div>
                        <div className={Style.boxWrap}>
                            <div className={Style.box}>
                                <span className={Style.span}>付款人<span className={Style.red}>*</span>：</span>
                                <Input value={this.state.payName} className={Style.select} placeholder='填写学生姓名，不超过20个字符' maxLength='20' onChange={(e) => { this.changeInputValue(e, 'payName') }}></Input>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>付款人微信号：</span>
                                <Input value={this.state.payWeChatNum} className={Style.select} placeholder='填写学生微信号，不超过20个字符' maxLength='20' onChange={(e) => { this.changeInputValue(e, 'payWeChatNum') }}></Input>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>业务线<span className={Style.red}>*</span>：</span>
                                <Select value={this.state.businessLine} ref='businessLine' className={Style.select} placeholder='请选择业务线' allowClear onChange={this.changeBusinessLine} disabled={this.state.showEditReceiveOrderModal}>
                                    <Option value={'美国'} key={1}>美国</Option>
                                    <Option value={'英国'} key={2}>英国</Option>
                                    <Option value={'澳洲'} key={3}>澳洲</Option>
                                    <Option value={'Career'} key={4}>Career</Option>
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>商品类型<span className={Style.red}>*</span>：</span>
                                <Select value={this.state.orderProductType} ref='orderProductType' className={Style.select} placeholder='全部' allowClear onChange={this.changeOrderProductType} disabled={this.state.showEditReceiveOrderModal}>
                                    {this.state.productTypeList.filter((item) => {
                                        return item.deleted === 0
                                    }).map((item) => {
                                        return (
                                            <Option value={item.name} key={item.id}>{item.name}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>商品名称<span className={Style.red}>*</span>：</span>
                                <Input value={this.state.productName} className={Style.select} placeholder='不超过20个字符' maxLength='20' onChange={(e) => { this.changeInputValue(e, 'productName') }} disabled={this.state.showEditReceiveOrderModal}></Input>
                            </div>
                            <div className={Style.boxInner}>
                                <div className={Style.select}>商品名称会显示在用户看到的收款页面上，谨慎填写</div>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>商品价格<span className={Style.red}>*</span>：</span>
                                <InputNumber value={this.state.productPrice} min='0' className={Style.select} placeholder='以元为单位，不超过6位' maxLength='6' onChange={(e) => { this.changePrice(e, 'productPrice') }} disabled={this.state.showEditReceiveOrderModal}></InputNumber>元RMB
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>订单备注：</span>
                                <TextArea value={this.state.orderRemark} className={Style.select} placeholder='不超过100个字符' maxLength={100} rows='4' onChange={(e) => { this.changeInputValue(e, 'orderRemark') }} ></TextArea>
                                <span></span>
                            </div>
                            <div className={Style.boxOut}>
                                <div className={Style.des}>{this.state.orderRemark.length}/100</div>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>预览收款页面：</span>
                                <Button type='primary' disabled={reviewDisabled || !this.state.showCreateReceiveOrderModal} onClick={() => { window.open(`https://dev-h5.lumiclass.com/activity/pay-h5-static/?productName=${this.state.productName}&productPrice=${this.state.productPrice}`) }}>预览</Button>
                            </div>
                            <div className={Style.boxInner}>
                                <div className={Style.select}> 订单创建后无法修改，可先预览收款页面</div>
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 维护商品类型 */}
                    {this.state.showKeepProductTypeModal ? <Modal title='维护商品类型' close={this.close} actions={[<Button onClick={this.close} type='primary'>取消</Button>, <Button ></Button>]}>
                        <div className={Style.keepProductTypeTopWrap}>
                            {this.state.addKeepProductTypeModal ?
                                <div className={Style.keepProductTypeTop}>
                                    <Input value={this.state.addKeepProductTypeName} placeholder='输入商品类型名称，不超过20个字符' className={Style.input} onChange={(e) => { this.changeInputValue(e, 'addKeepProductTypeName') }}></Input>
                                    <Button type='primary' className={Style.button} onClick={this.addKeepProductTypeSubmit}>保存</Button>
                                    <Button type='primary' onClick={this.cancelAddKeepProductTypeModal}>取消</Button>
                                </div>
                                : <Button type='primary' onClick={this.addKeepProductTypeModalClick}>添加商品类型</Button>}
                        </div>
                        <Table
                            columns={this.productTypeColumn}
                            dataSource={this.state.productTypeList}
                            rowKey={dataSource => dataSource.id}
                            bordered={true}
                            pagination={false}>
                        </Table>
                    </Modal> : ''}
                    {/* 收款链接 */}
                    {this.state.showReceiveLinkModal ? <Modal title='收款链接' close={this.close}>
                        <div className={Style.receiveLinkWrap}>
                            <div className={Style.box}>
                                <span className={Style.span}>收款链接：</span>
                                <span>{this.state.receiveLinkURL}</span>
                                <Button type='link' className={Style.button} onClick={this.copyReceiveLink}>复制链接</Button>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>二维码：</span>
                                <div className={Style.imgWrap} style={{ height: '450px' }} >
                                    < canvas ref='canvas' style={{ transform: 'scale(0.3,0.3)', border: '1px solid black' }}
                                        onClick={() => { }}
                                        onContextMenu={(e) => {
                                            e.stopPropagation();//这两行是为了阻止出现浏览器菜单
                                            e.preventDefault();
                                            if (this.pressTime) { return; } //如果touchstart触发，说明是触屏，这个方法不往下执行。
                                            this.setState({
                                                status: this.state.status === 'marked' ? 'default' : 'marked'
                                            });
                                        }}

                                        onTouchStart={this.touchStart}
                                        onTouchEnd={this.handleTouchEnd}
                                    ></ canvas>
                                </div>
                            </div>
                            <div className={Style.boxDownload}>
                                <Button type='primary' onClick={() => {
                                    var a = document.createElement('a');
                                    a.href = this.state.qrcode
                                    a.download = ''
                                    a.click()
                                }}>下载图片</Button>
                            </div>
                        </div>
                    </Modal> : ''}
                </Spin >
            </Fragment >
        );
    }
}
export default connect(store => store)(withRouter(ReceivablesOrder));