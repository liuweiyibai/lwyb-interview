import React,{Component,Fragment} from 'react';
import { Spin, Divider, message } from 'antd';
import {LoadingOutlined} from '@ant-design/icons';
import Style from './businessData.module.less';
import api from '../../../../utils/api';
//按需引入echarts
import ReactEcharts from 'echarts-for-react';
import 'echarts/lib/chart/bar';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/title';
import moment from 'moment';

class BusinessData extends Component{
    constructor(){
        super();
        this.state={
            loading:false,
            ordersNumData:[],//备考课付费订单数量 图表
            ordersQOQData:[],//备考课付费订单数量 环比
            vipNumData:[],//每周新增付费会员数量 图表
            vipQOQData:[],//每周新增付费会员数量 环比
            saleGMVNumData:[],//每周备考课销售GMV 图表
            saleGMVQOQData:[],//每周备考课销售GMV 环比
            subscribeBMVNumData:[],//每周付费会员订阅GMV 图表
            subscribeBMVQOQData:[],//每周付费会员订阅GMV 环比
        }
    }
    componentDidMount(){
        this.getBusinessData();
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    customMap=(arr)=>{
        return arr.map(item=>{
            let obj={};
            obj.value=(item.value*100).toFixed(2);
            return obj;
        });
    }
    getBusinessData=()=>{
        this.setState({loading:true},()=>{
            api.getBusinessData()
            .then((data)=>{
                if(data.ret === 20000 && Array.isArray(data.result.countAndRate) && data.result.countAndRate.length>0){
                    this.setState({
                        ordersNumData:data.result.countAndRate[0].count,//备考课付费订单数量 柱图
                        ordersQOQData:this.customMap(data.result.countAndRate[0].rate),//备考课付费订单数量 环比
                        vipNumData:data.result.countAndRate[1].count,//备考课付费订单数量 柱图
                        vipQOQData:this.customMap(data.result.countAndRate[1].rate),//备考课付费订单数量 环比
                        saleGMVNumData:data.result.countAndRate[2].count,//备考课付费订单数量 柱图
                        saleGMVQOQData:this.customMap(data.result.countAndRate[2].rate),//备考课付费订单数量 环比
                        subscribeBMVNumData:data.result.countAndRate[3].count,//备考课付费订单数量 柱图
                        subscribeBMVQOQData:this.customMap(data.result.countAndRate[3].rate),//备考课付费订单数量 环比
                        loading:false
                    })
                }else{
                    return Promise.reject(data);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    // [左y轴name,右y轴name]，柱形图数据，柱形图颜色，折线图数据，折线图颜色
    getOption = (legendData,columnData,columnColor,lineData,lineColor) => {
        let option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#283b56'
                    }
                },
                formatter: '{a}: {c}<br />{a1}: {c1}%'
            },
            legend: {
                data:legendData//关联series.name
            },
            toolbox: {
                show: true,//是否显示工具栏组件。
                orient: "horizontal",//工具栏 icon 的布局朝向。"horizontal"横向/'vertical'纵向
                itemSize: 15,//工具栏 icon 的大小。
                itemGap: 10,//工具栏 icon 每项之间的间隔。横向布局时为水平间隔，纵向布局时为纵向间隔。
                feature: {
                    restore: {},//配置项还原。
                    saveAsImage: {}//保存为图片
                },//各工具配置项。
                showTitle: true,//是否在鼠标 hover 的时候显示每个工具 icon 的标题。
            },//工具栏。内置有导出图片，数据视图，动态类型切换，数据区域缩放，重置五个工具。
            xAxis: [
                {
                    //下x轴
                    type: 'category',//category类目轴 value数值轴 time时间轴 log对数轴
                    boundaryGap: true,//坐标两边留白
                    data:[
                            {value : moment().week(moment().week()-4).startOf('week').format('YYYY/MM/DD')+'-'+moment().week(moment().week()-4).endOf('week').format('YYYY/MM/DD'),},
                            {value : moment().week(moment().week()-3).startOf('week').format('YYYY/MM/DD')+'-'+moment().week(moment().week()-3).endOf('week').format('YYYY/MM/DD')},
                            {value : moment().week(moment().week()-2).startOf('week').format('YYYY/MM/DD')+'-'+moment().week(moment().week()-2).endOf('week').format('YYYY/MM/DD')},
                            {value : moment().week(moment().week()-1).startOf('week').format('YYYY/MM/DD')+'-'+moment().week(moment().week()-1).endOf('week').format('YYYY/MM/DD')},
                            {value : moment().week(moment().week()).startOf('week').format('YYYY/MM/DD')+'-'+moment().format('YYYY/MM/DD')}
                        ]
                },
            ],
            yAxis: [
                {
                    //左y轴
                    type: 'value',
                    scale: true,//是否是脱离 0 值比例。设置成 true 后坐标刻度不会强制包含零刻度。在双数值轴的散点图中比较有用
                    name: legendData[0],
                    max:Math.ceil(Math.max(...columnData.map( item => item.value ))).toString().length>2 ? Math.ceil(Math.max(...columnData.map( item => item.value ))/100+0.001)*100 : Math.ceil(Math.max(...columnData.map( item => item.value ))/10+0.001)*10,//左y轴最大值
                    min: 0,
                    splitNumber: 5,//坐标轴的分割段数，需要注意的是这个分割段数只是个预估值，最后实际显示的段数会在这个基础上根据分割后坐标轴刻度显示的易读程度作调整。在类目轴中无效。
                    interval:Math.ceil(Math.max(...columnData.map( item => item.value ))).toString().length>2 ? Math.ceil(Math.max(...columnData.map( item => item.value ))/100+0.001)*20: Math.ceil(Math.max(...columnData.map( item => item.value ))/10+0.001)*2,
                },
                {
                    //右y轴
                    type: 'value',
                    scale: true,
                    name: legendData[1],
                    max:Math.ceil(Math.max(...lineData.map( item => item.value ))).toString().length>2 ? Math.ceil(Math.max(...lineData.map( item => item.value ))/100+0.001)*100 : Math.ceil(Math.max(...lineData.map( item => item.value ))/10+0.001)*10,//右y轴最大值
                    
                    min:Math.floor(Math.min(...lineData.map( item => item.value ))).toString().length>2 ? Math.floor(Math.min(...lineData.map( item => item.value ))/100-0.001)*100 : Math.floor(Math.min(...lineData.map( item => item.value ))/10-0.001)*10,//右y轴最小值

                    splitNumber: 5,

                    interval:( (Math.ceil(Math.max(...lineData.map( item => item.value ))).toString().length>2 ? Math.ceil(Math.max(...lineData.map( item => item.value ))/100+0.001)*100 : Math.ceil(Math.max(...lineData.map( item => item.value ))/10+0.001)*10)
                    -
                    (Math.floor(Math.min(...lineData.map( item => item.value ))).toString().length>2 ? Math.floor(Math.min(...lineData.map( item => item.value ))/100-0.001)*100 : Math.floor(Math.min(...lineData.map( item => item.value ))/10-0.001)*10) ) /5,
                    axisLabel: {
                        show: true,
                        interval: 'auto',
                        formatter: '{value} %'
                    },
                }
            ],
            series: [
                {
                    //柱图
                    name: legendData[0],
                    type: 'bar',
                    yAxisIndex: 0,
                    color:columnColor,
                    barWidth:120,//柱条的宽度，不设时自适应。
                    data: columnData
                },
                {
                    //折线图
                    name: legendData[1],
                    type: 'line',
                    yAxisIndex: 1,//使用的 y 轴的 index，在单个图表实例中存在多个 y轴的时候有用。
                    color:lineColor,
                    data: lineData
                }
            ]
        }
        return option
    }
    render(){
        return(
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周付费课程订单数量</span>
                        <ReactEcharts 
                            // [左y轴name,右y轴name]，左y轴最大值，右y轴最大值，右y轴最小值，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['付费课程订单数量', '环比变动'],
                                    this.state.ordersNumData,
                                    '#7eaa55',
                                    this.state.ordersQOQData,
                                    '#699ad0'
                                )
                            } 
                            theme="Imooc"
                            style={{ height: '600px' }} 
                        />
                    </div>
                    <Divider />
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周新增付费会员数量</span>
                        <ReactEcharts 
                            // [左y轴name,右y轴name]，左y轴最大值，右y轴最大值，右y轴最小值，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['新增付费会员数量', '环比变动'],
                                    this.state.vipNumData,
                                    '#4e73be',
                                    this.state.vipQOQData,
                                    '#df8143'
                                )
                            } 
                            theme="Imooc"
                            style={{ height: '600px' }} 
                        />
                    </div>
                    <Divider />
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周付费课程销售GMV（USD）</span>
                        <ReactEcharts 
                            // [左y轴name,右y轴name]，左y轴最大值，右y轴最大值，右y轴最小值，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['付费课程销售GMV', '环比变动'],
                                    this.state.saleGMVNumData,
                                    '#df8244',
                                    this.state.saleGMVQOQData,
                                    '#f6c142'
                                )
                            } 
                            theme="Imooc"
                            style={{ height: '600px' }} 
                        />
                    </div>
                    <Divider />
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周付费订阅会员GMV（USD）</span>
                        <ReactEcharts 
                            // [左y轴name,右y轴name]，左y轴最大值，右y轴最大值，右y轴最小值，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['付费订阅会员GMV', '环比变动'],
                                    this.state.subscribeBMVNumData,
                                    '#e00',
                                    this.state.subscribeBMVQOQData,
                                    '#888'
                                )
                            } 
                            theme="Imooc"
                            style={{ height: '600px' }} 
                        />
                    </div>
                </Spin>
            </Fragment>
        )
    }
}

export default BusinessData;