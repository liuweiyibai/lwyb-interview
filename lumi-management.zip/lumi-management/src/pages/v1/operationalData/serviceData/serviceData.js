import React,{Component,Fragment} from 'react';
import { Spin, message } from 'antd';
import {LoadingOutlined} from '@ant-design/icons';
import Style from './serviceData.module.less';
//按需引入echarts
import ReactEcharts from 'echarts-for-react';
import 'echarts/lib/chart/bar';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/title';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum';

class ServiceData extends Component{
    constructor(){
        super();
        this.state={
            loading:false,
            topicNumber:'',//题库题目数量
            videoNumber:'',//视频数量
            prepareCourseNumber:'',//备考课数量
            searchNumber:'',//拍搜次数
            topicNumData:[],//题库数目数量 饼图数据
            videoNumData:[],//视频数量 饼图数据
            prepareCourseNumData:[],//备考课数量 饼图数据
            searchNumData:[],//拍搜次数 饼图数据
        }
    }
    componentDidMount(){
        this.getServiceData();
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    getServiceData=()=>{
        this.setState({loading:true},()=>{
            api.getServiceData()
            .then((data)=>{
                if(data.ret === 20000){
                    this.setState({
                        topicNumber:data.result.question.total,//题库题目数量
                        videoNumber:data.result.video.total,//视频数量
                        prepareCourseNumber:data.result.preCourse.total,//备考课数量
                        searchNumber:data.result.search.total,//拍搜次数
                        topicNumData:data.result.question.info,//题库数目数量 饼图数据
                        videoNumData:data.result.video.info,//视频数量 饼图数据
                        prepareCourseNumData:data.result.preCourse.info,//备考课数量 饼图数据
                        searchNumData:data.result.search.info,//拍搜次数 饼图数据
                        loading:false
                    });
                }else{
                    return Promise.reject(data);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    // 饼图名称，饼图数据，左y轴最大值，右y轴最大值，柱形图数据，柱形图颜色，折线图数据，折线图颜色
    getOption = (name,data) => {
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: '{b} : {c} ({d}%)'
            },
            series: [
                {
                    name: name,
                    type: 'pie',
                    radius: '45%',//饼图的半径
                    center: ['50%', '50%'],//饼图的中心（圆心）坐标，数组的第一项是横坐标，第二项是纵坐标。
                    data: data,
                    label:{            //饼图图形上的文本标签
                        normal:{
                            show:true,
                            textStyle : {
                                fontWeight : 300 ,
                                fontSize : 10    //文字的字体大小
                            },
                        }
                    },
                    emphasis: {  //高亮的扇区和标签样式。
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    },
                    animationType: 'scale',
                    animationEasing: 'elasticOut',
                    animationDelay: function (idx) { //初始动画的延迟
                        return Math.random() * 200;
                    }
                }
            ]
        }
        return option
    }
    render(){
        return(
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>

                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_1}></span>
                                    <span className={Style.text}>题库题目数量</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.topicNumber).toString())}</div>
                            <ReactEcharts option={this.getOption('题库题目数量',this.state.topicNumData)} theme="Imooc" />
                        </div>
                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_2}></span>
                                    <span className={Style.text}>视频数量</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.videoNumber).toString())}</div>
                            <ReactEcharts option={this.getOption('视频数量',this.state.videoNumData)} theme="Imooc" />
                        </div>
                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_3}></span>
                                    <span className={Style.text}>课程数量</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.prepareCourseNumber).toString())}</div>
                            <ReactEcharts option={this.getOption('课程数量',this.state.prepareCourseNumData)} theme="Imooc" />
                        </div>
                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_4}></span>
                                    <span className={Style.text}>拍搜次数</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.searchNumber).toString())}</div>
                            <ReactEcharts option={this.getOption('拍搜次数',this.state.searchNumData)} theme="Imooc" />
                        </div>

                    </div>
                </Spin>
            </Fragment>
        )
    }
}

export default ServiceData;