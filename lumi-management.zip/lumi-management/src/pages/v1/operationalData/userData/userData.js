import React, { Component, Fragment } from 'react';
import { Spin, Divider, message } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import Style from './userData.module.less';
//按需引入echarts
import ReactEcharts from 'echarts-for-react';
import 'echarts/lib/chart/bar';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/title';
import moment from 'moment';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum';

class UserData extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            registerUserNumber: '',//注册用户
            subscribeVipNumber: '',//订阅会员
            buyCourseUserNumber: '',//购课用户
            registerUserNumberData: [],//新增注册用户 数量数据
            registerUserQOQData: [],//新增注册用户 环比数据
            additionsVipNumberData: [],//新增会员 数量数据
            additionsVipQOQData: [],//新增会员 环比数据
            BuyCourseUserNumberData: [],//新增购课用户 数量数据
            BuyCourseUserQOQrData: [],//新增购课用户 环比数据
        }
    }
    componentDidMount() {
        this.getUserData();
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    customMap=(arr)=>{
        return arr.map(item=>{
            let obj={};
            obj.value=(item.value*100).toFixed(2);
            return obj;
        });
    }
    getUserData = () => {
        this.setState({ loading: true }, () => {
            api.getUserData()
                .then((data) => {
                    if (data.ret === 20000) {
                        let bool = Array.isArray(data.result.countAndRate) && data.result.countAndRate.length > 0;
                        this.setState({
                            registerUserNumber: data.result.regTotal,
                            subscribeVipNumber: data.result.subscriptTotal,
                            buyCourseUserNumber: data.result.buyCourseTotal,
                            registerUserNumberData:bool ? data.result.countAndRate[0].count : [],//新增注册用户 柱图
                            registerUserQOQData: bool ? this.customMap(data.result.countAndRate[0].rate) : [],//新增注册用户 环比
                            additionsVipNumberData: bool ? data.result.countAndRate[1].count : [],//新增会员 柱图
                            additionsVipQOQData: bool ? this.customMap(data.result.countAndRate[1].rate) : [],//新增会员 环比
                            BuyCourseUserNumberData: bool ? data.result.countAndRate[2].count : [],//新增购课用户 柱图
                            BuyCourseUserQOQrData: bool ? this.customMap(data.result.countAndRate[2].rate) : [],//新增购课用户 环比
                            loading: false
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // [左y轴name,右y轴name]，右y轴最小值，柱形图数据，柱形图颜色，折线图数据，折线图颜色
    getOption = (legendData, columnData, columnColor, lineData, lineColor) => {
        let option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#283b56'
                    }
                },
                formatter: '{a}: {c}<br />{a1}: {c1}%'
            },
            legend: {
                data: legendData//关联series.name
            },
            toolbox: {
                show: true,//是否显示工具栏组件。
                orient: "horizontal",//工具栏 icon 的布局朝向。"horizontal"横向/'vertical'纵向
                itemSize: 15,//工具栏 icon 的大小。
                itemGap: 10,//工具栏 icon 每项之间的间隔。横向布局时为水平间隔，纵向布局时为纵向间隔。
                feature: {
                    restore: {},//配置项还原。
                    saveAsImage: {}//保存为图片
                },//各工具配置项。
                showTitle: true,//是否在鼠标 hover 的时候显示每个工具 icon 的标题。
            },//工具栏。内置有导出图片，数据视图，动态类型切换，数据区域缩放，重置五个工具。
            xAxis: [
                {
                    //下x轴
                    type: 'category',//category类目轴 value数值轴 time时间轴 log对数轴
                    boundaryGap: true,//坐标两边留白
                    data: [
                        { value: moment().week(moment().week() - 4).startOf('week').format('YYYY/MM/DD') + '-' + moment().week(moment().week() - 4).endOf('week').format('YYYY/MM/DD'), },
                        { value: moment().week(moment().week() - 3).startOf('week').format('YYYY/MM/DD') + '-' + moment().week(moment().week() - 3).endOf('week').format('YYYY/MM/DD') },
                        { value: moment().week(moment().week() - 2).startOf('week').format('YYYY/MM/DD') + '-' + moment().week(moment().week() - 2).endOf('week').format('YYYY/MM/DD') },
                        { value: moment().week(moment().week() - 1).startOf('week').format('YYYY/MM/DD') + '-' + moment().week(moment().week() - 1).endOf('week').format('YYYY/MM/DD') },
                        { value: moment().week(moment().week()).startOf('week').format('YYYY/MM/DD') + '-' + moment().format('YYYY/MM/DD') }
                    ]
                },
            ],
            yAxis: [
                {
                    //左y轴
                    type: 'value',
                    scale: true,//是否是脱离 0 值比例。设置成 true 后坐标刻度不会强制包含零刻度。在双数值轴的散点图中比较有用
                    name: legendData[0],
                    max: Math.ceil(Math.max(...columnData.map(item => item.value))).toString().length > 2 ? Math.ceil(Math.max(...columnData.map(item => item.value)) / 100 + 0.001) * 100 : Math.ceil(Math.max(...columnData.map(item => item.value)) / 10 + 0.001) * 10,//左y轴最大值
                    min: 0,
                    splitNumber: 5,//坐标轴的分割段数，需要注意的是这个分割段数只是个预估值，最后实际显示的段数会在这个基础上根据分割后坐标轴刻度显示的易读程度作调整。在类目轴中无效。
                    interval: Math.ceil(Math.max(...columnData.map(item => item.value))).toString().length > 2 ? Math.ceil(Math.max(...columnData.map(item => item.value)) / 100 + 0.001) * 20 : Math.ceil(Math.max(...columnData.map(item => item.value)) / 10 + 0.001) * 2,
                },
                {
                    //右y轴
                    type: 'value',
                    scale: true,
                    name: legendData[1],
                    max: Math.ceil(Math.max(...lineData.map(item => item.value))).toString().length > 2 ? Math.ceil(Math.max(...lineData.map(item => item.value)) / 100 + 0.001) * 100 : Math.ceil(Math.max(...lineData.map(item => item.value)) / 10 + 0.001) * 10,//右y轴最大值

                    min: Math.floor(Math.min(...lineData.map(item => item.value))).toString().length > 2 ? Math.floor(Math.min(...lineData.map(item => item.value)) / 100 - 0.001) * 100 : Math.floor(Math.min(...lineData.map(item => item.value)) / 10 - 0.001) * 10,//右y轴最小值

                    splitNumber: 5,

                    interval: ((Math.ceil(Math.max(...lineData.map(item => item.value))).toString().length > 2 ? Math.ceil(Math.max(...lineData.map(item => item.value)) / 100 + 0.001) * 100 : Math.ceil(Math.max(...lineData.map(item => item.value)) / 10 + 0.001) * 10)
                    -
                    (Math.floor(Math.min(...lineData.map(item => item.value))).toString().length > 2 ? Math.floor(Math.min(...lineData.map(item => item.value)) / 100 - 0.001) * 100 : Math.floor(Math.min(...lineData.map(item => item.value)) / 10 - 0.001) * 10)) / 5,
                    axisLabel: {
                        show: true,
                        interval: 'auto',
                        formatter: '{value} %'
                    },
                }
            ],
            series: [
                {
                    //柱图
                    name: legendData[0],
                    type: 'bar',
                    yAxisIndex: 0,
                    color: columnColor,
                    barWidth: 120,//柱条的宽度，不设时自适应。
                    data: columnData
                },
                {
                    //折线图
                    name: legendData[1],
                    type: 'line',
                    yAxisIndex: 1,//使用的 y 轴的 index，在单个图表实例中存在多个 y轴的时候有用。
                    color: lineColor,
                    data: lineData
                }
            ]
        }
        return option
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>
                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_1}></span>
                                    <span className={Style.text}>注册用户</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.registerUserNumber).toString())}</div>
                        </div>
                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_2}></span>
                                    <span className={Style.text}>会员数量（订阅会员）</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.subscribeVipNumber).toString())}</div>
                        </div>
                        <div className={Style.box}>
                            <div className={Style.imageWrap}>
                                <div className={Style.left}>
                                    <span className={Style.icon_3}></span>
                                    <span className={Style.text}>付费购课用户</span>
                                </div>
                                <span className={Style.right}>累计</span>
                            </div>
                            <div className={Style.total}>{fun.outputdollars((this.state.buyCourseUserNumber).toString())}</div>
                        </div>
                    </div>
                    <Divider />
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周新增注册用户</span>
                        <ReactEcharts
                            // [左y轴name,右y轴name]，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['新增注册用户', '环比变动'],
                                    this.state.registerUserNumberData,
                                    '#7eaa55',
                                    this.state.registerUserQOQData,
                                    '#699ad0'
                                )
                            }
                            theme="Imooc"
                            style={{ height: '600px' }}
                        />
                    </div>
                    <Divider />
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周新增会员（包含试用）</span>
                        <ReactEcharts
                            // [左y轴name,右y轴name]，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['新增会员', '环比变动'],
                                    this.state.additionsVipNumberData,
                                    '#4e73be',
                                    this.state.additionsVipQOQData,
                                    '#df8143'
                                )
                            }
                            theme="Imooc"
                            style={{ height: '600px' }}
                        />
                    </div>
                    <Divider />
                    <div className={Style.dataWrap}>
                        <span className={Style.title}>每周首次购课用户</span>
                        <ReactEcharts
                            // [左y轴name,右y轴name]，柱形图数据，柱形图颜色，折线图数据，折线图颜色
                            option={
                                this.getOption(
                                    ['首次购课用户', '环比变动'],
                                    this.state.BuyCourseUserNumberData,
                                    '#df8244',
                                    this.state.BuyCourseUserQOQrData,
                                    '#f6c142'
                                )
                            }
                            theme="Imooc"
                            style={{ height: '600px' }}
                        />
                    </div>
                </Spin>
            </Fragment>
        )
    }
}

export default UserData;