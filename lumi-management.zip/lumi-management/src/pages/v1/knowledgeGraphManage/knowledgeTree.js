import React, { Component } from 'react';
import { Button, Select, Upload, message, Input, Spin, Divider, Tabs } from 'antd';
import { DownloadOutlined, PlusOutlined, LoadingOutlined } from '@ant-design/icons';
import Sortable from "sortablejs";
import Style from './knowledgeTree.module.less';
import Modal from '../../../components/modalOfTree/modalOfTree';
import api from '../../../utils/api';
//按需引入echarts
import ReactEcharts from 'echarts-for-react';
// import 'echarts/lib/chart/tree';
const { Option } = Select;
const { TabPane } = Tabs;

class Knowledge extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,//全局Spin loading
            subjectList: [],//学科列表
            tree: '---------',//下拉所选学科
            showModalSub: false,//是否显示添加学科模态框
            showModalPoint: false,//是否显示添加知识点模态框
            showModalEdit: false,//是否显示编辑知识点模态框
            listState: {},//各个节点状态列表
            // modalTitle:'',//弹框title
            subjectName: '',//添加学科名称
            subjectPoint: '',//添加知识点名称
            fileList: [],//上传文件的列表
            showMenu: false,//是否显示右键菜单
            nodeData: '',//鼠标右键所点击的节点的数据
            x: '',//鼠标x轴位置
            y: '',//鼠标y轴位置
            activeTree: 'treeCatalog',
            deepLevel: 0,
            data: [],//树图数据
        }
    }
    componentDidMount() {
        this.refs.wrap.oncontextmenu = () => { return false; };//禁用鼠标右键菜单
        document.addEventListener('mousedown', this.hiddenMenu);
        this.getSubjectList();
    }
    componentDidUpdate() {
        //递归进行sortable
        let div = document.getElementById('treeWrap');
        if (div === null) return;
        //  每次更新时递归创建Sortable
        this.digTree(this.state.data);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.hiddenMenu);
        this.refs.wrap.oncontextmenu = () => { return true; };//禁用鼠标右键菜单
        this.setState = () => {
            return;
        };
    }
    //获取学科列表
    getSubjectList = () => {
        this.setState({ loading: true });
        api.getSubjectList()
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ subjectList: data.result, loading: false })
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                this.setState({ loading: false });
                message.error(err.msg);
            })
    }
    //下拉选择学科
    selectTree = (value) => {
        this.setState({ tree: value }, () => {
            this.getTreeData(this.state.tree);
        })
    }
    //获取下拉所选学科数据
    getTreeData = (tree) => {
        this.setState({ loading: true });
        api.getTreeData({ subjectName: tree })
            .then((data) => {
                if (data.ret === 20000) {
                    let data1 = []
                    data1.push(data.result);
                    this.setState({ data: data1, loading: false }, () => {
                        let obj = {};
                        let deepLevelObj = { deepLevel: 0 };
                        //递归获得每个节点展开状态
                        this.digState(this.state.data, obj, deepLevelObj);
                        this.setState({ listState: obj, deepLevel: deepLevelObj.deepLevel });
                    })

                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                this.setState({ loading: false });
                message.error(err.msg);
            })
    }
    //新增学科btn
    addSubject = () => {
        this.setState({ showModalSub: true })
    }
    //新增学科 获取输入的学科名
    getSubject = (e) => {
        e.persist();
        const pattern = /[`~!@#$%^&*()=|{}':;',\\[\].<>/?~！@#￥……&*（）——|{}【】'；：""'。，、？]/g;
        this.setState({ subjectName: e.target.value.replace(pattern, "") });
    }
    //确认新增学科
    sureAddSubject = () => {
        this.setState({ loading: true }, () => {
            api.addSubject({ subjectName: this.state.subjectName })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getSubjectList();
                        this.setState({ loading: false, showModalSub: false, subjectPoint: '' });
                        message.success('添加成功');
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //关闭弹框
    close = () => {
        this.setState({ showModalPoint: false, showModalSub: false, showModalEdit: false, modalTitle: '', subjectPoint: '' })
    }
    //知识树导入 上传csv
    beforeUpload = (file) => {
        this.setState({ loading: true });
        const isJpgOrPng = file.name.split('.')[1] === 'xlsx';
        if (!isJpgOrPng) {
            message.error('只能上传excel格式的文件！');
            this.setState({ fileList: [], loading: false });
            return false;
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('文件大小不能超过2MB!');
            this.setState({ fileList: [], loading: false });
            return false;
        }
        if (isJpgOrPng && isLt2M) {
            this.setState({ loading: true });
            let formData = new FormData();
            formData.append('file', file);
            // api.uploadCSV(formData)
            //     .then((data) => {
            //         this.setState({ fileList: [], loading: false }, () => {
            //             if (data.ret === 20000) {
            //                 this.setState({ loading: true });
            //                 // api.saveCSV('/v1/graph/save?fileName=' + data.result)
            //                 api.saveCSV(formData)
            //                     // formData
            //                     .then((data) => {
            //                         if (data.ret === 20000) {
            //                             this.setState({ loading: false });
            //                             message.success('导入成功');
            //                             this.getSubjectList();
            //                         } else {
            //                             return Promise.reject(data);
            //                         }
            //                     })
            //                     .catch((err) => {
            //                         this.getSubjectList();
            //                         this.setState({ loading: false });
            //                         message.error(err.msg);
            //                     })
            //             } else {
            //                 return Promise.reject(data);
            //             }
            //         })
            //     })
            //     .catch((err) => {
            //         this.setState({ fileList: [], loading: false });
            //         message.error(err.msg);
            //     })
            api.saveCSV(formData)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ loading: false });
                        message.success('导入成功');
                        this.getSubjectList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.getSubjectList();
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        }
        return false;//阻止antd upload action自动上传
    }
    //关闭自定义右键菜单
    hiddenMenu = (e) => {
        if (!this.state.showMenu || e.target.title === 'del' || e.target.title === 'add' || e.target.title === 'edit') return;
        this.setState({ showMenu: false });
    }
    //鼠标右键事件
    contextmenuEvent = (e, item) => {
        item.getDom().oncontextmenu = () => { return false; };//禁用ReactEcharts区域内鼠标右键菜单
        this.setState({ showMenu: true, x: e.event.offsetX, y: e.event.offsetY, nodeData: e.data })
    }
    //新增节点
    addNode = () => {
        this.setState({ showModalPoint: true, showMenu: false })
    }
    //获取新增知识点节点名称
    getSubjectPoint = (e) => {
        e.persist();
        const pattern = /[`~!@#$%^&*()=|{}':;',\\[\].<>/?~！@#￥……&*（）——|{}【】'；：""'。，、？]/g;
        this.setState({ subjectPoint: e.target.value.replace(pattern, "") });
    }
    //确定新增节点
    sureAddPoint = () => {
        this.setState({ loading: true }, () => {
            api.addNode({ level: Number(this.state.nodeData.level) + 1, id: Number(this.state.nodeData.id), name: this.state.subjectPoint, serial: Number(this.state.nodeData.serial) })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getTreeData(this.state.tree);
                        this.setState({ loading: false, showModalPoint: false, subjectPoint: '' });
                        message.success('添加成功');
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //删除节点
    deleteNode = () => {
        this.setState({ loading: true, showMenu: false }, () => {
            api.deleteNode({ type: this.state.nodeData.level, id: this.state.nodeData.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        if (Number(this.state.nodeData.level) === 0) {
                            window.location.reload(true);
                        } else {
                            this.getTreeData(this.state.tree);
                        }
                        this.setState({ loading: false });
                        message.success(data.msg);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.getTreeData(this.state.tree);
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        });
    }
    //编辑节点名称
    editNode = () => {
        this.setState({ showModalEdit: true, modalTitle: '', showMenu: false, newSubjectName: this.state.nodeData.name, })
    }
    //获取新节点名称
    getNewSubjectName = (e) => {
        const pattern = /[`~!@#$%^&*()=|{}':;',\\[\].<>/?~！@#￥……&*（）——|{}【】'；：""'。，、？]/g;
        let newTree = Number(this.state.nodeData.level) === 0 ? e.target.value : this.state.tree;
        this.setState({ newSubjectName: e.target.value.replace(pattern, ""), tree: newTree });
    }
    //确定编辑节点
    sureEditPointName = () => {
        this.setState({ loading: true }, () => {
            api.editSubject({ id: this.state.nodeData.id, level: this.state.nodeData.level, name: this.state.newSubjectName, serial: this.state.nodeData.serial })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getTreeData(this.state.tree);
                        this.setState({ showModalEdit: false });
                        message.success(data.msg);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.getTreeData(this.state.tree);
                    message.error(err.msg);
                })
        })
    }
    //获取echarts配置参数及渲染数据
    getOption = () => {
        let option = {
            toolbox: {
                show: true,//是否显示工具栏组件。
                orient: "horizontal",//工具栏 icon 的布局朝向。"horizontal"横向/'vertical'纵向
                itemSize: 15,//工具栏 icon 的大小。
                itemGap: 10,//工具栏 icon 每项之间的间隔。横向布局时为水平间隔，纵向布局时为纵向间隔。
                feature: {
                    restore: {},//配置项还原。
                    saveAsImage: {}//保存为图片
                },//各工具配置项。
                showTitle: true,//是否在鼠标 hover 的时候显示每个工具 icon 的标题。
            },//工具栏。内置有导出图片，数据视图，动态类型切换，数据区域缩放，重置五个工具。
            tooltip: {
                trigger: 'item',//触发类型。'item':数据项图形触发，主要在散点图，饼图等无类目轴的图表中使用。 'axis':坐标轴触发，主要在柱状图，折线图等会使用类目轴的图表中使用。 'none':什么都不触发。
                triggerOn: 'mousemove',//提示框触发的条件。'mousemove','click','mousemove|click','none'
            }, //提示框组件。
            series: [ //系列列表。每个系列通过 type 决定自己的图表类型
                {
                    name: 'tree',
                    type: "tree",
                    layout: 'orthogonal',//orthogonal树图/radial发散状树图
                    roam: true,//设置为true表示可滑动、缩放
                    symbol: "emptyCircle",//节点的形状 'emptyCircle','circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow', 'none'
                    symbolSize: 15,//节点大小,可以设置成诸如 10 这样单一的数字，也可以用数组分开表示宽和高，例如 [20, 10] 表示标记宽为20，高为10
                    edgeShape: 'curve',//树图在 正交布局 下，边的形状。分别有曲线和折线两种，对应的取值是 curve 和 polyline
                    edgeForkPosition: '50%',//树图形状为折线时，分叉点与子树父节点的距离占整个子树高度的百分比分。
                    expandAndCollapse: true,//子节点是否可以折叠，默认true
                    initialTreeDepth: -1,//默认展开的层级,根节点是第 0 层，如果设置为 -1 或者 null 或者 undefined，所有节点都将展开。
                    data: this.state.data ? this.state.data : [],
                    top: '0%',//距离顶部的距离
                    left: '14%',
                    bottom: '5%',
                    right: '20%',
                    label: {
                        position: 'left',//节点标签的位置，支持：top / left / right / bottom / inside / insideLeft / insideRight / insideTop / insideBottom / insideTopLeft / insideBottomLeft / insideTopRight / insideBottomRight
                        distance: 8,//节点标签距离节点图形的距离
                        verticalAlign: 'middle',//节点标签文字垂直对齐方式，支持'top','middle','bottom'
                        align: 'right',//节点标签文字水平对齐方式，默认自动。 right\left\center,
                        fontSize: 14, //节点标签字体大小
                        formatter: [
                            '{b|{b}}',//'{rich中的样式名 | {a}：系列名 / {b}：数据名 / {c}：数据值。{d}：百分比 / {@xxx}：数据中名为'xxx'的维度的值，如{@product}表示名为'product'` 的维度的值 / {@[n]}：数据中维度n的值，如{@[3]}` 表示维度 3 的值，从 0 开始计数。}'
                        ].join('\n'),
                        rich: {
                            b: {
                                fontSize: 14,
                                color: '#000000'
                            }
                        }
                    },
                    //叶子节点的特殊配置  叶子节点即最尾部的子节点
                    leaves: {
                        //label 同上label
                        label: {
                            position: 'right',
                            verticalAlign: 'middle',
                            align: 'left'
                        }
                    },
                    animationDuration: 550,//初始动画的时长
                    animationDurationUpdate: 750,//数据更新动画的时长
                }
            ]
        }
        return option
    }
    //click获得兄弟节点并且设置其display
    getSiblingsNone = (e) => {
        var sibling = e.target.parentNode.firstChild;
        let obj = JSON.parse(JSON.stringify(this.state.listState));
        for (; sibling; sibling = sibling.nextSibling) {
            if (sibling.nodeType !== 1 || sibling === e.target) continue;
            let dataset = sibling.children[0].dataset;
            let arr = `${dataset.name}-${dataset.id}-${dataset.level}`
            obj[arr] = !obj[arr];
        }
        this.setState({ listState: obj });
    }
    //获得当前元素相对于document.body的偏移量
    offset = (curEle) => {
        var totalLeft = null, totalTop = null, par = curEle.offsetParent;
        //首先把自己本身的进行累加
        totalLeft += curEle.offsetLeft;
        totalTop += curEle.offsetTop;
        //只要没有找到body，我们就把父级参照物的边框和偏移量累加
        while (par) {
            //累加父级参照物本身的偏移
            totalLeft += par.offsetLeft;
            totalTop += par.offsetTop;
            par = par.offsetParent;
        }
        return { left: totalLeft, top: totalTop };
    }
    //递归遍历知识树形成树结构目录
    dig = (list) => {
        return (
            list.map((item) => {
                //判断是否存在子节点，判断classname为label_right还是label_down，通过判断子节点的展开状态
                let labelRightDownClassName = (item && item.children && item.children.length) ? this.state.listState === {} ? Style.label_right : this.state.listState[`${item.children[0].name}-${item.children[0].id}-${item.children[0].level}`] === true ? Style.label_right : Style.label_down : '';
                //根据level决定branch的marginleft，选取不同的branch的classname
                let branchClassName = Number(this.state.deepLevel) === 0 ? Style.branch0 : Number(this.state.deepLevel) === 1 ? Style.branch1 : Number(this.state.deepLevel) === 2 ? Style.branch2 : Style.branch3;
                return <div
                    className={`${branchClassName} ${Style.branch}`}
                    id={item.name + item.level}
                    key={item.name + Math.floor(Math.random() * 10)}
                    style={{ display: this.state.listState === {} ? 'block' : this.state.listState[`${item.name}-${item.id}-${item.level}`] === true ? 'block' : 'none' }}
                >
                    <span
                        className={`${Style.label} ${labelRightDownClassName}`}
                        data-id={item.id}
                        data-level={item.level}
                        data-name={item.name}
                        data-serial={item.serial}
                        title={item.name}
                        //  当有子节点时当前元素存在click事件进行子节点展开
                        onClick={(item.children && item.children.length) ? this.getSiblingsNone : () => { }}
                        onContextMenu={(e) => {
                            let div = document.getElementById('treeWrap');
                            this.setState({ showMenu: true, x: this.offset(e.target).left - this.offset(div).left, y: this.offset(e.target).top - this.offset(div).top, nodeData: e.target.dataset });
                        }}
                    >
                        {item.name}
                    </span>
                    {/* 当有子节点时进行递归 */}
                    {item.children && item.children.length ? this.dig(item.children) : ''}
                </div >
            })
        )
    }
    //递归创建Sortable
    digTree = (list) => {
        list.forEach((item) => {
            //判断是否存在子节点
            if (item.children && item.children.length) {
                new Sortable(document.getElementById(item.name + item.level), {
                    swapThreshold: 1,//交换区阈值
                    animation: 300,//排序动画时间
                    // ghostClass: 'blue-background-class',
                    // group: item.name + item.level,
                    fallbackOnBody: false,
                    onEnd: (evt) => {
                        if (evt.item.previousSibling === null || evt.item.tagName === 'SPAN') {
                            message.error('不可跨级排序！')
                            this.getTreeData(this.state.tree);
                            return;
                        }
                        if (Number(evt.item.children[0].getAttribute('data-serial')) === 0 && evt.item.previousSibling.tagName === 'SPAN') return;

                        let toIndex = (evt.item.previousSibling !== null && evt.item.previousSibling.tagName !== 'SPAN') ? (Number(evt.item.previousSibling.children[0].getAttribute('data-serial')) > Number(evt.item.children[0].getAttribute('data-serial')) ? evt.item.previousSibling.children[0].getAttribute('data-serial') : evt.item.nextSibling !== null ? evt.item.nextSibling.children[0].getAttribute('data-serial') : Number(evt.item.children[0].getAttribute('data-serial'))) : 0;

                        this.sortAPI({ fromIndex: evt.item.children[0].getAttribute('data-serial'), id: evt.item.children[0].getAttribute('data-id'), toIndex, type: evt.item.children[0].getAttribute('data-level') });
                    },
                })
                this.digTree(item.children);
            }
        })
    }
    //排序接口
    sortAPI = (params) => {
        this.setState({ loading: true }, () => {
            api.knowledgeTreeSort(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getTreeData(this.state.tree);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //递归遍历知识树形成每个节点的状态，根据状态判断是否展开
    digState = (list, obj, deepLevelObj) => {
        return (
            list.forEach((item, index) => {
                if (Number(item.level) > Number(deepLevelObj.deepLevel)) {
                    deepLevelObj.deepLevel = item.level;
                }
                let arr = `${item.name}-${item.id}-${item.level}`;
                //判断是否存在子节点
                if (item.children && item.children.length) {
                    this.digState(item.children, obj, deepLevelObj);
                }
                obj[arr] = true;
            })
        )
    }
    //改变tab的树
    changeTreeCatalog = (key) => {
        this.setState({ activeTree: key });
    }
    // 增删编辑弹框 
    buttonList = () => {
        return this.state.showMenu ? <div className={Style.menuWrap} style={{ left: this.state.x, top: this.state.y, marginLeft: this.state.activeTree === 'treeCatalog' ? '150px' : '0px' }}
        >
            {Number(this.state.nodeData.level) !== 3 ? <div onClick={this.addNode} title='add' className='ant-btn'>新增</div> : ''}
            <div onClick={this.editNode} title='edit' className='ant-btn'>编辑</div>
            <div onClick={this.deleteNode} title='del' className='ant-btn'>删除</div>
        </div> : ''
    }
    render() {
        return (
            <div ref='wrap' className={Style.wrap} >
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    {/* 新增学科 */}
                    {this.state.showModalSub ? <Modal title='添加学科' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.sureAddSubject}>确定</Button>]}>
                        <div>
                            学科名称：<Input placeholder='请输入学科名称' className={Style.input} value={this.state.subjectName} onChange={this.getSubject}></Input>
                        </div>
                    </Modal> : ''}
                    {/* 新增知识点 */}
                    {this.state.showModalPoint ? <Modal title='新增知识点' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.sureAddPoint}>确定</Button>]}>
                        <div>
                            知识点名称：<Input placeholder='请输入知识点名称' className={Style.input} value={this.state.subjectPoint} onChange={this.getSubjectPoint}></Input>
                        </div>
                    </Modal> : ''}
                    {/* 编辑知识点名称 */}
                    {/* Continuity */}
                    {this.state.showModalEdit ? <Modal title='编辑知识点名称' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.sureEditPointName}>确定</Button>]}>
                        <div>
                            新知识点名称：<Input placeholder='请输入新知识点名称' className={Style.input} value={this.state.newSubjectName} onChange={this.getNewSubjectName}></Input>
                        </div>
                    </Modal> : ''}
                    <div className={Style.toolWrap}>
                        <Select placeholder='----输入学科名称-----' onChange={this.selectTree} className={Style.select} optionLabelProp="label" showSearch={true}>
                            {this.state.subjectList.map((item, index) => {
                                return (<Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>)
                            })}
                        </Select>
                        <div className={Style.tool}>
                            <Button type='primary' icon={<PlusOutlined />} onClick={this.addSubject}>新增学科</Button>
                            <Upload
                                name='file'
                                // action= ''
                                // headers= {{authorization: 'authorization-text',}}
                                fileList={this.state.fileList}
                                showUploadList={false}
                                beforeUpload={this.beforeUpload}
                                disabled={this.state.fileList.length >= 1}
                            >
                                <Button type='primary' icon={<DownloadOutlined />}>知识树导入</Button>
                            </Upload>
                            <Button type='primary'><a href='https://cdn.lumiclass.com/qm/2020/graph_template.xlsx' target='_self' rel="noreferrer"><DownloadOutlined />导入模板下载</a></Button>
                        </div>
                    </div>
                    <span className={Style.exp}>知识树结构：学科&nbsp;&nbsp;{`--->`}&nbsp;&nbsp;一级知识点&nbsp;&nbsp;{`--->`}&nbsp;&nbsp;二级知识点&nbsp;&nbsp;{`--->`}&nbsp;&nbsp;三级知识点</span>
                    <Divider />
                    <div className={Style.titleWrap}>
                        <h2>{this.state.tree}</h2>
                    </div>
                    {this.state.data.length > 0 ? <Tabs defaultActiveKey="treeCatalog" onChange={this.changeTreeCatalog} activeKey={this.state.activeTree}>
                        <TabPane key="treeCatalog" tab='树目录'>
                            <div className={Style.treeWrap} id='treeWrap' >
                                {/* 递归形成树目录 */}
                                {this.dig(this.state.data)}
                                {/* 增删编辑弹框 */}
                                {this.buttonList()}
                            </div>
                        </TabPane>
                        <TabPane key="treeChart" tab='树结构'>
                            <div className={Style.echartsWrap}>
                                {/* echart 树结构*/}
                                <ReactEcharts option={this.getOption()} theme="Imooc" onEvents={{ 'contextmenu': this.contextmenuEvent }} style={{ height: '900px' }} />
                                {/* 增删编辑弹框 */}
                                {this.buttonList()}
                            </div>
                        </TabPane>
                    </Tabs> : ''}
                </Spin>
            </div>
        )
    }
}

export default Knowledge;