import React, { Fragment } from "react";
import api from "../../../../utils/api";
import {
  Select,
  Table,
  Button,
  Modal,
  message,
  Spin,
  Tooltip,
  Empty,
  Input,
} from "antd";
import { LoadingOutlined } from "@ant-design/icons";
import { connect } from "react-redux";
import STORE from "../../../../store/store";
import actionCreator from "../../../../store/actionCeator.js";
import Modal1 from '../../../../components/modalOfTree/modalOfTree.js';
import Style from "./statistics.module.less";

const { Option } = Select;

@connect(store => store)
class Statistics extends React.Component {
  tableColumns = [
    {
      title: "学生姓名",
      dataIndex: "name",
      key: "name",
      align: "center",
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.6}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: "UserID",
      dataIndex: "studentId",
      key: "studentId",
      align: "center",
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.6}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: "微信",
      dataIndex: "wx",
      key: "wx",
      align: "center",
      render: (v) => {
        return (
          <Tooltip placement="top" title={v} mouseEnterDelay={0.6}>
            {v}
          </Tooltip>
        );
      },
    },
    {
      title: "直播签到",
      dataIndex: "qiandao",
      key: "qiandao",
      align: "center",
      render: (qiandao) => {
        return qiandao ? (
          <div>
            <span className={Style.checked}></span>已签到
          </div>
        ) : (
          <div>
            <span className={Style.noChecked}></span>未签到
          </div>
        );
      },
      filters: [
        {
          text: "已签到",
          value: 1,
        },
        {
          text: "未签到",
          value: 0,
        },
      ],
      onFilter: (value, record) => {
        return record.qiandao === value;
      },
      filterMultiple: false,
    },
    {
      title: "复习状态",
      dataIndex: "review",
      key: "review",
      align: "center",
      render: (review) => {
        return review ? (
          <div>
            <span className={Style.checked}></span>已复习
          </div>
        ) : (
          <div>
            <span className={Style.noChecked}></span>未复习
          </div>
        );
      },
      filters: [
        {
          text: "已复习",
          value: 1,
        },
        {
          text: "未复习",
          value: 0,
        },
      ],
      onFilter: (value, record) => {
        return record.review === value;
      },
      filterMultiple: false,
    },
    {
      title: "督学",
      dataIndex: "notifi",
      key: "notifi",
      align: "center",
      render: (notifi, record) => {
        return notifi ? (
          "已提醒"
        ) : (
          <div>
            <Button
              type="primary"
              onClick={() => {
                this.setAffirmModalVisible(true);
                this.setState({
                  currentRemindRecord: record,
                });
              }}
            >
              确认提醒
            </Button>
          </div>
        );
      },
      filters: [
        {
          text: "已提醒",
          value: 1,
        },
        {
          text: "未提醒",
          value: 0,
        },
      ],
      onFilter: (value, record) => {
        return record.notifi === value;
      },
      filterMultiple: false,
    },
  ];

  constructor() {
    super();
    this.state = {
      titleText: "",
      affirmModalVisible: false,
      loading: false,
      campusList: [],
      mentorList: [],
      courseList: [],
      currentCourseName: "",
      weekList: [],
      // 保存各个下拉框的值
      campusSelectValue: null,
      mentorSelectValue: null,
      courseSelectValue: null,
      weekSelectValue: null,
      // 保存caId casId
      selectedCaId: null,
      selectedCasId: null,
      tableData: [
        // {
        //   name: "zhsan",
        //   studentId: "234565",
        //   wx: "_dfkjdhfkdi",
        //   qiandao: false,
        //   review: false,
        //   notifi: false,
        // },
      ],
      statisticDetail: {},
      currentRemindRecord: null,
      showBindModal: false, // ===== 绑定导师账号 =====
      powerArr: [], // 账号权限列表
      errorMsg: "",
      accountNumber: "",
      password: "",
      isTeacher: false,
    };
  }

  componentDidMount() {
    this.setState({
      powerArr: STORE.store.getState().powerArr,
    });
    this.getCampus();
  }

  setAffirmModalVisible = (flag) => {
    this.setState({ affirmModalVisible: flag });
  };

  getCampus = () => {
    // 获取校区列表
    this.setState({ loading: true }, () => {
      api
        .getEduCampus()
        .then((res) => {
          if (res.code === 0) {
            this.setState({ campusList: res.data, loading: false });
          } else {
            if (res.ret === 60001) {
              this.setState({ isTeacher: true });
              res.message = res.msg;
            }
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          this.setState({ loading: false });
        });
    });
  };

  getMentors = (campusId, option) => {
    // 获取导师列表
    this.setState(
      {
        loading: true,
        campusSelectValue: option.value,
        mentorList: [], // 清空后边的下拉框
        mentorSelectValue: null,
        courseList: [],
        courseSelectValue: null,
        weekList: [],
        weekSelectValue: null,
      },
      () => {
        api
          .getEduCampusMentors({}, {}, campusId)
          .then((res) => {
            // console.log(res);
            if (res.code === 0) {
              const data = res.data.map((v) => {
                v.campusId = campusId;
                return v;
              });
              this.setState({ mentorList: data, loading: false });
            } else {
              return Promise.reject(res);
            }
          })
          .catch((err) => {
            message.error(err.message);
            this.setState({ loading: false });
          });
      }
    );
  };

  getCourseList = (mentorId, option) => {
    // 获取课程列表
    this.setState({
      loading: true,
      mentorSelectValue: option.value,
      courseList: [],
      courseSelectValue: null,
      weekList: [],
      weekSelectValue: null,
    });
    api
      .getEduStatisticCourseList({ mentorId }, {}, option.campusid)
      .then((res) => {
        // console.log(res);
        if (res.code === 0) {
          this.setState({ loading: false, courseList: res.data });
        } else {
          return Promise.reject(res);
        }
      })
      .catch((err) => {
        message.error(err.message);
        this.setState({ loading: false });
      });
  };

  getWeekList = (name, option) => {
    // 获取week列表
    // console.log("课程ID：", option.key);
    // console.log("课程上拿到的校区ID：", option.campusid);
    this.setState({
      loading: true,
      currentCourseName: name,
      courseSelectValue: option.value,
      weekList: [],
      weekSelectValue: null,
    });
    api
      .getEduStatisticWeekList({ campusId: option.campusid }, {}, +option.key)
      .then((res) => {
        if (res.code === 0) {
          const result = this.removeDoubleValue(res.data);
          this.setState({ loading: false, weekList: result });
        } else {
          return Promise.reject(res);
        }
      })
      .catch((err) => {
        message.error(err.message);
        this.setState({ loading: false });
      });
  };

  removeDoubleValue = (arr) => { // 去除casId 重复的对象
    let _arr = arr;
    for (let i = 0; i < _arr.length; i++) {
      for (let j = i+1; j < _arr.length; j++) {
        if (_arr[i].casId === _arr[j].casId) {
          _arr.splice(j, 1);
          j--;
        }
      }
    }
    return _arr;
  }

  getCourseStatisticDetail = (v, o) => {
    // console.log(o.value);
    this.setState(
      {
        loading: true,
        titleText: o.title,
        weekSelectValue: o.value,
        selectedCaId: o.caid,
        selectedCasId: o.casid,
      },
      () => {
        api
          .getEduStatisticCourseInfo(
            { courseAssignmentScheduleId: +o.casid },
            {},
            +o.caid
          )
          // .getEduStatisticCourseInfo(
          //   { courseAssignmentScheduleId: 1640 },
          //   {},
          //   822
          // )
          .then((res) => {
            // console.log(res);
            if (res.ret === 20000) {
              const tableData = this.getTableData(
                res.result.ezaCourseStatisticsList
              );
              this.setState({
                loading: false,
                statisticDetail: res.result,
                tableData,
              });
            } else {
              return Promise.reject(res);
            }
          })
          .catch((err) => {
            message.error(err.message);
            this.setState({ loading: false });
          });
      }
    );
  };

  getTableData = (data) => {
    let tableData = [];
    data.forEach((v) => {
      let item = {
        name: v.studentLastName + v.studentFirstName,
        studentId: v.studentId,
        wx: v.wechat || "--",
        qiandao: v.liveSignInStatus || 0,
        review: v.reviewStatus || 0,
        notifi: v.inspectStatus || 0,
        caId: this.state.selectedCaId,
        casId: this.state.selectedCasId,
        id: v.id, // 主键ID
      };
      tableData.push(item);
    });
    return tableData;
  };

  getLiveAttend = () => {
    // 直播出勤率
    const { statisticDetail } = this.state;
    if (statisticDetail.purchaseTotal) {
      return (
        ~~(
          (statisticDetail.liveAttendanceTotal /
            statisticDetail.purchaseTotal) *
          100
        ) + "%"
      );
    } else if (statisticDetail.purchaseTotal === 0) {
      return "0%";
    } else {
      return "--";
    }
  };

  getAllAttend = () => {
    // 总听课率
    const { statisticDetail } = this.state;
    if (statisticDetail.purchaseTotal) {
      return (
        ~~(
          (statisticDetail.attendClassTotal / statisticDetail.purchaseTotal) *
          100
        ) + "%"
      );
    } else if (statisticDetail.purchaseTotal === 0) {
      return "0%";
    } else {
      return "--";
    }
  };

  getNumberWithOutZero = (num) => {
    if (num) {
      return num;
    } else if (num === 0) {
      return 0;
    } else {
      return "--";
    }
  };

  remind = () => {
    const record = this.state.currentRemindRecord;
    // console.log(record);
    this.setState({
      loading: true,
    });
    this.setAffirmModalVisible(false);
    api
      .updateEduStatisticCourseInfo(
        {
          courseAssignmentId: record.caId,
          courseAssignmentScheduleId: record.casId,
          id: record.id,
          inspectStatus: 1,
          studentId: record.studentId,
          operator: this.props.userid,
        },
        {}
      )
      .then((res) => {
        // console.log(res);
        if (res.ret === 20000) {
          message.success("提醒成功");
          this.getCourseStatisticDetail(
            {},
            {
              title: this.state.titleText,
              value: this.state.weekSelectValue,
              caid: this.state.selectedCaId,
              casid: this.state.selectedCasId,
            }
          );
          this.setState({
            currentRemindRecord: null,
            loading: false,
          });
        } else {
          return Promise.reject(res);
        }
      })
      .catch((err) => {
        message.error(err.msg);
        this.setState({ loading: false });
      });
  };

  // //绑定导师账号
  bind = (params) => {
    this.setState({ loading: true }, () => {
      api
        .bindEDUTeacher(params)
        .then((res) => {
          if (res.ret === 20000) {
            message.success(res.msg);
            let isTeacher = actionCreator.saveIsTeacher(false);
            this.props.dispatch(isTeacher);
            this.getCampus();
            this.setState({
              loading: false,
              showBindModal: false,
              isTeacher: false,
            });
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          // message.error(err.msg);
          this.setState({ loading: false, errorMsg: err.msg });
        });
    });
  };

  close = () => {
    this.setState({ showBindModal: false, errorMsg: "" });
  };

  //
  getAccountNumber = (e) => {
    this.setState({ accountNumber: e.target.value });
  };
  //
  getPassword = (e) => {
    this.setState({ password: e.target.value });
  };

  render() {
    const {
      titleText,
      tableData,
      affirmModalVisible,
      campusList,
      mentorList,
      courseList,
      currentCourseName,
      weekList,
      campusSelectValue,
      mentorSelectValue,
      courseSelectValue,
      weekSelectValue,
      statisticDetail,
      // powerArr,
    } = this.state;

    // if (!(powerArr.includes(6) || powerArr.includes(19))) {
    //   // 非管理员和EZ班主任角色无法查看
    //   return <div></div>;
    // }

    return (
      <Spin
        spinning={this.state.loading}
        indicator={<LoadingOutlined />}
        tip="请稍候..."
        size="large"
      >
        <div className={Style.statisticsWrap}>
          {this.props.isTeacher ? (
            <div className={Style.bindWrap}>
              <div className={Style.bindContent}>
                <span className={Style.btn}></span>
                <div className={Style.text}>请先绑定Cypress帐号</div>
                <Button
                  type="primary"
                  className={Style.bind}
                  onClick={() => {
                    this.setState({ showBindModal: true });
                  }}
                >
                  前往绑定
                </Button>
              </div>
            </div>
          ) : (
            <Fragment>
              <div className={Style.titleBar}>{titleText}</div>
              <div className={Style.searchBar}>
                <div className={Style.t}>
                  <span className={Style.searchBarSpan}>校区：</span>
                  <Select
                    showSearch
                    optionFilterProp="title"
                    style={{ width: 160 }}
                    allowClear
                    placeholder="全部校区"
                    className={Style.schoolSelect}
                    onSelect={(v, o) => this.getMentors(v, o)}
                    value={campusSelectValue}
                    onClear={() => {
                      this.setState({
                        campusSelectValue: null,
                        mentorList: [],
                        mentorSelectValue: null,
                        courseList: [],
                        courseSelectValue: null,
                        weekList: [],
                        weekSelectValue: null,
                      });
                    }}
                  >
                    {campusList.map((v, i) => (
                      <Option
                        key={v.id}
                        value={v.id}
                        campusname={v.campusName}
                        title={v.campusName}
                      >
                        <Tooltip placement='top' title={v.campusName} mouseEnterDelay='0.5'>
                          {v.campusName}
                        </Tooltip>
                      </Option>
                    ))}
                  </Select>
                  <span
                    className={`${Style.searchBarSpan} ${Style.courseName}`}
                  >
                    导师：
                  </span>
                  <Select
                    showSearch
                    optionFilterProp="mentorname"
                    style={{ width: 160 }}
                    allowClear
                    placeholder="导师"
                    className={Style.schoolSelect}
                    onSelect={(v, o) => this.getCourseList(v, o)}
                    value={mentorSelectValue}
                    onClear={() => {
                      this.setState({
                        mentorSelectValue: null,
                        courseList: [],
                        courseSelectValue: null,
                        weekList: [],
                        weekSelectValue: null,
                      });
                    }}
                  >
                    {mentorList.map((v, i) => (
                      <Option
                        key={v.mentorId}
                        value={v.mentorId}
                        campusid={v.campusId}
                        mentorname={v.mentorName}
                        title={v.mentorName}
                      >
                        <Tooltip placement='top' title={v.name} mouseEnterDelay='0.5'>
                          {v.mentorName}
                        </Tooltip>
                      </Option>
                    ))}
                  </Select>
                  <span
                    className={`${Style.searchBarSpan} ${Style.courseName}`}
                  >
                    课程名称：
                  </span>
                  <Select
                    showSearch
                    style={{ width: 282 }}
                    allowClear
                    placeholder="全部课程"
                    className={Style.schoolSelect}
                    dropdownMatchSelectWidth={400}
                    onSelect={(v, o) => this.getWeekList(v, o)}
                    value={courseSelectValue}
                    onClear={() => {
                      this.setState({
                        courseSelectValue: null,
                        weekList: [],
                        weekSelectValue: null,
                      });
                    }}
                  >
                    {courseList.map((v, i) => (
                      <Option
                        key={v.id}
                        campusid={v.campusId}
                        value={`${v.courseCode} (${v.year}) ${v.termDisplay}-${v.assignTypeDisplay}`}
                      >
                        <Tooltip placement='top' title={`${v.courseCode} (${v.year}) ${v.termDisplay}-${v.assignTypeDisplay}`} mouseEnterDelay='0.5'>
                          {`${v.courseCode} (${v.year}) ${v.termDisplay}-${v.assignTypeDisplay}`}
                        </Tooltip>
                      </Option>
                    ))}
                  </Select>
                  <span
                    className={`${Style.searchBarSpan} ${Style.courseName}`}
                  >
                    直播课程：
                  </span>
                  <Select
                    showSearch
                    optionFilterProp="title"
                    style={{ width: 290 }}
                    allowClear
                    placeholder="直播课程"
                    className={Style.schoolSelect}
                    dropdownMatchSelectWidth={450}
                    value={weekSelectValue}
                    onSelect={(v, o) => this.getCourseStatisticDetail(v, o)}
                    onClear={() => {
                      this.setState({ weekSelectValue: null });
                    }}
                  >
                    {weekList.map((v, i) => (
                      <Option
                        key={v.id}
                        caid={v.caId}
                        casid={v.casId}
                        // value={`${currentCourseName}-${v.sectionDisplay}`}
                        title={`${currentCourseName}-${v.sectionDisplay}`}
                        value={v.id}
                      >
                        <Tooltip placement='top' title={`${currentCourseName}-${v.sectionDisplay}`}>
                          {`${currentCourseName}-${v.sectionDisplay}`}
                        </Tooltip>
                      </Option>
                    ))}
                  </Select>
                </div>
                <div className={Style.b}>
                  <span>直播出勤率：</span>
                  <span className={Style.colorText}>
                    {this.getLiveAttend()}
                  </span>
                  <span>
                    （
                    <i className={Style.colorText}>
                      {this.getNumberWithOutZero(
                        statisticDetail.liveAttendanceTotal
                      )}
                    </i>
                    /{this.getNumberWithOutZero(statisticDetail.purchaseTotal)}
                    ）
                  </span>

                  <span className={Style.marginSpan}>总听课率：</span>
                  <span className={Style.colorText}>{this.getAllAttend()}</span>
                  <span>
                    （
                    <i className={Style.colorText}>
                      {this.getNumberWithOutZero(
                        statisticDetail.attendClassTotal
                      )}
                    </i>
                    /{this.getNumberWithOutZero(statisticDetail.purchaseTotal)}
                    ）
                  </span>
                </div>
              </div>

              <div className={Style.mainBox}>
                <Table
                  dataSource={tableData}
                  columns={this.tableColumns}
                  rowKey={(record) => record.studentId}
                  pagination={{ total: tableData.length }}
                  locale={{
                    emptyText: (
                      <Empty
                        image={Empty.PRESENTED_IMAGE_SIMPLE}
                        description="尚未选择课程，请先选择直播课"
                      />
                    ),
                  }}
                />
              </div>

              <Modal
                title="确认提醒"
                centered
                visible={affirmModalVisible}
                onOk={() => {
                  this.remind();
                }}
                onCancel={() => {
                  this.setAffirmModalVisible(false);
                  this.setState({
                    currentRemindRecord: null,
                  });
                }}
                className="EDUStatisticsAffirmModal"
                width={384}
                height={148}
              >
                <p>确认已提醒学生进行学习？</p>
              </Modal>
            </Fragment>
          )}

          {/* 绑定导师账号Modal */}
          {this.state.showBindModal ? (
            <Modal1
              title="绑定Cypress帐号"
              close={this.close}
              actions={[
                <Button onClick={this.close}>取消</Button>,
                <Button
                  type="primary"
                  disabled={
                    this.state.accountNumber === "" ||
                    this.state.password === ""
                  }
                  onClick={() => {
                    this.bind({
                      account: this.state.accountNumber,
                      pwd: this.state.password,
                    });
                  }}
                >
                  确定
                </Button>,
              ]}
            >
              <Input
                placeholder="请输入账号"
                className={Style.bindInput}
                onChange={this.getAccountNumber}
                style={
                  this.state.errorMsg ? { border: "1px solid #DE350B" } : {}
                }
              ></Input>
              <Input
                placeholder="请输入密码"
                type="password"
                className={Style.bindInput}
                onChange={this.getPassword}
                style={
                  this.state.errorMsg ? { border: "1px solid #DE350B" } : {}
                }
              ></Input>
              {this.state.errorMsg ? (
                <div className={Style.errorMsg}>{this.state.errorMsg}</div>
              ) : (
                <div className={Style.block}></div>
              )}
            </Modal1>
          ) : (
            ""
          )}
        </div>
      </Spin>
    );
  }
}

export default connect((store) => store)(Statistics);
