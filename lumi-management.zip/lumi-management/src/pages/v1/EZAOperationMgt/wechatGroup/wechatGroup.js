import React, {useEffect, useState} from 'react';
import {Select, Table, Spin, message, Tooltip} from 'antd';
import Style from './wechatGroup.module.less';
import {LoadingOutlined} from "@ant-design/icons";
import BindCypress from "../../ezCollegeCourseManage/components/bindCypress/bindCypress";
import {connect} from 'react-redux';
import api from "../../../../utils/api";

const {Option} = Select;

function WechatGroup(props) {

  let [loading, setLoading] = useState(false);
  let [campusList, setCampusList] = useState(() => {
    if (props.history && props.history.StorageNavigation && props.history.StorageNavigation.Measures) {
      return props.history.StorageNavigation.Measures.campusList;
    }
    return [];
  });
  let [mentorList, setMentorList] = useState(() => {
    if (props.history && props.history.StorageNavigation && props.history.StorageNavigation.Measures) {
      return props.history.StorageNavigation.Measures.mentorList;
    }
    return [];
  });
  let [campusSelectValue, setCampusSelectValue] = useState(() => {
    if (props.history && props.history.StorageNavigation && props.history.StorageNavigation.Measures) {
      return props.history.StorageNavigation.Measures.campusSelectValue;
    }
    return null;
  });
  let [mentorSelectValue, setMentorSelectValue] = useState(() => {
    if (props.history && props.history.StorageNavigation && props.history.StorageNavigation.Measures) {
      return props.history.StorageNavigation.Measures.mentorSelectValue;
    }
    return null;
  });
  let [page, setPage] = useState(1);
  let [pageSize, setPageSize] = useState(10);
  let [total, setTotal] = useState(0);
  let [vipGroupMenu, setVipGroupMenu] = useState([]);
  let [wechatStatusMenu, setWechatStatusMenu] = useState([]);
  let [dataSource, setDataSource] = useState([
    // {
    //   caid: 123,
    //   name: '123',
    //   wechat: 1,
    //   status: 1,
    // }
  ]);
  let [columns, setColumns] = useState([
    {
      title: 'CAID',
      dataIndex: 'caId',
      key: 'caId',
      width: 200,
      render: (v, record) => {
        return (
            <Tooltip placement="top" title={v} mouseEnterDelay={0.6}>
              <span className={Style.tableClickSpan} onClick={() => {goDetail(record)}}>{v}</span>
            </Tooltip>
        );
      },
    },
    {
      title: 'CA Name',
      dataIndex: 'courseAssignName',
      key: 'courseAssignName',
      render: (v, record) => {
        return (
            <Tooltip placement="top" title={v} mouseEnterDelay={0.6}>
              <span className={Style.tableClickSpan} onClick={() => {goDetail(record)}}>{v}</span>
            </Tooltip>
        );
      },
    },
    {
      title: 'Wechat Status',
      dataIndex: 'groupCount',
      key: 'groupCount',
      filters: [
        // {
        //   text: '好友申请中',
        //   value: 3
        // },
        // {
        //   text: '学生已拉群',
        //   value: 1
        // },
        // {
        //   text: '微信ID有误',
        //   value: 4
        // },
        // {
        //   text: '未拉群',
        //   value: 2
        // }
      ],
      onFilter: (value, record) => {
        if (record.currentShowWechatStatus) {
          return record.currentShowWechatStatus.status === value;
        } else {
          return false;
        }
      },
      sorter: (a, b) => {
        if (a.currentShowWechatStatus && b.currentShowWechatStatus) {
          return (a.currentShowWechatStatus.num - b.currentShowWechatStatus.num);
        }
        return 1;
      },
      filterMultiple: false,
      width: 280,
      render: (v, record) => {
        let text = '';
        if (record.currentShowWechatStatus) {
          text = record.currentShowWechatStatus.num;
        } else if (record.groupCount) {
          text = record.groupCount.reduce((prev, cur) => {
            return prev + cur.num;
          }, 0);
          text = text === 0 ? '' : text;
        }
        return (
            <Tooltip placement="top" title={text} mouseEnterDelay={0.6}>
              <span className={Style.tableClickSpan} onClick={() => {goDetail(record)}}>{text}</span>
            </Tooltip>
        );
      },
    },
    {
      title: 'VIP Group Status',
      dataIndex: 'vipGroupCount',
      key: 'vipGroupCount',
      filters: [
        // {
        //   text: '全部已拉群',
        //   value: 7
        // },
        // {
        //   text: '好友申请中',
        //   value: 3
        // },
        // {
        //   text: '学生已拉群',
        //   value: 1
        // },
        // {
        //   text: '导师已拉群',
        //   value: 6
        // },
        // {
        //   text: '微信ID有误',
        //   value: 4
        // },
        // {
        //   text: '未拉群',
        //   value: 2
        // },
        // {
        //   text: 'Non - Weekly',
        //   value: -1
        // }
      ],
      onFilter: (value, record) => {
        if (record.currentShowVipGroupStatus) {
          return record.currentShowVipGroupStatus.status === value;
        } else {
          return false;
        }
      },
      sorter: (a, b) => {
        if (a.currentShowVipGroupStatus && b.currentShowVipGroupStatus) {
          return (a.currentShowVipGroupStatus.num - b.currentShowVipGroupStatus.num);
        }
        return 1;
      },
      filterMultiple: false,
      width: 280,
      render: (v, record) => {
        let text = '';
        if (record.currentShowVipGroupStatus) {
          if (record.currentShowVipGroupStatus.status === -1) { // 为 -1 的时候显示 non-weekly
            text = record.currentShowVipGroupStatus.statusDisplay;
          } else {
            text = record.currentShowVipGroupStatus.num;
          }
        } else if (record.vipGroupCount) {
          text = record.vipGroupCount.reduce((prev, cur) => {
            return prev + cur.num;
          }, 0);
          text = text === 0 ? '' : text;
        }
        return (
            <Tooltip placement="top" title={text} mouseEnterDelay={0.6}>
              <span className={Style.tableClickSpan} onClick={() => {goDetail(record)}}>{text}</span>
            </Tooltip>
        );
      },
    },
  ]);
  // eslint-disable-next-line
  let [loadingCount, setLoadingCount] = useState(0);

  useEffect(() => {
    getCampus();
    getWechatStatusList();
    // eslint-disable-next-line
  }, [])
  useEffect(() => { // 组件缓存
    props.history.StorageNavigation = {
      ...props.history.StorageNavigation,
      Measures: {
        campusSelectValue,
        mentorSelectValue,
        campusList,
        mentorList,
      }
    }
  //  eslint-disable-next-line
  }, [campusSelectValue, mentorSelectValue])

  useEffect(() => {
    if (mentorSelectValue && campusSelectValue) {
      getOrderList(mentorSelectValue, campusSelectValue);
    }
    //  eslint-disable-next-line
  }, [page, pageSize])

  const getCampus = () => {
    setLoadingCount(v => ++v);
    // 获取校区列表
    setLoading(true);
    api
        .getEduCampus()
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            closeLoading();
            setCampusList(res.data);
          } else {
            if (res.ret === 60001) {
              res.message = res.msg;
            }
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          closeLoading();
        });
  };

  const getMentors = (campusId, option) => {
    setLoadingCount(v => ++v);
    // 获取导师列表
    setLoading(true);
    setCampusSelectValue(option.value);
    setMentorList([]);
    setMentorSelectValue(null);
    api
        .getEduCampusMentors({}, {}, campusId)
        .then((res) => {
          // console.log(res);
          if (res.code === 0) {
            const data = res.data.map((v) => {
              v.campusId = campusId;
              return v;
            });
            setMentorList(data);
            closeLoading();
          } else {
            return Promise.reject(res);
          }
        })
        .catch((err) => {
          message.error(err.message);
          closeLoading();
        });
  };

  const getOrderList = (value, option) => {
    if (option === null) return;
    option.value && setMentorSelectValue(option.value);
    setLoadingCount(v => ++v);
    setLoading(true);
    api.getOrdersList_EZA_Wechat({
      page,
      pageSize,
      mentorId: value,
      campusId: option.campusid || option,
    }).then(res => {
      // console.log(res);
      if (res.code === 0) {
        res.data.forEach(item => {
          if (item.groupCount === null) {
            item.groupCount = [];
          }
          if (item.vipGroupCount === null) {
            item.vipGroupCount = [];
          }
        })
        setDataSource(res.data);
        closeLoading();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      closeLoading();
    })
  }

  const getTotal = (val, option) => {
    setLoadingCount(v => ++v);
    setLoading(true);
    api.getEZA_CA_CourseListTotalCount({
      campusId: option.campusid,
      mentorId: val,
    }).then(res => {
      // console.log(res);
      if (res.code === 0) {
        setTotal(res.data);
        closeLoading();
      }
    }).catch(err => {
      message.error(err.message);
      closeLoading();
    })
  }

  const getWechatStatusList = () => {
    setLoadingCount(v => ++v);
    setLoading(true);
    // 接口参数固定写死 -1
    api.getEZA_CampusOptions(-1).then(res => {
      // console.log(res);
      if (res.code === 0) {
        if (res.data.wechatStatus) {
          let _temp = res.data.wechatStatus.map(item => {
            return {
              value: item.id,
              text: item.name,
            };
          });
          let _vipGroupMenu = [..._temp, {value: -1, text: 'Non - Weekly'}];
          let _wechatData = _temp.filter(item => item.text !== '全部已拉群' && item.text !== '导师已拉群');
          setVipGroupMenu(_vipGroupMenu);
          setWechatStatusMenu(_wechatData);

          setColumns(v => {
            let temp = [...v];
            temp[2].filters = _wechatData;
            temp[3].filters = _vipGroupMenu;
            return temp;
          })
        }
        closeLoading();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      closeLoading();
    })
  }

  const closeLoading = () => {
    setLoadingCount(v => {
      if (--v === 0) {
        setLoading(false);
      }
      return v;
    })
  }

  const goDetail = (record) => {
    props.history.push(`/admin/v1/EZAOperationMgt/wechat-group-detail?caId=${record.caId}&cname=${encodeURI(record.courseAssignName)}`);
  }

  return (
      <Spin size='large' spinning={loading} indicator={<LoadingOutlined/>} tip="请稍候...">
        {
          props.isTeacher ? (
              <BindCypress refresh={() => {
                getCampus();
                getWechatStatusList();
              }}/>
          ) : (
              <div className={Style.EZA_WechatGroupWrap}>
                <div className={Style.topBar}>
                  <Select
                      style={{width: 134}}
                      placeholder='Campus'
                      showSearch
                      optionFilterProp="title"
                      allowClear
                      onSelect={(v, o) => getMentors(v, o)}
                      value={campusSelectValue}
                      onClear={() => {
                        setCampusSelectValue(null);
                        setMentorList([]);
                        setMentorSelectValue(null);
                        setPage(1);
                        setPageSize(10);
                        setTotal(0);
                        setDataSource([]);
                      }}
                  >
                    {
                      campusList.map((v, i) => (
                          <Option
                              key={v.id}
                              value={v.id}
                              campusname={v.campusName}
                              title={v.campusName}
                          >
                            <Tooltip placement='top' title={v.campusName} mouseEnterDelay='0.5'>
                              {v.campusName}
                            </Tooltip>
                          </Option>
                      ))
                    }
                  </Select>
                  <Select
                      style={{width: 134}}
                      placeholder='Mentor'
                      className={Style.mentorSelect} showSearch
                      optionFilterProp="mentorname"
                      allowClear
                      onSelect={(v, o) => {
                        // console.log(v, o);
                        getOrderList(v, o);
                        getTotal(v, o);
                      }}
                      value={mentorSelectValue}
                      onClear={() => {
                        setMentorSelectValue(null);
                        setPage(1);
                        setPageSize(10);
                        setTotal(0);
                        setDataSource([]);
                      }}

                  >
                    {mentorList.map((v, i) => (
                        <Option
                            key={v.mentorId}
                            value={v.mentorId}
                            campusid={v.campusId}
                            mentorname={v.mentorName}
                            title={v.mentorName}
                        >
                          <Tooltip placement='top' title={v.name} mouseEnterDelay='0.5'>
                            {v.mentorName}
                          </Tooltip>
                        </Option>
                    ))}
                  </Select>
                </div>

                <div className={Style.table}>
                  <Table columns={columns} dataSource={dataSource} rowKey={(record) => {
                    return record.caId + record.courseAssignName;
                  }}
                         pagination={{
                           total, pageSize, current: page, showQuickJumper: true, onChange: (_page, _pageSize) => {
                             setPage(_page);
                             setPageSize(_pageSize);
                           },
                           showTotal: total => `Total ${total} items`
                         }}
                         onChange={(pagination, filters) => {
                           let _columnTitleArr = ['', ''];
                           if (filters.groupCount !== null) {
                             for (let i = 0; i < wechatStatusMenu.length; i++) {
                               let item = wechatStatusMenu[i];
                               if (item.value === filters.groupCount[0]) {
                                 _columnTitleArr[0] = 'Wechat - ' + item.text;
                                 break;
                               }
                             }
                           } else {
                             _columnTitleArr[0] = 'Wechat Status';
                           }

                           if (filters.vipGroupCount !== null) {
                             vipGroupMenu.some(item => {
                               if (item.value === filters.vipGroupCount[0]) {
                                 _columnTitleArr[1] = 'VIP Group - ' + item.text;
                               }
                               return item.value === filters[1];
                             })
                           } else {
                             _columnTitleArr[1] = 'VIP Group Status';
                           }

                           // 设置列标题
                           setColumns(v => {
                             let temp = [...v];
                             temp[2].title = _columnTitleArr[0];
                             temp[3].title = _columnTitleArr[1];
                             return temp;
                           })
                           /**
                            * 筛选菜单变化，将相应列数据中符合条件的挑选出来
                            * 分别用 currentShowWechatStatus, 和 currentShowVipGroupStatus 来表示
                            */
                           let _tableData = [...dataSource];
                           _tableData.forEach(item => {
                             // wechat
                             if (filters.groupCount !== null && item.groupCount !== null && item.groupCount.length > 0) {
                               for (let i = 0; i < item.groupCount.length; i++) {
                                 let el = item.groupCount[i];
                                 if (filters.groupCount[0] === el.status) {
                                   item.currentShowWechatStatus = el;
                                   break;
                                 }
                               }
                             }
                             // vip group
                             if (filters.vipGroupCount !== null && item.vipGroupCount !== null && item.vipGroupCount.length > 0) {
                               for (let i = 0; i < item.vipGroupCount.length; i++) {
                                 let el = item.vipGroupCount[i];
                                 if (filters.vipGroupCount[0] === el.status) {
                                   item.currentShowVipGroupStatus = el;
                                   break;
                                 }
                               }
                             }

                             if (filters.groupCount === null) {
                               item.currentShowWechatStatus = '';
                             }
                             if (filters.vipGroupCount === null) {
                               item.currentShowVipGroupStatus = '';
                             }
                           })
                           setDataSource(_tableData);
                         }}
                  />
                </div>
              </div>
          )
        }

      </Spin>
  );
}

export default connect(store => store)(WechatGroup);