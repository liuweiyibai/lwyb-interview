import React, {useEffect, useState} from 'react';
import {withRouter} from 'react-router-dom';
import {Select, Table, Spin, message, Tooltip, Button, Modal, Input} from 'antd';
import Style from './wechatGroupDetail.module.less';
import {LoadingOutlined, EditOutlined, SettingOutlined, PhoneOutlined, MailOutlined} from "@ant-design/icons";
import BindCypress from "../../../ezCollegeCourseManage/components/bindCypress/bindCypress";
import {connect} from 'react-redux';
import api from "../../../../../utils/api";

const {Option} = Select;
const { TextArea } = Input;

function WechatGroupDetail(props) {

  let [loading, setLoading] = useState(false);
  let [ordersCount, setOrdersCount] = useState({
    paid: 0,
    pending: 0,
    refunded: 0,
  })
  let [modalVisible, setModalVisible] = useState(false);
  let [commentModalVisible, setCommentModalVisible] = useState(false);
  let [modalTag, setModalTag] = useState(''); // value: wechat  status  vip
  let [currentRecord, setCurrentRecord] = useState(null);
  let [modalTitle, setModalTitle] = useState('Edit WeChat ID')
  let [courseName, setCourseName] = useState('');
  let [nameId, setNameId] = useState('');
  let [wechatId, setWechatId] = useState('');
  let [wechatStatus, setWechatStatus] = useState(null);
  let [vipGroup, setVipGroup] = useState(null);
  let [comments, setComments] = useState('');
  let [commentsOrderId, setCommentsOrderId] = useState(null);
  let [isEditSubmit, setIsEditSubmit] = useState(false);
  let [isCommentsSubmit, setIsCommentsSubmit] = useState(false);
  let [page, setPage] = useState(1);
  let [pageSize, setPageSize] = useState(10);
  let [total, setTotal] = useState(0);
  let [dataSource, setDataSource] = useState([]);
  let [wechatStatusMenu, setWechatStatusMenu] = useState([]);
  let [vipGroupMenu, setVipGroupMenu] = useState([]);
  let [propsCaId, setPropsCaId] = useState(null);
  let [propsCourseName, setPropsCourseName] = useState('');
  // eslint-disable-next-line
  let [loadingCount, setLoadingCount] = useState(0);
  const columns = [
    {
      title: 'Order Number',
      dataIndex: 'orderNum',
      key: 'orderNum',
      width: 140,
      ellipsis: true,
      render: (v) => {
        return (
            <Tooltip placement="top" title={v}>
              {v}
            </Tooltip>
        );
      },
    },
    {
      title: 'Students Name',
      dataIndex: 'student',
      key: 'student',
      width: 140,
      ellipsis: true,
      render: (v, record) => {
        let name = record.student.lastName + record.student.firstName;
        return (
            <Tooltip placement="top" title={() => {
              return (
                  <div className={Style.toolTipBgWhite}>
                    {
                      record.student.cellphone && <div><PhoneOutlined/> {record.student.cellphone}</div>
                    }
                    {
                      record.student.email && <div><MailOutlined/> {record.student.email}</div>
                    }
                  </div>
              )
            }}>
              {name}
            </Tooltip>
        );
      },
    },
    {
      title: 'Payment Status',
      dataIndex: 'payStatus',
      key: 'payStatus',
      width: 140,
      ellipsis: true,
      render: (v) => {
        let color = '';
        if (v === 'PAID') {
          color = 'green';
        } else if (v === 'UNPAID') {
          color = 'orange';
        } else {
          color = 'red';
        }
        return (
            <Tooltip placement="top" title={v}>
              <div className={Style.paymentCell}><span className={`${Style.paymentStatusDot} ${Style[color]}`}/>{v}
              </div>
            </Tooltip>
        );
      },
    },
    {
      title: 'Wechat ID',
      dataIndex: 'student',
      key: 'wechatId',
      width: 150,
      ellipsis: true,
      render: (v, record) => {
        return (
            <div className={Style.wechatIdCell}>
              <Tooltip placement="top" title={record.student.wechat}>
                <div className={Style.leftText}>{record.student.wechat}</div>
              </Tooltip>
              <div><Button icon={<EditOutlined/>} onClick={() => {
                openModal('wechat', record)
              }} type='text'/></div>
            </div>
        );
      },
    },
    {
      title: 'Wechat Status',
      dataIndex: 'wechatStatusDisplay',
      key: 'wechatStatusDisplay',
      width: 140,
      ellipsis: true,
      render: (v, record) => {
        return (
            <div className={Style.wechatIdCell}>
              <Tooltip placement="top" title={v}>
                <div className={Style.leftText}>{v}</div>
              </Tooltip>
              <div><Button icon={<SettingOutlined/>} onClick={() => {
                openModal('status', record)
              }} type='text'/></div>
            </div>
        );
      },
    },
    {
      title: 'VIP Group',
      dataIndex: 'vipWechatStatusDisplay',
      key: 'vipWechatStatusDisplay',
      width: 140,
      ellipsis: true,
      render: (v, record) => {
        return (
            <div className={Style.wechatIdCell}>
              <Tooltip placement="top" title={v}>
                <div className={Style.leftText}>{v}</div>
              </Tooltip>
              <div><Button icon={<SettingOutlined/>} onClick={() => {
                openModal('vip', record)
              }} type='text'/></div>
            </div>
        );
      },
    },
    {
      title: 'Wechat Assistant',
      dataIndex: 'assistant',
      key: 'assistant',
      width: 155,
      ellipsis: true,
      render: (v) => {
        return (
            <Tooltip placement="top" title={v}>
              {v}
            </Tooltip>
        );
      },
    },
    {
      title: 'Add By',
      dataIndex: 'addGroupBy',
      key: 'addGroupBy',
      width: 140,
      ellipsis: true,
      render: (v) => {
        return (
            <Tooltip placement="top" title={v}>
              {v}
            </Tooltip>
        );
      },
    },
    {
      title: 'Comments',
      dataIndex: 'comments',
      key: 'comments',
      width: 140,
      ellipsis: true,
      render: (v, record) => {
        return (
            <div className={Style.wechatIdCell}>
              <Tooltip placement="top" title={v}>
                <div className={Style.leftText}>{v}</div>
              </Tooltip>
              <div><Button icon={<EditOutlined/>} onClick={() => {
                openCommentsModal(record);
              }} type='text'/></div>
            </div>
        );
      },
    }
  ];

  useEffect(() => {
    getWechatStatusList();
    let paramResult = getUrlParams();
    if (paramResult.cname) {
      setPropsCourseName(decodeURI(paramResult.cname));
    }
  // eslint-disable-next-line
  }, [])

  useEffect(() => {
    if (props.location.search) {
      try {
        // let caid = props.location.search.split('=')[1];
        // setPropsCaId(caid);
        let _props = getUrlParams();
        if (_props.caId) {
          setPropsCaId(_props.caId);
        }
      } catch (e) {}
    }
    getTableData();
    getOrdersCount();
    // eslint-disable-next-line
  }, [page, pageSize, propsCaId])

  useEffect(() => {
    getIsEditSubmit();
    //  eslint-disable-next-line
  }, [modalTag, wechatId, wechatStatus, vipGroup])

  const getUrlParams = () => {
    let paramsStr = props.location.search;
    if (!paramsStr) {
      return {};
    }
    let str = paramsStr.split('?')[1];
    let strArr = str.split('&');
    let result = {};
    strArr.forEach(item => {
      let _arr = item.split('=');
      result[_arr[0]] = _arr[1];
    })
    return result;
  }

  const getTableData = (caid) => {
    if (propsCaId === null) return;
    setLoadingCount(v => ++v);
    setLoading(true);
    api.getOrdersListDetail_EZA_Wechat(caid || propsCaId, {page, pageSize}).then(res => {
      // console.log(res);
      if (res.code === 0) {
        setDataSource(res.data);
        closeLoading();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      closeLoading();
    })
  }

  const getOrdersCount = () => {
    if (propsCaId === null) return;
    setLoadingCount(v => ++v);
    setLoading(true);
    api.getOrdersCount_EZA_Wechat(propsCaId).then(res => {
      // console.log(res);
      if (res.code === 0) {
        if (res.data) {
          let _paid = 0;
          let _all = 0;
          let _refunded = 0;
          res.data.forEach(item => {
            if (item.name === 'PAID') {
              _paid = item.num;
            } else if (item.name === 'REFUNDED') {
              _refunded = item.num;
            } else if (item.name === 'ALL') {
              _all = item.num;
            }
          })
          setOrdersCount({
            paid: _paid,
            pending: _all - _paid - _refunded,
            refunded: _refunded,
          });
          setTotal(_all);
          closeLoading();
        }
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      closeLoading();
      message.error(err.msg);
    })
  }

  const getWechatStatusList = () => {
    setLoadingCount(v => ++v);
    setLoading(true);
    // 接口参数固定写死 -1
    api.getEZA_CampusOptions(-1).then(res => {
      // console.log(res);
      if (res.code === 0) {
        if (res.data.wechatStatus) {
          setVipGroupMenu(res.data.wechatStatus);
          let _wechatData = res.data.wechatStatus.filter(item => item.name !== '全部已拉群' && item.name !== '导师已拉群');
          setWechatStatusMenu(_wechatData);
        }
        closeLoading();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      closeLoading();
    })
  }

  const updateWechatId = ({userId, wechat}) => {
    setLoadingCount(v => ++v);
    setLoading(true);
    api.updateWechat_EZA_Wechat({
      userId: userId,
      wechat,
    }).then(res => {
      // console.log(res);
      if (res.ret === 20000) {
        message.success(res.msg);
        closeLoading();
        closeModal();
        getTableData();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.msg);
      closeLoading();
    })
  }

  const updateComment = ({content, orderId}) => {
    setLoadingCount(v => ++v);
    setLoading(true);
    api.updateComment_EZA_Wechat(orderId, {content}).then(res => {
      // console.log(res);
      if (res.ret === 20000) {
        message.success(res.msg);
        getTableData();
        closeLoading();
        closeCommentsModal();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.msg);
      closeLoading();
    })
  }

  const updateWechatStatus = ({orderId, statusId, type}) => {
    setLoadingCount(v => ++v);
    setLoading(true);
    api.updateWechatStatus_EZA_Wechat(orderId, statusId, {
      type,
    }).then(res => {
      // console.log(res);
      if (res.code === 0) {
        message.success(res.message || 'SUCCESS');
        closeLoading();
        closeModal();
        getTableData();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      closeLoading();
    })
  }

  const closeLoading = () => {
    setLoadingCount(v => {
      if (--v === 0) {
        setLoading(false);
      }
      return v;
    })
  }

  const closeModal = () => {
    setModalVisible(false);
    clearEditModalData();
  }

  const openModal = (tag, record) => {
    setModalTag(tag);
    setModalVisible(true);
    // console.log(record);
    setCourseName(record.courseAssignName);
    setNameId(record.student.lastName + record.student.firstName);
    setWechatId(record.student.wechat || '');
    setWechatStatus(record.wechatStatus);
    setVipGroup(record.vipWechatStatus);
    setCurrentRecord(record);

    if (tag === 'wechat') {
      setModalTitle('Edit WeChat ID');
    } else if (tag === 'status') {
      setModalTitle('Edit WeChat Status');
    } else {
      setModalTitle('Edit VIP Group');
    }
  }

  const openCommentsModal = (record) => {
    setIsCommentsSubmit(false);
    setComments(record.comments || '');
    setCommentsOrderId(record.id);
    setCommentModalVisible(true);
  }

  const closeCommentsModal = () => {
    setCommentModalVisible(false);
    setCommentsOrderId(null);
    setComments('');
  }

  const clearEditModalData = () =>{
    setModalTag('');
    setCurrentRecord(null);
    setCourseName('');
    setNameId('');
    setWechatId('');
    setWechatStatus(null);
    setVipGroup(null);
  }

  const getIsEditSubmit = () => {
    let canClick = false;
    canClick = (modalTag === 'wechat' && wechatId !== '') ||
        (modalTag === 'status' && wechatStatus !== null) ||
        (modalTag === 'vip' && vipGroup !== null);
    setIsEditSubmit(canClick);
  }

  const setWechatIdInputValue = (e) => {
    setWechatId(e.target.value);
  }

  const setWechatStatusSelectValue = (val) => {
    val = val === undefined ? null : val;
    setWechatStatus(val);
  }

  const setVipGroupSelectValue = (val) => {
    val = val === undefined ? null : val;
    setVipGroup(val);
  }

  const setCommentsInputValue = (e) => {
    // console.log(e.target.value);
    setComments(e.target.value);
    if (e.target.value !== '') {
      setIsCommentsSubmit(true);
    } else {
      setIsCommentsSubmit(false);
    }
  }

  const changePageAndSize = (_page, _pageSize) => {
    // console.log(_page, _pageSize);
    setPage(_page);
    setPageSize(_pageSize);
  }

  const modalSubmit = () => {
    if (modalTag === 'wechat') {
      // console.log(wechatId, currentRecord.student.id);
      updateWechatId({userId: currentRecord.student.id, wechat: wechatId});
    } else if (modalTag === 'status') {
      // console.log('status');
      let params = {
        orderId: currentRecord.id,
        statusId: wechatStatus,
        type: 0,
      }
      // console.log(params);
      updateWechatStatus(params);
    } else if (modalTag === 'vip') {
      let params = {
        orderId: currentRecord.id,
        statusId: vipGroup,
        type: 1,
      }
      updateWechatStatus(params);
    }
  }

  return (
      <Spin size='large' spinning={loading} indicator={<LoadingOutlined/>} tip="请稍候...">
        {
          props.isTeacher ? (
              <BindCypress refresh={() => {

              }}/>
          ) : (
              <div className={Style.EZA_WechatGroupDetailWrap}>
                <div className={Style.topBar}>
                  <div className={Style.courseName}>
                    {propsCourseName}
                  </div>
                  <div className={Style.topBarRight}>
                    <span>Paid: <i className={Style.green}>{ordersCount.paid}</i></span>
                    <span>Pending: <i className={Style.orange}>{ordersCount.pending}</i></span>
                    <span>Refunded: <i className={Style.red}>{ordersCount.refunded}</i></span>
                  </div>
                </div>

                <div className={Style.table}>
                  <Table columns={columns} dataSource={dataSource} rowKey='id'
                         pagination={{total, pageSize, current: page, showQuickJumper: true, onChange: changePageAndSize}}/>
                </div>

                <Modal visible={modalVisible} title={modalTitle} className={Style.wechatModal} getContainer={false}
                       cancelButtonProps={{type: 'text'}} width={680} okButtonProps={{disabled: !isEditSubmit}}
                       onCancel={closeModal} onOk={modalSubmit}
                >
                  <div className={Style.modalItem}>
                    <div className={Style.title}>Course Assignment Name</div>
                    <div className={Style.content}>{courseName}</div>
                  </div>
                  <div className={Style.modalItem}>
                    <div className={Style.title}>Name ID</div>
                    <div className={Style.content}>{nameId}</div>
                  </div>

                  {
                    modalTag !== 'wechat' && wechatId !== '' && (
                        <div className={Style.modalItem}>
                          <div className={Style.title}>WeChat ID</div>
                          <div className={Style.content}>{wechatId}</div>
                        </div>
                    )
                  }
                  {/*WeChat ID*/}
                  {
                    modalTag === 'wechat' && (
                        <div className={Style.modalItem}>
                          <div className={Style.title}>WeChat ID</div>
                          <div className={Style.content}>
                            <Input className={Style.wechatInput} allowClear placeholder='Input WeChat ID'
                                   value={wechatId} onChange={setWechatIdInputValue}/>
                          </div>
                        </div>
                    )
                  }
                  {/*Wechat Status*/}
                  {
                    modalTag === 'status' && (
                        <div className={Style.modalItem}>
                          <div className={Style.title}>Wechat Status</div>
                          <div className={Style.content} id='select-status'>
                            <Select className={Style.modalSelect} placeholder='Select Wechat Status' allowClear
                                    value={wechatStatus}
                                    getPopupContainer={() => document.getElementById('select-status')}
                                    onChange={setWechatStatusSelectValue}
                            >
                              {
                                wechatStatusMenu.map(item => (
                                    <Option key={item.id} value={item.id}>{item.name}</Option>
                                ))
                              }
                            </Select>
                          </div>
                        </div>
                    )
                  }
                  {/*VIP Group*/}
                  {
                    modalTag === 'vip' && (
                        <div className={Style.modalItem}>
                          <div className={Style.title}>VIP Group</div>
                          <div className={Style.content} id='select-vip'>
                            <Select className={Style.modalSelect} placeholder='Select VIP Group' allowClear
                                    value={vipGroup}
                                    getPopupContainer={() => document.getElementById('select-vip')}
                                    onChange={setVipGroupSelectValue}
                            >
                              {
                                vipGroupMenu.map(item => (
                                    <Option key={item.id} value={item.id}>{item.name}</Option>
                                ))
                              }
                            </Select>
                          </div>
                        </div>
                    )
                  }
                </Modal>

                <Modal visible={commentModalVisible} title='Comments' className={Style.wechatModal} getContainer={false}
                       cancelButtonProps={{type: 'text'}} width={680} onCancel={closeCommentsModal}
                       okButtonProps={{disabled: !isCommentsSubmit}} onOk={() => {
                         updateComment({
                           content: comments,
                           orderId: commentsOrderId,
                         })
                }}
                >
                  <TextArea rows={4} value={comments} onChange={setCommentsInputValue} placeholder='Input Comments'/>
                </Modal>
              </div>
          )
        }

      </Spin>
  )
}

export default withRouter(connect(store => store)(WechatGroupDetail));