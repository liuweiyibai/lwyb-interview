import React, {useState, useEffect} from 'react';
import { Button, Input, Divider, Table, Spin, Popconfirm, message } from 'antd';
import fun from '../../../../utils/funSum.js';
import api from '../../../../utils/api';
import {QuestionCircleOutlined, LoadingOutlined} from '@ant-design/icons';
import Style from './wechatUnbind.module.less';

export default function WechatUnbind() {
  const [dataSource, setDataSource] = useState([
    // {
    //   email: '123456789@qq.com',
    //   campus: 'UTSG',
    //   userId: '123456789',
    //   wechat_name: 'abcdefghj',
    //   unbind_time: '2021-08-03 14:13:12',
    //   unbind_status: !true,
    // }
  ]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [emailVal, setEmailVal] = useState('');
  const [wechatNameVal, setWechatNameVal] = useState('');
  const [isSearchBtnDisable, setIsSearchBtnDisable] = useState(false);
  const [loading, setLoading] = useState(false);
  const columns = [
    fun.getColumnItem('学生邮箱', 'oauthEmail', 160),
    fun.getColumnItem('userID', 'userId', 160),
    fun.getColumnItem('微信名', 'oauthUserName', 160),
    fun.getColumnItem('解绑人', 'unbindOperator', 160),
    fun.getColumnTimeItem('解绑时间', 'unbindTime'),
    {
      title: '当前状态',
      align: 'center',
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (record) => {
        const status = record.deleted;

        const jsx = status ? <span className={Style.unbind_status}>已解绑</span> : <div>使用中<Popconfirm icon={<QuestionCircleOutlined style={{ color: 'red' }} />} onConfirm={() => onUnbindClick(record)} placement="top" title="确认解绑吗？" okText="确定" cancelText="取消"><Button type="link" >解绑</Button></Popconfirm></div>;
        
        return jsx;
      },
    }
  ];

  useEffect(() => {
    emailVal || wechatNameVal ? setIsSearchBtnDisable(false) : setIsSearchBtnDisable(true);
  }, [emailVal, wechatNameVal])

  useEffect(() => {
    getSearchData();
    // eslint-disable-next-line
  }, [currentPage, pageSize])

  const onInputEmail = (e) => {
    setEmailVal(e.target.value);
  }

  const onInputWechatName = (e) => {
    setWechatNameVal(e.target.value);
  }

  const onUnbindClick = (item) => {
    // console.log(item);
    unbindWechat(item.id);
  }

  const onPaginationChange = (page, pageSize) => {
    setCurrentPage(page);
    setPageSize(pageSize);
  }

  const onSearch = () => {
    // console.log(emailVal, wechatNameVal);
    if (currentPage === 1) {
      getSearchData();
    } else {
      setCurrentPage(1);
    }
    
  }

  const getSearchData = () => {
    if (!(emailVal || wechatNameVal)) return;
    setLoading(true);
    api.getWechatUnbindData_EZA_Wechat({ email: emailVal || null, weChatName: wechatNameVal || null , idisplayLength: pageSize, idisplayStart: currentPage - 1}).then(res => {
      // console.log(res);
      if (res.code === 0) {
        setDataSource(res.data?.data || []);
        setLoading(false);
        setTotal(res.data.total);
      } else {
        if (res.code === 400000) {
          res.message = '请求频繁，稍后再试';
        }
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      setLoading(false);
    })
  }

  const unbindWechat = (userOauthWeChatId) => {
    const cms_username = window.localStorage.getItem('userName').replace(/"/g, '');
    setLoading(true);
    api.unBindWechat_EZA_Wechat({ unbindOperator: cms_username, userOauthWeChatId }).then(res => {
      // console.log(res);
      if (res.code === 0) {
        setLoading(false);
        getSearchData();
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      setLoading(false);
    })
  }

  return (
    <div className={Style.wechatUnbind}>
      <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...'>
        <div className={Style.header}>
          <div className={Style.left}>
            <div><span>邮箱：</span><Input className={Style.inputBox} placeholder="请输入邮箱" onChange={onInputEmail}/></div>
            <div><span>微信名：</span><Input className={`${Style.inputBox} ${Style.inputBox_wechat}`} placeholder="请输入微信名" onChange={onInputWechatName}/></div>
          </div>
          <Button className={Style.btn} type="primary" onClick={onSearch} disabled={isSearchBtnDisable}>查询</Button>
        </div>

        <Divider />

        <Table dataSource={dataSource} columns={columns} className={Style.table} rowKey={(record => record.userId + record.id)} pagination={{current: currentPage, pageSize: pageSize, showQuickJumper: true, onChange: onPaginationChange, total: total}}/>
      </Spin>
    </div>
  )
}
