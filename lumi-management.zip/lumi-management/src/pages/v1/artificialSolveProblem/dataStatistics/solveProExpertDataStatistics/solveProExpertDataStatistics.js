import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Spin, Button, Table, Pagination, DatePicker, Select, message, Tabs } from 'antd';
import { LoadingOutlined, SearchOutlined, DownloadOutlined } from '@ant-design/icons';
import Style from './solveProExpertDataStatistics.module.less';
import api from '../../../../../utils/api';
import moment from 'moment';
import 'moment/locale/zh-cn';
import fun from '../../../../../utils/funSum.js';
moment.locale('zh-cn');

const { TabPane } = Tabs;

const { Option } = Select;
class SolveProExpertDataStatistics extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            typeId: 1, // 查询 类型  每日 1/ 每周 2
            nameList: [],//解题专家姓名列表
            expertName: null,//下拉所选解题专家名
            expertId: '',//下拉所选解题专家id
            subjectList: [],//擅长学科列表
            subjectName: null,//下拉所选擅长学科名
            subjectId: '',//下拉所选擅长学科id
            startDate: moment().subtract(7, 'days').startOf('week'),//所选周起始日期  -------|
            endDate: moment().subtract(7, 'days').endOf('week'),//所选周结束日期    -------|___每日的时候默认选中的是昨天
            chooseDate: moment().subtract(1, 'days'),//每日
            page: 1,
            pageSize: 10,
            total: 0,
            exportData: '',
            columnsWeek: []
        }
    }
    columns = [
        fun.getColumnItem('姓名','userName'),
        fun.getColumnItem('擅长学科','subjectAndLevel'),
        fun.getColumnItem('被分配工单','assignCount'),
        fun.getColumnItem('人工关闭工单','orderClosedCount'),
        fun.getColumnItem('已解答工单','answerCount'),
        fun.getColumnItem('被抽检工单','inspectOrderCount'),
        fun.getColumnItem('通过抽检工单','passCheckOrderCount'),
        fun.getColumnItem('通过率','passRate'),
        fun.getColumnItem('解题平均用时','avgSolveTime'),
    ]
    componentDidMount() {// 初始化每日数据的表格columns数据，复制数组，将需要屏蔽的数据去掉
        let _columns = [...this.columns];
        _columns.splice(5, 3);
        this.setState({
            columnsWeek: _columns
        })
        this.getExpertNamelist();
        this.getSubjectList();
        this.getExpertOrdersList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, start: this.state.typeId === 2 ? this.state.startDate.format('YYYY-MM-DD') : this.state.chooseDate.format('YYYY-MM-DD'), end: this.state.typeId === 2 ? this.state.endDate.format('YYYY-MM-DD') : this.state.chooseDate.format('YYYY-MM-DD'), type: this.state.typeId });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取解题专家下拉列表
    getExpertNamelist = () => {
        this.setState({ loading: true }, () => {
            api.getExpertNamelist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ nameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取擅长学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取所选周
    getWeek = (date) => {
        if (date) {
            this.refs.changeWeek.blur();
            let startDate = moment(date).startOf('week');
            let endDate = moment(date).endOf('week');
            this.setState({ startDate, endDate });
        } else {
            this.setState({ startDate: '', endDate: '' });
        }
    }
    //获取所选日
    getDay = (date) => {
        if (date) {
            this.refs.changeDay.blur();
            let chooseDate = date;
            this.setState({ chooseDate });
        } else {
            this.setState({ chooseDate: '' });
        }
    }
    //获取解题专家工单统计列表
    getExpertOrdersList = (params) => {
        this.setState({ loading: true }, () => {
            api.getExpertOrdersList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                })
        })
    }
    //获取需要导出的专家统计数据
    getExportExpertStatistics = (params) => {
        this.setState({ loading: true }, () => {
            api.getExportExpertOrdersList(params, { responseType: 'arraybuffer' })
                .then(async (response) => {
                    fun.download(response, `专家提交答案数据统计-${moment(new Date()).format('YYYYMMDD')}.xlsx`)
                    this.setState({ loading: false })
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false })
                })
        })
    }
    //获取学科下拉所选value
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //获取解题专家下拉所选value
    getExpert = (value, option) => {
        if (value && option) {
            this.refs.expert.blur();
            this.setState({ expertName: value, expertId: option.key });
        } else {
            this.setState({ expertName: null, expertId: '' });
        }
    }
    //查询
    search = () => {
        this.getExpertOrdersList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, start: this.state.typeId === 2 ? this.state.startDate.format('YYYY-MM-DD') : this.state.chooseDate.format('YYYY-MM-DD'), end: this.state.typeId === 2 ? this.state.endDate.format('YYYY-MM-DD') : this.state.chooseDate.format('YYYY-MM-DD'), subId: this.state.subjectId, solverId: this.state.expertId, type: this.state.typeId });
    }
    //查询需要导出的专家统计数据
    searchExportData = () => {
        this.getExportExpertStatistics({ start: this.state.typeId === 2 ? this.state.startDate.format('YYYY-MM-DD') : moment(this.state.chooseDate, 'YYYY-MM-DD'), end: this.state.typeId === 2 ? this.state.endDate.format('YYYY-MM-DD') : moment(this.state.chooseDate, 'YYYY-MM-DD'), solverId: this.state.expertId });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getExpertOrdersList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, start: this.state.typeId === 2 ? this.state.startDate.format('YYYY-MM-DD') : moment(this.state.chooseDate, 'YYYY-MM-DD'), end: this.state.typeId === 2 ? this.state.endDate.format('YYYY-MM-DD') : moment(this.state.chooseDate, 'YYYY-MM-DD'), subId: this.state.subjectId, solverId: this.state.expertId, type: this.state.typeId });
        })
    }
    // tab回调
    tabChange = (key) => {
        // 接口参数  1 => 日  2 => 周
        this.setState({ typeId: Number(key), startDate: moment().subtract(7, 'days').startOf('week'), endDate: moment().subtract(7, 'days').endOf('week'), }, () => {
            this.search(); // 刷新页面
        });
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <Tabs defaultActiveKey="1" onChange={this.tabChange}>
                        <TabPane tab="每日数据" key="1"></TabPane>
                        <TabPane tab="每周数据" key="2"></TabPane>
                    </Tabs>
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <span>统计时间段：</span>
                            {
                                // 日为1，周为2
                                this.state.typeId === 1 ?
                                    <Fragment>
                                        <DatePicker ref='changeDay' className={Style.select} allowClear={false} onChange={this.getDay} disabledDate={(date) => {
                                            return date > moment()
                                        }} value={this.state.chooseDate} />
                                    </Fragment> : ''}
                            {
                                this.state.typeId === 2 ?
                                    <Fragment>
                                        <DatePicker picker="week" ref='changeWeek' className={Style.select} allowClear={false} onChange={this.getWeek} disabledDate={(date) => {
                                            return date > moment().startOf('week')
                                        }} defaultValue={moment().subtract(7, "days")}
                                        />
                                    </Fragment> : ''
                            }
                            {this.props.level === 2 ? <Fragment>
                                <span>解题专家：</span>
                                <Select placeholder='全部' ref='expert' className={Style.select} value={this.state.expertName} onChange={this.getExpert} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.nameList.map((item, index) => {
                                        return (
                                            <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                        )
                                    })}
                                </Select>
                                <span>学科：</span>
                                <Select placeholder='全部' ref='subject' className={Style.select} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item, index) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    })}
                                </Select>
                            </Fragment> : ''}
                        </div>
                        <div className={Style.right}>
                            <Button type='primary' className={Style.button} icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                            {this.state.typeId === 1 ? "" : <Button type='primary' className={Style.button} icon={<DownloadOutlined />} onClick={this.searchExportData} > 工单解答时段数据</Button>}
                        </div>
                    </div>
                    {
                        this.state.typeId === 1 ?
                            <Table
                                dataSource={this.state.dataSource}
                                columns={this.state.columnsWeek}
                                bordered={true}
                                pagination={false}
                                rowKey={dataSource => dataSource.userName}
                            ></Table> :
                            <Table
                                dataSource={this.state.dataSource}
                                columns={this.columns}
                                bordered={true}
                                pagination={false}
                                rowKey={dataSource => dataSource.userName}
                            ></Table>
                    }
                    <Pagination className={Style.pagination} showQuickJumper hideOnSinglePage current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                </Spin>
            </Fragment>
        )
    }
}

export default connect(store => store)(SolveProExpertDataStatistics);