import React, { Fragment, Component } from "react";
import moment from "moment";
import Style from "./workOrderStatistics.module.less";
import api from "../../../../../utils/api.js";
import fun from '../../../../../utils/funSum.js';
import { Divider, DatePicker, Select, Button, Table, Popover, message, Spin } from "antd";
import { ExclamationCircleOutlined, DoubleRightOutlined, LoadingOutlined, SearchOutlined } from "@ant-design/icons";
const { Option } = Select;

class WorkOrdStatistical extends Component {
	constructor() {
		super();
		this.state = {
			loading: false,
			// 工单数量统计表格数据
			quantityTableData: [
				{
					key: "1",
					item: "数量（个）",
					add: 0,
					close: 0,
					resolved: 0,
					inspection: 0,
					pass: 0,
				},
			],
			quantityTableColumns: [
				{
					title: "",
					dataIndex: "item",
					key: "item",
					align: "center",
					render: (text) => (
						<div className={Style["table-first-col"]}>{text}</div>
					),
				},
				{
					title: (
						<Popover content="创建时间在统计时段内的工单" title="新增工单">
							新增工单
						</Popover>
					),
					dataIndex: "add",
					key: "add",
					align: "center",
				},
				{
					title: (
						<Popover
							content="关闭时间在统计时段内并且是人工关闭的工单"
							title="人工关闭工单"
						>
							人工关闭工单
						</Popover>
					),
					dataIndex: "close",
					key: "close",
					align: "center",
				},
				{
					title: (
						<Popover
							content="解答时间均在统计时段内的工单，其创建时间可能在统计时段内，也可能更早"
							title="已解答工单"
						>
							已解答工单
						</Popover>
					),
					key: "resolved",
					dataIndex: "resolved",
					align: "center",
				},
				{
					title: (
						<Popover
							content="统计时段内，被抽取出进行质检的工单"
							title="被抽检工单"
						>
							被抽检工单
						</Popover>
					),
					key: "inspection",
					dataIndex: "inspection",
					align: "center",
				},
				{
					title: (
						<Popover
							content="统计时段内，被抽检且通过了质检的工单"
							title="通过质检工单"
						>
							通过质检工单
						</Popover>
					),
					key: "pass",
					dataIndex: "pass",
					align: "center",
				},
			],
			// 工单时长统计表格数据
			durationTableData: [
				{
					key: "1",
					item: (
						<Popover
							content="解答时间在统计时间段内的工单，其分配时间 – 创建时间记为分配时长"
							title="分配用时"
						>
							分配用时
						</Popover>
					),
					average: 0,
					max: 0,
					min: 0,
				},
				{
					key: "2",
					item: (
						<Popover
							content="解答时间在统计时间段内的工单，其解答时间 – 分配时间记为解答时长"
							title="解答用时"
						>
							解答用时
						</Popover>
					),
					average: 0,
					max: 0,
					min: 0,
				},
			],
			durationTableColumns: [
				{
					title: "",
					dataIndex: "item",
					key: "item",
					align: "center",
					render: (text) => (
						<div className={Style["table-first-col"]}>{text}</div>
					),
				},
				{
					title: "平均值（min）",
					dataIndex: "average",
					key: "average",
					align: "center",
				},
				{
					title: "最大值（min）",
					dataIndex: "max",
					key: "max",
					align: "center",
				},
				{
					title: "最小值（min）",
					key: "min",
					dataIndex: "min",
					align: "center",
				},
			],
			// 上周的今天
			weekPickerDefaultValue: moment().subtract(7, "days"),
			weekStartDate: moment().week(moment().week() - 1).startOf('week').format('YYYY-MM-DD'),//所选周起始日期
			weekEndDate: moment().week(moment().week() - 1).endOf('week').format('YYYY-MM-DD'),//所选周结束日期
			// 学科下拉菜单按钮
			subjectMenu: [],
			// 当前选中的学科
			currentSubjectId: null,
		};
	}

	componentDidMount() {
		this.getSubjectList();
		this.getTableData({ end: this.state.weekEndDate, start: this.state.weekStartDate });
		fun.addKeyboardListener(this.search);//监听回车查询事件
	}
	componentWillUnmount() {
		fun.removeKeyboardListener();
		this.setState = () => {
            return;
        };
	}
	// 获取支持的学科
	getSubjectList = () => {
		this.setState({ loading: true }, () => {
			api.getSubject({ manualMark: 1 })
				.then((res) => {
					if (res.ret === 20000) {
						this.setState({ subjectMenu: [{ id: "all", manualMark: 1, subjectName: "全部", }, ...res.result], loading: false });
					} else {
						return Promise.reject(res);
					}
				})
				.catch((err) => {
					message.error(err.msg);
					this.setState({ loading: false });
				})
		})
	}
	//获取table数据
	getTableData = (params) => {
		this.setState({ loading: true }, () => {
			api.getOrderStatisticsData(params)
				.then(res => {
					// 分配用时、解答用时
					let assignTimeStatic = this.state.durationTableData[0];
					let solveTimeStatic = this.state.durationTableData[1];
					// 工单数量统计
					let countStaticResult = this.state.quantityTableData[0];
					assignTimeStatic.average = res.result.timeStaticResult.assignTimeStatic.avgTime;
					assignTimeStatic.max = res.result.timeStaticResult.assignTimeStatic.maxTime;
					assignTimeStatic.min = res.result.timeStaticResult.assignTimeStatic.minTime;

					solveTimeStatic.average = res.result.timeStaticResult.solveTimeStatic.avgTime;
					solveTimeStatic.max = res.result.timeStaticResult.solveTimeStatic.maxTime;
					solveTimeStatic.min = res.result.timeStaticResult.solveTimeStatic.minTime;

					countStaticResult.add = res.result.countStaticResult.increasedCount;
					countStaticResult.close = res.result.countStaticResult.closeByManualCount;
					countStaticResult.resolved = res.result.countStaticResult.solvedCount;
					countStaticResult.inspection = res.result.countStaticResult.checkedCount;
					countStaticResult.pass = res.result.countStaticResult.checkedPassCount;
					this.setState({
						durationTableData: [assignTimeStatic, solveTimeStatic],
						quantityTableData: [countStaticResult],
						loading: false
					});
				})
				.catch((err) => {
					message.error(err.msg);
					this.setState({ loading: false });
				})
		})
	}
	// dataPicker组件
	changeWeek = (v1, v2) => {
		//获取周的范围
		this.refs.changeWeek.blur();
		const startDate = moment(v1).startOf('week').format("YYYY-MM-DD"); //这样是年月日的格式
		const endDate = moment(v1).endOf('week').format("YYYY-MM-DD"); //这样是时间戳的格式
		this.setState({
			weekStartDate: startDate,
			weekEndDate: endDate
		})
	};
	// 下拉菜单
	changeSelect = (value, option) => {
		if (value && option) {
			this.refs.changeSelect.blur();
			this.setState({ currentSubjectId: value });
		} else {
			this.setState({ currentSubjectId: '' });
		}
	};
	// 跳转页面
	changePage = () => {
		this.props.history.push("/admin/v1/artificialSolveProblem/solveProExpertDataStatistics");
	};
	//查询
	search = () => {
		this.getTableData({ start: this.state.weekStartDate, end: this.state.weekEndDate, subId: this.state.currentSubjectId === 'all' ? null : this.state.currentSubjectId });
	};
	render() {
		const { quantityTableData, quantityTableColumns, durationTableData, durationTableColumns, weekPickerDefaultValue, subjectMenu } = this.state;
		return (
			<Fragment>
				<Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
					<div className={Style["top-tip"]}>
						<ExclamationCircleOutlined />
						&emsp;可查看上周或更早时间的工单统计数据
					</div>
					<Divider />
					<div className={Style.searchWrap}>
						<div className={Style.left}>
							<span className={Style.span}>统计时间段：</span>
							<DatePicker
								ref='changeWeek'
								onChange={this.changeWeek}
								picker="week"
								disabledDate={(date) => {
									return date > moment().startOf('week')
								}}
								defaultValue={weekPickerDefaultValue}
							/>
							<span className={Style.span}>工单学科：</span>
							<Select
								ref='changeSelect'
								defaultValue="all"
								showSearch
								className={Style.select}
								placeholder="请选择工单学科"
								optionFilterProp="children"
								onChange={this.changeSelect}
								filterOption={(input, option) =>
									option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
								}
								allowClear={true}
							>
								{subjectMenu.map((item) => {
									return (
										<Option value={item.id} key={item.id}>
											{item.subjectName}
										</Option>
									);
								})}
							</Select>
						</div>
						<Button type="primary" icon={<SearchOutlined />} className={Style.button} onClick={this.search}>查询</Button>
					</div>
					<div className={Style["main-table"]}>
						<Table
							className={Style.table}
							columns={quantityTableColumns}
							dataSource={quantityTableData}
							bordered={true}
							size="small"
							pagination={false}
							title={(v) => {
								return <div className={Style["table-title"]}>工单数量统计：</div>;
							}}
						/>
						<Table
							className={Style.table}
							columns={durationTableColumns}
							dataSource={durationTableData}
							bordered
							size="small"
							pagination={false}
							title={(v) => {
								return <div className={Style["table-title"]}>工单时长统计：</div>;
							}}
						/>
					</div>
					<div className={Style.table}>
						<Button type="link" onClick={this.changePage}>
							查看解题专家工单统计 <DoubleRightOutlined />
						</Button>
					</div>
				</Spin>
			</Fragment>
		);
	}
}
export default WorkOrdStatistical;
