import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { message, Pagination, Divider, Select, Button, Spin, Tooltip, Table } from 'antd';
import { SearchOutlined, LoadingOutlined, ExclamationCircleOutlined, } from '@ant-design/icons';
import api from '../../../../../utils/api';
import fun from '../../../../../utils/funSum';
import Style from './orderHumanResourceMonitor.module.less';
import moment from 'moment';
import 'moment/locale/zh-cn';
moment.locale('zh-cn');

const { Option } = Select;

class OrderHumanResourceMonitor extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            subjectList: [],//学科列表
            subjectName: null,//学科名
            showSubjectName: '',//展示的学科名
            dataSource: [],
            page: 1,
            pageSize: 50,
            total: 0,
        }
    }
    columns = [
        {
            title: '解题专家',
            dataIndex: 'solverName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: solverName => (
                <Tooltip placement="top" title={solverName}>
                    {solverName}
                </Tooltip>
            ),
        },
        {
            title: '待解答工单数量',
            dataIndex: 'prepAnswerOrderCount',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: prepAnswerOrderCount => (
                <Tooltip placement="top" title={prepAnswerOrderCount}>
                    {prepAnswerOrderCount}
                </Tooltip>
            ),
        },
        {
            title: '工单库容量',
            dataIndex: 'orderCapacity',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: orderCapacity => (
                <Tooltip placement="top" title={orderCapacity}>
                    {orderCapacity}
                </Tooltip>
            ),
        },
        {
            title: '工单饱和度',
            align: 'center',
            render: record => {
                let value = record.orderCapacity === 0 ? 'NAN' : Math.floor(record.prepAnswerOrderCount / record.orderCapacity * 100) + '%';
                return (
                    <Tooltip placement="top" title={value}>
                        {value}
                    </Tooltip>
                )
            }
        },
        {
            title: '人力状态',
            align: 'center',
            render: record => {
                let value = record.orderCapacity === 0 ? '系统分配停止' : Math.floor(record.prepAnswerOrderCount / record.orderCapacity * 100) >= 100 ? '系统分配停止' : '系统分配中';
                return (
                    <Tooltip placement="top" title={value}>
                        {value}
                    </Tooltip>
                )
            }
        }
    ]
    componentDidMount() {
        this.getOrderHumanReourseMonitorList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        this.getSubjectList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取select所选学科
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //获取工单人力资源监控表
    getOrderHumanReourseMonitorList = (params) => {
        this.setState({ loading: true }, () => {
            api.getOrderHumanReourseMonitorList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false, showSubjectName: this.state.subjectName === null ? 'All' : this.state.subjectName });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //查询
    search = () => {
        this.getOrderHumanReourseMonitorList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, subId: this.state.subjectId, });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getOrderHumanReourseMonitorList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, subId: this.state.subjectId, });
        });
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.h3}>
                        <ExclamationCircleOutlined />
						&emsp;展示岗位状态为工作中且当前时间包含在工作时间段内的解题专家
					</div>
                    <Divider />
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <div className={Style.box}>
                                <span className={Style.span}>学科：</span>
                                <Select placeholder='全部' ref='subject' className={Style.select} maxTagTextLength={10} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </div>
                        <Button type='primary' icon={<SearchOutlined />} className={Style.search} onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <h3 className={Style.h3}>{this.state.showSubjectName}学科解题专家共{this.state.total}位</h3>
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.solverId}
                        bordered={true}
                        pagination={false}
                        rowClassName={dataSource => dataSource.orderCapacity === 0 || Math.floor(dataSource.prepAnswerOrderCount / dataSource.orderCapacity * 100 >= 100) ? Style.selectRow : ''}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                </Spin>
            </Fragment>
        )
    }
}

export default connect(store => store)(OrderHumanResourceMonitor);