import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux'
import { Button, Select, Divider, Spin, message } from 'antd';
import { DoubleLeftOutlined, LoadingOutlined, SearchOutlined, EditOutlined } from '@ant-design/icons';
import Style from './expertTimeManage.module.less';
import api from '../../../../../utils/api';
import fun from '../../../../../utils/funSum.js';

const { Option } = Select;

class ExpertTimeManage extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            nameList: [],//解题专家姓名下拉列表
            expertName: null,//下拉选择解题专家姓名
            expertId: '',//下拉选择解题专家id
            subjectList: [],//解题专家学科下拉列表
            subjectName: null,//下拉选择学科名
            subjectId: '',//下拉选择学科id
            receiveDate: [],//解题专家时间列表
            count: 1,//解题专家人数
            name: '',//解题专家姓名
            userId: '',//解题专家id
            edit: true,//点击编辑 显示取消确定btn
            // date:time,
            startX: 0,//选择框的左横坐标
            startY: 0,//选择框的左纵坐标
            flag: false,//判断是否是从外部div进来
            width: 0,//图层宽度
            height: 0,//图层高度
            left: 0,//图层div相对wrap div的最终左偏移
            top: 0,//图层div相对wrap div的最终上偏移
            startOffsetTop: 0,//图层div相对wrap div的开始上偏移
            startOffsetLeft: 0,//图层div相对wrap div的开始左偏移
            date: ['一', '二', '三', '四', '五', '六', '日'].map(item => {
                return {
                    week: item,
                    clock: [...Array(24)].map((value, index) => {
                        return {
                            time: index,
                            checked: false
                        }
                    })
                }
            })
        }
    }
    componentDidMount() {
        this.getTimes();
        if (this.props.level !== 2) return;
        this.getNameList();
        this.getSubjectList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取解题专家姓名下拉列表
    getNameList = () => {
        this.setState({ loading: true }, () => {
            api.getExpertNamelist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ nameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取解题专家学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取解题专家工作时间段
    getTimes = () => {
        this.setState({ loading: true }, () => {
            api.getTimeList()
                .then((data) => {
                    if (data.ret === 20000 && data.result.time) {
                        this.setState({ count: data.result.count, name: data.result.name, receiveDate: data.result.time, userId: data.result.solverId, loading: false }, () => {
                            let arr = this.state.date;
                            arr.map((item2, index2) => {
                                item2.clock.map((item3, index3) => {
                                    arr[index2].clock[index3].checked = false;
                                    return null
                                })
                                return null
                            })
                            data.result.time.map((item) => {
                                item.val.map((item1) => {
                                    arr[item.week - 1].clock[item1].checked = true;
                                    return null
                                })
                                return null
                            })
                            this.setState({ date: arr });
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取解题专家下拉选择的姓名
    getName = (value, option) => {
        if (value && option) {
            this.refs.name.blur();
            this.setState({ expertName: value, expertId: option.key })
        } else {
            this.setState({ expertName: null, expertId: '' });
        }
    }
    //获取解题专家下拉选择的学科
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key })
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //点击查询
    search = () => {
        this.setState({ loading: true }, () => {
            api.getTimeList({ solverId: this.state.expertId, subId: this.state.subjectId })
                .then((data) => {
                    if (data.ret === 20000 && data.result.time) {
                        this.setState({ count: data.result.count, name: data.result.name, receiveDate: data.result.time, userId: data.result.solverId, loading: false }, () => {
                            let arr = JSON.parse(JSON.stringify(this.state.date));
                            arr.map((item2, index2) => {
                                item2.clock.map((item3, index3) => {
                                    arr[index2].clock[index3].checked = false;
                                    return null
                                })
                                return null
                            })
                            data.result.time.map((item) => {
                                item.val.map((item1) => {
                                    arr[item.week - 1].clock[item1].checked = true;
                                    return null
                                })
                                return null
                            })
                            this.setState({ date: arr });
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //渲染周视图
    getTable = () => {
        return (
            <div className={Style.timeWrap}
                onMouseLeave={e => {
                    //鼠标抬起时清空
                    if (this.state.edit) return;
                    this.setState({ width: 0, height: 0, startX: 0, startY: 0, startOffsetTop: 0, startOffsetLeft: 0, });
                    this.refs.movebox.style.width = '0px';
                    this.refs.movebox.style.height = '0px';
                    this.refs.movebox.style.border = '0px';
                }}>
                <div
                    // 该div在拖曳过程中随鼠标变化宽高，鼠标抬起该div消失 
                    style={{ width: '0px', height: '0px', position: 'absolute', zIndex: '99', border: '0px solid #d0d0d0', background: '#ffffff', opacity: '.7', }}
                    ref='movebox'
                    onMouseUp={e => {
                        // 解决鼠标向左上方移动时，由于图层存在，导致无法选中问题
                        let arr = this.state.date;
                        arr.forEach((item_0, index_0) => {
                            item_0.clock.forEach((item_1, index_1) => {
                                if (index_0 >= this.state.finalStartX && index_0 <= this.state.finalEndX) {
                                    if (index_1 >= this.state.finalStartY && index_1 <= this.state.finalEndY) {
                                        arr[index_0].clock[index_1].checked = !arr[index_0].clock[index_1].checked;
                                    }
                                }
                            })
                        })
                        this.setState({ date: arr, width: 0, height: 0, startOffsetTop: 0, startOffsetLeft: 0, });
                        this.refs.movebox.style.width = '0px';
                        this.refs.movebox.style.height = '0px';
                        this.refs.movebox.style.border = '0px';
                    }}
                >
                </div>
                <div
                    style={{ position: 'relative' }}
                    onMouseDown={e => {
                        //记录该div相对wrap div的偏移量
                        e.persist();
                        if (this.state.edit) return;
                        this.setState({
                            startOffsetTop: e.target.offsetTop + e.nativeEvent.layerY, startOffsetLeft: e.target.offsetLeft + e.nativeEvent.layerX, flag: true
                        });
                    }}
                    onMouseMove={
                        e => {
                            //计算图层div的宽高以及相对wrap div的位置
                            e.persist();
                            if (this.state.edit) return;
                            if (this.state.startOffsetTop === 0 && this.state.startOffsetLeft === 0) return
                            let height = this.state.startOffsetTop - (e.target.offsetTop + e.nativeEvent.layerY)
                            let width = this.state.startOffsetLeft - (e.target.offsetLeft + e.nativeEvent.layerX)
                            let top = (height < 0 ? this.state.startOffsetTop : (this.state.startOffsetTop - height))
                            let left = (width < 0 ? this.state.startOffsetLeft : (this.state.startOffsetLeft - width))
                            this.refs.movebox.style.width = Math.abs(width) + 'px';
                            this.refs.movebox.style.height = Math.abs(height) + 'px';
                            this.refs.movebox.style.left = left + 'px';
                            this.refs.movebox.style.top = top + 'px';
                            this.refs.movebox.style.border = '3px solid #d0d0d0';
                        }
                    }
                    onMouseUp={e => {
                        //鼠标抬起时清空
                        if (this.state.edit) return;
                        this.setState({ width: 0, height: 0, startOffsetTop: 0, startOffsetLeft: 0, flag: false });
                        this.refs.movebox.style.width = '0px';
                        this.refs.movebox.style.height = '0px';
                        this.refs.movebox.style.border = '0px';
                    }}
                >
                    {this.state.date.map((item, index) => {
                        return (
                            <div className={Style.timeTr} key={index} ref="fatherBox">
                                <div className={Style.week}>{item.week}</div>
                                {item.clock.map((item1, index1) => {
                                    return (
                                        <span className={item1.checked ? Style.checkTime : Style.time} key={index1}
                                            onClick={e => this.check(item, index, item1, index1, e)}
                                            onMouseDown={e => {
                                                //记录起点的横纵坐标
                                                if (this.state.edit) return;
                                                this.setState({ startX: index, startY: index1, flag: true });
                                            }}
                                            onMouseMove={e => {
                                                //计算起始横纵坐标，并记录下来，让wrap div的mouseup得到该值
                                                if (this.state.edit) return;
                                                let startX = Math.min(this.state.startX, index)
                                                let endX = Math.max(this.state.startX, index)
                                                let startY = Math.min(this.state.startY, index1)
                                                let endY = Math.max(this.state.startY, index1)
                                                this.setState({ finalStartX: startX, finalStartY: startY, finalEndX: endX, finalEndY: endY });
                                            }}
                                            onMouseUp={e => {
                                                //计算起始点的横纵坐标，将网格的选中状态切换为true
                                                if (this.state.edit || !this.state.flag) return;
                                                if (this.state.startX === index && this.state.startY === index1) return
                                                let startX = Math.min(this.state.startX, index)
                                                let endX = Math.max(this.state.startX, index)
                                                let startY = Math.min(this.state.startY, index1)
                                                let endY = Math.max(this.state.startY, index1)
                                                let arr = this.state.date;
                                                arr.forEach((item_0, index_0) => {
                                                    item_0.clock.forEach((item_1, index_1) => {
                                                        if (index_0 >= startX && index_0 <= endX) {
                                                            if (index_1 >= startY && index_1 <= endY) {
                                                                arr[index_0].clock[index_1].checked = !arr[index_0].clock[index_1].checked;
                                                            }
                                                        }
                                                    })
                                                })
                                                //清空数据
                                                this.setState({ date: arr, width: 0, height: 0, startOffsetTop: 0, startOffsetLeft: 0, flag: false });
                                                this.refs.movebox.style.width = '0px';
                                                this.refs.movebox.style.height = '0px';
                                                this.refs.movebox.style.border = '0px';
                                            }}
                                        >
                                            {index === 0 ? <div>
                                                {index1 % 2 === 0 ? <span style={{ position: 'absolute', top: '-20px', left: '-7px' }}>{index1}</span> : ''}
                                                {index1 === 23 ? <span style={{ position: 'absolute', top: '-20px', left: '20px' }}>{index1 + 1}</span> : ''}
                                            </div> : ''}
                                        </span>
                                    )
                                })}
                            </div>
                        )
                    })}
                </div>
            </div>
        )
    }
    //点击单元格
    check = (item, index, item1, index1, e) => {
        if (this.state.edit) return;
        if (this.state.startX === index && this.state.startY === index1) {
            let arr = this.state.date;
            arr[index].clock[index1].checked = !arr[index].clock[index1].checked;
            this.setState({ date: arr });
        }
    }
    //点击提交
    editSubmit = () => {
        this.setState({ loading: true }, () => {
            let dateArr = JSON.parse(JSON.stringify(this.state.date));//简单深拷贝 切断引用关系
            let arr = dateArr.map((item, index) => {
                item.week === '一' ? item.week = 1 : item.week === '二' ? item.week = 2 : item.week === '三' ? item.week = 3 : item.week === '四' ? item.week = 4 : item.week === '五' ? item.week = 5 : item.week === '六' ? item.week = 6 : item.week === '日' ? item.week = 7 : item.week = 0;
                item.hours = item.clock;
                delete item.clock;
                //筛除checked为false的对象，并删除checked属性
                item.hours = item.hours.filter((item1) => { return item1.checked }).map((item2) => {
                    delete item2.checked
                    return item2
                })
                //将对象中的time属性value放到数组中
                item.hours = item.hours.map((item1) => {
                    return item1.time
                })
                return item
            });
            let obj = {};
            obj.solverId = this.state.userId;
            obj.time = arr;
            api.editTimeList(obj)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.setState({ loading: false, edit: true });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //取消
    close = () => {
        this.search();
        this.setState({ edit: true })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.goback}>
                        <Button type='link' icon={<DoubleLeftOutlined />} onClick={() => { this.props.history.go(-1) }}>返回上一页</Button>
                    </div>
                    {this.props.level === 2 ? <div>
                        <div className={Style.searchWrap}>
                            <div>
                                <span>解题专家姓名：</span>
                                <Select placeholder='全部' ref='name' className={Style.select} value={this.state.expertName} onChange={this.getName} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.nameList.map((item) => {
                                        return <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                    })}
                                </Select>
                                <span>解题专家学科：</span>
                                <Select placeholder='全部' ref='subject' className={Style.select} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item) => {
                                        return <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                    })}
                                </Select>
                            </div>
                            <Button type='primary' icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                        </div>
                        <Divider />
                    </div> : ''}
                    <div className={Style.hThree}>
                        {this.state.count <= 1 ? <h3>{this.state.name}的解题工作时间段如下</h3> : <h3>{this.state.name}等{this.state.count}位解题专家的解题工作时间段如下</h3>}
                    </div>
                    <div className={Style.timeBox}>{this.getTable()}</div>
                    <div className={Style.btnsWrap}>
                        {this.state.edit ? <Button type='primary' icon={<EditOutlined />} disabled={this.state.count === 1 ? false : true} onClick={() => { this.setState({ edit: false }) }}>编辑</Button> : <span>
                            <Button className={Style.leftBtn} onClick={this.close}>取消</Button>
                            <Button type='primary' onClick={this.editSubmit}>确定</Button>
                        </span>}
                    </div>
                </Spin>
            </Fragment>
        )
    }
}

export default connect(store => store)(withRouter(ExpertTimeManage));