import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { Select, Button, Divider, Table, Pagination, Spin, Tooltip, InputNumber, message, Switch } from 'antd';
import { LoadingOutlined, DoubleRightOutlined, PlusOutlined, MinusCircleOutlined, SearchOutlined, EditOutlined } from '@ant-design/icons';
import Style from './expertManage.module.less';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import { connect } from 'react-redux';
import api from '../../../../../utils/api';
import fun from '../../../../../utils/funSum.js';

const { Option } = Select;
class ExpertManage extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            nameList: [],//员工姓名列表
            subjectList: [],//擅长学科列表
            stationStatusList: [{ type: '工作', id: 1 }, { type: '休假', id: 0 }],//岗位状态
            expertName: null,//所选解题专家名
            expertId: '',//所选解题专家id
            subjectName: null,//擅长学科名
            subjectId: '',//擅长学科id
            stationStatus: null,//岗位状态名
            stationStatusId: '',//岗位状态id
            dataSource: [],
            page: 1,
            pageSize: 10,
            total: 0,
            showModal: false,//点击编辑 弹框
            rowInfo: {},//所点击行的数据
            modalInfo: [],//弹框内容初始数据
        }
    }
    columns = [
        {
            title: '姓名',
            dataIndex: 'solverName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: solverName => (
                <Tooltip placement="top" title={solverName}>
                    {solverName}
                </Tooltip>
            ),
        },
        {
            title: '擅长学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            ),
        },
        {
            title: '工单库容量',
            dataIndex: 'orderCapacity',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: orderCapacity => (
                <Tooltip placement="top" title={orderCapacity}>
                    {orderCapacity}
                </Tooltip>
            ),
        },
        {
            title: '岗位状态',
            align: 'center',
            render: record => {
                return (
                    <Switch checked={record.workStatus === 1 ? true : false} onChange={(checked) => { this.changeStatus(checked, record) }} checkedChildren="工作" unCheckedChildren="休假" />
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            render: (record) => {
                return (
                    <Button type='primary' icon={<EditOutlined />} onClick={() => { this.edit(record) }}>编辑</Button>
                )
            },
        }
    ]
    componentDidMount() {
        this.getExpertlist({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        if (this.props.level !== 2) {
            this.columns.splice(this.columns.length - 1, 1);
            return;
        }
        this.getExpertNamelist();
        this.getSubjectList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取解题专家下拉列表
    getExpertNamelist = () => {
        this.setState({ loading: true }, () => {
            api.getExpertNamelist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ nameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取擅长学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, page: data.result.start + 1, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取解题专家table列表
    getExpertlist = (params) => {
        this.setState({ loading: true }, () => {
            api.getExpertlist(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //获取select所选解题专家
    getExpert = (value, option) => {
        if (value && option) {
            this.refs.expert.blur();
            this.setState({ expertName: value, expertId: option.key });
        } else {
            this.setState({ expertName: null, expertId: '' });
        }
    }
    //获取select所选擅长学科
    getsubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //获取岗位状态
    getStationStatus = (value, option) => {
        if (value && option) {
            this.refs.stationStatus.blur();
            this.setState({ stationStatus: value, stationStatusId: option.key });
        } else {
            this.setState({ stationStatus: null, stationStatusId: '' });
        }
    }
    //查询
    search = () => {
        this.getExpertlist({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, solverId: this.state.expertId, subId: this.state.subjectId, workStatus: this.state.stationStatusId });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getExpertlist({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, solverId: this.state.expertId, subId: this.state.subjectId, workStatus: this.state.stationStatusId });
        });
    }
    //点击switch改变工作状态
    changeStatus = (checked, record) => {
        this.setState({ loading: true }, () => {
            let workStatus = checked === true ? 1 : 0;
            api.changeWoekStatus('/v1/manual/order/setSolverStatus/' + record.solverId + '/' + workStatus)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //点击编辑
    edit = (record) => {
        this.setState({ rowInfo: record, showModal: true, loading: true }, () => {
            api.getExpertInfo('/v1/manual/order/solver/config/' + record.solverId)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ modalInfo: data.result, modalCapacity: data.result[0].orderCapacity === 0 ? 1 : data.result[0].orderCapacity, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        });
    }
    //获取工单库容量
    getModalCapaCity = (value) => {
        this.setState({ modalCapacity: value });
    }
    //删除解题证书
    modalRemove = (index) => {
        this.state.modalInfo.splice(index, 1);
        this.setState({ modalInfo: this.state.modalInfo })
    }
    //增加解题证书
    modalAdd = () => {
        this.state.modalInfo.push({ id: null, level: "", solverId: this.state.rowInfo.solverId, subId: '' });
        this.setState({ modalInfo: this.state.modalInfo });
    }
    //获取擅长学科
    getModalSubject = (index, value, option) => {
        let arr = this.state.modalInfo;
        if (value && option) {
            arr[index].subId = Number(option.key);
            arr[index].subjectName = value;
        } else {
            arr[index].subId = '';
            arr[index].subjectName = null;
        }
        this.setState({ modalInfo: this.state.modalInfo });
    }
    //获取能力等级
    getModalLevel = (index, value, option) => {
        let arr = this.state.modalInfo;
        if (value && option) {
            arr[index].level = option.key;
        } else {
            arr[index].level = '';
        }
        this.setState({ modalInfo: this.state.modalInfo });
    }
    //确定提交
    modalSubmit = () => {
        let arr = this.state.modalInfo;
        arr.map((item) => {
            item.orderCapacity = this.state.modalCapacity
            return null
        })
        this.setState({ loading: true }, () => {
            api.editExpertInfo(arr)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ showModal: false });
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭弹框
    close = () => {
        this.setState({ showModal: false });
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    {this.props.level === 2 ? <div className={Style.searchWrap}>
                        <div className={Style.search}>
                            <div className={Style.left}>
                                <div className={Style.box}>
                                    <span>解题专家：</span>
                                    <Select placeholder='全部' ref='expert' className={Style.select} value={this.state.expertName} onChange={this.getExpert} optionLabelProp="label" showSearch={true} allowClear={true}>
                                        {this.state.nameList.map((item) => {
                                            return (
                                                <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                <div className={Style.box}>
                                    <span>擅长学科：</span>
                                    <Select placeholder='全部' ref='subject' className={Style.select} value={this.state.subjectName} onChange={this.getsubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                        {this.state.subjectList.map((item) => {
                                            return (
                                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                <div className={Style.box}>
                                    <span>岗位状态：</span>
                                    <Select placeholder='全部' ref='stationStatus' className={Style.select} value={this.state.stationStatus} onChange={this.getStationStatus} allowClear={true} optionLabelProp="label" showSearch={true}>
                                        {this.state.stationStatusList.map((item) => {
                                            return (
                                                <Option key={item.id} value={item.type}>{item.type}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                            </div>
                            <Button type='primary' icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                        </div>
                        <Divider />
                        <div className={Style.des}>
                            <h3 >符合条件的解题专家共{this.state.total}人</h3>
                            <div className={Style.buttonWrap}>
                                <Button type='link' className={Style.button} onClick={() => { this.props.history.push('/admin/v1/artificialSolveProblem/expertTimeManage') }}>解题专家工作时间<DoubleRightOutlined /></Button>
                                <Button type='link' onClick={() => { this.props.history.push('/admin/v1/artificialSolveProblem/orderHumanResourceMonitor') }}>当前工作中的专家名单<DoubleRightOutlined /></Button>
                            </div>
                        </div>
                    </div> : ''}
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    {this.state.showModal ? <Modal title={`解题专家${this.state.rowInfo.solverName}的信息`} close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type="primary" onClick={this.modalSubmit}>确定</Button>]}>
                        <span className={Style.modalTop}>
                            <h4 className={Style.hFour}>工单库容量：</h4>
                            <InputNumber placeholder='请输入工单库容量' value={this.state.modalCapacity} onChange={this.getModalCapaCity} min='1' max='99' />
                            <div className={Style.text}>工单库容量取值范围（0，100）</div>
                        </span>
                        {this.state.modalInfo.map((item, index) => {
                            return (
                                <div key={index} className={Style.modalSelectWrap}>
                                    <h4 className={Style.hFour}>解题证书{index + 1}：</h4>
                                    <Select
                                        placeholder="学科名称"
                                        className={Style.modalSelect}
                                        value={item.subjectName}
                                        onChange={(value, option) => { this.getModalSubject(index, value, option) }}
                                        allowClear
                                        optionLabelProp="label"
                                        showSearch={true}
                                    >
                                        {this.state.subjectList.map((item) => {
                                            return (
                                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                            )
                                        })}
                                    </Select>
                                    <Select
                                        placeholder="能力等级"
                                        className={Style.modalSelect}
                                        value={item.level}
                                        onChange={(value, option) => { this.getModalLevel(index, value, option) }}
                                        allowClear
                                        optionLabelProp="label"
                                        showSearch={true}
                                    >
                                        <Option key='junior' value='junior'>junior</Option>
                                        <Option key='senior' value='senior'>senior</Option>
                                        <Option key='master' value='master'>master</Option>
                                    </Select>
                                    <MinusCircleOutlined onClick={() => { this.modalRemove(item, index) }} />
                                </div>
                            )
                        })}
                        <Button type="dashed" icon={<PlusOutlined />} onClick={() => { this.modalAdd() }} className={Style.addBtn}></Button>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default connect(store => store)(withRouter(ExpertManage));