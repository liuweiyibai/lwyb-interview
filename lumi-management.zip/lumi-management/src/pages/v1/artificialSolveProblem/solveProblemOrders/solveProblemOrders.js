import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Card, Skeleton, message, Pagination, Divider, Input, Select, Button, Empty, Upload, Spin, Radio, DatePicker, Tooltip, Checkbox } from 'antd';
import { SearchOutlined, PlusOutlined, LoadingOutlined, InfoCircleFilled, DownloadOutlined } from '@ant-design/icons';
import api from '../../../../utils/api';
import Style from './solveProblemOrders.module.less';
import Viewer from 'viewerjs';
import 'viewerjs/dist/viewer.css';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import moment from 'moment';
import 'moment/locale/zh-cn';
import fun from '../../../../utils/funSum';
// import piexif from 'piexifjs';
moment.locale('zh-cn');

const { Option } = Select;
const { RangePicker } = DatePicker;
const { TextArea } = Input;

class SolveProOrders extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showEditAnswer: false,//是否展示编辑答案弹框
            fileList: [],//上传文件列表
            awsUrl: [],
            // 关闭工单弹框
            showCloseOrder: false,//是否展示关闭工单弹框
            radioValue: '',//关闭原因单选value
            customizedReasonInputShow: false,//是否显示自定义关闭原因输入框
            customizedReason: '',//用户输入的自定义工单关闭原因
            closeReason: [
                'The question is not in the list of subjects that can be answered. Thank you for choosing Lumist!',

                'Over 3 subquestions have been identified. Please make sure the amount of questions are within the limitation. Thank you for choosing Lumist!',

                'This question is too complicated and beyond our time limit for solving it. Thank you for choosing Lumist!',

                'More than one question in your posted picture, we don’t know which to answer. Thank you for choosing Lumist!',

                'The picture is too blurry to recognize the question. Thank you for choosing Lumist!',

                'The question is missing important information. Thank you for choosing Lumist!',

                'There is no specific question on the picture. Thank you for choosing Lumist!',

                'You have submitted duplicate content multiple times. Thank you for choosing Lumist!',

                'Your submitted question is not in English. Thank you for choosing Lumist!'
            ],//工单关闭原因
            // 修改学科弹框
            showChangeSubject: false,//是否展示修改学科弹框
            modalSubjectName: null,//修改学科所选学科名
            modalSubjectId: '',//修改学科所选id
            // 修改解题专家弹框
            showChangeExpert: false,//是否展示修改解题专家弹框
            modalExpertName: null,//修改解题专家所选专家名
            modalExpertId: '',//修改解题专家所选专家id
            solveOrdersList: [],//解题工单列表
            rowInfo: [],//所点击订单的数据
            imgUrl: '',//删除所点击图片的地址
            // 工单备注弹框
            showRemarkModal: false,//是否展示工单备注弹框
            modalRemark: '',//工单备注
            modalOrderId: '',//工单ID
            // 查询项
            subjectList: [],//题目学科下拉列表
            nameList: [],//解题专家名下拉列表
            workNameList: [],//工作状态的解题专家名下拉列表
            orderNum: '',//工单号
            userID: '',//用户ID
            subjectName: null,//题目学科名
            subjectId: '',//题目学科id
            expertName: null,//解题专家名
            expertId: '',//解题专家id
            orderStatus: '待解答',//工单状态所选名
            orderStatusId: 1,//工单状态所选id
            userComment: null,//用户评价
            userCommentId: '',//用户评价ID
            createStartTime: '',//创建开始时间
            createEndTime: '',//创建结束时间
            remarkStatus: null,// 工单备注状态
            remarkStatusId: '',// 工单备注状态id
            orderDifficulty: null,// 工单难度状态
            orderDifficultyId: '',// 工单难度状态id
            greatOrder: null,//优质工单状态
            greatOrderId: '',//优质工单状态ID
            page: 1,
            pageSize: 9,
            total: 0,
            previewImage: '',
            previewVisible: false,
            previewTitle: ''
        }
    }
    componentDidMount() {
        this.getSolveOrdersList();
        this.getSubjectList();
        if (this.props.level !== 2) return;
        this.getExpertNamelist();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取解题专家下拉列表
    getExpertNamelist = () => {
        this.setState({ loading: true }, () => {
            api.getExpertNamelist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ nameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取工作状态的解题专家下拉列表
    getWorkExpertNamelist = () => {
        this.setState({ loading: true }, () => {
            api.getExpertNamelist({ type: 1 })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ workNameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取擅长学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取解题工单列表
    getSolveOrdersList = () => {
        this.setState({ loading: true }, () => {
            let params = { start: this.state.createStartTime, end: this.state.createEndTime, iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, orderId: this.state.orderNum, subId: this.state.subjectId, solverId: this.state.expertId, orderStatus: this.state.orderStatusId, userId: this.state.userID, isPop: this.state.greatOrderId, isRemark: this.state.remarkStatusId, difficultyLevel: this.state.orderDifficultyId, commentType: this.state.userCommentId }
            api.getSolveOrdersList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ solveOrdersList: data.result.data ? data.result.data : [], total: data.result.total, page: data.result.start + 1, loading: false }, () => {
                            if (Array.isArray(this.state.solveOrdersList) && this.state.solveOrdersList.length > 0) {
                                this.state.solveOrdersList.forEach((item, index) => {
                                    if ((Array.isArray(item.answerPicArr) && item.answerPicArr.length > 0)) {
                                        if (this.refs['answerImageList' + index]) {
                                            new Viewer(this.refs['answerImageList' + index], {})
                                        }
                                    }
                                    if (this.refs['questionImage' + index]) {
                                        new Viewer(this.refs['questionImage' + index], {})
                                    }

                                })
                            }
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取输入的工单号
    getOrderNum = (e) => {
        this.setState({ orderNum: e.target.value });
    }
    //获取输入的用户ID
    getUserID = (e) => {
        this.setState({ userID: e.target.value });
    }
    //获取题目学科下拉所选value
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //获取解题专家下拉所选value
    getExpert = (value, option) => {
        if (value && option) {
            this.refs.expert.blur();
            this.setState({ expertName: value, expertId: option.key });
        } else {
            this.setState({ expertName: null, expertId: '' });
        }
    }
    //获取工单状态下拉所选value
    getOrderStatus = (value, option) => {
        if (value && option) {
            this.refs.orderStatus.blur();
            this.setState({ orderStatus: value, orderStatusId: option.key });
        } else {
            this.setState({ orderStatus: null, orderStatusId: '' });
        }
    }
    //获取用户评价的下拉所选
    getUserComment = (value, option) => {
        if (value && option) {
            this.refs.userComment.blur();
            this.setState({ userComment: value, userCommentId: option.key });
        } else {
            this.setState({ userComment: null, userCommentId: '' });
        }
    }
    //改变创建时间
    changeCreateTime = (date, dateString) => {
        if (date && dateString) {
            this.refs.changeCreateTime.blur();
            let startAt = date[0] ? moment(date[0]).format('YYYY-MM-DD') : '';
            let endAt = date[1] ? moment(date[1]).format('YYYY-MM-DD') : '';
            this.setState({ createStartTime: startAt, createEndTime: endAt });
        }
        else {
            this.refs.changeCreateTime.blur();
            this.setState({ createStartTime: null, createEndTime: null });
        }
    }
    // 改变工单状态
    getRemarkStatus = (value, option) => {
        if (value && option) {
            this.refs.remarkStatus.blur();
            this.setState({ remarkStatus: value, remarkStatusId: option.key });
        } else {
            this.setState({ remarkStatus: null, remarkStatusId: '' });
        }
    }
    //改变优质工单状态
    getGreatOrder = (value, option) => {
        if (value && option) {
            this.refs.greatOrder.blur();
            this.setState({ greatOrder: value, greatOrderId: option.key });
        } else {
            this.setState({ greatOrder: null, greatOrderId: '' });
        }
    }
    //改变工单难度状态
    getOrderDifficulty = (value, option) => {
        if (value && option) {
            this.refs.orderDifficulty.blur();
            this.setState({ orderDifficulty: value, orderDifficultyId: option.key });
        } else {
            this.setState({ orderDifficulty: null, orderDifficultyId: '' });
        }
    }
    // 导出解题工单
    exportOrder = () => {
        this.setState({ loading: true }, () => {
            let params = { start: this.state.createStartTime, end: this.state.createEndTime, orderId: this.state.orderNum, subId: this.state.subjectId, solverId: this.state.expertId, orderStatus: this.state.orderStatusId, userId: this.state.userID, isPop: this.state.greatOrderId, isRemark: this.state.remarkStatusId, difficultyLevel: this.state.orderDifficultyId, commentType: this.state.userCommentId }
            api.exportOrder(params, { responseType: 'arraybuffer' })
                .then(async (response) => {
                    let parse_result = await fun.ab2str(response);
                    if (parse_result === false) {
                        fun.download(response, `工单数据-${moment(new Date()).format('YYYYMMDD')}.xlsx`);
                        this.setState({ loading: false });
                        message.success('导出成功！');
                    } else {
                        if (parse_result.ret === 20000) {
                            message.success(parse_result.msg);
                            this.setState({ loading: false });
                        } else {
                            return Promise.reject(parse_result);
                        }
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false })
                })
        })
    }
    //编辑答案
    editAnswer = (item) => {
        if (item.solverId !== this.props.userid) {
            message.error('你不是该工单的解题专家，无法编辑答案');
            return;
        }
        let arr = [];
        item.answerPicArr.forEach((item1, index1) => {
            let obj = {};
            obj.url = item.cloudFrontUrl + '/' + item1;
            obj.uid = index1 - 2 * index1;
            arr.push(obj);
        })
        this.setState({ rowInfo: item, showEditAnswer: true, fileList: arr });
    }
    //关闭工单
    closeOrder = (item) => {
        this.setState({ showCloseOrder: true, rowInfo: item, radioValue: '' });
    }
    //修改学科
    changeSubject = (item) => {
        this.setState({ showChangeSubject: true, rowInfo: item, modalSubjectName: item.subjectName, modalSubjectId: item.subId });
    }
    //修改解题专家
    changeExpert = (item) => {
        this.getWorkExpertNamelist()
        this.setState({ showChangeExpert: true, rowInfo: item, modalExpertName: item.solverName, modalExpertId: item.solverId });
    }
    //修改工单备注
    changeRemark = (item) => {
        this.setState({ showRemarkModal: true, rowInfo: item, modalRemark: item.remark === null ? '' : item.remark, modalOrderId: item.id });
    }
    // 改变工单备注的值
    changeRemarkValue = (e) => {
        this.setState({ modalRemark: e.target.value });
    }
    //上传文件改变时的状态
    handleChange = ({ file, fileList }) => {
        if (fileList.length > 5) {
            message.warning('文件总数不能超过5个！');
            return;
        }
        // console.log(file, fileList)
        this.setState({ fileList: fileList });
    }
    //编辑答案确定
    modalEditAnswerSubmit = async () => {
        // console.log(this.state.fileList);
        // return;
        for (let item of this.state.fileList) {
            if (item.name) {
                let pictureType = item.name.split('.')[item.name.split('.').length - 1]
                if (pictureType !== 'jpg' && pictureType !== 'jpeg' && pictureType !== 'png' && pictureType !== 'bmp' && pictureType !== 'gif' && pictureType !== 'svg' && pictureType !== 'psd' && pictureType !== 'ai' && pictureType !== 'TIFF' && pictureType !== 'webp' && pictureType !== 'EPS') {
                    message.warning('仅可上传图片文件！');
                    this.setState({ fileList: [] });
                    this.close();
                    return;
                }
            }
        }
        if (this.state.fileList.length > 5) {
            this.setState({ fileList: this.state.fileList.splice(5) });
            message.warning('上传文件不能大于5个，超出部分将不会上传！');
        }
        this.setState({ loading: true });
        let arr = [];
        for (let item of this.state.fileList) {
            if (item.url) {
                continue;
            };
            let sign;
            try {
                //获取预签名
                sign = await api.getUploadPicUrl();
                if (sign.ret !== 20000) {
                    message.error(sign.msg);
                    throw new Error(sign);
                }
                arr.push(sign.result.key);
            } catch (err) {
                message.error(err.msg);
                throw err;
            }
            if (sign && sign.ret && sign.ret === 20000) {
                let file = await fun.removeExif(item.originFileObj);
                // .then((res)=>{
                //     // console.log(res)
                //     // arr.push(res)
                //     // console.log(arr)
                // })
                try {
                    //上传aws
                    await api.uploadAWS(sign.result.url, file, { headers: { 'Content-Type': 'image/png' } });
                    // let formData = new FormData();
                    // formData.append('file', file);
                    // let data = await api.uploadPic(formData);
                    // if (data.ret !== 20000) {
                    //     message.error(data.msg);
                    //     throw new Error(data);
                    // }
                    // arr.push(data.result);

                } catch (err) {
                    message.error(err.msg);
                    this.setState({ loading: false });
                    throw err;
                }
            } else {
                message.error(sign.msg);
            }
        }
        if (arr.length <= 0) {
            message.success('编辑成功');
        } else {
            await api.editOrderAnswer('/v1/manual/order/answer/' + this.state.rowInfo.id, { fileNames: arr.toString() })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        }
        this.setState({ showEditAnswer: false });
        this.search();
    }
    getBase64 = (file) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }
    //查看图片
    handlePreview = async (file) => {
        if (!file.url && !file.preview) {
            file.preview = await this.getBase64(file.originFileObj);
        }
        this.setState({
            previewImage: file.url || file.preview,
            previewVisible: true,
            previewTitle: file.name || file.url.substring(file.url.lastIndexOf('/') + 1),
        });
    }
    // 切换优质工单状态
    checkGreatOrder = (item, index) => {
        let status = item.popId && item.popId === item.id;
        this.setState({ loading: true }, () => {
            api.changePopGreatOrder({
                id: item.id,
                rec: !status ? 1 : 0
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        let arr = this.state.solveOrdersList.map((item1, index1) => {
                            if (index === index1) {
                                if (item1.popId) {
                                    item1.popId = null
                                } else {
                                    item1.popId = item1.id
                                }
                            }
                            return item1
                        })
                        this.setState({ loading: false, solveOrdersList: arr });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                    return false;
                })
        })
    }
    // 切换工单难度
    changeOrderDifficulty = (e, item, index) => {
        this.setState({ loading: true }, () => {
            api.changeOrderDifficulty({ id: item.id, level: e.target.value })
                .then((data) => {
                    if (data.ret === 20000) {
                        let arr = this.state.solveOrdersList.map((item1, index1) => {
                            if (index === index1) {
                                item1.difficultyLevel = e.target.value
                            }
                            return item1
                        })
                        this.setState({ loading: false, solveOrdersList: arr });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                    return false;
                })
        })
    }
    //upload删除
    onRemove = (file) => {
        // console.log(file)
        if (file.url) {
            this.setState({ loading: true }, () => {
                api.deleteAnswerImage('/v1/manual/order/answer/del/' + this.state.rowInfo.id + '?answerPic=' + file.url.split('.com/')[1])
                    .then((data) => {
                        if (data.ret === 20000) {
                            message.success(data.msg);
                            this.search()
                        } else {
                            return Promise.reject(data);
                        }
                    })
                    .catch((err) => {
                        message.error(err.msg);
                        this.setState({ loading: false });
                        return false;
                    })
            })
        }
    }
    //获取单选value
    closeOrderRadio = (e) => {
        if (e.target.value === 10) {
            this.setState({ radioValue: e.target.value, customizedReasonInputShow: true, });
            return;
        }
        this.setState({ customizedReasonInputShow: false, customizedReason: '', radioValue: e.target.value, radioCloseReason: this.state.closeReason[Number(e.target.value) - 1] });
    }
    //获取用户输入的自定义关闭原因
    getCustomizedReason = (e) => {
        let value = e.target.value.replace(/[\u4e00-\u9fa5]+$/g, '')
        this.setState({ customizedReason: value });
    }
    //关闭工单确定
    modalCloseOrderSubmit = () => {
        if (this.state.radioValue === '') {
            message.warning('请选择关闭原因！')
            return;
        }
        if (this.state.radioValue === 10 && this.state.customizedReason === '') {
            message.warning('自定义关闭原因不能为空！')
            return;
        }
        if (this.state.radioValue === 10 && this.state.customizedReason.search(/[\u4e00-\u9fa5]/) !== -1) {
            message.warning('只允许英文字符！')
            return;
        }
        this.setState({ loading: true }, () => {
            api.closeOrder({
                closeReason: this.state.radioValue === 10 ? this.state.customizedReason : this.state.radioCloseReason,
                closeReasonType: this.state.radioValue,
                id: this.state.rowInfo.id
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.search();
                        message.success(data.msg);
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ showCloseOrder: false, loading: false });
                })
        })
    }
    //获取修改学科下拉所选value
    getModalSubject = (value, option) => {
        if (value && option) {
            this.setState({ modalSubjectName: value, modalSubjectId: option.key });
        } else {
            this.setState({ modalSubjectName: null, modalSubjectId: '' });
        }
    }
    //修改学科确定
    modalChangeSubjectSubmit = () => {
        if (this.state.modalSubjectId === '') {
            message.warning('请选择要修改的学科！');
            return;
        }
        this.setState({ loading: true }, () => {
            api.changeSubject('/v1/manual/order/modSubject/' + this.state.rowInfo.id + '/' + this.state.modalSubjectId)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.search();
                        message.success(data.msg);
                        this.setState({ showChangeSubject: false, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ showChangeSubject: false, loading: false });
                })
        })
    }
    //获取修改解题专家下拉所选value
    getModalExpert = (value, option) => {
        if (value && option) {
            this.setState({ modalExpertName: value, modalExpertId: option.key });
        } else {
            this.setState({ modalExpertName: null, modalExpertId: '' });
        }
    }
    //修改解题专家确定
    modalChangeExpertSubmit = () => {
        this.setState({ loading: true }, () => {
            api.changeExpert('/v1/manual/order/modSolver/' + this.state.rowInfo.id + '/' + this.state.modalExpertId)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.search();
                        message.success(data.msg);
                        this.setState({ showChangeExpert: false, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ showChangeExpert: false, loading: false });
                })
        })
    }
    //修改备注确定
    modalChangeRemarkSubmit = () => {
        this.setState({ loading: true }, () => {
            api.changeRemark({
                id: this.state.modalOrderId,
                remark: this.state.modalRemark
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.search();
                        message.success('备注保存成功!');
                        this.setState({ showRemarkModal: false, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ showChangeExpert: false, loading: false });
                })
        })
    }
    // 对用户评价进行转换
    getComment = (commentItem) => {
        if (Number(commentItem.commentType) === 1) {
            return 'helpful'
        } else if (Number(commentItem.commentType) === 2) {
            let res = ''
            let comment = commentItem.comment.split(',')
            comment.forEach((item, index) => {
                if (Number(item) === 4) {
                    res = res.concat('incomplete answer')
                }
                else if (Number(item) === 5) {
                    res = res.concat('incorrect answer')
                } else if (Number(item) === 6) {
                    res = res.concat('scraw answer')
                } else if (Number(item) === 7) {
                    res = res.concat('time-consuming answer')
                }
                if (comment.length - 1 !== index) {
                    res = res.concat(',')
                }
            })
            if (res.length === 0) {
                return 'unhelpful'
            } else {
                return <Tooltip placement='topRight' title={res}>unhelpful<InfoCircleFilled className={Style.commentCircle} />
                </Tooltip>
            }
        } else {
            return '暂无评价'
        }
    }
    //查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getSolveOrdersList();
        })
    }
    //关闭所有弹框
    close = () => {
        this.setState({ showEditAnswer: false, showCloseOrder: false, customizedReason: '', customizedReasonInputShow: false, showChangeSubject: false, showChangeExpert: false, showRemarkModal: false, fileList: [] });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getSolveOrdersList();
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrapTop}>
                        <div className={Style.box}>
                            <span className={Style.span}>工单号：</span>
                            <Input placeholder='请输入工单号' maxLength='20' className={Style.select} value={this.state.orderNum} onChange={this.getOrderNum} />
                        </div>
                        {this.props.level === 2 ? <Fragment>
                            <div className={Style.box}>
                                <span className={Style.span}>解题专家：</span>
                                <Select placeholder='全部' ref='expert' className={Style.select} value={this.state.expertName} onChange={this.getExpert} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.nameList.map((item) => {
                                        return (
                                            <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </Fragment> : ''}
                        <div className={Style.box}>
                            <span className={Style.span}>题目学科：</span>
                            <Select placeholder='全部' ref='subject' className={Style.select} maxTagTextLength={10} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.subjectList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.boxButton}>
                            <Input placeholder='请输入用户ID' maxLength='20' value={this.state.userID} onChange={this.getUserID} />
                        </div>
                    </div>
                    <div className={Style.searchWrapTop}>
                        <div className={Style.box}>
                            <span className={Style.span}>创建时间：</span>
                            <RangePicker ref='changeCreateTime' onChange={this.changeCreateTime} className={Style.select}
                                disabledDate={(date) => {
                                    return date > moment().startOf(1, 'day')
                                }}
                                defaultValue={
                                    this.state.createStartTime ? [moment(this.state.createStartTime, 'YYYY-MM-DD'), moment(this.state.createEndTime, 'YYYY-MM-DD')] : null
                                }>
                            </RangePicker>
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>工单状态：</span>
                            <Select placeholder='全部' ref='orderStatus' className={Style.select} value={this.state.orderStatus} onChange={this.getOrderStatus} optionLabelProp="label" showSearch={true} allowClear={true}>
                                <Option key={0} value='未分配'>未分配</Option>
                                <Option key={1} value='待解答'>待解答</Option>
                                <Option key={2} value='已解答'>已解答</Option>
                                <Option key={3} value='已关闭'>已关闭</Option>
                            </Select>
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>用户评价：</span>
                            <Select placeholder='全部' ref='userComment' className={Style.select} value={this.state.userComment} onChange={this.getUserComment} optionLabelProp="label" showSearch={true} allowClear={true}>
                                <Option key={1} value='helpful'>helpful</Option>
                                <Option key={2} value='unhelpful'>unhelpful</Option>
                                <Option key={0} value='无评价'>无评价</Option>
                            </Select>
                        </div>
                        <div className={Style.boxButton}>
                            <Button type='primary' className={Style.button} icon={<DownloadOutlined />} onClick={this.exportOrder}>导出</Button>
                        </div>
                    </div>
                    <div className={Style.searchWrapTop}>
                        {this.props.level === 2 ? <Fragment>
                            <div className={Style.box}>
                                <span className={Style.span}>工单备注：</span>
                                <Select placeholder='全部' ref='remarkStatus' className={Style.select} value={this.state.remarkStatus} onChange={this.getRemarkStatus} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    <Option key={1} value='有备注'>有备注</Option>
                                    <Option key={0} value='无备注'>无备注</Option>
                                </Select>
                            </div>
                            <div className={Style.box}>
                                <span className={Style.span}>优质工单：</span>
                                <Select placeholder='全部' ref='greatOrder' className={Style.select} value={this.state.greatOrder} onChange={this.getGreatOrder} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    <Option key={1} value='是'>是</Option>
                                    <Option key={0} value='否'>否</Option>
                                </Select>
                            </div>
                        </Fragment> : ''}
                        <div className={Style.box}>
                            <span className={Style.span}>工单难度：</span>
                            <Select placeholder='全部' ref='orderDifficulty' className={Style.select} value={this.state.orderDifficulty} onChange={this.getOrderDifficulty} optionLabelProp="label" showSearch={true} allowClear={true}>
                                <Option key={1} value='S'>S</Option>
                                <Option key={2} value='A'>A</Option>
                                <Option key={3} value='B'>B</Option>
                                <Option key={4} value='C'>C</Option>
                                <Option key={5} value='D'>D</Option>
                                <Option key={0} value='无'>无</Option>
                            </Select>
                        </div>
                        <div className={Style.boxButton}>
                            <Button type='primary' className={Style.button} icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                        </div>
                    </div>
                    <Divider />
                    <div className={Style.cardBox}>
                        {(Array.isArray(this.state.solveOrdersList) && this.state.solveOrdersList.length > 0) ? this.state.solveOrdersList.map((item, index) => {
                            let arr = [];
                            (Array.isArray(item.answerPicArr) && item.answerPicArr.length > 0) ? item.answerPicArr.map((item1) => {
                                let obj = {};
                                obj.alt = '答案图片';
                                obj.src = item.cloudFrontUrl + '/' + item1;
                                arr.push(obj);
                                return arr;
                            }) : arr = [];
                            // moment 默认转换格式为用户所在地的本地时间
                            // let date = moment(new Date(new Date(item.createdAt).getTime() + 28800000)).format('YYYY-MM-DD HH:mm:ss');
                            let date = moment.utc(item.createdAt).utcOffset(480).format('YYYY-MM-DD HH:mm:ss');
                            return (
                                <Card
                                    className={Style.cradWrap}
                                    style={{ border: item.orderStatus === 1 ? '1px solid #FCAB26' : '' }}
                                    key={index}
                                    actions={this.props.level === 2 ? [
                                        <Button type='link' size='small' disabled={item.orderStatus === 3} key="edit" onClick={() => { this.editAnswer(item) }} style={{ color: '#1890ff' }}>编辑答案</Button>,
                                        <Button type='link' size='small' disabled={item.orderStatus === 3} key="close" onClick={() => { this.closeOrder(item) }} style={{ color: '#1890ff' }}>关闭工单</Button>,
                                        <Button type='link' size='small' disabled={item.orderStatus === 3} key="changeSub" onClick={() => { this.changeSubject(item) }} style={{ color: '#1890ff' }}>修改学科</Button>,
                                        <Button type='link' size='small' disabled={item.orderStatus === 3} key="changeExpert" onClick={() => { this.changeExpert(item) }} style={{ color: '#1890ff' }}>修改解题专家</Button>
                                    ] : [
                                            <Button type='link' size='small' disabled={item.orderStatus === 3} key="edit" onClick={() => { this.editAnswer(item) }} style={{ color: '#1890ff' }}>编辑答案</Button>,
                                            <Button type='link' size='small' disabled={item.orderStatus === 3} key="close" onClick={() => { this.closeOrder(item) }} style={{ color: '#1890ff' }}>关闭工单</Button>,
                                            <Button type='link' size='small' disabled={item.orderStatus === 3} key="changeSub" style={{ color: '#1890ff' }}>修改学科</Button>
                                        ]}
                                >
                                    <span className={Style.source}>{item.sourceType === 1 ? 'APP' : item.sourceType === 2 ? '小程序' : ''}</span>
                                    <Skeleton active loading={this.state.loading}>
                                        <div className={Style.cardContent} >
                                            <div className={Style.box}>
                                                <span className={Style.title}>工单号：{item.orderId}</span>
                                                <Button type='link' size='small' className={Style.remark} key="changeSub" onClick={() => { this.changeRemark(item) }} style={{ color: '#1890ff' }}>工单备注</Button>
                                            </div>
                                            <div className={Style.box}>
                                                <span className={Style.title}>用户ID：{item.userId}</span>
                                                <Tooltip placement='topRight' title={`该用户发起的第${item.qaTimes}个工单`}>
                                                    <InfoCircleFilled className={Style.questionCircle} />{item.qaTimes}
                                                </Tooltip>
                                            </div>
                                            <div className={Style.wrap}>
                                                <div className={Style.left}>
                                                    <div className={Style.box}>
                                                        <span className={Style.title}>题目学科：{item.subjectName}</span>
                                                    </div>
                                                    <div className={Style.box}>
                                                        <span className={Style.title}>创建时间：{date}</span>
                                                    </div>
                                                    <div className={Style.box}>
                                                        <span className={Style.title}>解答用时：</span>{item.answerConsumeTime !== null ? item.answerConsumeTime + ' min' : ''}
                                                    </div>
                                                    <div className={Style.box}>
                                                        <span className={Style.title}>解题专家：</span>{item.solverName}
                                                    </div>
                                                </div>
                                                <div className={Style.right}>
                                                    <img ref={'questionImage' + index} className={Style.image} src={item.cloudFrontUrl + '/' + item.pic} alt='题目图片'  ></img>
                                                </div>
                                            </div>
                                            <div className={Style.box}>
                                                <span className={Style.title}>题目答案：</span>
                                            </div>
                                            <div className={Style.answerBox}>
                                                {item.orderStatus === 1 ? <div className={Style.h1}>
                                                    <h1>距离工单完成分配已过去 {item.assignTimePast} min</h1>
                                                </div> : (Array.isArray(item.answerPicArr) && item.answerPicArr.length > 0) ? <div ref={'answerImageList' + index} className={Style.imageListWrap} > {item.answerPicArr.map((item1, index1) => {
                                                    return (
                                                        <img className={Style.image} key={index1} src={item.cloudFrontUrl + '/' + item1} alt='答案图片' ></img>
                                                    )
                                                })}</div> : '暂无答案'}
                                            </div>
                                            <div className={Style.bottom}>
                                                <div className={Style.left}>
                                                    <span className={Style.title}>工单状态：</span>{item.orderStatus === 0 ? '未分配' : item.orderStatus === 1 ? '待解答' : item.orderStatus === 2 ? '已解答' : item.orderStatus === 3 ? <span > 已关闭 <Tooltip title={item.closeReason ? item.closeReason : this.state.closeReason[item.closeReasonType - 1]}> <InfoCircleFilled /></Tooltip>
                                                    </span> : '未分配'}
                                                </div>
                                                <div className={Style.wrap}>
                                                    <span className={Style.title}>用户评价：</span>{this.getComment(item)}
                                                </div>
                                            </div>
                                            <div className={Style.bottom}>
                                                {(this.props.powerArr.indexOf(9) !== -1 || this.props.powerArr.indexOf(6) !== -1) ? <div className={Style.left}>
                                                    <Checkbox className={Style.check} onChange={() => { this.checkGreatOrder(item, index) }} checked={item.popId && item.popId === item.id}> 优质工单</Checkbox>
                                                </div> : ''}
                                                <div className={Style.right}>
                                                    <span className={Style.title}>难度：</span>
                                                    <Radio.Group className={Style.radioGroup} value={item.difficultyLevel.toString()} onChange={(e) => { this.changeOrderDifficulty(e, item, index) }}>
                                                        <Radio.Button value='1' className={Style.radio}>S</Radio.Button>
                                                        <Radio.Button value='2' className={Style.radio}>A</Radio.Button>
                                                        <Radio.Button value='3' className={Style.radio}>B</Radio.Button>
                                                        <Radio.Button value='4' className={Style.radio}>C</Radio.Button>
                                                        <Radio.Button value='5' className={Style.radio}>D</Radio.Button>
                                                    </Radio.Group>
                                                </div>
                                            </div>
                                        </div>
                                    </Skeleton>
                                    {this.state.loading ? <Skeleton.Image /> : ''}
                                </Card>
                            )
                        }) : <Empty className={Style.empty} />}
                    </div>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} pageSizeOptions={['9', '18', '45', '90']} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} ></Pagination>
                    {/* 工单备注弹框 */}
                    {
                        this.state.showRemarkModal ? <Modal title='工单备注' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.modalChangeRemarkSubmit}>确定</Button>]}>
                            <div className={Style.showRemark} >
                                <span className={Style.left}>备注：&emsp;</span>
                                <TextArea placeholder='请输入工单备注' rows={12} maxLength='500' value={this.state.modalRemark} onChange={this.changeRemarkValue} />
                            </div>
                            <div className={Style.showRemarkBottom}>{this.state.modalRemark.length}/500</div>
                        </Modal> : ''
                    }
                    {/* 编辑答案弹框 */}
                    {
                        this.state.showEditAnswer ? <Modal title='编辑答案' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={this.state.fileList.length <= 0 || this.state.fileList.length > 5} onClick={this.modalEditAnswerSubmit}>确定</Button>]}>
                            <ol style={{ textAlign: 'left' }}>
                                <li>每道题最多允许上传 5 张图片</li>
                                <li>点击【确定】后将保存图片，并向用户发送通知邮件，推送 APP 消息通知</li>
                            </ol>
                            <Upload
                                beforeUpload={() => false}
                                onChange={this.handleChange}
                                accept='.bmp,.jpg,jpeg,.png,.gif,.svg,.psd,.ai,.TIFF,.webp,.EPS'
                                listType="picture-card"
                                fileList={this.state.fileList}
                                multiple={true}
                                onRemove={this.onRemove}
                                onPreview={this.handlePreview}
                            >
                                {this.state.fileList.length >= 5 ? null : <div><PlusOutlined /><div className="ant-upload-text">Upload</div></div>}
                            </Upload>
                            {this.state.previewVisible ? <Modal title={this.state.previewTitle} close={() => { this.setState({ previewVisible: false }) }}>
                                <img alt="example" style={{ width: '100%' }} src={this.state.previewImage} />
                            </Modal> : ''}
                        </Modal> : ''
                    }
                    {/* 关闭工单弹框 */}
                    {
                        this.state.showCloseOrder ? <Modal title='关闭工单' width='200px' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={this.state.radioValue === ''} onClick={this.modalCloseOrderSubmit}>确定</Button>]}>
                            <ol className={Style.text_close}>
                                <li>工单关闭后不可重新开启，请慎重操作</li>
                                <li>人工关闭工单后，将退回本次提问所消耗的人工解题服务次数</li>
                                <li>人工关闭工单后，将向用户发送邮件通知，说明原因</li>
                            </ol>
                            <div className={Style.text_close}>
                                <h4>请选择关闭工单的原因</h4>
                                <Radio.Group onChange={this.closeOrderRadio} value={this.state.radioValue}>
                                    {/* {this.state.closeReason.map((item, index) => <Radio value={index + 1} key={index}>{index===2?'333':item}{item}</Radio>)} */}
                                    <Radio value={1} key={0}>The question is not in the list of subjects that can be answered. Thank you for choosing Lumist!</Radio>
                                    <Radio value={2} key={1}>Over 3 subquestions have been identified. Please make sure the amount of questions are within<br/> &emsp;&emsp;the limitation. Thank you for choosing Lumist!</Radio>
                                    <Radio value={3} key={2}>This question is too complicated and beyond our time limit for solving it. Thank you for choosing Lumist!</Radio>
                                    <Radio value={4} key={3}>More than one question in your posted picture, we don’t know which to answer. Thank you for choosing<br/> &emsp;&emsp; Lumist!</Radio>
                                    <Radio value={5} key={4}>The picture is too blurry to recognize the question. Thank you for choosing Lumist!</Radio>
                                    <Radio value={6} key={5}>The question is missing important information. Thank you for choosing Lumist!</Radio>
                                    <Radio value={7} key={6}>There is no specific question on the picture. Thank you for choosing Lumist!</Radio>
                                    <Radio value={8} key={7}>You have submitted duplicate content multiple times. Thank you for choosing Lumist!</Radio>
                                    <Radio value={9} key={8}>Your submitted question is not in English. Thank you for choosing Lumist!</Radio>
                                    <br />
                                    <Radio value={10}>
                                        {this.state.customizedReasonInputShow ? <Input placeholder='不超过200个字符' maxLength='200' className={Style.select} value={this.state.customizedReason} onChange={this.getCustomizedReason} /> : '自定义'}
                                    </Radio>
                                </Radio.Group>
                            </div>
                        </Modal> : ''
                    }
                    {/* 修改学科弹框 */}
                    {
                        this.state.showChangeSubject ? <Modal title='修改学科' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.modalChangeSubjectSubmit}>确定</Button>]}>
                            <ol className={Style.text}>
                                <li>若题目所属学科不在当前的人工解题服务范围内，可直接关闭工单</li>
                                <li>点击确定后，会为工单重新分配解题专家</li>
                            </ol>
                            <div className={Style.select}>
                                <h4>选择题目学科</h4>
                                <Select placeholder='全部' className={Style.select} value={this.state.modalSubjectName} onChange={this.getModalSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.subjectList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </Modal> : ''
                    }
                    {/* 修改解题专家弹框 */}
                    {
                        this.state.showChangeExpert ? <Modal title='修改解题专家' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.modalChangeExpertSubmit}>确定</Button>]}>
                            <ol className={Style.text}>
                                <li>修改解题专家不改变工单状态</li>
                                <li>当解题专家发生变化时，将向新解题专家发送通知</li>
                            </ol>
                            <div className={Style.text}>
                                <span><b>题目学科：</b>{this.state.rowInfo.subjectName}</span>
                            </div>
                            <div className={Style.select}>
                                <h4>工单解题专家</h4>
                                <Select placeholder='全部' className={Style.select} value={this.state.modalExpertName} onChange={this.getModalExpert} optionLabelProp="label" showSearch={true} allowClear={true}>
                                    {this.state.workNameList.map((item) => {
                                        return (
                                            <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                        </Modal> : ''
                    }
                </Spin>
            </Fragment>
        )
    }
}

export default connect(store => store)(SolveProOrders);