import React, { Component, Fragment } from 'react';
import { Spin, Select, Button, Table, Pagination, Switch, message, DatePicker, Tooltip, Divider } from 'antd';
import { LoadingOutlined, SearchOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import Style from './ordersQualityTest.module.less';
import Viewer from 'viewerjs';
import 'viewerjs/dist/viewer.css';
import moment from 'moment';
import 'moment/locale/zh-cn';
moment.locale('zh-cn');

const { Option } = Select
class OrdersQualityTest extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showModalTest: false,//是否显示质检弹框
            dataSource: [],
            subjectList: [],//下拉学科列表
            subjectName: null,//下拉所选学科名
            subjectId: '',//下拉所选学科id
            startDate: moment().week(moment().week() - 1).startOf('week').format('YYYY-MM-DD'),//所选周起始日期
            endDate: moment().week(moment().week() - 1).endOf('week').format('YYYY-MM-DD'),//所选周结束日期
            solvedExpertList: [],//下拉解题专家列表
            solvedExpertName: null,//下拉所选解题专家
            solvedExpertId: '',//下拉所选解题专家id
            testStatus: null,//下拉所选是否质检名
            testStatusId: '',//下拉所选是否质检id
            rowInfo: {},//所点击行的数据
            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '工单号',
            dataIndex: 'orderId',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: orderId => (
                <Tooltip placement="top" title={orderId}>
                    {orderId}
                </Tooltip>
            ),
        },
        {
            title: '解题专家',
            dataIndex: 'solverName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: solverName => {
                return (
                    <Tooltip placement="top" title={solverName}>
                        {solverName}
                    </Tooltip>
                )
            },
        },
        {
            title: '创建时间',
            dataIndex: 'createdAt',
            align: 'center',
            width: '200px',
            render: createdAt => {
                let date = new Date(createdAt).getTime() + 28800000;
                return (
                    <Tooltip placement="top" title={createdAt !== null ? moment(date).format('YYYY-MM-DD HH:mm:ss') : ''}>
                        {createdAt !== null ? moment(date).format('YYYY-MM-DD HH:mm:ss') : ''}
                    </Tooltip>
                )
            },
        },
        {
            title: '题目学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => {
                return (
                    <Tooltip placement="top" title={subjectName}>
                        {subjectName}
                    </Tooltip>
                )
            },
        },
        {
            title: '学术检查',
            dataIndex: 'correct',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: correct => {
                let text = correct === 1 ? '通过' : correct === 0 ? '未通过' : '';
                return (
                    <Tooltip placement="top" title={text}>
                        {text}
                    </Tooltip>
                )
            },
        },
        {
            title: '可用性检查',
            dataIndex: 'availability',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: availability => {
                let text = availability === 1 ? '通过' : availability === 0 ? '未通过' : '';
                return (
                    <Tooltip placement="top" title={text}>
                        {text}
                    </Tooltip>
                )
            },
        },
        {
            title: '操作项',
            align: 'center',
            render: (record) => {
                return (
                    <Button type='primary' onClick={() => { this.qualityTest(record) }}>质检</Button>
                )
            }
        }
    ]
    componentDidMount() {
        this.getSubjectList();
        this.getSolvedExpertList();
        this.getordersQualityTestList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, start: this.state.startDate, end: this.state.endDate });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取题目学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取解题专家下拉列表
    getSolvedExpertList = () => {
        this.setState({ loading: true }, () => {
            api.getExpertNamelist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ solvedExpertList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取质检工单列表
    getordersQualityTestList = (params) => {
        this.setState({ loading: true }, () => {
            api.getordersQualityTest(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false }, () => {
                            if (this.state.dataSource.length <= 0 || this.state.rowInfo !== {}) return;
                            let arr = this.state.dataSource;
                            let currentRecord = arr.filter((item) => item.id === this.state.rowInfo.id)[0];
                            this.setState({ learningInspectChecked: currentRecord.correct === 1 ? true : false });
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取下拉所选题目学科
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //获取所选周
    getWeek = (date) => {
        if (date) {
            this.refs.selectDate.blur();
            let startDate = moment(date).startOf('week').format("YYYY-MM-DD");
            let endDate = moment(date).endOf('week').format("YYYY-MM-DD");
            this.setState({ startDate, endDate });
        } else {
            this.setState({ startDate: '', endDate: '' });
        }
    }
    //获取所选解题专家
    getSolvedExpert = (value, option) => {
        if (value && option) {
            this.refs.solvedExpert.blur();
            this.setState({ solvedExpertName: value, solvedExpertId: option.key });
        } else {
            this.setState({ solvedExpertName: null, solvedExpertId: '' });
        }
    }
    //获取下拉所选是否质检
    getTestStatus = (value, option) => {
        if (value && option) {
            this.refs.testStatus.blur();
            this.setState({ testStatus: value, testStatusId: option.key });
        } else {
            this.setState({ testStatus: null, testStatusId: '' });
        }
    }
    //查询
    search = () => {
        this.getordersQualityTestList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, start: this.state.startDate, end: this.state.endDate, subId: this.state.subjectId, inspectionStatus: this.state.testStatusId, solverId: this.state.solvedExpertId });
    }
    //点击质检
    qualityTest = (record) => {
        this.setState({ rowInfo: record, usabilityInspectChecked: record.availability === 1 ? true : false, learningInspectChecked: record.correct === 1 ? true : false, showModalTest: true }, () => {
            if (this.refs['topicPic' + this.state.rowInfo.orderId]) {
                new Viewer(this.refs['topicPic' + this.state.rowInfo.orderId], {})
            }
            if (this.state.rowInfo.answerPicArr) {
                if (this.refs['answerPic' + this.state.rowInfo.orderId]) {
                    new Viewer(this.refs['answerPic' + this.state.rowInfo.orderId], {})
                }
            }
        });
    }
    //学术检查switch
    changeLearningStatus = (checked) => {
        this.setState({ learningInspectChecked: checked, loading: true }, () => {
            api.changeLearningStatus({ id: this.state.rowInfo.id, status: this.state.learningInspectChecked === true ? 1 : 0 })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.paginationChange(this.state.page, this.state.pageSize);
                })
        })
    }
    //可用性检查switch
    changeUsabilityStatus = (checked) => {
        this.setState({ usabilityInspectChecked: checked, loading: true }, () => {
            api.changeUsabilityStatus({ id: this.state.rowInfo.id, status: this.state.usabilityInspectChecked === true ? 1 : 0 })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.paginationChange(this.state.page, this.state.pageSize);
                })
        })
    }
    //关闭弹框
    close = () => {
        this.setState({ showModalTest: false });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getordersQualityTestList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, start: this.state.startDate, end: this.state.endDate, subId: this.state.subjectId, inspectionStatus: this.state.testStatusId, solverId: this.state.solvedExpertId });
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <span className={Style.span}>题目学科：</span>
                            <Select placeholder='全部' ref='subject' className={Style.select} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.subjectList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                    )
                                })}
                            </Select>
                            <span className={Style.span}>质检工单日期：</span>
                            <DatePicker picker="week" ref='selectDate' className={Style.select} allowClear={false} onChange={this.getWeek} disabledDate={(date) => {
                                return date > moment().startOf('week')
                            }} defaultValue={moment().subtract(7, "days")} />
                            <span className={Style.span}>解题专家：</span>
                            <Select placeholder='全部' ref='solvedExpert' className={Style.select} value={this.state.solvedExpertName} onChange={this.getSolvedExpert} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.solvedExpertList.map((item) => {
                                    return (
                                        <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                    )
                                })}
                            </Select>
                            <span className={Style.span}>是否质检：</span>
                            <Select placeholder='全部' ref='testStatus' className={Style.select} value={this.state.testStatus} onChange={this.getTestStatus} optionLabelProp="label" showSearch={true} allowClear={true}>
                                <Option key={1} value='已质检'>已质检</Option>
                                <Option key={0} value='未质检'>未质检</Option>
                            </Select>
                            <Tooltip placement="bottomLeft" title={() => {
                                return (
                                    <ol>
                                        <li>本页面中提及的时间为北京时间（UTC +8）</li>
                                        <li>每周一 0 点从上周提交答案的工单中抽取质检工单</li>
                                        <li>每位解题专家随机抽取 5%的已解答工单做质检</li>
                                        <li>所有质检工单完成质检后，才能生成质检报告</li>
                                    </ol>
                                )
                            }}>
                                <QuestionCircleOutlined style={{ fontSize: '20px', paddingLeft: '10px' }} />
                            </Tooltip>
                        </div>
                        <Button type='primary' icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        bordered={true}
                        pagination={false}
                        rowKey={dataSource => dataSource.id}
                    ></Table>
                    <Pagination className={Style.pagination} showQuickJumper hideOnSinglePage current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    {this.state.showModalTest ? <Modal title='工单质检' close={this.close}>
                        <div className={Style.modalBox}>
                            <div className={Style.left}>
                                <b className={Style.title}>工单号：</b>
                                {this.state.rowInfo.orderId}
                            </div>
                            <div>
                                <b className={Style.title}>题目学科：</b>
                                {this.state.rowInfo.subjectName}
                            </div>
                        </div>
                        <div className={Style.modalBox}>
                            <div className={Style.left}>
                                <b className={Style.title}>学术检查：</b>
                                <Switch checked={this.state.learningInspectChecked} onChange={this.changeLearningStatus} checkedChildren="&emsp;通过" unCheckedChildren="未通过" />
                            </div>
                            <div>
                                <b className={Style.title}>可用性检查：</b>
                                <Switch checked={this.state.usabilityInspectChecked} onChange={this.changeUsabilityStatus} checkedChildren="&emsp;通过" unCheckedChildren="未通过" />
                            </div>
                        </div>
                        <div className={Style.modalBox}>
                            <b className={Style.title}>题目图片：</b>
                            <img className={Style.image} ref={'topicPic' + this.state.rowInfo.orderId} src={this.state.rowInfo.cloudFrontUrl + '/' + this.state.rowInfo.pic} alt='题目图片' ></img>
                        </div>
                        <div className={Style.modalBox}>
                            <b className={Style.title}>答案图片：</b>
                            {this.state.rowInfo.answerPicArr ? <div ref={'answerPic' + this.state.rowInfo.orderId}>{this.state.rowInfo.answerPicArr.map((item, index) => {
                                let arr = [];
                                this.state.rowInfo.answerPicArr.map((item1) => {
                                    let obj = {};
                                    obj.alt = '答案图片';
                                    obj.src = this.state.rowInfo.cloudFrontUrl + '/' + item1;
                                    arr.push(obj);
                                    return arr;
                                });
                                return (
                                    <img className={Style.image} src={this.state.rowInfo.cloudFrontUrl + '/' + item} alt='答案图片' key={index}></img>
                                )
                            })}</div> : ''}
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default OrdersQualityTest;