import React, { Component, Fragment } from "react";
import Style from "./subjectConfiguration.module.less";
import { Radio, Row, Col, Checkbox, Empty, message, Spin, Divider } from "antd";
import { LoadingOutlined } from '@ant-design/icons';
import api from "../../../../utils/api.js";

class SubConfigure extends Component {
	constructor() {
		super();
		this.state = {
			loading: false,
			radioGroupDefaultValue: "all",
			allSubjectList: [],
		};
	}

	componentDidMount() {
		this.getSubjectList({ manualMark: -1 });
	}
	componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
	// 获取全部学科
	getSubjectList = (params) => {
		this.setState({ loading: true }, () => {
			api.getSubject(params)
				.then((res) => {
					if (res.ret === 20000) {
						this.setState({ allSubjectList: res.result, loading: false });
					} else {
						return Promise.reject(res);
					}
				})
				.catch((err) => {
					message.error(err.msg);
					this.setState({ loading: false });
				})
		})
	}

	// 分类显示切换
	selectBtnClickEvent = (e) => {
		if (e.target.value === "yes") {
			this.getSubjectList({ manualMark: 1 });
		} else if (e.target.value === "no") {
			this.getSubjectList({ manualMark: 0 });
		} else {
			this.getSubjectList({ manualMark: -1 });
		}
	};

	// 变更状态
	checkBoxChangeEvent = (e, id) => {
		this.setState({ loading: true }, () => {
			api.changeSubjectState({ id, status: e.target.checked | 0 })
				.then((data) => {
					if (data.ret === 20000) {
						this.setState({ loading: false });
					} else {
						return Promise.reject(data);
					}
				})
				.catch((err) => {
					message.error(err.msg);
					this.setState({ loading: false });
				})
		})
	};

	allSubjectCards = () => {
		return this.state.allSubjectList.map((item) => {
			return (
				<Col className="gutter-row" span={8} key={item.id}>
					<div className={Style["subject-card"]}>
						<div className={Style["card-top"]}>{item.subjectName}</div>
						<div className={Style["card-bot"]}>
							<Checkbox
								onChange={(e) => {
									this.checkBoxChangeEvent(e, item.id);
								}}
								defaultChecked={item.manualMark}
								style={{ fontSize: 13 }}
							>
								支持人工解题
              				</Checkbox>
						</div>
					</div>
				</Col>
			);
		});
	};

	render() {
		const { radioGroupDefaultValue, allSubjectList } = this.state;
		return (
			<Fragment>
				<Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
					<div className={Style["top-select-bar"]}>
						<Radio.Group
							defaultValue={radioGroupDefaultValue}
							size="large"
							onChange={this.selectBtnClickEvent}
						>
							<Radio.Button value="all">全部学科</Radio.Button>
							<Radio.Button value="yes">支持人工解题</Radio.Button>
							<Radio.Button value="no">不支持人工解题</Radio.Button>
						</Radio.Group>
					</div>
					<Divider />
					<Row gutter={[40, 25]} className={Style.content}>
						{this.allSubjectCards()}
					</Row>
					{
						allSubjectList.length === 0 ? <Empty description="无符合条件的学科" className={Style.empty} /> : ''
					}
				</Spin>
			</Fragment>
		);
	}
}

export default SubConfigure;
