import React, { Component, Fragment } from 'react';
import { Spin, Input, Select, Button, Divider, Table, message, Pagination, Tooltip, InputNumber, Popconfirm } from 'antd';
import { LoadingOutlined, SearchOutlined, PlusOutlined, DownloadOutlined, CopyOutlined, QrcodeOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import Style from './extensionCode.module.less';
import moment from 'moment';
const { Option } = Select;

class ExtensionCode extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showAddModal: false,//新增推广码弹框
            showQRImgModal: false,//展示二维码弹框
            searchExtensionCode: null,//推广码
            channelName: null,//渠道名称
            channelNameList: [],//渠道名称列表
            creator: null,//生成人
            creatorID: '',//生成人ID
            creatorList: [],//生成人列表
            stopStatus: null,//是否停用
            stopStatusID: null,//是否停用ID
            //弹框内容
            showExtensionCodeID: '',//新增/编辑推广码ID
            showExtensionCode: '',//新增/编辑推广码
            showChannelName: '',//新增/编辑渠道名称
            // showVIPDay: '',//新增/编辑赠送会员天数
            showQATimes: '',//新增/编辑QA次数
            showRemark: '',//新增/编辑备注
            qrImgSrc: '',
            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 0,//总条数
            dataSource: [],//数据资源
        }
    }
    columns = [
        {
            title: '推广码',
            dataIndex: 'spreadCode',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: spreadCode => {
                return (
                    <div>
                        {(spreadCode === null || spreadCode === '') ? '' : <Button type='link' size='small' onClick={() => { this.copyExtensionCode(spreadCode) }}><CopyOutlined /></Button>}
                        <Tooltip placement="top" title={spreadCode}>
                            {spreadCode}
                        </Tooltip>
                    </div>
                )
            }
        },
        fun.getColumnItem( '渠道名称','name'),
        fun.getColumnItem( '赠送Q&A(次)','awardQaCount'),
        {
            title: '生成时间',
            dataIndex: 'createdAt',
            align: 'center',
            width: '180px',
            ellipsis: {
                showTitle: false,
            },
            render: createdAt => {
                let date = createdAt ? moment(new Date(createdAt).getTime() - new Date().getTimezoneOffset() * 60000).format('YYYY/MM/DD HH:mm:ss') : '';//用户所在地时间
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        fun.getColumnItem( '生成人','createdBy'),
        fun.getColumnItem( '使用人数','useCount'),
        fun.getColumnItem( '备注','remark'),
        {
            title: '操作项',
            align: 'center',
            width: '280px',
            render: record => {
                let stopTime = record.stopTime ? moment(new Date(record.stopTime).getTime() - new Date().getTimezoneOffset() * 60000).format('YYYY/MM/DD HH:mm:ss') : '';//用户所在地时间
                return (
                    <span >
                        <Button type='primary' className={Style.button} onClick={() => { this.editExtensionCodeClick(record) }}>编辑</Button>
                        <Tooltip placement="top" title={record.codeStatus === 0 ? `该推广码于${stopTime}停用` : ''}>
                            <Popconfirm title="确定停用该推广码吗？停用后不支持重新启用" okText="确定" cancelText="取消" onConfirm={() => { this.stopExtensionCode(record.id) }} disabled={record.codeStatus === 0}>
                                <Button type='primary' className={Style.button} disabled={record.codeStatus === 0}>停用</Button>
                            </Popconfirm>
                        </Tooltip>
                        <Tooltip placement="top" title='二维码'>
                            <Button type='link' size='small' onClick={() => { this.showQRImg(record.qrCode) }} ><QrcodeOutlined /></Button>
                        </Tooltip>
                    </span>
                )
            }
        },
    ]
    componentDidMount() {
        this.getExtensionCodeList({
            channel: '',
            codeStatus: '',
            id: '',
            idisplayStart: 0,
            idisplayLength: 10,
            spreadCode: '',
            sysUserId: ''
        });//获取二维码列表
        this.getChannelNameList();//获取渠道名称下拉列表
        this.getCreatorList();//获取生成人下拉列表
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    // 得到渠道名称列表
    getChannelNameList = () => {
        this.setState({ loading: true }, () => {
            api.getChannelNameList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            channelNameList: data.result,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 得到生成人列表
    getCreatorList = () => {
        this.setState({ loading: true }, () => {
            api.getCreatorList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            creatorList: data.result,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获得填入推广码
    getExtensionCOde = (e) => {
        this.setState({ searchExtensionCode: e.target.value });
    }
    //获得所选的渠道名称
    getChannleName = (value, option) => {
        if (value && option) {
            this.refs.channelName.blur();
            this.setState({ channelName: option.value });
        } else {
            this.setState({ channelName: '' });
        }
    }
    //获得所选生成人
    getCreator = (value, option) => {
        if (value && option) {
            this.refs.creator.blur();
            this.setState({ creator: option.value, creatorID: option.key });
        } else {
            this.setState({ creator: '', creatorID: '' });
        }
    }
    //获得所选的停用状态
    getStopStatus = (value, option) => {
        if (value && option) {
            this.refs.stopStatus.blur();
            this.setState({ stopStatus: option.value, stopStatusID: option.key });
        } else {
            this.setState({ stopStatus: '', stopStatusID: '' });
        }
    }
    // 得到推广码列表
    getExtensionCodeList = (params) => {
        this.setState({ loading: true }, () => {
            api.getExtensionCodeList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            dataSource: data.result.data,
                            page: data.result.start + 1,
                            total: data.result.total,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //复制推广码按钮
    copyExtensionCode = (spreadCode) => {
        let input = document.createElement('input');
        input.value = spreadCode;
        input.setAttribute('display', 'none');
        document.body.appendChild(input);
        input.select();
        document.execCommand("Copy");
        document.body.removeChild(input);
        message.success("已将推广码复制到剪切板");
    }
    //展示新增弹框
    addExtensionCodeClick = () => {
        this.setState({
            showAddModal: true,
            showExtensionCodeID: '',
            showExtensionCode: '',
            showChannelName: '',
            // showVIPDay: '',
            showQATimes: '',
            showRemark: ''
        })
    }
    //展示编辑弹框
    editExtensionCodeClick = (record) => {
        this.setState({
            showAddModal: true,
            showExtensionCodeID: record.id,
            showExtensionCode: record.spreadCode,
            showChannelName: record.name,
            // showVIPDay: record.awardVipDay,
            showQATimes: record.awardQaCount,
            showRemark: record.remark,
        })
    }
    //新增/编辑弹框
    //获得填入新增/编辑-渠道名称
    getShowChannelName = (e) => {
        this.setState({ showChannelName: e.target.value });
    }
    //获得填入新增/编辑-赠送会员天数
    // getShowVIPDay = (value) => {
    //     this.setState({ showVIPDay: value });
    // }
    //获得填入新增/编辑-赠QA次数
    getShowQATimes = (value) => {
        this.setState({ showQATimes: value });
    }
    //获得填入新增/编辑-备注
    getShowRemark = (e) => {
        this.setState({ showRemark: e.target.value });
    }
    //展示二维码弹框
    showQRImg = (imgSrc) => {
        this.setState({ showQRImgModal: true, qrImgSrc: imgSrc })
    }
    //保存新建/编辑推广码
    submit = () => {
        this.setState({ loading: true }, () => {
            api.saveExtensionCode({
                awardQaCount: this.state.showQATimes,
                // awardVipDay: this.state.showVIPDay,
                channel: this.state.showChannelName,
                id: this.state.showExtensionCodeID,
                remark: this.state.showRemark
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.close();
                        message.success('推广码已生成！');
                        this.getExtensionCodeList({
                            channel: this.state.channelName,
                            codeStatus: this.state.stopStatusID,
                            id: '',
                            idisplayStart: this.state.page - 1,
                            idisplayLength: this.state.pageSize,
                            spreadCode: this.state.searchExtensionCode,
                            sysUserId: this.state.creatorID
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })

    }
    //停用
    stopExtensionCode = (id) => {
        this.setState({ loading: true }, () => {
            api.stopExtensionCode({ id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getExtensionCodeList({
                            channel: this.state.channelName,
                            codeStatus: this.state.stopStatusID,
                            id: '',
                            idisplayStart: this.state.page - 1,
                            idisplayLength: this.state.pageSize,
                            spreadCode: this.state.searchExtensionCode,
                            sysUserId: this.state.creatorID
                        });
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getExtensionCodeList({
                channel: this.state.channelName,
                codeStatus: this.state.stopStatusID,
                id: '',
                idisplayStart: this.state.page - 1,
                idisplayLength: this.state.pageSize,
                spreadCode: this.state.searchExtensionCode,
                sysUserId: this.state.creatorID
            });
        })
    }
    //分页器
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getExtensionCodeList({
                channel: this.state.channelName,
                codeStatus: this.state.stopStatusID,
                id: '',
                idisplayStart: this.state.page - 1,
                idisplayLength: this.state.pageSize,
                spreadCode: this.state.searchExtensionCode,
                sysUserId: this.state.creatorID
            });
        });
    }
    close = () => {
        this.setState({
            showAddModal: false,
            showQRImgModal: false,
            showExtensionCodeID: '',//新增/编辑推广码ID
            showExtensionCode: '',//新增/编辑推广码
            showChannelName: '',//新增/编辑渠道名称
            // showVIPDay: '',//新增/编辑赠送会员天数
            showQATimes: '',//新增/编辑QA次数
            showRemark: '',//新增/编辑备注
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>
                        <Button type='primary' icon={<PlusOutlined />} className={Style.addButton} onClick={this.addExtensionCodeClick}>新增推广码</Button>
                        <div className={Style.leftWrap}>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>推广码:</span>
                                <Input placeholder='请输入推广码' className={Style.input} onChange={this.getExtensionCOde} maxLength='20' value={this.state.searchExtensionCode} />
                            </div>
                            <div className={Style.boxSelect}>
                                <span className={Style.span}>渠道名称:</span>
                                <Select placeholder='全部' ref='channelName' className={Style.select} onChange={this.getChannleName} optionLabelProp="label" showSearch={true} allowClear>
                                    {this.state.channelNameList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.name}>{item.name}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.boxSelect}>
                                <span className={Style.span}>生成人:</span>
                                <Select placeholder='全部' ref='creator' className={Style.select} onChange={this.getCreator} optionLabelProp="label" showSearch={true} allowClear>
                                    {this.state.creatorList.map((item) => {
                                        return (
                                            <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.boxSelect}>
                                <span className={Style.span}>是否停用:</span>
                                <Select placeholder='全部' ref='stopStatus' className={Style.select} onChange={this.getStopStatus} optionLabelProp="label" allowClear>
                                    <Option key={0} value='是'>是</Option>
                                    <Option key={1} value='否'>否</Option>
                                </Select>
                            </div>
                        </div>
                        <Button icon={<SearchOutlined />} className={Style.button} type='primary' onClick={this.search} >查询</Button>
                    </div>
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {this.state.showAddModal ? <Modal title='新增/编辑推广码' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.submit}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}><ExclamationCircleOutlined />&emsp;</span>
                                <span className={Style.spanRight}> 推广码生成后不允许修改赠送内容，请谨填写</span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>推广码：</span>
                                <span className={Style.spanRight}>{this.state.showExtensionCode}</span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>渠道名称：</span>
                                <Input className={Style.input} placeholder='请输入渠道名称' maxLength='100' value={this.state.showChannelName} onChange={this.getShowChannelName} />
                            </div>
                            {/* <div className={Style.rowWrap}>
                                <span className={Style.span}>赠送会员天数：</span>
                                <InputNumber className={Style.input} placeholder='最多赠送90天' min='0' max='90' value={this.state.showVIPDay} onChange={this.getShowVIPDay} disabled={this.state.showExtensionCodeID !== ''} />
                            </div> */}
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>赠送Q&A次数：</span>
                                <InputNumber className={Style.input} placeholder='最多赠送30次' min='0' max='30' value={this.state.showQATimes} onChange={this.getShowQATimes} disabled={this.state.showExtensionCodeID !== ''} />
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>备注：</span>
                                <Input className={Style.input} placeholder='请输入备注' maxLength='200' value={this.state.showRemark} onChange={this.getShowRemark} />
                                <div className={Style.inputValue}>{this.state.showRemark.length}/200</div>
                            </div>
                        </div>
                    </Modal> : ''}
                    {this.state.showQRImgModal ? <Modal title='显示二维码' close={this.close}>
                        <Fragment>
                            <div className={Style.modalWrapCode}>
                                <img src={this.state.qrImgSrc} alt='二维码图片' />
                            </div>
                        </Fragment>
                        <div className={Style.btnWrapCode}>
                            <a className={Style.download} href={this.state.qrImgSrc}><Button type='primary' icon={<DownloadOutlined />} >下载</Button></a>
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment >
        )
    }
}

export default ExtensionCode;