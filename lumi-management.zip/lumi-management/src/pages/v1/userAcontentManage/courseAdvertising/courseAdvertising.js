import React, { Component, Fragment } from 'react';
import { Spin, Button, Table, Divider, Tooltip, Input, message, Pagination, Popconfirm } from 'antd';
import { LoadingOutlined, PlusOutlined, DeleteOutlined, SearchOutlined, ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons';
import api from '../../../../utils/api'
import fun from '../../../../utils/funSum.js';
import Style from './courseAdvertising.module.less'
import Modal from '../../../../components/modalOfTree/modalOfTree.js';

class CourseAdvertising extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showAddModal: false,//展示添加广告课程弹框
            searchContent: '',//搜索内容
            courseDataSource: [],//课程列表
            dataSource: [],//广告资源
            page: 1,//当前页码
            pageSize: 5,//每页显示条数
            total: 0,//总条数
        }
    }
    //广告列表
    columns = [
        {
            title: '轮播排序',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: (text, record, index) => {
                return (
                    <span>{index + 1}</span>
                )
            }
        },
        fun.getColumnItem('课程ID','prepId'),
        fun.getColumnItem('课程标题','title'),
        {
            title: '课程类型',
            dataIndex: 'courseType',
            ellipsis: {
                showTitle: false,
            },
            align: 'center',
            render: courseType => (
                <Tooltip placement="top" title={courseType === 1 ? '公开课' : courseType === 2 ? '备考课' : ''}>
                    {courseType === 1 ? '公开课' : courseType === 2 ? '备考课' : ''}
                </Tooltip>
            ),
        },
        {
            title: '课程状态',
            dataIndex: 'courseStatus',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: courseStatus => (
                <Tooltip placement="top" title={courseStatus === 1 ? '上线' : courseStatus === 0 ? '下线' : '下线'}>
                    {courseStatus === 1 ? '上线' : courseStatus === 0 ? '下线' : '下线'}
                </Tooltip>
            ),
        },
        {
            title: '操作项目',
            align: 'center',
            width:'350px',
            render: (text, record, index) => {
                return (
                    <span>
                        <Popconfirm title="确定将该课程从轮播广告列表中删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.delAdvertising(record.id) }}>
                            <Button type='primary' className={Style.button} icon={<DeleteOutlined />}>删除</Button>
                        </Popconfirm>
                        <Button type='primary' className={Style.button} icon={<ArrowUpOutlined />} disabled={index === 0} onClick={() => { this.moveAdvertising(record, index, 1) }}>上移</Button>
                        <Button type='primary' className={Style.button} icon={<ArrowDownOutlined />} disabled={index === this.state.dataSource.length - 1} onClick={() => { this.moveAdvertising(record, index, 2) }}>下移</Button>
                    </span>
                )
            }
        }
    ]
    //课程列表
    courseColumn = [
        fun.getColumnItem('课程ID','id'),
        fun.getColumnItem('课程标题','title'),
        {
            title: '课程类型',
            dataIndex: 'courseType',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: courseType => (
                <Tooltip placement="top" title={courseType === 1 ? '公开课' : courseType === 2 ? '备考课' : ''}>
                    {courseType === 1 ? '公开课' : courseType === 2 ? '备考课' : ''}
                </Tooltip>
            ),
        },
        {
            title: '课程状态',
            dataIndex: 'courseStatus',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: courseStatus => (
                <Tooltip placement="top" title={courseStatus === 1 ? '上线' : courseStatus === 0 ? '下线' : '下线'}>
                    {courseStatus === 1 ? '上线' : courseStatus === 0 ? '下线' : '下线'}
                </Tooltip>
            ),
        },
        {
            title: '操作项',
            align: 'center',
            render: (record) => (
                <div>
                    <Button type='primary' className={Style.button} icon={<PlusOutlined />} onClick={() => { this.addAdvertising(record.id) }}>添加到广告列表</Button>
                </div>
            ),
        },
    ]
    componentDidMount() {
        this.getCourseAdvertisingList();
        fun.addKeyboardListener(this.searchAdvertising);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获得课程广告列表
    getCourseAdvertisingList = () => {
        this.setState({ loading: true }, () => {
            api.getCourseAdvertisingList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取课程列表
    getCourseList = (params) => {
        this.setState({ loading: true }, () => {
            api.getTestPrepareCourseList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ courseDataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //添加广告课程
    addAdvertisingClick = () => {
        this.setState({ showAddModal: true }, () => {
            this.getCourseList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        })
    }
    //改变输入框内容
    changeSearchContent = (e) => {
        this.setState({ searchContent: e.target.value });
    }
    //根据输入框内容查询课程
    searchAdvertising = () => {
        let reg = /^\d*$/;
        if (reg.test(this.state.searchContent)) {
            this.getCourseList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.searchContent, });
        }
        else {
            this.getCourseList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, title: this.state.searchContent, });
        }
    }
    //添加课程广告
    addAdvertising = (id) => {
        this.setState({ loading: true }, () => {
            api.addCourseAdvertising({ prepId: id })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.getCourseAdvertisingList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //删除课程广告
    delAdvertising = (id) => {
        this.setState({ loading: true }, () => {
            api.delCourseAdvertising({ id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getCourseAdvertisingList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //移动广告顺序
    moveAdvertising = (record, index, moveType) => {
        let nextIndex = moveType === 1 ? (index - 1) : (index + 1)
        this.setState({ loading: true }, () => {
            api.moveCourseAdvertising({
                id: record.id,
                moveType: moveType,
                nextId: this.state.dataSource[nextIndex].id
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getCourseAdvertisingList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭添加广告课程的弹框
    close = () => {
        this.setState({ showAddModal: false, searchContent: '' })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getCourseList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        });
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.top}>
                        <Button type='primary' icon={<PlusOutlined />} className={Style.button} onClick={this.addAdvertisingClick}>添加广告课程</Button>
                        <span>最多添加5个备考课或公开课，课程下线后将不会在APP中轮播展示</span>
                    </div>
                    {this.state.showAddModal ? <Modal title='添加广告课程' close={this.close}>
                        <div className={Style.searchTop}>
                            <Input placeholder='请输入课程ID或课程标题' className={Style.input} value={this.state.searchContent} onChange={this.changeSearchContent} maxLength='100'></Input>
                            <Button type='primary' icon={<SearchOutlined />} onClick={this.searchAdvertising}>查询</Button>
                        </div>
                        <Divider />
                        <Table
                            columns={this.courseColumn}
                            dataSource={this.state.courseDataSource}
                            rowKey={dataSource => dataSource.id}
                            bordered={true}
                            pagination={false}
                        ></Table>
                        <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    </Modal> : ''}
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                </Spin>
            </Fragment>
        )
    }
}

export default CourseAdvertising;
