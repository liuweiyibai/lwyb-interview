import React, { Component, Fragment } from 'react';
import { Spin, Input, Select, Button, Divider, Table, message, Pagination, Tooltip, Switch, Upload, notification, Popconfirm } from 'antd';
import { LoadingOutlined, SearchOutlined, PlusOutlined, ExclamationCircleOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import Style from './schoolManage.module.less';
import TextArea from 'antd/lib/input/TextArea';
const { Option } = Select;

class SchoolManage extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            //搜索框
            countryList: [],//国家下拉列表
            schoolName: '',//学校名称
            schoolShortName: '',//学校缩写
            country: '',//国家
            hotSchoolStatus: '',//是否热门学校
            showAddSchoolModal: false,//是否展示新增/编辑学校弹框
            //批量新增学校弹框
            showBulkAddSchoolModal: false,//是否展示批量新增学校弹框
            fileList: [],
            //新增/编辑弹框
            showSchoolID: null,//编辑的学校ID
            showSchoolName: '',//弹框中学校名称
            showSchoolShortName: '',//弹框中学校缩写
            showDiscordLink: '',//弹框中discord链接
            showCountry: null,//弹框中所在国家
            showHotSchoolStatus: 0,//弹框中是否为热门学校
            //页码
            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 0,//总条数
            dataSource: [],//数据资源
        }
    }
    columns = [
        fun.getColumnItem('学校名称', 'name'),
        fun.getColumnItem('学校缩写', 'shortName', '90px'),
        fun.getColumnItem('所在国家', 'country', '90px'),
        {
            title: '热门学校',
            dataIndex: 'isPopular',
            width: '90px',
            align: 'center',
            render: isPopular => {
                return (
                    <Tooltip placement="top" title={isPopular === 0 ? '' : '热门'}>
                        {isPopular === 0 ? '' : '热门'}
                    </Tooltip>
                )
            }
        },
        {
            title: 'Discord邀请链接',
            dataIndex: 'jumpLink',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: jumpLink => {
                return (
                    <Tooltip placement="topLeft" title={jumpLink}>
                        {jumpLink}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: '280px',
            render: record => {
                return (
                    <span >
                        <Button type='primary' icon={<EditOutlined />} className={Style.button} onClick={() => { this.editSchoolClick(record) }}>编辑</Button>
                        <Popconfirm title="确认删除该学校吗？" okText="确定" cancelText="取消" onConfirm={() => { this.deleteSchool(record.id) }} disabled={record.codeStatus === 0}>
                            <Button type='primary' icon={<DeleteOutlined />} className={Style.button} >删除</Button>
                        </Popconfirm>
                    </span>
                )
            }
        },
    ]
    componentDidMount() {
        this.getSchoolList({ country: '', idisplayLength: this.state.pageSize, idisplayStart: this.state.page - 1, isPopular: '', name: '', shortName: '' });//获取学校列表
        this.getCountryList();//获取国家下拉列表
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    // 得到国家下拉列表
    getCountryList = () => {
        this.setState({ loading: true }, () => {
            api.getCountryList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            countryList: data.result,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 公用API
    commonApi = (params, apiName, afterFun) => {
        this.setState({ loading: true }, async function () {
            try {
                let data = await api[apiName](params);
                if (data.ret === 20000) {
                    afterFun(data)
                } else {
                    throw data
                }
            }
            catch (err) {
                message.error(err.msg);
                this.setState({ loading: false });
            }
        })
    }
    // // 得到国家下拉列表
    // getCountryList = () => {
    //     this.commonApi({}, 'getCountryList', (data) => {
    //         this.setState({
    //             countryList: data.result,
    //             loading: false
    //         })
    //     })
    // }
    //获得学校名称
    getSchoolName = (e) => {
        this.setState({ schoolName: e.target.value });
    }
    //获得学校缩写
    getSchoolShortName = (e) => {
        let value = e.target.value.replace(/[\u4e00-\u9fa5]+$/g, '')
        this.setState({ schoolShortName: value });
    }
    //获得所在国家
    getCountry = (value, option) => {
        if (value && option) {
            this.refs.country.blur();
            this.setState({ country: option.value });
        } else {
            this.setState({ country: '' });
        }
    }
    //获得热门学校
    getHotSchoolStatus = (value, option) => {
        if (value && option) {
            this.refs.hotSchoolStatus.blur();
            this.setState({ hotSchoolStatus: option.key });
        } else {
            this.setState({ hotSchoolStatus: '' });
        }
    }
    // 得到学校列表
    getSchoolList = (params) => {
        this.setState({ loading: true }, () => {
            api.getSchoolManageList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            dataSource: data.result.data,
                            page: data.result.start + 1,
                            total: data.result.total,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 点击新增学校按钮
    addSchoolClick = () => {
        this.setState({ showAddSchoolModal: true, });
    }
    // 点击编辑学校按钮
    editSchoolClick = (record) => {
        this.setState({ showAddSchoolModal: true, showSchoolName: record.name, showSchoolShortName: record.shortName, showCountry: record.country, showHotSchoolStatus: record.isPopular, showSchoolID: record.id, showDiscordLink: record.jumpLink });
    }
    // 改变弹框中学校名称
    getShowSchoolName = (e) => {
        this.setState({ showSchoolName: e.target.value });
    }
    // 改变弹框中学校缩写
    getShowSchoolShortName = (e) => {
        this.setState({ showSchoolShortName: e.target.value });
    }
    // 改变弹框中discord链接
    getDiscordLink = (e) => {
        this.setState({ showDiscordLink: e.target.value });
    }
    // 改变弹框中国家
    getShowCountry = (value, option) => {
        if (value && option) {
            this.setState({ showCountry: option.value });
        } else {
            this.setState({ showCountry: null });
        }
    }
    // 改变弹框中热门学校
    getShowHotSchoolStatus = () => {
        this.setState({ showHotSchoolStatus: this.state.showHotSchoolStatus === 1 ? 0 : 1 })
    }
    // 新增编辑确定提交
    addEditSchoolSubmit = () => {
        this.setState({ loading: true }, () => {
            api.addEditSchool({
                country: this.state.showCountry,
                id: this.state.showSchoolID,
                isPopular: this.state.showHotSchoolStatus,
                name: this.state.showSchoolName,
                shortName: this.state.showSchoolShortName,
                jumpLink: this.state.showDiscordLink
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success('新增/编辑学校成功！')
                        this.paginationChange(this.state.page, this.state.pageSize);//获取学校列表
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 删除提交
    deleteSchool = (id) => {
        this.setState({ loading: true }, () => {
            api.deleteSchool({ id })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success('删除学校成功！');
                        this.paginationChange(this.state.page, this.state.pageSize);//获取学校列表
                        this.search();//获取学校列表
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 点击批量添加学校按钮
    bulkAddSchoolClick = () => {
        this.setState({ showBulkAddSchoolModal: true });
    }
    //上传文件改变时的状态
    handleChange = ({ file, fileList }) => {
        if (file.name.split('.')[file.name.split('.').length - 1] !== 'xlsx') {
            message.warning('仅可上传Excel文件！');
            this.setState({ fileList: [] });
            return;
        }
        this.setState({ fileList: fileList });
    }
    //批量添加学校
    bulkAddSchoolSubmit = () => {
        let file = this.state.fileList
        let formData = new FormData();
        formData.append('file', file[0].originFileObj);
        this.setState({ loading: true }, () => {
            api.bulkAddSchool(formData)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success('批量添加学校成功！');
                        this.search();//获取学校列表
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    notification.warning({
                        message: err.msg,
                        duration: null,
                        placement: 'topRight',
                        style: { position: "absolute", right: window.screen.width / 2, transform: "translateX(50%)" },
                        btn: <Button type='primary' onClick={() => { notification.close(1); this.close() }}>确定</Button>,
                        key: 1,
                        onClose: () => {
                            this.close();
                        }
                    });
                })
        })
    }
    // 查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getSchoolList({ country: this.state.country, idisplayLength: this.state.pageSize, idisplayStart: this.state.page - 1, isPopular: this.state.hotSchoolStatus, name: this.state.schoolName, shortName: this.state.schoolShortName });//获取学校列表
        })
    }
    //分页器
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getSchoolList({ country: this.state.country, idisplayLength: this.state.pageSize, idisplayStart: this.state.page - 1, isPopular: this.state.hotSchoolStatus, name: this.state.schoolName, shortName: this.state.schoolShortName });//获取学校列表
        });
    }
    // 关闭弹框
    close = () => {
        this.setState({ showAddSchoolModal: false, showBulkAddSchoolModal: false, loading: false, fileList: [], showSchoolName: '', showSchoolShortName: '', showCountry: null, showHotSchoolStatus: 0, showSchoolID: '', showDiscordLink: '' });
    }
    render() {
        let disable = !(Boolean(this.state.showSchoolName) && Boolean(this.state.showCountry));
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>
                        <Button type='primary' icon={<PlusOutlined />} onClick={this.addSchoolClick}>新增学校</Button>
                        <div className={Style.leftWrap}>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>学校名称:</span>
                                <Input placeholder='请输入学校名称' className={Style.input} onChange={this.getSchoolName} maxLength='50' value={this.state.schoolName} />
                            </div>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>学校缩写:</span>
                                <Input placeholder='请输入学校缩写' className={Style.input} onChange={this.getSchoolShortName} maxLength='50' value={this.state.schoolShortName} onPaste={(e) => e.preventDefault()} />
                            </div>
                            <div className={Style.boxSelect}>
                                <span className={Style.span}>所在国家:</span>
                                <Select placeholder='全部' ref='country' className={Style.select} onChange={this.getCountry} optionLabelProp="label" showSearch={true} allowClear>
                                    {this.state.countryList.map((item) => {
                                        return (
                                            <Option key={item.country} value={item.country}>{item.country}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.boxSelect}>
                                <span className={Style.span}>热门学校:</span>
                                <Select placeholder='全部' ref='hotSchoolStatus' className={Style.select} onChange={this.getHotSchoolStatus} optionLabelProp="label" allowClear>
                                    <Option key={1} value='是'>是</Option>
                                    <Option key={0} value='否'>否</Option>
                                </Select>
                            </div>
                        </div>
                        <div className={Style.rightWrap}>
                            <Button icon={<SearchOutlined />} className={Style.button} type='primary' onClick={this.search} >查询</Button>
                            <Button className={Style.button} type='primary' onClick={this.bulkAddSchoolClick} >批量添加学校</Button>
                        </div>
                    </div>
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {/* 新增编辑弹框 */}
                    {this.state.showAddSchoolModal ? <Modal close={this.close} title='新增/编辑学校' actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.addEditSchoolSubmit} disabled={disable}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>学校名称<span className={Style.red}>*</span>：</span>
                                <Input placeholder='请输入学校名称' className={Style.input} onChange={this.getShowSchoolName} maxLength='200' value={this.state.showSchoolName} />
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>学校缩写：</span>
                                <Input placeholder='请输入学校缩写' className={Style.input} onChange={this.getShowSchoolShortName} maxLength='50' value={this.state.showSchoolShortName} />
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>Discord邀请链接：</span>
                                <TextArea rows='6' placeholder='请输入Discord邀请链接' className={Style.input} onChange={this.getDiscordLink} maxLength='200' value={this.state.showDiscordLink} />
                                <span className={Style.showCount}>{this.state.showDiscordLink ? this.state.showDiscordLink.length : 0}/200</span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>所在国家<span className={Style.red}>*</span>：</span>
                                <Select placeholder='全部' className={Style.select} onChange={this.getShowCountry} optionLabelProp="label" showSearch={true} allowClear value={this.state.showCountry}>
                                    {this.state.countryList.map((item) => {
                                        return (
                                            <Option key={item.country} value={item.country}>{item.country}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>热门学校<span className={Style.red}>*</span>：</span>
                                <Switch checked={this.state.showHotSchoolStatus === 1 ? true : false} onChange={this.getShowHotSchoolStatus} checkedChildren="是" unCheckedChildren="否" />
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 批量添加学校弹框 */}
                    {this.state.showBulkAddSchoolModal ? <Modal title='批量添加学校' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.bulkAddSchoolSubmit} disabled={this.state.fileList.length === 0}>确定</Button>]}>
                        <div className={Style.bulkAddSchoolModal}>
                            <span><ExclamationCircleOutlined />&emsp;学校名称、所在国家不可为空，学校缩写，热门学校可以不填写</span>
                            <a className={Style.download} href='https://cdn.lumiclass.com/cms/qm/template/批量添加学校模版.xlsx'><Button type='link'>模板下载</Button></a>
                            <div className={Style.wrap}>
                                <span>请选择Excel文件：</span>
                                <Upload
                                    beforeUpload={() => false}
                                    onChange={this.handleChange}
                                    fileList={this.state.fileList}
                                    accept='.xlsx'
                                >
                                    {this.state.fileList.length === 0 ? <Button type='primary' >选择文件</Button> : ''}
                                </Upload>
                            </div>
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment >
        )
    }
}

export default SchoolManage;