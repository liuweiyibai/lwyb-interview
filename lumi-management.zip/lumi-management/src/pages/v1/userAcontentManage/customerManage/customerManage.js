import React, { Component, Fragment } from 'react';
import { Spin, Input, Select, Button, Divider, Table, message, Pagination, Tooltip, InputNumber, Upload, notification, DatePicker, Popconfirm, Badge, Steps } from 'antd';
import { LoadingOutlined, MinusOutlined, PlusOutlined, GiftOutlined, ExclamationCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import api from '../../../../utils/api';
import Style from './customerManage.module.less';
import moment from 'moment';
import fun from '../../../../utils/funSum.js';
const { Option } = Select;
const { RangePicker } = DatePicker;
const { Step } = Steps;
const { TextArea } = Input;

class CustomerManage extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            // 查询项
            id: '',//用户ID
            email: '',//用户邮箱
            nickname: '',//用户昵称
            appVersionList: [],//app版本下拉列表
            selectAppVersionList: [],//所选的APP版本
            OSType: '',//OS类型   
            OSTypeId: null,//OS类型id
            phoneNumber: '',//手机号码
            schoolList: [],//学校下拉列表
            school: '',//学校
            vipStatus: null,//VIP状态
            vipStatusId: null,//VIP状态ID
            registerTimeStart: moment(moment().startOf('day')).format('YYYY-MM-DD HH:mm:ss'),//注册开始时间
            registerTimeEnd: moment(moment().endOf('day')).format('YYYY-MM-DD HH:mm:ss'),//注册结束时间
            conditionGroup: [],//条件
            // conditionGroup: [{ logicKey: 1, logicValue: '且', behaviorValue: '发起Q&A', behaviorKey: 1, computeValue: '<', computeKey: 2, count: '1', timeValue: '注册后', timeKey: 3, timeStart: null, timeEnd: null, timeDay: '1' }],//条件
            //赠送权益弹框
            showGiveRightModal: false,//赠送权益弹框
            showGiveRightID: '',//弹框用户ID
            showGiveRightEmail: '',//弹框用户邮箱
            // showVIPDay: '',//弹框赠送会员天数
            showQATimes: '',//弹框QA次数
            //批量赠送权益弹框
            showBulkGiveRightModal: false,//批量赠送权益弹框
            fileList: [],
            //用户群弹框
            showUserGroup: false,//用户群弹框
            userGroupList: [],//用户群列表
            //保存用户群弹框
            showSaveUserGroup: false,//保存用户群弹框
            saveUserGroupName: '',//用户群名称
            //推送通知弹框
            showPushNotification: false,//推送通知弹框
            currentStep: 0,//当前步骤
            // 第一步，设置推送目标
            pushMode: '查询结果',//现在上传文件还是查询结果,
            pushModeId: 0,
            pushFileList: [],//推送文件
            uploadAlready: false,//已经上传成功
            taskId: '',//上传成功返回的taskId
            userCount: 0,//上传成功返回的userCount
            // 第二步，设置推送内容
            notificationTitle: '',//推送通知标题
            notificationContent: '',//推送通知内容
            notificationLinkTitle: null,//推送通知跳转链接
            notificationLinkTitleJumpSchema: '',//推送通知跳转链接JumpSchema
            notificationLinkKey: '',//推送通知跳转链接ID,
            jumpLinkList: [],//推送通知跳转链接的下拉列表,
            prepareCourseList: [],//推送通知跳转链接选择备考课时的下拉列表,
            showPrepareCourseList: false,//是否展示备考课时的下拉列表,
            prepareCourse: null,//所选备考课
            prepareCourseId: null,//所选备考课ID
            subjectList: [],//推送通知跳转链接选择知识点详情时的下拉列表,
            showSubjectList: false,//是否展示知识点详情时的下拉列表,
            subject: null,//所选学科
            subjectId: null,//所选学科ID
            showH5: false,//是否展示h5的输入链接
            h5Link: '',//输入的h5的链接
            // 第三步，测试推送 
            pushTestEmail: '',
            testAlready: false,//已经测试成功

            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 0,//总条数
            dataSource: [],//数据资源
        }
    }
    columns = () => [
        fun.getColumnItem('用户ID', 'id'),
        fun.getColumnItem('用户邮箱', 'email'),
        fun.getColumnItem('手机号码', 'phoneNumber'),
        fun.getColumnTimeItem('注册时间', 'createdAt', 1),
        fun.getColumnItem('用户昵称', 'nickname'),
        {
            title: <Tooltip placement="top" title='是否是会员'>是否是会员</Tooltip>,
            dataIndex: 'vipStatus',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: vipStatus => {
                return (
                    <Tooltip placement="top" title={vipStatus === 1 ? '是' : '否'}>
                        {vipStatus === 1 ? '是' : '否'}
                    </Tooltip>
                )
            }
        },
        fun.getColumnItem('学校', 'schoolName'),
        fun.getColumnTimeItem('VIP到期时间', 'expiredTimeVip', 1),
        fun.getColumnItem('剩余的Q&A次数', 'availableQACount'),
        {
            title: '操作项',
            align: 'center',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return (
                    <Button type='primary' className={Style.button} icon={<GiftOutlined />} onClick={() => { this.giveRight(record) }}>权益赠送</Button>
                )
            }
        },
    ]
    componentDidMount() {
        this.getAppUserList();
        this.getSchoolList();
        this.getAppVersionList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    // 得到用户信息列表
    getAppUserList = () => {
        this.setState({ loading: true }, () => {
            let arr = this.state.conditionGroup.map((item, index) => {
                let list = {
                    logic: Number(item.logicKey), //逻辑关系 1=and 2=or
                    behavior: Number(item.behaviorKey),//1发起Q&A、2拍照搜题、3购买课程、4订阅VIP
                    conditions: Number(item.computeKey), //条件 1大于 2小于 3等于
                    count: item.count, //次数
                    timeType: Number(item.timeKey),//1任意时间 2自定义时间 3注册x天
                    start: item.timeStart,
                    end: item.timeEnd,
                    days: item.timeDay //timeType =3时的 天数
                }
                return list;
            })
            let lumistersion = this.state.selectAppVersionList.map((item, index) => {
                if (index === this.state.selectAppVersionList.length - 1) {
                    return item
                }
                return item + ','
            })
            lumistersion = lumistersion.join('')
            api.getAppUserList({ email: this.state.email, id: this.state.id, idisplayLength: this.state.pageSize, idisplayStart: this.state.page - 1, nickname: this.state.nickname, schoolId: this.state.school, vipStatus: this.state.vipStatusId, platform: this.state.OSTypeId, lumistersion: lumistersion, tel: this.state.phoneNumber, createdAtStart: this.state.registerTimeStart, createdAtEnd: this.state.registerTimeEnd, userBehavior: JSON.stringify(arr) })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            dataSource: data.result.data,
                            page: data.result.start + 1,
                            total: data.result.total,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 获取APP版本下拉列表
    getAppVersionList = () => {
        this.setState({ loading: true }, () => {
            api.getAppVersionList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            appVersionList: data.result,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 得到学校列表
    getSchoolList = () => {
        this.setState({ loading: true }, () => {
            api.getSchoolList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            schoolList: data.result,
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // ------------查询条件
    // 改变输入框文字内容
    changeInput = (e, type) => {
        let obj = {}
        obj[type] = e.target.value;
        this.setState(obj);
    }
    // 改变输入框数字内容
    changeInputNumber = (value, type) => {
        let obj = {}
        obj[type] = value;
        this.setState(obj);
    }
    //获得APP版本
    getAppVersion = (value, option) => {
        if (value && option) {
            this.setState({ selectAppVersionList: value })
        } else {
            this.setState({ selectAppVersionList: [] })
        }
    }
    // 获得OS类型
    getOS = (value, option) => {
        if (value && option) {
            this.refs.OSType.blur();
            this.setState({ OSType: option.value, OSTypeId: option.key });
        } else {
            this.setState({ OSType: '', OSTypeId: '' });
        }
    }
    //获得用户所在学校
    getSchool = (value, option) => {
        if (value && option) {
            this.refs.school.blur();
            this.setState({ school: option.key });
        } else {
            this.setState({ school: '' });
        }
    }
    //获得用户是否是VIP
    getVip = (value, option) => {
        if (value && option) {
            this.refs.vipStatus.blur();
            this.setState({ vipStatusId: option.key });
        } else {
            this.setState({ vipStatusId: '' });
        }
    }
    // 获得注册时间
    getRegisterTime = (date, dateString) => {
        if (date && dateString) {
            this.refs.registerTime.blur();
            let startAt = date[0] ? moment(date[0]).format('YYYY-MM-DD') : '';
            let endAt = date[1] ? moment(date[1]).format('YYYY-MM-DD') : '';
            this.setState({ registerTimeStart: startAt, registerTimeEnd: endAt });
        }
        else {
            this.setState({ registerTimeStart: '', registerTimeEnd: '' });
        }
    }
    // ------------用户群条件
    //改变或且逻辑
    getLogic = (value, option, select) => {
        this.refs['logicValue' + select].blur();
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                if (value && option) {
                    item.logicKey = option.key;
                    item.logicValue = option.value;
                } else {
                    item.logicKey = '';
                    item.logicValue = '';
                }
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    //改变发起拍搜等行为
    getBehavior = (value, option, select) => {
        this.refs['behaviorValue' + select].blur();
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                if (value && option) {
                    item.behaviorKey = option.key;
                    item.behaviorValue = option.value;
                } else {
                    item.behaviorKey = '';
                    item.behaviorValue = '';
                }
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    // 改变大于小于等计算方式
    getCompute = (value, option, select) => {
        this.refs['computeValue' + select].blur();
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                if (value && option) {
                    item.computeKey = option.key;
                    item.computeValue = option.value;
                } else {
                    item.computeKey = '';
                    item.computeValue = '';
                }
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    // 改变操作次数
    getCount = (count, select) => {
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                item.count = count;
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    //改变行为时间
    getTimeType = (value, option, select) => {
        this.refs['timeValue' + select].blur();
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                if (value && option) {
                    item.timeKey = option.key;
                    item.timeValue = option.value;
                } else {
                    item.timeKey = '';
                    item.timeValue = '';
                }
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    // 改变选择注册后时间天数
    getTimeDay = (count, select) => {
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                item.timeDay = count;
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    //改变选择自定义时间范围
    getTimeRange = (date, dateString, select) => {
        this.refs['timeStart' + select].blur();
        let arr = this.state.conditionGroup;
        arr = arr.map((item, index) => {
            if (index === select) {
                if (date && dateString) {
                    item.timeStart = date[0] ? moment(date[0]).format('YYYY/MM/DD') : '';
                    item.timeEnd = date[1] ? moment(date[1]).format('YYYY/MM/DD') : '';
                } else {
                    item.timeStart = '';
                    item.timeEnd = '';
                }
                return item;
            }
            return item;
        })
        this.setState({ conditionGroup: arr });
    }
    // 增加条件
    addCondition = () => {
        let condition = { logicKey: 1, logicValue: '且', behaviorValue: '发起Q&A', behaviorKey: 1, computeValue: '<', computeKey: 2, count: '1', timeValue: '注册后', timeKey: 3, timeStart: null, timeEnd: null, timeDay: '1' };
        let conditionGroup = this.state.conditionGroup;
        conditionGroup.push(condition);
        this.setState({ conditionGroup: conditionGroup });
    }
    // 删除条件
    deleteCondition = (select) => {
        let arr = this.state.conditionGroup;
        arr = arr.filter((item, index) => index !== select);
        this.setState({ conditionGroup: arr });
    }
    // ------------保存用户群弹框
    // 改变用户群名称
    getSaveUserGroupName = (e) => {
        this.setState({ saveUserGroupName: e.target.value });
    }
    // 确认保存用户群名称
    saveUserGroupNameSubmit = () => {
        let arr = this.state.conditionGroup.map((item, index) => {
            let list = {
                logic: Number(item.logicKey), //逻辑关系 1=and 2=or
                behavior: Number(item.behaviorKey),//1发起Q&A、2拍照搜题、3购买课程、4订阅VIP
                conditions: Number(item.computeKey), //条件 1大于 2小于 3等于
                count: item.count, //次数
                timeType: Number(item.timeKey),//1任意时间 2自定义时间 3注册x天
                start: item.timeStart,
                end: item.timeEnd,
                days: item.timeDay //timeType =3时的 天数
            }
            return list;
        })
        var formData = new FormData();
        formData.append('name', this.state.saveUserGroupName);
        formData.append('id', '');
        formData.append('userBehavior', JSON.stringify(arr));
        this.setState({ loading: true }, () => {
            api.saveUserGroup(formData)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.close();
                        this.setState({
                            loading: false
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // ------------点击用户群
    // 点击用户群
    userGroup = () => {
        this.setState({ loading: true }, () => {
            api.userGroupList()
                .then((data) => {
                    if (data.ret === 20000) {
                        let arr = data.result.map((item) => {
                            item.show = false;
                            return item
                        })
                        this.setState({
                            loading: false,
                            showUserGroup: true,
                            userGroupList: arr
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 选择用户群
    selectUserGroup = (select) => {
        let arr = this.state.userGroupList;
        arr = arr.map((item, index) => {
            if (index === select) {
                item.show = !item.show;
            } else {
                item.show = false;
            }
            return item
        })
        this.setState({ userGroupList: arr });
    }
    // 选择用户群的确定按钮
    selectUserGroupConfirm = () => {
        let res = [];
        this.state.userGroupList.forEach((item, index) => {
            if (item.show) {
                let list = JSON.parse(item.behaviorJson)
                list.forEach((item1) => {
                    // res.push(item1)
                    // logic: Number(item.logicKey), //逻辑关系 1=and 2=or
                    // behavior: Number(item.behaviorKey),//1发起Q&A、2拍照搜题、3购买课程、4订阅VIP
                    // conditions: Number(item.computeKey), //条件 1大于 2小于 3等于
                    // count: item.count, //次数
                    // timeType: Number(item.timeKey),//1任意时间 2自定义时间 3注册x天
                    // start: item.timeStart,
                    // end: item.timeEnd,
                    // days: item.timeDay //timeType =3时的 天数
                    let condition = {
                        logicKey: item1.logic,
                        logicValue: item1.logic === 1 ? '且' : item1.logic === 2 ? '或' : '',
                        behaviorValue: item1.behavior === 1 ? '发起Q&A' : item1.behavior === 2 ? '拍照搜题' : item1.behavior === 3 ? '购买课程' : item1.behavior === 4 ? '订阅VIP' : '',
                        behaviorKey: item1.behavior,
                        computeValue: item1.conditions === 1 ? '>' : item1.conditions === 2 ? '<' : item1.conditions === 3 ? '=' : '',
                        computeKey: item1.conditions,
                        count: item1.count,
                        timeValue: item1.timeType === 1 ? '任意时间' : item1.timeType === 2 ? '自定义时间' : item1.timeType === 3 ? '注册后' : '',
                        timeKey: item1.timeType,
                        timeStart: item1.start,
                        timeEnd: item1.end,
                        timeDay: item1.days
                    }
                    res.push(condition);
                })
            }
        })
        this.close();
        this.setState({ conditionGroup: res, });
    }
    // 删除用户群确定按钮
    delUserGroupConfirm = (item) => {
        this.setState({ loading: true }, () => {
            api.delUserGroupConfirm({ id: item.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.userGroup();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // ------------批量赠送权益弹框
    //上传文件改变时的状态
    handleChange = ({ file, fileList }) => {
        if (file.name.split('.')[file.name.split('.').length - 1] !== 'xlsx') {
            message.warning('仅可上传Excel文件！');
            this.setState({ fileList: [] });
            return;
        }
        this.setState({ fileList: fileList });
    }
    //批量权益赠送提交
    bulkGiveRightSubmit = () => {
        let file = this.state.fileList;
        let formData = new FormData();
        formData.append('file', file[0].originFileObj);
        this.setState({ loading: true }, () => {
            api.bulkGiveRight(formData)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ loading: false, fileList: [] });
                        message.success('已完成批量权益赠送！');
                        this.getAppUserList();
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    notification.warning({
                        message: err.msg,
                        duration: null,
                        placement: 'topRight',
                        style: { position: "absolute", right: window.screen.width / 2, transform: "translateX(50%)" },
                        btn: <Button type='primary' onClick={() => { notification.close(1); this.close() }}>确定</Button>,
                        key: 1,
                        onClose: () => {
                            this.close();
                        }
                    });
                })
        })
    }
    // ------------权益赠送弹框
    //权益赠送
    giveRight = (record) => {
        this.setState({ showGiveRightModal: true, showGiveRightID: record.id, showGiveRightEmail: record.email, })
    }
    //获得填入赠送会员天数
    // getShowVIPDay = (value) => {
    //     this.setState({ showVIPDay: value });
    // }
    //获得填入赠QA次数
    getShowQATimes = (value) => {
        this.setState({ showQATimes: value });
    }
    //权益赠送提交按钮
    giveRightSubmit = () => {
        this.setState({ loading: true }, () => {
            api.giveRight({
                id: this.state.showGiveRightID,
                qacredits: this.state.showQATimes,
                // vipDays: this.state.showVIPDay,
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success('权益赠送成功!');
                        this.getAppUserList();
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // ------------导出
    export = () => {
        this.setState({ loading: true }, () => {
            let arr = this.state.conditionGroup.map((item) => {
                let list = {
                    logic: Number(item.logicKey), //逻辑关系 1=and 2=or
                    behavior: Number(item.behaviorKey),//1发起Q&A、2拍照搜题、3购买课程、4订阅VIP
                    conditions: Number(item.computeKey), //条件 1大于 2小于 3等于
                    count: item.count, //次数
                    timeType: Number(item.timeKey),//1任意时间 2自定义时间 3注册x天
                    start: item.timeStart,
                    end: item.timeEnd,
                    days: item.timeDay //timeType =3时的 天数
                }
                return list;
            })
            let lumistersion = this.state.selectAppVersionList.map((item, index) => {
                if (index === this.state.selectAppVersionList.length - 1) {
                    return item
                }
                return item + ','
            })
            lumistersion = lumistersion.join('')

            let params = {
                email: this.state.email, id: this.state.id, nickname: this.state.nickname, schoolId: this.state.school, vipStatus: this.state.vipStatusId, platform: this.state.OSTypeId, lumistersion: lumistersion, tel: this.state.phoneNumber, createdAtStart: this.state.registerTimeStart, createdAtEnd: this.state.registerTimeEnd, userBehavior: JSON.stringify(arr)
            };
            api.exporList(params, { responseType: 'arraybuffer' })
                .then(async (response) => {
                    fun.download(response, `Lumist用户数据-${moment(new Date()).format('YYYYMMDD')}.xlsx`);
                    this.setState({ loading: false });
                    message.success('导出成功！');
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false })
                })
        })
    }
    // ------------推送APP通知弹框
    // 推送APP通知弹框
    pushNotification = () => {
        let notificationTitle = fun.getItem('notificationTitle') && fun.getItem('notificationTitle').length > 0 ? JSON.parse(fun.getItem('notificationTitle')) : '';
        let notificationContent = fun.getItem('notificationContent') && fun.getItem('notificationContent').length > 0 ? JSON.parse(fun.getItem('notificationContent')) : '';
        let notificationLinkTitle = fun.getItem('notificationLinkTitle') && fun.getItem('notificationLinkTitle').length > 0 ? JSON.parse(fun.getItem('notificationLinkTitle')) : '';
        let notificationLinkTitleJumpSchema = fun.getItem('notificationLinkTitleJumpSchema') && fun.getItem('notificationLinkTitleJumpSchema').length > 0 ? JSON.parse(fun.getItem('notificationLinkTitleJumpSchema')) : '';
        let notificationLinkKey = fun.getItem('notificationLinkKey') && fun.getItem('notificationLinkKey').length > 0 ? JSON.parse(fun.getItem('notificationLinkKey')) : '';
        let prepareCourse = fun.getItem('prepareCourse') && fun.getItem('prepareCourse').length > 0 ? JSON.parse(fun.getItem('prepareCourse')) : '';
        let prepareCourseId = fun.getItem('prepareCourseId') && fun.getItem('prepareCourseId').length > 0 ? JSON.parse(fun.getItem('prepareCourseId')) : '';
        let subject = fun.getItem('subject') && fun.getItem('subject').length > 0 ? JSON.parse(fun.getItem('subject')) : '';
        let subjectId = fun.getItem('subjectId') && fun.getItem('subjectId').length > 0 ? JSON.parse(fun.getItem('subjectId')) : '';
        let h5Link = fun.getItem('h5Link') && fun.getItem('h5Link').length > 0 ? JSON.parse(fun.getItem('h5Link')) : '';
        this.getJumpLinkList();
        this.getPrepareCourseList();
        this.getSubjectList();
        this.setState({ showPushNotification: true, notificationTitle, notificationContent, notificationLinkTitle, notificationLinkTitleJumpSchema, prepareCourse, prepareCourseId, subject, subjectId, h5Link, notificationLinkKey }, () => {
            if (fun.getItem('prepareCourse') && fun.getItem('prepareCourse').length > 0 && Number(this.state.notificationLinkKey) === 3) {
                this.setState({ showPrepareCourseList: true })
            }
            if (fun.getItem('subject') && fun.getItem('subject').length > 0 && Number(this.state.notificationLinkKey) === 5) {
                this.setState({ showSubjectList: true })
            }
            if (fun.getItem('h5Link') && fun.getItem('h5Link').length > 0 && Number(this.state.notificationLinkKey) === 9) {
                this.setState({ showH5: true })
            }
        });
    }
    // 改变步骤
    changeSteps = (current) => {
        this.setState({ currentStep: current });
    }
    // 步骤
    steps = [
        {
            title: '设置推送目标',
            content: this.pushGoal,
        },
        {
            title: '配置推送内容',
            content: 'Second-content',
        },
        {
            title: '测试推送',
            content: 'Last-content',
        },
        {
            title: '正式推送',
            content: 'Last-content',
        }
    ];
    // -----步骤内容
    //第一步内容 设置推送目标步骤的内容

    getPushMode = (value, option) => {
        if (value && option) {
            this.refs.pushMode.blur();
            this.setState({ pushMode: option.value, pushModeId: option.key });
        } else {
            this.setState({ pushMode: null, pushModeId: null });
        }
    }
    pushGoal = () => {
        return (
            <div className={Style.setPushGoal}>
                <div className={Style.top}>
                    <span>选择方式：</span>
                    <Select placeholder='全部' ref='pushMode' className={Style.select} onChange={this.getPushMode} optionLabelProp="label" showSearch={true} allowClear value={this.state.pushMode}>
                        <Option key={0} value={'查询结果'}>查询结果</Option>
                        <Option key={1} value={'上传文件'}>上传文件</Option>
                    </Select>
                </div>
                {Number(this.state.pushModeId) === 0 ? <span><ExclamationCircleOutlined />&emsp;根据查询结果，向{this.state.total}位用户推送APP通知</span> : ''}
                {Number(this.state.pushModeId) === 1 ? <span>  <span><ExclamationCircleOutlined />&emsp;根据上传文件，向{this.state.userCount}位用户推送APP通知
                        <a className={Style.download} href='https://cdn.lumiclass.com/cms/qm/template/%E6%8E%A8%E9%80%81%E7%94%A8%E6%88%B7%E6%A8%A1%E6%9D%BF.xlsx'>模板下载</a></span>
                    <div className={Style.wrap}>
                        <span>请选择Excel文件：</span>
                        <Upload
                            beforeUpload={() => false}
                            onChange={this.handlePushChange}
                            fileList={this.state.pushFileList}
                            onRemove={this.onRemovePush}
                            accept='.xlsx'
                        >
                            {this.state.pushFileList.length === 0 ? <Button type='primary' >选择文件</Button> : ''}
                        </Upload>
                    </div>
                </span> : ''}
            </div>
        );
    }
    //第二步内容 设置推送内容步骤的内容
    pushContent = () => {
        return (
            <div className={Style.setPushGoal}>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>通知标题<span className={Style.red}>*</span>：</span>
                    <Input placeholder='不超过50个字符' className={Style.input} onChange={this.getNotificationTitle} maxLength='50' value={this.state.notificationTitle} />
                    <span className={Style.spanHint}>{this.state.notificationTitle.length}/100</span>
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>通知内容：</span>
                    <TextArea placeholder='不超过100个字符' className={Style.input} onChange={this.getNotificationContent} rows={3} maxLength='100' value={this.state.notificationContent} />
                    <span className={Style.spanHint}>{this.state.notificationContent.length}/100</span>
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>跳转目标：</span>
                    <Select placeholder='全部' className={Style.select} onChange={this.getNotificationLink} optionLabelProp="label" showSearch={true} allowClear value={<Tooltip placement="top" title={this.state.notificationLinkTitleJumpSchema}>{this.state.notificationLinkTitle}</Tooltip>}>
                        {this.state.jumpLinkList.map((item) => {
                            return (
                                <Option key={item.id} value={item.name}><Tooltip placement="right" title={item.jumpSchema}>{item.name}</Tooltip></Option>
                            )
                        })}
                    </Select>
                    {this.state.showPrepareCourseList ? <Select placeholder='全部' className={Style.selectPrepare} onChange={this.getPrepareCourse} optionLabelProp="label" showSearch={true} allowClear value={this.state.prepareCourse}>
                        {this.state.prepareCourseList.map((item) => {
                            return (
                                <Option key={item.id} value={item.title}>{item.title}</Option>
                            )
                        })}
                    </Select> : ''}
                    {this.state.showSubjectList ? <Select placeholder='全部' className={Style.selectPrepare} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear value={this.state.subject}>
                        {this.state.subjectList.map((item) => {
                            return (
                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                            )
                        })}
                    </Select> : ''}
                    {this.state.showH5 ? <Input placeholder='请填写以http或https开头的URL链接' className={Style.selectH5Link} onChange={this.getH5Link} value={this.state.h5Link} /> : ''}
                </div>
            </div>
        );
    }
    //第二步内容 设置推送内容步骤的内容中跳转目标的下拉列表
    getJumpLinkList = () => {
        this.setState({ loading: true }, () => {
            api.getJumpLinkList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ loading: false, jumpLinkList: data.result });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //第三步内容 测试推送步骤的内容
    pushTest = () => {
        return (
            <div className={Style.setPushGoal}>
                <span><ExclamationCircleOutlined />&emsp;在正式推送之前，请务必先使用自己的账号测试</span>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>测试账号<span className={Style.red}>*</span>：</span>
                    <Input placeholder='请输入测试账号的Email地址' className={Style.input} onChange={this.getPushTestEmail} value={this.state.pushTestEmail} />
                </div>
            </div>
        )
    }
    // 第四步内容 正式推送步骤的 内容
    pushFormal = () => {
        return (
            <div className={Style.setPushGoal}>
                <span><ExclamationCircleOutlined />&emsp;当推送目标用户较多时，需要较长时间才能完成推送，不同用户会有消息延迟</span>
            </div>
        )
    }
    // -----步骤操作
    //---------- 第一步 操作
    //上传文件改变时的状态
    handlePushChange = ({ file, fileList }) => {
        if (file.name.split('.')[file.name.split('.').length - 1] !== 'xlsx') {
            message.warning('仅可上传Excel文件！');
            this.setState({ pushFileList: [], uploadAlready: false });
            return;
        }
        this.setState({ pushFileList: fileList, uploadAlready: false });
    }
    // 删除上传的文件
    onRemovePush = () => {
        this.setState({ pushFileList: [], uploadAlready: false });
    }
    //---------- 第二步 操作
    // 改变通知标题
    getNotificationTitle = (e) => {
        this.setState({ notificationTitle: e.target.value }, () => {
            fun.setItem('notificationTitle', this.state.notificationTitle)
        })
    }
    // 改变通知内容
    getNotificationContent = (e) => {
        this.setState({ notificationContent: e.target.value }, () => {
            fun.setItem('notificationContent', this.state.notificationContent)
        })
    }
    // 选择备考课详情页或者知识点课程详情页时，显示下拉菜单
    getPrepareCourseList = () => {
        this.setState({ loading: true }, () => {
            api.getPrepareCourseList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ loading: false, prepareCourseList: data.result });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取擅长学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getGoodAtSublist()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 改变通知跳转链接
    getNotificationLink = (value, option) => {
        let notificationLinkTitleJumpSchema
        this.state.jumpLinkList.forEach((item, index) => {
            if (Number(item.id) === Number(option.key)) {
                notificationLinkTitleJumpSchema = item.jumpSchema
            }
        })
        if (value && option) {
            this.setState({ notificationLinkTitle: value, notificationLinkTitleJumpSchema: notificationLinkTitleJumpSchema, notificationLinkKey: option.key, showSubjectList: Number(option.key) === 5, showPrepareCourseList: Number(option.key) === 3, showH5: Number(option.key) === 9 }, () => {
                fun.setItem('notificationLinkTitle', this.state.notificationLinkTitle)
                fun.setItem('notificationLinkTitleJumpSchema', this.state.notificationLinkTitleJumpSchema)
                fun.setItem('notificationLinkKey', this.state.notificationLinkKey)

            })
        } else {
            this.setState({ notificationLinkTitle: '', notificationLinkKey: '', notificationLinkTitleJumpSchema: '' })
        }
        // })
    }
    //改变所选备考课
    getPrepareCourse = (value, option) => {
        if (value && option) {
            this.setState({ prepareCourse: value, prepareCourseId: option.key }, () => {
                fun.setItem('prepareCourse', this.state.prepareCourse)
                fun.setItem('prepareCourseId', this.state.prepareCourseId)
            })
        } else {
            this.setState({ prepareCourse: '', prepareCourseId: '' })
        }
    }
    //改变所选学科
    getSubject = (value, option) => {
        if (value && option) {
            this.setState({ subject: value, subjectId: option.key }, () => {
                fun.setItem('subject', this.state.subject)
                fun.setItem('subjectId', this.state.subjectId)
            })
        } else {
            this.setState({ subject: '', subjectId: '' })
        }
    }
    //改变输入的h5链接
    getH5Link = (e) => {
        this.setState({ h5Link: e.target.value }, () => {
            fun.setItem('h5Link', this.state.h5Link)
        })
    }
    //---------- 第三步 操作
    // 改变测试推送邮箱
    getPushTestEmail = (e) => {
        this.setState({ pushTestEmail: e.target.value, testAlready: false })
    }
    //---------- 第四步 操作
    // 第一步 推送目标提交
    pushGoalSubmit = () => {
        this.setState({ loading: true }, () => {
            let file = this.state.pushFileList
            let formData = new FormData();
            formData.append('file', file[0].originFileObj);
            api.uploadPushGoal(formData)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.setState({ loading: false, uploadAlready: true, taskId: data.result.taskId, userCount: data.result.userCount });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    notification.warning({
                        message: err.msg,
                        duration: null,
                        placement: 'topRight',
                        style: { position: "absolute", right: window.screen.width / 2, transform: "translateX(50%)" },
                        btn: <Button type='primary' onClick={() => { notification.close(1); this.setState({ loading: false }) }}>确定</Button>,
                        key: 1,
                        onClose: () => {
                            this.setState({ loading: false })
                        }
                    });
                })
        })
    }
    //第二步 推送内容提交
    pushContentSubmit = () => {
    }
    //第三步 推送测试提交
    pushTestSubmit = () => {
        this.setState({ loading: true }, () => {
            api.sendTestPush({
                pushConfigDTO: {
                    content: this.state.notificationContent,
                    jumpSchema: JSON.stringify({ jumpId: this.state.notificationLinkKey, ext: Number(this.state.notificationLinkKey) === 9 ? this.state.h5Link : Number(this.state.notificationLinkKey) === 3 ? this.state.prepareCourseId : Number(this.state.notificationLinkKey) === 5 ? this.state.subjectId : 0 }),
                    title: this.state.notificationTitle,
                    userCount: 1
                },
                pushType: 3,
                email: this.state.pushTestEmail
                // chao.zhang@easygroup.ca
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.setState({ loading: false, testAlready: true });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //第四步 推送正式提交
    pushFormalSubmit = () => {
        this.setState({ loading: true }, () => {
            let params = {}
            //用上传文件
            if (Number(this.state.pushModeId) === 1) {
                params = {
                    pushConfigDTO: {
                        content: this.state.notificationContent,
                        jumpSchema: JSON.stringify({ jumpId: this.state.notificationLinkKey, ext: Number(this.state.notificationLinkKey) === 9 ? this.state.h5Link : Number(this.state.notificationLinkKey) === 3 ? this.state.prepareCourseId : Number(this.state.notificationLinkKey) === 5 ? this.state.subjectId : 0 }),
                        title: this.state.notificationTitle,
                        userCount: this.state.userCount
                    },
                    pushType: 2,
                    taskId: this.state.taskId,
                }
            }
            //用查询结果
            if (Number(this.state.pushModeId) === 0) {
                // 查询条件参数
                let arr = this.state.conditionGroup.map((item, index) => {
                    let list = {
                        logic: Number(item.logicKey), //逻辑关系 1=and 2=or
                        behavior: Number(item.behaviorKey),//1发起Q&A、2拍照搜题、3购买课程、4订阅VIP
                        conditions: Number(item.computeKey), //条件 1大于 2小于 3等于
                        count: item.count, //次数
                        timeType: Number(item.timeKey),//1任意时间 2自定义时间 3注册x天
                        start: item.timeStart,
                        end: item.timeEnd,
                        days: item.timeDay //timeType =3时的 天数
                    }
                    return list;
                })

                let lumistersion = this.state.selectAppVersionList.map((item, index) => {
                    if (index === this.state.selectAppVersionList.length - 1) {
                        return item
                    }
                    return item + ','
                })
                lumistersion = lumistersion.join('')
                params = {
                    pushConfigDTO: {
                        content: this.state.notificationContent,
                        jumpSchema: JSON.stringify({ jumpId: this.state.notificationLinkKey, ext: Number(this.state.notificationLinkKey) === 9 ? this.state.h5Link : Number(this.state.notificationLinkKey) === 3 ? this.state.prepareCourseId : Number(this.state.notificationLinkKey) === 5 ? this.state.subjectId : 0 }),
                        title: this.state.notificationTitle,
                        userCount: this.state.total
                    },
                    pushType: 1,
                    userBehaviorDTO: {
                        createdAtEnd: this.state.registerTimeEnd,
                        createdAtStart: this.state.registerTimeStart,
                        email: this.state.email,
                        id: this.state.id,
                        idisplayLength: null,
                        idisplayStart: null,
                        lumistersion: lumistersion,
                        nickname: this.state.nickname,
                        platform: this.state.OSTypeId,
                        schoolId: this.state.school,
                        tel: this.state.phoneNumber,
                        userBehavior: JSON.stringify(arr),
                        vipStatus: this.state.vipStatusId,
                    },
                }
            }
            api.sendPush(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.close();
                        this.setState({ loading: false, testAlready: true }, () => {
                            fun.setItem('notificationTitle', '')
                            fun.setItem('notificationContent', '')
                            fun.setItem('notificationLinkTitle', '')
                            fun.setItem('notificationLinkTitleJumpSchema', '')
                            fun.setItem('notificationLinkKey', '')
                            fun.setItem('subject', '')
                            fun.setItem('subjectId', '')
                            fun.setItem('prepareCourse', '')
                            fun.setItem('prepareCourseId', '')
                            fun.setItem('h5Link', '')
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 判断四个提交按钮的disabled状态
    judgeDisabled = () => {
        let disabled = this.state.pushFileList.length === 0
        switch (this.state.currentStep) {
            case 0: disabled = this.state.pushFileList.length === 0; break;
            case 1: disabled = this.state.notificationTitle.length === 0; break;
            case 2: disabled = (Number(this.state.pushModeId) === 1 && !this.state.uploadAlready) || this.state.notificationTitle.length === 0 || this.state.pushTestEmail.length === 0; break;
            case 3: disabled = (Number(this.state.pushModeId) === 1 && !this.state.uploadAlready) || this.state.notificationTitle.length === 0 || this.state.pushTestEmail.length === 0 || !this.state.testAlready; break;
            default: break
        }
        return disabled
    }
    // 判断四个步骤的状态
    judgeStatus = (index) => {
        let status = 'wait'
        if (index === this.state.currentStep) {
            return 'process'
        }
        if (index === 0) {
            if (Number(this.state.pushModeId) === 0) {
                return 'finish'
            }
            if (Number(this.state.pushModeId) === 1) {
                if (this.state.uploadAlready) {
                    return 'finish'
                } else {
                    return 'wait'
                }
            }
        }
        if (index === 1 && this.state.notificationTitle.length !== 0) {
            return 'finish'
        }
        if (index === 2 && this.state.testAlready) {
            return 'finish'
        }
        return status
    }
    // 判断四个步骤的提交文案
    judgeSubmitText = () => {
        let text = '上传'
        switch (this.state.currentStep) {
            case 0: text = Number(this.state.pushModeId) === 1 ? '上传' : ''; break;
            case 1: text = ''; break;
            case 2: text = '发送测试通知'; break;
            case 3: text = '正式推送'; break;
            default: break
        }
        return text;
    }
    // 判断四个步骤的内容
    judgePushContent = () => {
        let content = this.pushGoal()
        switch (this.state.currentStep) {
            case 0: content = this.pushGoal(); break;
            case 1: content = this.pushContent(); break;
            case 2: content = this.pushTest(); break;
            case 3: content = this.pushFormal(); break;
            default: break
        }
        return content;
    }
    // ---------查询
    //分页器
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getAppUserList();
        });
    }
    // 查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getAppUserList();
        })
    }
    //展开行
    expandedRowRender = (record) => {
        const columns = [
            fun.getColumnItem('APP版本', 'lumistVersionStr'),
            {
                title: 'OS类型',
                dataIndex: 'platform',
                align: 'center',
                ellipsis: {
                    showTitle: false,
                },
                render: platform => {
                    return (
                        <Tooltip placement="top" title={platform === 1 ? 'iOS' : platform === 2 ? 'Android' : ''}>
                            {platform === 1 ? 'iOS' : platform === 2 ? 'Android' : ''}
                        </Tooltip>
                    )
                }
            },
            fun.getColumnItem('专业', 'majorName'),
            fun.getColumnItem('国家', 'country'),
            fun.getColumnItem('城市', 'city'),
            fun.getColumnItem('发起拍搜次数', 'searchCount'),
            fun.getColumnItem('发起Q&A次数', 'qacount'),
            fun.getColumnTimeItem('VIP试用开始时间', 'vipTrialCreatedAt', 1),
            fun.getColumnTimeItem('VIP试用结束时间', 'expiredTimeVipTrial', 1),
            fun.getColumnTimeItem('首次付费订阅VIP时间', 'vipCreatedAt', 1),
        ];
        return <Table columns={columns} dataSource={[record]} bordered style={{ textAlign: 'center' }} rowKey={dataSource => dataSource.id} pagination={false} />;
    };
    // 关闭弹框
    close = () => {
        this.setState({
            loading: false,
            showGiveRightModal: false,//赠送权益弹框
            showGiveRightID: '',//弹框用户ID
            showGiveRightEmail: '',//弹框用户邮箱
            // showVIPDay: '',//弹框赠送会员天数
            showQATimes: '',//弹框QA次数
            //批量赠送权益弹框
            showBulkGiveRightModal: false,//批量赠送权益弹框
            fileList: [],
            //用户群弹框
            showUserGroup: false,//用户群弹框
            userGroupList: [],//用户群列表
            //保存用户群弹框
            showSaveUserGroup: false,//保存用户群弹框
            saveUserGroupName: '',//用户群名称
            //推送通知弹框
            showPushNotification: false,//推送通知弹框
            currentStep: 0,//当前步骤
            // 第一步，设置推送目标
            pushMode: '查询结果',//现在上传文件还是查询结果,
            pushModeId: 0,
            pushFileList: [],//推送文件
            uploadAlready: false,//已经上传成功
            taskId: '',//上传成功返回的taskId
            userCount: 0,//上传成功返回的userCount
            // 第二步，设置推送内容
            notificationTitle: '',//推送通知标题
            notificationContent: '',//推送通知内容
            notificationLinkTitle: null,//推送通知跳转链接
            notificationLinkTitleJumpSchema: null,//推送通知跳转链接JumpSchema
            notificationLinkKey: '',//推送通知跳转链接ID,
            jumpLinkList: [],//推送通知跳转链接的下拉列表,
            prepareCourseList: [],//推送通知跳转链接选择备考课时的下拉列表,
            showPrepareCourseList: false,//是否展示备考课时的下拉列表,
            prepareCourse: null,//所选备考课
            prepareCourseId: null,//所选备考课ID
            subjectList: [],//推送通知跳转链接选择知识点详情时的下拉列表,
            showSubjectList: false,//是否展示知识点详情时的下拉列表,
            subject: null,//所选学科
            subjectId: null,//所选学科ID
            h5Link: null,
            // 第三步，测试推送 
            pushTestEmail: '',
            testAlready: false,//已经测试成功
        });
    }
    render() {
        let selectUserGroupDisabled = this.state.userGroupList.every((item) => !item.show)
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    {/* 查询项 */}
                    <div className={Style.topWrap}>
                        <div className={Style.leftWrap}>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>用户ID:</span>
                                <InputNumber placeholder='输入用户ID查询' className={Style.input} maxLength='11' onChange={(value) => { this.changeInputNumber(value, 'id') }} />
                            </div>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>邮箱:</span>
                                <Input placeholder='输入用户邮箱查询' className={Style.input} onChange={(e) => { this.changeInput(e, 'email') }} maxLength='50' />
                            </div>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>昵称:</span>
                                <Input placeholder='输入用户昵称查询' className={Style.input} onChange={(e) => { this.changeInput(e, 'nickname') }} maxLength='50' />
                            </div>
                            <div className={Style.boxInputTypeWrap}>
                                <div className={Style.boxInputType}>
                                    <span className={Style.span}>APP版本:</span>
                                    <Select placeholder='全部' ref='appVersion' mode='multiple' className={Style.input} onChange={this.getAppVersion} optionLabelProp="label" showSearch={true} allowClear maxTagCount={0} value={this.state.selectAppVersionList} autoFocus={false}>
                                        {this.state.appVersionList.map((item) => {
                                            return (
                                                <Option key={item.id} value={item.lumistVersion}>{item.lumistVersion}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                <div className={Style.boxInputType}>
                                    <span className={Style.span}>OS类型:</span>
                                    <Select placeholder='全部' ref='OSType' className={Style.input} onChange={this.getOS} optionFilterProp="label" allowClear>
                                        <Option key={1} value='iOS'>iOS</Option>
                                        <Option key={2} value='Android '>Android </Option>
                                    </Select>
                                </div>
                            </div>
                        </div>
                        <Button type='primary' className={Style.searchButton} onClick={this.userGroup} >用户群</Button>
                    </div>
                    <div className={Style.topWrap}>
                        <div className={Style.leftWrap}>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>手机:</span>
                                <InputNumber placeholder='输入用户手机查询' value={this.state.phoneNumber} className={Style.input} onChange={(value) => { this.changeInputNumber(value, 'phoneNumber') }} maxLength='20' />
                            </div>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>学校:</span>
                                <Select placeholder='全部' ref='school' className={Style.input} value={this.state.schooltName} onChange={this.getSchool} optionLabelProp="label" showSearch={true} allowClear>
                                    {this.state.schoolList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.name}>{item.name}</Option>
                                        )
                                    })}
                                </Select>
                            </div>
                            <div className={Style.boxInput}>
                                <span className={Style.span}>会员:</span>
                                <Select placeholder='全部' ref='vipStatus' className={Style.input} onChange={this.getVip} optionFilterProp="label" allowClear>
                                    <Option key={1} value='是'>是</Option>
                                    <Option key={0} value='否'>否</Option>
                                </Select>
                            </div>
                            <div className={Style.boxInputTime}>
                                <span className={Style.span}>注册时间:</span>
                                <RangePicker className={Style.input} ref='registerTime'defaultValue={[moment(),moment()]} onCalendarChange={this.getRegisterTime} />
                            </div>
                        </div>
                        <Button type='primary' className={Style.searchButton} onClick={this.search} >查询</Button>
                    </div>
                    {/* 条件查询项 */}
                    <div className={Style.userBehavior}>
                        <div className={Style.conditionGroupWrap}>
                            <Button type='link' onClick={this.addCondition} disabled={this.state.conditionGroup.length === 5}>   <PlusOutlined /></Button>
                            <div className={Style.conditionGroup}>
                                {
                                    this.state.conditionGroup.map((item, index) => {
                                        return (
                                            <div className={Style.conditionWrap} key={index}>
                                                <div className={Style.condition}>

                                                    <Select value={item.logicValue} ref={'logicValue' + index} className={Style.select} onChange={(value, option) => { this.getLogic(value, option, index) }} optionFilterProp="label" allowClear >
                                                        <Option key={2} value='或'>或</Option>
                                                        <Option key={1} value='且'>且</Option>
                                                    </Select>

                                                    <Select value={item.behaviorValue} ref={'behaviorValue' + index} className={Style.input} onChange={(value, option) => { this.getBehavior(value, option, index) }} optionFilterProp="label" allowClear>
                                                        <Option key={1} value='发起Q&A'>发起Q&A</Option>
                                                        <Option key={2} value='拍照搜题'>拍照搜题</Option>
                                                        <Option key={3} value='购买课程'>购买课程</Option>
                                                        <Option key={4} value='订阅VIP'>订阅VIP</Option>
                                                    </Select>

                                                    <Select value={item.computeValue} ref={'computeValue' + index} className={Style.select} onChange={(value, option) => { this.getCompute(value, option, index) }} optionFilterProp="label" allowClear>
                                                        <Option key={1} value='>'>&gt;</Option>
                                                        <Option key={2} value='<'>&lt;</Option>
                                                        <Option key={3} value='='>=</Option>
                                                    </Select>

                                                    <InputNumber value={item.count} className={Style.inputNumber} min='1' max='1000' onChange={(count) => { this.getCount(count, index) }} />次&emsp;

                                                    在<Select value={item.timeValue} ref={'timeValue' + index} className={Style.input} onChange={(value, option) => { this.getTimeType(value, option, index) }} optionFilterProp="label" allowClear>
                                                        <Option key={1} value='任意时间'>任意时间</Option>
                                                        <Option key={2} value='自定义'>自定义</Option>
                                                        <Option key={3} value='注册后'>注册后</Option>
                                                    </Select>

                                                    {Number(item.timeKey) === 3 ? <span><InputNumber className={Style.inputNumber} ref='timeDay' value={item.timeDay} min='1' max='90' onChange={(timeDay) => { this.getTimeDay(timeDay, index) }} />天内</span> : ''}

                                                    {Number(item.timeKey) === 2 ? <RangePicker className={Style.time}
                                                        value={[item.timeStart ? moment(item.timeStart, 'YYYY/MM/DD') : '', item.timeEnd ? moment(item.timeEnd, 'YYYY/MM/DD') : '']}
                                                        ref={'timeStart' + index} onCalendarChange={(date, dateString) => { this.getTimeRange(date, dateString, index) }} /> : ''}

                                                </div>
                                                <MinusOutlined className={Style.delete} onClick={() => { this.deleteCondition(index) }} />
                                            </div>
                                        );
                                    })
                                }
                            </div>
                        </div>
                        {this.state.conditionGroup.length === 0 ? '' : <Button type='primary' className={Style.addButton} onClick={() => { this.setState({ showSaveUserGroup: true }) }}>保存用户群</Button>}
                    </div>
                    <Divider />
                    {/* 按钮 */}
                    <div className={Style.buttonGroup}>
                        <Button type='primary' className={Style.addButton} onClick={() => { this.setState({ showBulkGiveRightModal: true }) }}>批量权益赠送</Button>
                        <Button type='primary' className={Style.addButton} onClick={this.pushNotification}>推送APP通知</Button>
                        <Button type='primary' className={Style.addButton} onClick={this.export}>导出查询结果</Button>
                    </div>
                    <Table
                        columns={this.columns()}
                        expandable={{ expandedRowRender: this.expandedRowRender }}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {/* 批量权益赠送弹框 */}
                    {this.state.showBulkGiveRightModal ? <Modal title='批量权益赠送' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.bulkGiveRightSubmit} disabled={this.state.fileList.length === 0}>确定</Button>]}>
                        <div className={Style.bulkGiveRightModal}>
                            <span><ExclamationCircleOutlined />&emsp;赠送Q&A次数应为0 – 30，一次批量操作最多5000条数据。批量赠送人数较多时处理时间较长，请耐心等待。</span>
                            <a className={Style.download} href='https://cdn.lumiclass.com/cms/qm/template/%E6%89%B9%E9%87%8F%E8%B5%A0%E9%80%81%E6%9D%83%E7%9B%8A%E6%A8%A1%E7%89%88.xlsx'><Button type='link'>模板下载</Button></a>
                            <div className={Style.wrap}>
                                <span>请选择Excel文件：</span>
                                <Upload
                                    beforeUpload={() => false}
                                    onChange={this.handleChange}
                                    fileList={this.state.fileList}
                                    accept='.xlsx'
                                >
                                    {this.state.fileList.length === 0 ? <Button type='primary' >选择文件</Button> : ''}
                                </Upload>
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 权益赠送弹框 */}
                    {this.state.showGiveRightModal ? <Modal title='权益赠送' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.giveRightSubmit}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>用户ID：</span>
                                <span className={Style.spanRight}>{this.state.showGiveRightID} </span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>Email：</span>
                                <span className={Style.spanRight}>{this.state.showGiveRightEmail}  </span>
                            </div>
                            {/* <div className={Style.rowWrap}>
                                <span className={Style.span}>赠送会员(天)：</span>
                                <InputNumber className={Style.input} placeholder='最多90天' min='0' max='90' value={this.state.showVIPDay} onChange={this.getShowVIPDay} />
                            </div> */}
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>赠送Q&A(次)：</span>
                                <InputNumber className={Style.input} placeholder='最多30次' min='0' max='30' value={this.state.showQATimes} onChange={this.getShowQATimes} />
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 选择用户群弹框 */}
                    {this.state.showUserGroup ? <Modal title='选择用户群' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.selectUserGroupConfirm} disabled={selectUserGroupDisabled}>确定</Button>]}>
                        <div className={Style.editModal}>
                            {this.state.userGroupList.map((item, index) => {
                                return (
                                    <span className={Style.SelectUserGroupWrap} key={index}>
                                        <div className={item.show ? Style.selectUserGroup : Style.unSelectUserGroup} onClick={() => { this.selectUserGroup(index) }}>{item.name}</div>
                                        <Popconfirm className={Style.popconfirm} placement="top" title="确认删除该用户群吗？" onConfirm={() => { this.delUserGroupConfirm(item) }} okText="确定" cancelText="取消">
                                            <Badge count={<CloseCircleOutlined />}></Badge>
                                        </Popconfirm>
                                    </span>
                                )
                            })}
                        </div>
                    </Modal> : ''}
                    {/* 保存用户群弹框 */}
                    {this.state.showSaveUserGroup ? <Modal title='保存用户群' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.saveUserGroupNameSubmit} disabled={this.state.saveUserGroupName.length === 0}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>用户群名称：</span>
                                <Input className={Style.input} placeholder='请输入用户群名称' value={this.state.saveUserGroupName} onChange={this.getSaveUserGroupName} maxLength='100' />
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 推送通知弹框 */}
                    {this.state.showPushNotification ?
                        <Modal
                            title='推送APP通知'
                            close={this.close}
                            actions={[
                                <Button onClick={this.close}>{(Number(this.state.currentStep) === 0 && Number(this.state.pushModeId) === 0) ? '' : this.state.currentStep !== 1 ? '取消' : ''}</Button>,
                                <Button
                                    type='primary'
                                    disabled={this.judgeDisabled()}
                                    onClick={this.state.currentStep === 0 ? this.pushGoalSubmit : this.state.currentStep === 1 ? this.pushContentSubmit : this.state.currentStep === 2 ? this.pushTestSubmit : this.state.currentStep === 3 ? this.pushFormalSubmit : this.pushGoalSubmit}
                                >
                                    {this.judgeSubmitText()}
                                </Button>
                            ]}
                        >
                            <div className={Style.notification}>
                                <div className={Style.rowWrap}>
                                    <Steps current={this.state.currentStep} onChange={this.changeSteps}>
                                        {this.steps.map((item, index) => (
                                            <Step key={item.title} title={item.title} status={this.judgeStatus(index)} />
                                        ))}
                                    </Steps>
                                    <div className="steps-content">{this.judgePushContent()}</div>
                                </div>
                            </div>
                        </Modal> : ''}
                </Spin>
            </Fragment >
        )
    }
}

export default CustomerManage;