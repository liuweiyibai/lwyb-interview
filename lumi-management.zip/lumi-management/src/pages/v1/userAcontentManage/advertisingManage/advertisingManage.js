import React, { Component, Fragment } from 'react';
import { Spin, Input, Button, Divider, Table, message, Badge, DatePicker, Pagination, Select } from 'antd';
import { LoadingOutlined, PlusOutlined, CloseCircleOutlined, EditOutlined } from '@ant-design/icons';
import Viewer from 'viewerjs';
import 'viewerjs/dist/viewer.css';
import api from '../../../../utils/api'
import Modal from '../../../../components/modalOfTree/modalOfTree'
import Style from './advertisingManage.module.less'
import moment from 'moment';
import fun from '../../../../utils/funSum.js';

const { TextArea } = Input;
const { RangePicker } = DatePicker;
const { Option } = Select;

class AdvertisingManage extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showModal: false,//展示弹框
            id: null,//广告ID
            prepareCourseId: null,//备考课ID
            prepareCourseTitle: '',//备考课名字
            jumpUrl: '',//跳转链接
            imgUrlKey: '',//广告URL的key，用于确定时
            imgUrl: '',//广告URL，用于展示图片/上传图片
            showStartTime: null,//展示时段的开始时间
            showEndTime: null,//展示时段的结束时间
            prepareCourseList: [],//备考课下拉列表
            dataSource: [],//数据资源
            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 0,//总条数
        }
    }
    columns = [
        fun.getColumnItem('广告ID', 'id', '80px'),
        {
            title: '广告图片',
            align: 'center',
            width: '100px',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return (
                    <img className={Style.zmage} id={'advertisePic' + record.id} key={record.imgUrl} src={record.cloudFrondUrl + '/' + record.imgUrl} alt='广告图片'></img>
                )
            }
        },
        fun.getColumnItem('跳转备考课ID', 'redirectId', '80px'),
        fun.getColumnItem('跳转链接', 'redirectUrl', '80px'),
        {
            title: '展示时段（美东时间）',
            align: 'center',
            width: '180px',
            render: record => {
                let startAt = record.startAt ? moment(record.startAt).format('YYYY/MM/DD HH:mm:ss') : '';
                let endAt = record.endAt ? moment(record.endAt).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <div>
                        {startAt}<Divider /> {endAt}
                    </div>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: '80px',
            ellipsis: {
                showTitle: false,
            },
            render: (record) => {
                return (
                    <div>
                        <Button icon={<EditOutlined />} className={Style.addButton} type='primary' onClick={() => { this.editAdvertising(record) }} >编辑广告</Button>
                    </div>
                )
            }
        },
    ]
    componentDidMount() {
        this.getAdvertisingList({
            iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize
        });
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    //获取广告列表
    getAdvertisingList = (params) => {
        this.setState({ loading: true }, () => {
            api.getAdvertisingList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, total: data.result.total, loading: false }, () => {
                            this.state.dataSource.forEach((item) => {
                                if (document.getElementById('advertisePic' + item.id)) {
                                    new Viewer(document.getElementById('advertisePic' + item.id), {});
                                }
                            })
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取备考课下拉列表
    getPrepareCourseList = (params) => {
        this.setState({ loading: true }, () => {
            api.getPrepareCourseList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ prepareCourseList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //新增广告
    addAdvertising = () => {
        this.getPrepareCourseList();
        this.setState({
            loading: false,
            id: '',
            imgUrl: '',
            imgUrlKey: '',
            prepareCourseId: null,
            prepareCourseTitle: '',
            jumpUrl: '',
            showStartTime: null,
            showEndTime: null,
            showModal: true
        });
    }
    //编辑广告
    editAdvertising = (record) => {
        this.getPrepareCourseList();
        let startAt = record.startAt ? moment(record.startAt).format('YYYY-MM-DD HH:mm:ss') : '';
        let endAt = record.endAt ? moment(record.endAt).format('YYYY-MM-DD HH:mm:ss') : '';
        this.setState({ showModal: true, imgUrlKey: record.imgUrl, imgUrl: record.cloudFrondUrl + '/' + record.imgUrl, id: record.id, prepareCourseId: record.redirectId, jumpUrl: record.redirectUrl, showStartTime: startAt, showEndTime: endAt }, () => {
            if (document.getElementById('advertiseModalPic' + this.state.imgUrl)) {
                new Viewer(document.getElementById('advertiseModalPic' + this.state.imgUrl), {});
            }
        });
    }
    //改变广告备考课ID
    changePrepareCourse = (value, option) => {
        if (value && option) {
            this.setState({ prepareCourseTitle: option.value, prepareCourseId: option.key, jumpUrl: 'lumi://prep?id=' + option.key });
        } else {
            this.setState({ prepareCourseTitle: '', prepareCourseId: null, jumpUrl: '' });
        }
    }
    //改变广告跳转链接
    changeJumpUrl = (e) => {
        this.setState({ jumpUrl: e.target.value });
    }
    //改变展示时段
    changeShowTime = (date, dateString) => {
        if (date && dateString) {
            let startAt = date[0] ? moment(date[0]).format('YYYY-MM-DD HH:mm:ss') : '';
            let endAt = date[1] ? moment(date[1]).format('YYYY-MM-DD HH:mm:ss') : '';
            this.setState({ showStartTime: startAt, showEndTime: endAt });
        }
        else {
            this.setState({ showStartTime: null, showEndTime: null });
        }
    }
    //点击图片
    imgUploadClick = () => {
        this.refs.inputUpload.click();
    };
    //upload图片
    upload = (e) => {
        e.persist();
        this.setState({ loading: true }, () => {
            let url = window.URL || window.webkitURL;
            let img = new Image();//手动创建一个Image对象
            img.src = url.createObjectURL(e.target.files[0]);//创建Image的对象的url
            img.onload = () => {
                if (img.height !== 360 || img.width !== 1308) {
                    message.error('图片尺寸不符合要求，请重新选择');
                    this.setState({ loading: false });
                    return;
                }
                api.getUploadPicUrl()
                    .then((data) => {
                        if (data.ret === 20000) {
                            fun.removeExif(e.target.files[0])
                            .then((res)=>{
                                // api.uploadAWS(data.result.url, e.target.files[0])
                                api.uploadAWS(data.result.url, res)
                                    .then((res1) => {
                                        this.setState({ imgUrlKey: data.result.key, imgUrl: (data.result.cmsCloudfront + '/' + data.result.key), loading: false }, () => {
                                            if (document.getElementById('advertiseModalPic' + this.state.imgUrl)) {
                                                new Viewer(document.getElementById('advertiseModalPic' + this.state.imgUrl), {});
                                            }
                                        });
                                    })
                                    .catch((err) => {
                                        message.error(err);
                                        this.setState({ loading: false });
                                    })
                            })
                        } else {
                            return Promise.reject(data);
                        }
                    })
                    .catch((err) => {
                        message.error(err);
                        this.setState({ loading: false });
                    })
            }
        })
    }
    //删除图片
    deleteImg = () => {
        this.setState({ imgUrl: null });
    }
    //分页器
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getAdvertisingList({
                iDisplayLength: this.state.pageSize,
                iDisplayStart: this.state.page - 1,
            })
        });
    }
    //关闭弹框
    close = () => {
        this.setState({
            showModal: false,
        });
    }
    //广告配置
    advertisingConfig = (params) => {
        this.setState({ loading: true }, () => {
            api.advertisingConfig(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.setState({ showModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //保存提交
    submit = () => {
        this.advertisingConfig({
            id: this.state.id,
            imgUrl: this.state.imgUrlKey,
            redirectId: this.state.prepareCourseId,
            redirectType: 1,
            redirectUrl: this.state.jumpUrl,
            endAt: this.state.showEndTime,
            startAt: this.state.showStartTime,
        });

    }
    render() {
        let disabled = !(Boolean(this.state.imgUrl) && Boolean(this.state.showStartTime) && Boolean(this.state.showEndTime));
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>
                        <Button icon={<PlusOutlined />} className={Style.addButton} type='primary' onClick={this.addAdvertising} >新增广告</Button>
                        <span className={Style.remark}> 为保留广告历史，广告不可删除。若同时配置备考课和链接，则优先跳转备考课</span>
                    </div>
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {this.state.showModal ? <Modal title='新增/编辑广告' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.submit} disabled={disabled}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}>
                                <span className={Style.span}>广告素材<span className={Style.red}>*</span>：</span>
                                {this.state.imgUrl ?
                                    <span >
                                        <Badge count={<CloseCircleOutlined onClick={this.deleteImg} />}>
                                            <img className={Style.image} id={'advertiseModalPic' + this.state.imgUrl} src={this.state.imgUrl} alt='广告素材'></img>
                                        </Badge>
                                    </span>
                                    : <span>
                                        <Button onClick={this.imgUploadClick}>{this.state.loading ? <LoadingOutlined /> : <PlusOutlined />} Click to Upload</Button>
                                        <input type="file" accept="image/*"
                                            name="uploader-input"
                                            ref='inputUpload' style={{ display: 'none' }} onChange={this.upload}></input>
                                        <span className={Style.spanLeft}>图片尺寸应为1308×360</span>
                                    </span>
                                }
                            </div>

                            <div className={Style.rowWrap}>
                                <span className={Style.span}>广告备考课：</span>
                                <Select placeholder='全部' className={Style.select} value={this.state.prepareCourseId} onChange={this.changePrepareCourse} optionLabelProp="label" showSearch={true} allowClear>
                                    {this.state.prepareCourseList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.id}>{item.id + '_' + item.title}</Option>
                                        )
                                    })}
                                </Select>
                            </div>

                            <div className={Style.rowWrap}>
                                <span className={Style.span}>广告跳转链接：</span>
                                <TextArea className={Style.input} placeholder='请填写以http或https开头的URL链接' maxLength='500' value={this.state.jumpUrl} onChange={this.changeJumpUrl} /><br />
                                <span className={Style.spanRight}>已输入{this.state.jumpUrl.length}/500字</span>
                            </div>
                            <div className={Style.rowWrap}>
                                <span className={Style.spanTime}>
                                    <span className={Style.spanBox}> 展示时段</span>
                                    <span className={Style.spanBox}> （美东时间）<span className={Style.red}>*</span>：</span>
                                </span>
                                <RangePicker onChange={this.changeShowTime} showTime
                                    defaultValue={
                                        this.state.showStartTime ? [moment(this.state.showStartTime, 'YYYY-MM-DD HH:mm:ss'), moment(this.state.showEndTime, 'YYYY-MM-DD HH:mm:ss')] : null
                                    }
                                />
                            </div>
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default AdvertisingManage;