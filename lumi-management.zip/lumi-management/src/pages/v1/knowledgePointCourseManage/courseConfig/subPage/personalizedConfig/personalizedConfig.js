import React, { Fragment } from "react";
import { Divider, Input, Select, Button, Table, Pagination, Checkbox, message, Spin, Tooltip } from "antd";
import { LoadingOutlined, SearchOutlined, EditOutlined } from "@ant-design/icons";
import Style from "./personalizedConfig.module.less";
import Modal from "../../../../../../components/modalOfTree/modalOfTree.js";
import api from "../../../../../../utils/api";
import fun from '../../../../../../utils/funSum.js';

const { Option } = Select;

class KnowledgeCoursePersonaliseSet extends React.Component {
    constructor() {
        super();
        this.state = {
            dataSource: [],
            loading: false,
            curSubId: "", // 当前课程的Id
            curSubName: "", // 当前课程的name
            classNumConfType: "-1", // 全部-1  已经1 未 0
            schoolName: "", // 学校名称
            total: 0, // 主页面上的
            page: 1,
            pageSize: 10,
            totalToVideo: 0, // 视频弹框中的
            pageToVideo: 1,
            pageSizeToVideo: 5,
            videoUrl: "",
            showVideo: false, // 视频播放弹框
            currentEditItem: {}, // 当前编辑的行的数据
            showEditClassNum: false, // 编辑课号弹框tag
            showEditVideo: false, // 编辑简介视频弹框tag
            inputValueClassNum: "", // 编辑课号输入的内容
            inputVideoId: "", // 输入的视频的Id
            inputVideoName: "", // 输入的视频的名称
            editVideoTableData: [],
            currentCheckedVideoId: -1,
        };
    }
    columns = [
        fun.getColumnItem("学校名称","schoolName"),
        fun.getColumnItem("个性化课号","schoolSubjectName"),
        {
            title: "个性化课程简介视频",
            dataIndex: "videoName",
            align: "center",
            width: '300px',
            ellipsis: {
                showTitle: false,
            },
            render: (text, record) => (
                <Tooltip placement="top" title={record.videoName}>
                    <span className={Style.buttonSpan} onClick={() => this.showVideoBox(record)}>{record.videoName}</span>
                </Tooltip>
            ),
        },
        {
            title: "操作",
            align: "center",
            width: '300px',
            ellipsis: {
                showTitle: false,
            },
            render: (record) => (
                <div >
                    <Button icon={<EditOutlined />} type="primary" className={Style.button} onClick={() => this.clickEditClassNumBtn(record)}>编辑课号</Button>
                    <Button icon={<EditOutlined />} type="primary" onClick={() => this.clickEditVideoBtn(record)}>编辑视频</Button>
                </div>
            ),
        },
    ]
    editVideoColumns = [
        {
            title: "视频ID",
            dataIndex: "id",
            align: "center",
            ellipsis: {
                showTitle: false,
            },
            render: id => (
                <Tooltip placement="top" title={id}>
                    {id}
                </Tooltip>
            ),
        },
        {
            title: "视频名称",
            dataIndex: "name",
            align: "center",
            ellipsis: {
                showTitle: false,
            },
            render: name => (
                <Tooltip placement="top" title={name}>
                    {name}
                </Tooltip>
            ),
        },
        {
            title: "单选框",
            dataIndex: "vedioselect",
            align: "center",
            render: (text, record) => (
                <Checkbox
                    checked={this.state.currentCheckedVideoId === -1 ? false : this.state.currentCheckedVideoId === record.id ? true : false}
                    onChange={() => { this.setState({ currentCheckedVideoId: record.id, }); }}
                ></Checkbox>
            ),
        },
    ]
    componentDidMount() {
        const id = this.props.location.search.split('=')[1].split('&')[0];
        const name = this.props.location.search.split('=')[2];
        this.setState({ curSubId: id, curSubName: name, }, () => {
            this.getPersonaliseList({ cid: this.state.curSubId, idisplayStart: 0, idisplayLength: this.state.pageSize, type: this.state.classNumConfType, schoolName: this.state.schoolName, });
        });
        fun.addKeyboardListener(this.confSearch);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    // 下拉菜单
    changeSelectMenu = (v) => {
        this.refs.selectMenu.blur()
        this.setState({ classNumConfType: v });
    };
    //获得个性化课号和课程简介视频
    getPersonaliseList = (params) => {
        this.setState({ loading: true }, () => {
            api.getPersonalizedList(params)
            .then((data) => {
                if (data.ret === 20000) {
                    const result = data.result;
                    this.setState({ loading: false, page: result.start + 1, total: result.total, dataSource: result.data });
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            });
        });

    }
    // 查询按钮
    confSearch = () => {
        this.getPersonaliseList({
            cid: this.state.curSubId,
            idisplayStart: 0,
            idisplayLength: this.state.pageSize,
            schoolName: this.state.schoolName,
            type: this.state.classNumConfType,
        });
    };
    // 切换分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize, loading: true }, () => {
            this.getPersonaliseList({
                cid: this.state.curSubId,
                idisplayStart: this.state.page - 1,
                idisplayLength: this.state.pageSize,
                schoolName: this.state.schoolName,
                type: this.state.classNumConfType,
            })
        });
    };
    // 视频列表切换分页
    videoPaginationChange = (page, pageSize) => {
        this.setState({ pageToVideo: page, pageSizeToVideo: pageSize }, () => {
            this.getVideoList({
                iDisplayStart: this.state.pageToVideo - 1,
                iDisplayLength: this.state.pageSizeToVideo,
                id: this.state.inputVideoId,
                videoName: this.state.inputVideoName,
                videoType: 0,
            });
        });
    };
    //关闭视频播放
    close = () => {
        if (this.state.showVideo) {
            let videoDom = document.getElementById("video");
            videoDom.pause();
        }
        this.setState({
            showVideo: false, showEditClassNum: false, showEditVideo: false,
            inputVideoId: "",
            inputVideoName: "",
            currentCheckedVideoId: -1,
        });
    };
    // 点击视频名字播放视频
    showVideoBox = (record) => {
        this.setState({ videoUrl: record.videoUrl, showVideo: true, });
    };
    //获取知识点视频列表
    getVideoList = (params) => {
        this.setState({ loading: true }, () => {
            api.getVideoList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({
                            editVideoTableData: data.result.data,
                            totalToVideo: data.result.total,
                            pageToVideo: data.result.start + 1,
                            loading: false,
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                });
        });
    };
    // 点击编辑课号按钮
    clickEditClassNumBtn = (record) => {
        this.setState({ showEditClassNum: true, currentEditItem: record });
    };
    //编辑课号/视频提交 api封装
    editClassnumAVideo = (params) => {
        this.setState({ loading: true }, () => {
            api.editClassnumAVideo(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                });
        })
    }
    // 编辑课号确定提交
    editClassNumSubmitBtn = () => {
        this.editClassnumAVideo({ id: this.state.currentEditItem.id, schoolId:this.state.currentEditItem.schoolId, schoolSubjectName: this.state.inputValueClassNum, cid:this.state.curSubId, vid: null });
    };
    //获取 input个性化课号
    getPersonalise = (e) => {
        this.setState({ inputValueClassNum: e.target.value, });
    }
    // 点击编辑视频按钮
    clickEditVideoBtn = (record) => {
        this.setState({ showEditVideo: true, currentEditItem: record });
        this.searchVideoCourseBtn();
    };
    // 获取视频ID
    getVideoID = (e) => {
        this.setState({ inputVideoId: e.target.value, });
    }
    // 获取视频名称
    getVideoName = (e) => {
        this.setState({ inputVideoName: e.target.value, });
    }
    // 查询视频课程按钮
    searchVideoCourseBtn = () => {
        this.getVideoList({
            iDisplayStart: 0,
            iDisplayLength: this.state.pageSizeToVideo,
            id: this.state.inputVideoId,
            videoName: this.state.inputVideoName,
            videoType: 0,
        });
    };
    // 编辑视频简介确定提交
    editVideoSubmitBtn = () => {
        this.editClassnumAVideo({ id: this.state.currentEditItem.id, schoolId:this.state.currentEditItem.schoolId, schoolSubjectName: null, cid:this.state.curSubId, vid: this.state.currentCheckedVideoId });
    };

    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip="请稍候..." size="large" >
                    <h2 className={Style.headLine}>为{decodeURI(this.state.curSubName)}配置和学校相关的个性化课号和课程简介视频</h2>
                    <Divider />
                    <div className={Style.searchLine}>
                        <span>学校名称：</span>
                        <Input placeholder='请输入学校名称' allowClear className={Style.input} maxLength={50} onChange={(e) => this.setState({ schoolName: e.target.value })} />
                        <span>课号配置：</span>
                        <Select ref='selectMenu' className={Style.input} defaultValue={this.state.classNumConfType} onChange={(value) => this.changeSelectMenu(value)}>
                            <Option value="-1">全部</Option>
                            <Option value="1">已配置</Option>
                            <Option value="0">未配置</Option>
                        </Select>
                        <Button type="primary" icon={<SearchOutlined />} onClick={this.confSearch} >查询</Button>
                    </div>
                    <Divider />
                    <Table
                        columns={this.columns}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.schoolId}
                        bordered
                        pagination={false}
                    />
                    <Pagination className={Style.pagination} showQuickJumper total={this.state.total} current={this.state.page} pageSize={this.state.pageSize} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} />
                    {/* 视频播放弹框 */}
                    {this.state.showVideo ? (<Modal title="视频播放" close={this.close}>
                        <video id="video" src={this.state.videoUrl} width="700" autoPlay="autoplay" controls="controls"></video>
                    </Modal>
                    ) : ''}
                    {/* 编辑课号弹框 */}
                    {this.state.showEditClassNum ? (<Modal title="编辑课号" close={this.close} actions={[<Button className={Style.button} onClick={this.close}>取消</Button>, <Button type="primary" className={Style.button} onClick={this.editClassNumSubmitBtn}>确定</Button>]}>
                        <div className={Style.editClassName}>
                            <span>个性化课号：</span>
                            <Input placeholder='请输入个性化课号' allowClear className={Style.input} defaultValue={this.state.currentEditItem.schoolSubjectName} onChange={this.getPersonalise} maxLength={20} />
                        </div>
                    </Modal>
                    ) : ''}
                    {/* 编辑视频弹框 */}
                    {this.state.showEditVideo ? (<Modal title="编辑知识点课程简介视频" close={this.close} actions={[<Button className={Style.button} onClick={this.close}>取消</Button>,
                    <Button className={Style.button} disabled={this.state.currentCheckedVideoId === -1 ? true : false} type="primary" onClick={this.editVideoSubmitBtn}>确定</Button>]}>
                        <div className={Style.editVideo}>
                            <span>视频ID：</span>
                            <Input placeholder='请输入视频ID' allowClear onChange={this.getVideoID} className={Style.input} maxLength={20} />
                            <span>视频名称：</span>
                            <Input placeholder='请输入视频名称' allowClear onChange={this.getVideoName} className={Style.input} maxLength={20} />
                            <Button icon={<SearchOutlined />} type="primary" onClick={this.searchVideoCourseBtn}>查询</Button>
                        </div>
                        <Divider />
                        <Table
                            columns={this.editVideoColumns}
                            dataSource={this.state.editVideoTableData}
                            rowKey={editVideoTableData => editVideoTableData.id}
                            bordered
                            pagination={false}
                        />
                        <Pagination className={Style.pagination} showQuickJumper hideOnSinglePage total={this.state.totalToVideo} current={this.state.pageToVideo} pageSize={this.state.pageSizeToVideo} onChange={this.videoPaginationChange} showTotal={total => `Total ${total} items`}
                        />
                    </Modal>
                    ) : ''}
                </Spin>
            </Fragment>
        );
    }
}
export default KnowledgeCoursePersonaliseSet;
