import React, { Component, Fragment } from 'react';
import { Select, Divider, Button, Table, message, Input, Spin, Badge, InputNumber, Pagination, Tooltip, Popconfirm } from 'antd';
import { EditOutlined, PlusOutlined, LoadingOutlined, CloseCircleOutlined, DeleteOutlined, MenuOutlined, SettingOutlined, SwapOutlined, SearchOutlined } from '@ant-design/icons';
import Style from './contentConfig.module.less';
import Modal from '../.././../../../../components/modalOfTree/modalOfTree.js';
import api from '../../../../../../utils/api';
import Sortable from 'sortablejs';

import { connect } from 'react-redux';
import actionCreator from '../../../../../../store/actionCeator';

import { sortableContainer, sortableElement, sortableHandle } from 'react-sortable-hoc';
import arrayMove from 'array-move';

const DragHandle = sortableHandle(() => (
    <MenuOutlined style={{ cursor: 'pointer', color: '#999' }} />
));
const SortableItem = sortableElement(props => <tr {...props} />);
const SortableContainer = sortableContainer(props => <tbody {...props} />);
const { Option } = Select;
const { Search,TextArea } = Input;

class ContentConfiguration extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            courseId:'',//课程id
            chapterList: [],//chapter列表
            leftTitle:'',//左 chapter title
            showAddChapter:false,//点击新增chapter
            chapterTitle:null,//新增chapter input输入的value
            // chapterInputLength:40,//新增chapter input默认可输入长度
            showAddLesson:false,//点击新增lesson
            lessonTitle:'',//新增lesson input输入的value
            // lessonInputLength:40,//新增lesson input默认可输入长度
            lessonID:'',//点击配置视频时 获取当前行id
            showConfigVideoModal:false,//显示添加/替换 视频弹框
            videoSubjectList:[],//配置视频 学科下拉
            configVideoTotal:0,//配置视频列表 总页数
            configVideoPage:1,//配置视频列表 当前页
            configVideoPageSize:5,//配置视频列表 每页显示条数
            configVideoId:'',//配置视频 视频id
            configVideoName:null,//配置视频 视频名称
            configVideoSubId:'',//配置视频 学科id
            configVideoSubName:null,//配置视频 学科名称
            titleError:false,//添加chapter、lesson title时超出长度显示提示

            topicConfigurationModal: false,//题目配置弹框
            showVideo: false,//是否显示播放弹层
            showAdd: true,//是否展示新增按钮
            addButtonDisabled: false,
            inputTopicID: '',//新增课后题value input
            subjectList: [],//学科列表
            selectSubject: '1',//选择学科 select
            selectName: '',//选择学科名字
            activeKey: '',//所选中的tab
            //table列表
            dataSource: [],//table列表数据
            rowInfo: {},//点击行数据
            //知识点视频课后题弹框
            searchPage: 1,//页数
            searchPageSize: 5,//每页显示条数
            searchTotal: 0,//总条数
            //题目信息
            tid: '',//题目id
        }
    }
    columns = [
        {
            title: 'Sort',
            width: 70,
            align: 'center',
            className: 'drag-visible',
            render: (record) => <DragHandle onClick={() => { this.getSortRowId(record) }} />,
        },
        {
            title: 'Lesson名称',
            // dataIndex: 'title',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return (
                    record.editTitle ? <Input value={record.title} autoFocus='autoFocus' onBlur={()=>{this.lessonAdd({cpId:this.state.activeKey,id:record.id,title:record.title})}} onChange={(e)=>{this.changeLessonTitle(record,e)}}></Input> : <Tooltip placement="top" title={record.title}>
                        {record.title}
                    </Tooltip>
                )
            },
        },
        {
            title: '视频',
            align: 'center',
            render: record => {
                return (
                    record.videoUrl ? <Tooltip placement="top" title={record.videoName}>
                        <div className={Style.videoTH}>
                            <Button className={Style.button} type='primary' size='small' icon={<SwapOutlined />} onClick={()=>{this.configVideoModal(record)}}></Button>
                            <div className={Style.videoNameButton} type='link' onClick={() => { this.videoPreview(record) }}>{record.videoName}</div>
                        </div>
                    </Tooltip> : <Button icon={<PlusOutlined />} onClick={()=>{this.configVideoModal(record)}}></Button>
                )
            },
        },
        {
            title: '课后题',
            align: 'center',
            render: (record) => {
                return (
                    <Tooltip placement="top" >
                        {record.qidList ? record.qidList.map((item, index) => {
                            return (
                                <Button type='link' key={index} onClick={() => { window.open(api.pageURL + `/admin/v1/questionBankManage/preview?id=${item}`); }}>{item ? item : ''}</Button>
                            )
                        }) : ''}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width:350,
            render: (record) => {
                return (
                    <div>
                        <Button type='primary' icon={<SettingOutlined />} disabled={record.videoName ? false : true} onClick={() => { this.topicConfiguration(record) }}>课后题配置</Button>
                        <Button type='primary' className={Style.btn} icon={<EditOutlined />} onClick={()=>{this.editLessonTitle(record)}}>编辑</Button>
                        <Popconfirm placement="top" title="确认删除该Lesson吗？" onConfirm={()=>{this.deleteLesson(record.id)}} okText="确定" cancelText="取消">
                            <Button type='primary' icon={<DeleteOutlined />}>删除</Button>
                        </Popconfirm>
                    </div>
                )
            }
        },
    ]
    configVideoColumns = [
        {
            title: '视频ID',
            dataIndex: 'id',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: id => (
                <Tooltip placement="top" title={id}>
                    {id}
                </Tooltip>
            ),
        },
        {
            title: '视频名称',
            dataIndex: 'videoName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: videoName => (
                <Tooltip placement="top" title={videoName}>
                    {videoName}
                </Tooltip>
            ),
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            ),
        },
        {
            title: '操作项',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: (record) => (
                <Button type='primary' icon={<PlusOutlined />} onClick={()=>{this.configVideo(record)}}>加入课程</Button>
            ),
        }
    ]
    topicColumns = [
        {
            title: '题目ID',
            dataIndex: 'id',
            align: 'center',
        },
        {
            title: '题干内容',
            dataIndex: 'content',
            align: 'center',
            width: '500px',
            ellipsis: {
                showTitle: false,
            },
            render: content => (
                <Tooltip placement="top" title={content}>
                    {content}
                </Tooltip>
            ),
        },
        {
            title: '操作',
            align: 'center',
            render: (record) => {
                return (
                    <Button disabled={this.state.addButtonDisabled} onClick={() => { this.tableAdd(record) }}>添加到课后题</Button>
                )
            }
        }
    ]
    componentDidMount() {
        new Sortable(this.refs.leftWrap, {
            // new Sortable(document.getElementsByClassName('ant-tabs-nav-list')[0], {
            swapThreshold: 1,//交换区阈值
            animation: 150,//排序动画时间
            ghostClass: 'blue-background-class',
            onEnd: (evt) => {
                // this.chapterSort({ id:evt.item.getAttribute('data-id'),fromIndex:evt.item.getAttribute('data-sortnum'),toIndex:evt.item.nextSibling ? Number(evt.item.nextSibling.getAttribute('data-sortnum')) !== 0 ? Number(evt.item.nextSibling.getAttribute('data-sortnum'))-1 : 0 : evt.item.previousSibling.getAttribute('data-sortnum') });
                // this.initDom(evt,this.refs.leftWrap);
                // console.log(evt.item,evt.item.previousSibling,evt.item.nextSibling)
                // console.log(evt.newIndex,evt.oldIndex)
                // console.log( evt.item.previousSibling,evt.item.previousSibling ? (evt.item.nextSibling ? Number(evt.item.previousSibling.getAttribute('data-sortnum')+1):Number(evt.item.previousSibling.getAttribute('data-sortnum'))) : 0)
                // this.chapterSort({ fromIndex:evt.item.getAttribute('data-sortnum'), toIndex:evt.item.previousSibling ? (evt.item.nextSibling ? Number(evt.item.previousSibling.getAttribute('data-sortnum')+1) : Number(evt.item.previousSibling.getAttribute('data-sortnum'))) : 0, id:evt.item.getAttribute('data-id'), });
                this.chapterSort({ fromIndex:evt.oldIndex, toIndex:evt.newIndex, id:evt.item.getAttribute('data-id')});
                //解决插件移动后调用接口，数据顺序改变，dom顺序不改变问题
                // this.sort({ pre: evt.item.previousSibling !== null ? evt.item.previousSibling.getAttribute('data-sortnum') : 0, after: evt.item.nextSibling !== null ? evt.item.nextSibling.getAttribute('data-sortnum') : -1, id: evt.item.getAttribute('data-id'), pid: evt.item.getAttribute('data-pid') });
            },
        })
        this.getCourseList();
        this.setState({courseId:this.props.courseID,selectName:this.props.courseName},()=>{
            this.getChapterList();
        });
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    //获取 chapter 列表
    getChapterList=()=>{
        // this.setState({loading:true});
        api.getCourseChapterList(`/v1/learn/chapter/${this.state.courseId}`)
        .then((res)=>{
            // console.log(res)
            if(res.ret === 20000){
                let arr = res.result.map((item)=>{
                    item.checked = false;
                    return item;
                })
                // console.log(arr)
                this.setState({loading:false,chapterList:arr,activeKey:''})
            }else{
                return Promise.reject(res);
            }
        })
        .catch((err)=>{
            message.error(err.msg);
            this.setState({loading:false});
        })
    }
    //解决数据与dom元素顺序不同步bug
    initDom = (evt, box) => {
        let $tr = box.children[evt.newIndex];
        let $oldTr = box.children[evt.oldIndex];
        // 先删除移动的节点
        box.removeChild($tr);
        // 再插入移动的节点到原有节点，还原了移动的操作
        if (evt.newIndex > evt.oldIndex) {
            box.insertBefore($tr, $oldTr);
        } else {
            box.insertBefore($tr, $oldTr.nextSibling);
        }
    }
    //chapter拖拽排序 api
    chapterSort=(params)=>{
        this.setState({loading:true},()=>{
            api.chapterSort(params)
            .then((res)=>{
                if(res.ret === 20000){
                    // message.success(res.msg);
                    this.setState({loading:false});
                    // setTimeout(()=>{
                        // this.getChapterList();
                        // window.location.reload();
                    // },3000)
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    //获取学科下拉列表
    getCourseList = () => {
        this.setState({loading:true},()=>{
            api.getCourseConfigList()
            .then((res)=>{
                // console.log(res)
                if(res.ret === 20000){
                    this.setState({subjectList:res.result,loading: false})
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    //获取所选学科 select
    getSubject = (value, option) => {
        // console.log(value,option)
        let courseID = actionCreator.saveKnowledgeCourseID(option.key);
        this.props.dispatch(courseID);
        this.setState({ courseId: option.key, selectName: value, activeKey:'', loading: true }, () => {
            this.getChapterList();
            //获取一级知识点列表
            // api.getFirstKnowledge('/v1/graph/get/level/first/' + this.state.selectSubject)
            //     .then((data) => {
            //         if (data.ret === 20000) {
            //             this.setState({ firstKnowledgePointList: data.result, loading: false })
            //         } else {
            //             return Promise.reject(data);
            //         }
            //     })
            //     .catch((err) => {
            //         this.setState({ loading: false });
            //         message.error(err.msg);
            //     })
        });
    }
    //获取chapter对应lesson列表api 封装
    getLessonList = (activeKey)=>{
        this.setState({loading:true},()=>{
            api.getLessonList(`/v1/learn/unit/${activeKey}`)
                .then((data) => {
                    if (data.ret === 20000) {
                        let arr = data.result.map((item)=>{
                            item.editTitle = false;
                            return item
                        })
                        this.setState({ dataSource: arr,loading:false }, () => {
                            // if (!this.state.rowInfo) {
                            //     this.setState({ loading: false });
                            //     return;
                            // };
                            // let obj = this.state.dataSource.filter((item) => item.id === this.state.rowInfo.id)[0];
                            // let disabled = obj ? obj.tids.length >= 5 ? true : false : false;
                            // this.setState({ rowInfo: obj, loading: false, addButtonDisabled: disabled });
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //tab切换 获取一级知识点对应的信息
    tabChange = (activeKey) => {
        this.state.chapterList.map((item)=>{
            item.edit = false;
            if(item.id === activeKey){
                item.checked = true;
            }else{
                item.checked = false;
            }
            return item;
        })
        this.setState({ dataSource: [], activeKey, loading: true }, () => {
            this.getLessonList(activeKey);
        })
    }
    //编辑chapter
    editLeft=(item)=>{
        let arr = this.state.chapterList.map((el)=>{
            if(item.id === el.id){
                el.edit = true;
            }else{
                el.edit = false;
            }
            return el
        })
        this.setState({chapterList:arr,leftTitle:item.title});
        // console.log(this.state.chapterList)
    }
    //新增、编辑chapter api封装
    chapterSE=(params)=>{
        this.setState({loading:true},()=>{
            api.chapterSE(params)
            .then((res)=>{
                if(res.ret === 20000){
                    message.success(res.msg);
                    this.getChapterList();
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
        this.close();
    }
    //input 失焦触发
    blur=(item)=>{
        let arr = this.state.chapterList.map((el)=>{
            if(item.id === el.id){
                el.edit = false;
            }
            return el;
        })
        this.setState({chapterList:arr},()=>{
            this.chapterSE({cid:item.cid,id:item.id,title:this.state.leftTitle});
        });
    }
    //编辑 获取 chapter input
    changeLeftTitle=(e)=>{
        this.setState({leftTitle:e.target.value});
    }
    // 新增 获取 chapter input
    getChapterTitle=(e)=>{
        // let num = e.target.value.match(/[\r\n]/g) ? e.target.value.match(/[\r\n]/g).length + 40 : 40;
        let val = e.target.value.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/,'');
        this.setState({chapterTitle:val});
        // let event = e;
        // setTimeout(((e)=>{console.log('输入字符的长度：',e.target.value.length,'匹配到的换行符：',e.target.value.match(/[\r\n]/g),'可输入长度：',this.state.chapterInputLength)})(event),300)
    }
    //新增chapter 点击确定
    titleCheck=(params)=>{
        const arr = params.title.split(/[\r\n]/g);
        for(let i = 0;i < arr.length;i++){
            if(arr[i].length > 40){
                this.setState({titleError:true});
                return;
            }
        }
        if(params.case === 1){
            this.chapterSE(params);
        }else{
            this.lessonAdd(params); 
        }
    }
    //新增 获取 lesson input
    getLessonTitle=(e)=>{
        // let num = e.target.value.match(/[\r\n]/g) ? e.target.value.match(/[\r\n]/g).length + 40 : 40;
        let val = e.target.value.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/,'');
        this.setState({lessonTitle:val});
    }
    //删除chapter
    deleteTab=(id)=>{
        this.setState({loading:true},()=>{
            api.deleteChapter(`/v1/learn/chapter/del/${id}`)
            .then((res)=>{
                if(res.ret === 20000){
                    message.success(res.msg);
                    this.getChapterList();
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    //删除lesson
    deleteLesson=(id)=>{
        this.setState({loading:true},()=>{
            api.deleteLesson(`/v1/learn/unit/del/${id}`)
            .then((res)=>{
                if(res.ret === 20000){
                    message.success(res.msg);
                    this.getLessonList(this.state.activeKey);
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }

    //添加/编辑lesson api
    lessonAdd=(params)=>{
        this.setState({loading:true},()=>{
            api.addLesson(params)
            .then((res)=>{
                if(res.ret === 20000){
                    message.success(res.msg);
                    this.getLessonList(this.state.activeKey);
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                let arr = this.state.dataSource.map((item)=>{
                    item.editTitle = false;
                    return item
                })
                this.setState({loading:false,dataSource:arr});
            })
        })
        this.close();
    }
    //点击编辑lesson
    editLessonTitle=(record)=>{
        let arr = this.state.dataSource.map((item)=>{
            if(item.id === record.id){
                item.editTitle = true;
            }
            return item
        })
        this.setState({dataSource:arr});
    }
    //编辑 获取 lesson input
    changeLessonTitle=(record,e)=>{
        let arr = this.state.dataSource.map((item)=>{
            if(item.id === record.id){
                item.title = e.target.value;
            }
            return item;
        })
        this.setState({dataSource:arr});
    }

    //查询视频 api封装
    getVideoList=(params)=>{
        this.setState({loading:true},()=>{
            api.getVideoList(params)
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ configVideoData: data.result.data, configVideoPage: data.result.start + 1, configVideoTotal: data.result.total, loading: false })
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    //获取视频id
    getConfigVideoId=(e)=>{
        this.setState({configVideoId:e.target.value});
    }
    //获取视频名称
    getConfigVideoName=(e)=>{
        this.setState({configVideoName:e.target.value});
    }
    //获取学科
    getConfigVideoSubject=(value, option) => {
        if (value && option) {
            this.setState({ configVideoSubId: option.key, configVideoSubName: value });
        } else {
            this.setState({ configVideoSubId: '', configVideoSubName: null });
        }
    }
    //查询 视频
    searchVideo=()=>{
        this.getVideoList({ iDisplayStart: this.state.configVideoPage - 1, iDisplayLength: this.state.configVideoPageSize, id:this.state.configVideoId, videoName:this.state.configVideoName, subId:this.state.configVideoSubId, videoType: 0 });
    }
    //配置视频分页
    configVideoPaginationChange = (configVideoPage, configVideoPageSize) => {
        this.setState({ configVideoPage, configVideoPageSize }, () => {
            this.getVideoList({ iDisplayStart: this.state.configVideoPage - 1, iDisplayLength: this.state.configVideoPageSize, id:this.state.configVideoId, videoName:this.state.configVideoName, subId:this.state.configVideoSubId,videoType: 0 });
        });
    }
    //点击上传视频
    configVideoModal=(record)=>{
        this.setState({showConfigVideoModal:true,lessonID:record.id,loading:true},()=>{
            api.getSubjectList()
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ videoSubjectList: data.result, loading: false });
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
            this.getVideoList({ iDisplayStart: this.state.configVideoPage - 1, iDisplayLength: this.state.configVideoPageSize, videoType: 0 });
        });
    }
    //添加/替换 视频
    configVideo=(record)=>{
        this.setState({loading:true},()=>{
            api.configVideo({id:this.state.lessonID,vkId:record.id})
            .then((data) => {
                if (data.ret === 20000) {
                    message.success(data.msg);
                    this.getLessonList(this.state.activeKey);
                    this.close();
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }

    //视频预览
    videoPreview = (record) => {
        this.setState({ showVideo: true, rowInfo: record })
    }
    //题目配置 弹框
    topicConfiguration = (record) => {
        let disabled = (Array.isArray(record.tids) && record.tids.length) >= 5 ? true : false;
        this.setState({ topicConfigurationModal: true, rowInfo: record, addButtonDisabled: disabled })
    }
    //删除课后题
    deleteTopic = (item) => {
        this.setState({ loading: true }, () => {
            api.deleteTopic(`/v1/video/knowledge/exercises/del/${item}/${this.state.rowInfo.vkId}`)
            .then((data) => {
                if (data.ret === 20000) {
                    message.success(data.msg);
                    this.getLessonList(this.state.activeKey);
                    this.close();
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
        });
    }
    //点击新增按钮
    add = () => {
        this.setState({ showAdd: false })
    }
    //获取新增课后题id
    getInputTopicID = (value) => {
        this.setState({ inputTopicID: value })
    }
    //新增 取消
    hiddenAdd = () => {
        this.setState({ showAdd: true })
    }
    //新增 确定
    sureAdd = () => {
        if (this.state.inputTopicID === '') {
            message.error('请输入有效值！');
            return;
        }
        this.addQuestion({ kid: this.state.rowInfo.vkId, tid: this.state.inputTopicID });
    }
    //添加 课后题
    tableAdd = (record) => {
        this.addQuestion({ kid: this.state.rowInfo.vkId, tid: record.id });
    }
    addQuestion = (params) => {
        this.setState({ loading: true }, () => {
            api.addAfterClassTopic(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.getLessonList(this.state.activeKey);
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    //获取搜索题干 input的value
    getSearch = (value) => {
        if (value === '') {
            message.error('请输入题目ID或题干内容！');
            return;
        }
        this.setState({ searchTopic: encodeURIComponent(value), loading: true }, () => {
            api.searchTopic({ iDisplayStart: 0, iDisplayLength: this.state.searchPageSize, content: this.state.searchTopic })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ topicList: data.result.data, searchPage: data.result.start + 1, searchTotal: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //题目配置 分页
    pageChange = (page, pageSize) => {
        this.setState({ searchPage: page, searchPageSize: pageSize, loading: true }, () => {
            api.searchTopic({ iDisplayStart: this.state.searchPage - 1, iDisplayLength: this.state.searchPageSize, content: this.state.searchTopic })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ topicList: data.result.data, searchPage: data.result.start + 1, searchTotal: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭题目配置弹框
    close = () => {
        if (this.state.showVideo) {
            let videoDom = document.getElementById('video');
            videoDom.pause();
        }
        this.setState({ topicConfigurationModal: false, topicList: [], showAdd: true, showVideo: false, rowInfo: null, showAddChapter:false, chapterTitle:null, showAddLesson:false, lessonTitle:null, showConfigVideoModal:false, titleError:false });
    }
    //获取拖拽行的id
    getSortRowId = (record) => {
        this.setState({ rowId: record.id });
    }
    //鼠标松开后
    onSortEnd = ({ oldIndex, newIndex }) => {
        const { dataSource } = this.state;
        if (oldIndex !== newIndex) {
            const newData = arrayMove([].concat(dataSource), oldIndex, newIndex).filter(el => !!el);
            let id = newData[newIndex].id;
            this.setState({ loading: true }, () => {
                api.lessonSort({ id,fromIndex:oldIndex,toIndex:newIndex })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getLessonList(this.state.activeKey);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })

                // api.sortMockTestTopic({ fromIndex: oldIndex, toIndex: newIndex, id: id, pid: this.state.id })
                //     .then((data) => {
                //         if (data.ret === 20000) {
                //             this.getTestTopicsList();
                //         } else {
                //             return Promise.reject(data);
                //         }
                //     })
                //     .catch((err) => {
                //         message.error(err.msg);
                //         this.setState({ loading: false });
                //     })
            })
        }
    };
    DraggableBodyRow = ({ className, style, ...restProps }) => {
        const { dataSource } = this.state;
        const index = dataSource.findIndex(x => x.serialNumber === restProps['data-row-key']);
        return <SortableItem index={index} {...restProps} />;
    };
    render() {
        const DraggableContainer = props => (
            <SortableContainer
                useDragHandle
                helperClass="row-dragging"
                onSortEnd={this.onSortEnd}
                {...props}
            />
        );
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.selectWrap}>
                        <span className={Style.span}>知识点课程名称：</span>
                        <Select placeholder='---请选择学科---' className={Style.select} value={this.state.selectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true}>
                            {this.state.subjectList.map((item, index) => {
                                return (
                                    <Option key={item.id} value={item.title}>{item.title}</Option>
                                )
                            })}
                        </Select>
                    </div>
                    <Divider />

                    {/* {this.state.chapterList.length > 0 ?
                        <div>
                            <Tabs id='box' tabPosition='left' onChange={this.tabChange} activeKey={this.state.activeKey} type="editable-card">
                            <DraggableTabs onChange={this.tabChange} activeKey={this.state.activeKey}>
                            </DraggableTabs>
                                {this.state.chapterList.map((item, index) => {
                                    return (
                                        <TabPane closeIcon={(()=>{
                                            return <Popconfirm placement="top" title="确认删除吗？" onConfirm={this.deleteTab} okText="确定" cancelText="取消">
                                                        <DeleteOutlined />
                                                    </Popconfirm>
                                        })()} tab={item.title} key={item.id} className={Style.tabPane}>
                                            <Table
                                                dataSource={this.state.dataSource}
                                                columns={this.columns}
                                                rowKey={dataSource => dataSource.levelSecondName + Math.floor(Math.random() * 10000)}
                                                components={{
                                                    body: {
                                                        wrapper: DraggableContainer,
                                                        row: this.DraggableBodyRow,
                                                    },
                                                }}
                                                bordered={true}
                                                pagination={false}
                                            >
                                            </Table>
                                        </TabPane>
                                    )
                                })}
                            </Tabs>
                        </div>
                    : <div>暂无数据</div>} */}
                    {/* 左边tab + 右边table */}
                    {/* {this.state.chapterList.length > 0 ? <div className={Style.contentWrap}> */}
                    <div className={Style.contentWrap}>
                        <div>
                            <Button icon={<PlusOutlined />} className={Style.addLeft} onClick={()=>{this.setState({showAddChapter:true});}}>新增chapter</Button>
                            <div ref='leftWrap' className={Style.leftWrap}>
                                {this.state.chapterList.map((item, index) => {
                                        return (
                                            <div className={Style.left} key={index} style={item.checked ? {'borderRight':'2px solid #1890ff','color':'#1890ff'} : {}} data-sortnum={item.serialNumber} data-id={item.id}>
                                                <Button type='text' icon={<EditOutlined />} onClick={()=>{this.editLeft(item)}}></Button>
                                                <Popconfirm placement="top" title="确认删除该Chapter吗？" onConfirm={()=>{this.deleteTab(item.id)}} okText="确定" cancelText="取消">
                                                    <Button type='text' icon={<DeleteOutlined />}></Button>
                                                </Popconfirm>
                                                {item.edit ? <Input className={Style.input} value={this.state.leftTitle} autoFocus='autoFocus' onBlur={()=>{this.blur(item)}} onChange={this.changeLeftTitle}></Input> : <div className={Style.input} onClick={()=>{this.tabChange(item.id)}}>{item.title}</div>}
                                            </div>
                                        )
                                    })
                                }
                            </div>
                        </div>
                        <Divider type='vertical' className={Style.divider} />
                        {this.state.activeKey !== '' ? <div className={Style.tableWrap}>
                            <Button type='primary' icon={<PlusOutlined />} className={Style.addLesson} onClick={()=>{this.setState({showAddLesson:true});}}>新增lesson</Button>
                            <Table
                                dataSource={this.state.dataSource}
                                columns={this.columns}
                                rowKey={dataSource => dataSource.serialNumber} //排序需要根据rowkey
                                components={{
                                    body: {
                                        wrapper: DraggableContainer,
                                        row: this.DraggableBodyRow,
                                    },
                                }}
                                bordered={true}
                                pagination={false}
                            >
                            </Table>
                        </div> : ''}
                    </div>
                    {/* </div> : <div>暂无数据</div>} */}

                    {/* 新增chapter弹框 */}
                    {this.state.showAddChapter ? <Modal title='新增知识点课程chapter' close={this.close} actions={[<Button onClick={this.close}>取消</Button>,<Button type='primary' disabled={this.state.chapterTitle ? this.state.chapterTitle.replace(/[\r\n]/g,'').length <= 0 : true} onClick={()=>{this.titleCheck({cid:this.state.courseId,id:null,title:this.state.chapterTitle,case:1});}}>确定</Button>]}>
                        <div>
                            <div>如果新增多个chapter，在两个chapter名称之间用回车分隔</div>
                            <div>
                                <span>chapter名称：</span>
                                {/* <TextArea placeholder='每个chapter名称最多40个字符' rows={4} value={this.state.chapterTitle} onChange={this.getChapterTitle} maxLength={this.state.chapterInputLength}></TextArea> */}
                                <TextArea placeholder='每个chapter名称最多40个字符' rows={4} value={this.state.chapterTitle} onChange={this.getChapterTitle}></TextArea>
                                {this.state.titleError ? <div className={Style.titleError}>chapter名称不能超过40个字符</div> : ''}
                            </div>
                        </div>
                    </Modal> : ''}

                    {/* 新增lesson弹框 */}
                    {this.state.showAddLesson ? <Modal title='新增知识点课程Lesson' close={this.close} actions={[<Button onClick={this.close}>取消</Button>,<Button type='primary' disabled={this.state.lessonTitle ? this.state.lessonTitle.replace(/[\r\n]/g,'').length <= 0 : true} onClick={()=>{this.titleCheck({cpId:this.state.activeKey,id:null,title:this.state.lessonTitle});}}>确定</Button>]}>
                        <div>
                            <div>如果新增多个lesson，在两个lesson名称之间用回车分隔</div>
                            <div>
                                <span>lesson名称：</span>
                                <TextArea placeholder='每个lesson名称最多40个字符' rows={4} value={this.state.lessonTitle} onChange={this.getLessonTitle}></TextArea>
                                {this.state.titleError ? <div className={Style.titleError}>lesson名称不能超过40个字符</div> : ''}
                            </div>
                        </div>
                    </Modal> : ''}

                    {/* 添加/替换视频弹框 */}
                    {this.state.showConfigVideoModal ? <Modal title='配置课程视频' close={this.close}>
                        <div>
                            <div className={Style.configVideoWrap}>
                                <div>
                                    <span>视频ID：</span>
                                    <Input className={Style.input} onChange={this.getConfigVideoId}></Input>
                                </div>
                                <div>
                                    <span>视频名称：</span>
                                    <Input className={Style.input} onChange={this.getConfigVideoName}></Input>
                                </div>
                                <div>
                                    <span>学科：</span>
                                    <Select placeholder='全部' className={Style.input} onChange={this.getConfigVideoSubject} optionLabelProp="label" showSearch={true}>
                                        {this.state.videoSubjectList.map((item) => {
                                            return (
                                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                <Button type="primary" icon={<SearchOutlined />} onClick={this.searchVideo}>查询</Button>
                            </div>
                            <Table
                                dataSource={this.state.configVideoData}
                                columns={this.configVideoColumns}
                                rowKey={dataSource => dataSource.id}
                                bordered={true}
                                pagination={false}
                            ></Table>
                            <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} total={this.state.configVideoTotal} current={this.state.configVideoPage} pageSize={this.state.configVideoPageSize} onChange={this.configVideoPaginationChange} showTotal={total => `Total ${total} items`} />
                        </div>
                    </Modal> : ''}

                    {this.state.topicConfigurationModal ? <Modal title='视频课后题配置' close={this.close}>
                        <div className={Style.afterClass}>
                            <div className={Style.afterClassList} >
                                <span className={Style.title}>课后题：</span>
                                <span>
                                    {this.state.rowInfo.qidList ? this.state.rowInfo.qidList.map((item, index) => {
                                        return (
                                            <span key={index} className={Style.topics} onClick={() => { this.deleteTopic(item) }}>
                                                <Badge count={<CloseCircleOutlined style={{ borderRadius: '50%', background: '#ffffff', cursor: 'pointer' }} />}>
                                                    <Button type='primary'>{item}</Button>
                                                </Badge>
                                            </span>
                                        )
                                    }) : ''}
                                    {this.state.showAdd ? <Button disabled={this.state.addButtonDisabled} onClick={this.add} icon={<PlusOutlined />}>新增</Button> : <div className={Style.addWrap}>
                                        <InputNumber placeholder='输入题目ID' className={Style.input} onChange={this.getInputTopicID} maxLength='11' />
                                        <div className={Style.addBtns}>
                                            <Button className={Style.addControl} onClick={this.hiddenAdd}>取消</Button>
                                            <Button className={Style.addControl} type='primary' onClick={this.sureAdd}>确定</Button>
                                        </div>
                                    </div>}
                                </span>
                            </div>
                            <Divider />
                            <Search placeholder="输入题目ID或题干内容搜索题目" onSearch={(value) => { this.getSearch(value) }} enterButton maxLength='100' />
                            <Table
                                dataSource={this.state.topicList}
                                columns={this.topicColumns}
                                rowKey={dataSource => dataSource.id}
                                bordered={true}
                                pagination={false}
                            >
                            </Table>
                            <Pagination className={Style.pagination} current={this.state.searchPage} pageSize={this.state.searchPageSize} total={this.state.searchTotal} onChange={this.pageChange} hideOnSinglePage showTotal={total => `Total ${total} items`}></Pagination>
                        </div>
                    </Modal> : ''}
                    {this.state.showVideo ? <Modal title='视频播放' close={this.close}>
                        <video id='video' className={Style.video} src={this.state.rowInfo.videoUrl} width='700' height='500px' autoPlay="autoplay" controls="controls"></video>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default connect(store=>store)(ContentConfiguration);