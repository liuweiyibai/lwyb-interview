import React,{Component,Fragment} from 'react';
import { Spin, Table, Button, Popconfirm, Badge, Switch, message, Input } from 'antd';
import { LoadingOutlined, CloseCircleOutlined, PlusOutlined } from '@ant-design/icons';
import Viewer from 'viewerjs';
import 'viewerjs/dist/viewer.css';
import Style from './courseConfig.module.less';
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import api from '../../../../utils/api.js';
import fun from '../../../../utils/funSum.js';

import { connect } from 'react-redux';
import actionCreator from '../../../../store/actionCeator';
const { TextArea } = Input;

class CourseConfig extends Component{
    constructor(){
        super();
        this.state={
            loading:false,
            createCourseModal:false,//新建 弹框
            isEdit:null,
            dataSource:[],
            //弹框
            courseTitle:'',//课程标题
            courseIntroduction:'',//课程简介
        }
    }
    columns = [
        fun.getColumnItem('课程标题','title'),
        fun.getColumnItem('课程简介','introduction'),
        {
            title: '课程封面',
            align: 'center',
            width:150,
            render: record => (
                <Fragment>
                    {record.courseCover ?
                        <div className={Style.imageWrap}>
                            <img className={Style.courseImage} id={'coursePic' + record.id} src={record.courseCover} alt='课程封面'></img>
                            <Popconfirm placement="top" title="确认删除该课程的封面图片吗？" onConfirm={this.delCoverImgConfirm} okText="确定" cancelText="取消">
                                <Badge count={<CloseCircleOutlined onClick={() => {
                                    this.setState({ recordId: record.id });
                                }} className={Style.popconfirm} />}>
                                </Badge>
                            </Popconfirm>
                        </div>
                        : <Button type="primary" icon={<PlusOutlined />} onClick={() => {
                            this.setState({ recordId: record.id });
                            this.refs.coverInput.click();
                        }} >添加封面</Button>
                    }
                </Fragment>
            ),
        },
        {
            title: '课程状态',
            align: 'center',
            width:100,
            render: record => (
                <Switch checked={record.courseStatus} onChange={(e) => { this.changeStatus(record, e) }} checkedChildren="上线" unCheckedChildren="下线" />
            ),
        },
        {
            title: '操作项',
            align: 'center',
            width:350,
            render: record => (
                <div>
                    <Button type="primary" onClick={()=>{this.edit(record)}}>编辑</Button>
                    <Button className={Style.btn} type="primary" onClick={()=>{this.toContentConfigPage(record)}}>内容配置</Button>
                    <Button type="primary" onClick={() => {
                        this.toPersonalizedConfPage(record);
                    }}>个性化配置</Button>
                </div>
            ),
        },
    ]
    componentDidMount(){
        this.getCourseList();
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    //获取课程列表
    getCourseList=()=>{
        this.setState({loading:true},()=>{
            api.getCourseConfigList()
            .then((res)=>{
                // console.log(res)
                if(res.ret === 20000){
                    this.setState({dataSource:res.result,loading: false},()=>{
                        this.state.dataSource.forEach( item => {
                            // console.log(item,`coursePic${item.id}`,document.getElementById(`coursePic${item.id}`))
                            if(item.courseCover){
                                new Viewer(document.getElementById(`coursePic${item.id}`),{});
                            }
                        })
                    })
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({ loading: false });
            })
        })
    }
    // input的onchange事件
    inputChange = async (e) => {
        if(!e.target.files[0]) return;
        const file = e.target.files[0];
        const fileType = file ? file.type.split('/')[0] : '';
        if (fileType !== 'image') {
            message.error('只能上传图片');
            return false;
        } else {
            this.setState({ loading: true });
            let data;
            try{
                data = await api.getPicAwsAddress()
                if (data.ret !== 20000) {
                    message.error(data.msg);
                    throw new Error(data);
                }
            }catch(err){
                message.error(err.msg);
                throw err;
            }
            if(data.ret === 20000){
                let newFile;
                try{
                    newFile = await fun.removeExif(file);
                }catch(err){
                    message.error(err.msg);
                    throw err;
                }
                try{
                    await api.uploadAWS(data.result.url,newFile);
                }catch(err){
                    message.error(err.msg);
                    throw err;
                }
                try{
                    await api.uploadCoursePic({courseCover:data.result.key,id:this.state.recordId});
                }catch(err){
                    message.error(err.msg);
                    throw err;
                }
                this.getCourseList();
            }
        }
    }
    // 删除课程图片
    delCoverImgConfirm = () => {
        this.setState({ loading: true }, () => {
            api.deleteCoursePic(`/v1/learn/course/cover/del/${this.state.recordId}`)
            .then(data => {
                if (data.ret === 20000) {
                    message.success(data.msg);
                    this.getCourseList();
                } else {
                    return Promise.reject(data);
                }
            }).catch(err => {
                message.error(err.msg);
                this.setState({ loading: false })
            })
        })
    }
    //改变学科展示状态
    changeStatus = (record, checked) => {
        this.setState({loading:true},()=>{
            api.changeCourseStatus({ courseStatus: checked ? 1 : 0, id: record.id})
            .then((res)=>{
                if(res.ret === 20000){
                    this.getCourseList();
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
    }
    //编辑 显示弹框
    edit=(info)=>{
        this.setState({createCourseModal:true,courseTitle:info.title ? info.title : null,courseIntroduction:info.introduction ? info.introduction : null,isEdit:info.id ? info.id : null});
    }
    //获取课程标题
    getCourseTitle=(e)=>{
        let val = e.target.value;
        e.target.value = val.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/,'');
        this.setState({courseTitle:e.target.value});
    }
    //获取课程简介
    getCourseIntroduction=(e)=>{
        let val = e.target.value.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/,'');
        this.setState({courseIntroduction:val});
    }
    //取消 关闭
    close=()=>{
        this.setState({createCourseModal:false,courseTitle:'',courseIntroduction:''});
    }
    //保存
    save=()=>{
        this.setState({loading:true},()=>{
            api.saveCourse({id:this.state.isEdit,introduction:this.state.courseIntroduction,title:this.state.courseTitle})
            .then((res)=>{
                if(res.ret === 20000){
                    message.success(res.msg);
                    this.getCourseList();
                }else{
                    return Promise.reject(res);
                }
            })
            .catch((err)=>{
                message.error(err.msg);
                this.setState({loading:false});
            })
        })
        message.success('知识点课程保存成功！');
        this.setState({createCourseModal:false});
    }
    //前往课程内容配置页面
    toContentConfigPage=(record)=>{
        let courseID = actionCreator.saveKnowledgeCourseID(record.id);
        this.props.dispatch(courseID); //权限等级
        let courseName = actionCreator.saveKnowledgeCourseName(record.title);
        this.props.dispatch(courseName);
        this.props.history.push('/admin/v1/knowledgePointCourseManage/contentConfig');
    }
    // 前往个性化配置页面
    toPersonalizedConfPage = (record) => {
        this.props.history.push(`/admin/v1/knowledgePointCourseManage/personalizedConfig?id=${record.id}&name=${record.title}`);
    }
    render(){
        return(
            <div className={Style.wrap}>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <input type="file" id="cover-input" ref="coverInput" accept="image/png, image/jpeg, image/jpg" style={{ display: "none" }} onChange={(e) => this.inputChange(e)} />
                    <Button className={Style.add} type='primary' onClick={()=> this.edit({}) }>新建课程</Button>
                    <h4>课程下线状态时将不会在APP中展示</h4>
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    {this.state.createCourseModal ? <Modal title='新建/编辑知识点课程' close={this.close} actions={[<Button className={Style.button} onClick={this.close}>取消</Button>, <Button type="primary" disabled={this.state.courseTitle === ''} className={Style.button} onClick={this.save}>保存</Button>]}>
                        <div className={Style.lineWrap}>
                            <span className={Style.title}><span className={Style.red}>*</span>课程标题：</span>
                            <Input className={Style.input} placeholder='最多40个字符' value={this.state.courseTitle} maxLength={40} onChange={this.getCourseTitle} allowClear></Input>
                        </div>
                        <div className={Style.lineWrap}>
                            <span className={Style.title}>课程简介：</span>
                            <TextArea className={Style.input} placeholder='最多100个字符' value={this.state.courseIntroduction} maxLength={100} onChange={this.getCourseIntroduction} rows={4} allowClear></TextArea>
                        </div>
                    </Modal> : ''}
                </Spin>
            </div>
        )
    }
}

export default connect(store=>store)(CourseConfig);