import React, {useEffect, useState} from 'react';
import {connect} from 'react-redux';
import api from '../../../../utils/api';
import {Button, Input, Divider, Table, Tooltip, Modal, Select, InputNumber, Spin, message} from 'antd';
import {PlusOutlined, SearchOutlined, MinusCircleOutlined, LoadingOutlined} from '@ant-design/icons'
import Style from './activity.module.less';

const {Option} = Select;

function Activity(props) {
  let [loading, setLoading] = useState(false);
  let [activityId, setActivityId] = useState(null);
  let [activityName, setActivityName] = useState(null);
  let [page, setPage] = useState(1);
  let [pageSize, setPageSize] = useState(10);
  let [total, setTotal] = useState(0);
  let [isModalVisible, setIsModalVisible] = useState(false);
  let [tableSource, setTableSource] = useState([
    // {
    //   id: '我们一起来数一数一二三四五六七八九十',
    //   activityName: 'helsdkfjksdjfk dsjfkdsjfkjdskflo',
    //   participateWay: 'jdfsajdkfjdsjkfjdkfjkd jfkjdkfj',
    //   activeTag: 'sdfjdfk djsfkjdsf kdjfkjdkfkd jfkdj',
    // }
  ]);
  // Modal 相关变量
  let [wechatGroup, setWechatGroup] = useState([]); // 接口中获取到的 - 未绑定的微信群
  let [currentWechatGroup, setCurrentWechatGroup] = useState([]); // 弹框中微信群应该包含当前item的
  let [tags, setTags] = useState([]);
  let [modalActivityName, setModalActivityName] = useState('');
  let [wechatSelectItem, setWechatSelectItem] = useState([]);
  let [activityTypeValue, setActivityTypeValue] = useState(null);
  let [modalKeyWord, setModalKeyWord] = useState('');
  let [modalWechatCount, setModalWechatCount] = useState(null);
  let [activityFlagValue, setActivityFlagValue] = useState(null);
  let [activityFlagNameValue, setActivityFlagNameValue] = useState(null);
  let [isModalSubmit, setIsModalSubmit] = useState(false);
  let [currentEditItem, setCurrentEditItem] = useState(null);
  // eslint-disable-next-line no-unused-vars
  let [promisePendingCount, setPromisePendingCount] = useState(0); // 当前正在请求的 promise ， 用于控制请求结束之后设置loading状态

  useEffect(() => {
    // getTableData();
    getWechatGroup();
    getTags();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    getTableData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, pageSize])

  useEffect(() => {
    getIsModalSubmit();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalActivityName, wechatSelectItem, activityTypeValue, activityFlagValue, modalKeyWord, modalWechatCount])

  useEffect(() => {
    if (loading === false) getTableTagName();
    //  eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading])

  const participateWayMenu = [
    {
      id: 0,
      text: ''
    },
    {
      id: 1,
      text: '加活动微信群'
    },
    {
      id: 2,
      text: '在群内发言且有关键词'
    },
    {
      id: 3,
      text: '在群内发言且发言次数达到'
    }
  ]
  const columns = [
    {
      title: '活动ID',
      dataIndex: 'id',
      key: 'id',
      align: 'center',
      width: 150,
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '活动名称',
      dataIndex: 'activityName',
      key: 'activityName',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '参与方式',
      dataIndex: 'participateWayText',
      key: 'participateWayText',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '关联标签',
      dataIndex: 'activeTagName',
      key: 'activeTagName',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '操作项目',
      key: 'opt',
      align: 'center',
      width: 100,
      render: (text, item) => {
        return (
            <Button type='primary' onClick={()=>{
              if (item.hjWxGroups) {
                let wechatIds = item.hjWxGroups.map(el => {
                  return el.id;
                })
                // console.log(wechatIds);
                setWechatSelectItem(val => {
                  wechatIds.forEach(ID => {
                    val.push({selectValue: ID});
                  })
                  return [...val];
                });
                // console.log([...item.hjWxGroups,...wechatGroup]);
              }

              // console.log(item);



              item.hjWxGroups !== null ? setCurrentWechatGroup([...item.hjWxGroups,...wechatGroup]): setCurrentWechatGroup([...wechatGroup]);
              setModalActivityName(item.activityName || '');
              item.participateWay !== 0 && setActivityTypeValue(item.participateWay+'' || null);
              item.hiKeywords && item.hiKeywords.length > 0 && setModalKeyWord(item.hiKeywords[0].keyword || '');
              item.hiSpeakCount && setModalWechatCount(item.hiSpeakCount.count+'' || null);
              setActivityFlagValue(item.activeTag ||null);
              setIsModalVisible(true);
              setCurrentEditItem(item);
              }}
            >编辑</Button>
        )
      }
    }
  ]

  const changeActivityId = (e) => {
    let value = e.target.value;
    const reg = /\D/g;
    if (reg.test(value)) {
      value = value.replace(reg, '');
    }
    if (value.length > 7) return;
    setActivityId(value);
  }

  const changeActivityName = (e) => {
    let value = e.target.value;
    if (value.length > 50) return;
    setActivityName(value);
  }

  const search = () => {
    // console.log(activityId, activityName);
    setPage(1);
    getTableData();
  }

  const setIsNoLoading = () => {
    setPromisePendingCount(val => {
      if (val - 1 === 0) {
        setLoading(false);
      }
      return --val;
    });
  }

  const getTableData = () => {
    setPromisePendingCount(val => ++val);
    setLoading(true);
    api.getActivityList({
      id: activityId,
      activityName,
      iDisplayLength: pageSize,
      iDisplayStart: page - 1,
    }).then(res => {
      // console.log(res);
      if (res.code === 0) {
        setTotal(res.data.total);
        if (res.data.data) {
          res.data.data[0].forEach(item => {
            item.participateWayText = participateWayMenu[item.participateWay].text;
            if (item.participateWay === 2 && item.hiKeywords) {
              item.participateWayText += `（${item.hiKeywords[0].keyword}）`;
            }
            if (item.participateWay === 3 && item.hiSpeakCount) {
              item.participateWayText += `（${item.hiSpeakCount.count}）`;
            }
          });
          setTableSource(res.data.data[0]);
        } else {
          setTableSource([]);
        }
        setIsNoLoading();
      } else {
        return Promise.reject(res);
      }
    }).catch((err) => {
      message.error(err.message);
      setIsNoLoading();
    })
  }

  const getWechatGroup = () => {
    setPromisePendingCount(val => ++val);
    setLoading(true);
    api.getAvailableWechatGroup().then(res => {
      // console.log(res);
      if (res.code === 0) {
        setIsNoLoading();
        setWechatGroup(res.data);
      } else {
        return Promise.reject(res);
      }
    }).catch((err) => {
      message.error(err.message);
      setIsNoLoading();
    })
  }

  const getTags = () => {
    setPromisePendingCount(val => ++val);
    setLoading(true);
    api.getActivityTagList().then(res => {
      // console.log(res);
      if (res.code === 0) {
        let tags = [];
        if (res.data && res.data.data) {
          tags = res.data.data.filter(item => {
            return item.name === '客户参与活动';
          })
          if (tags.length !== 0) tags = tags[0].tagContent;
        }
        setTags(tags);
        setIsNoLoading();

      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      setIsNoLoading();
    })
  }

  const getTableTagName = () => {
    setTimeout(() => {
      if (tags.length !== 0 && tableSource.length !== 0) {
        let _tableSource = [...tableSource];
        let _tags = [...tags];
        for (let i of _tableSource) {
          for (let j of _tags) {
            if (i.activeTag === j.id) {
              i.activeTagName = j.name;
              break;
            } else {
              i.activeTagName = null;
            }
          }
        }
        setTags(_tags);
        setTableSource(_tableSource);
      }
    }, 0)
  }

  const getOrUpdateActivity = (params) => {
    setLoading(true);
    api.editActivity(params).then(res => {
      // console.log(res);
      if (res.ret === 20000) {
        setLoading(false);
        closeModal();
        getTableData();
        getWechatGroup();
        getTags();
      } else {
        return Promise.resolve(res);
      }
    }).catch(err => {
      message.error(err.msg);
      setLoading(false);
    })
  }

  const getModalActivityName = (e) => {
    setModalActivityName(e.target.value);
  }

  const getModalKeyWord = (e) => {
    setModalKeyWord(e.target.value);
  }

  const minusItem = (itemIndex) => {
    setWechatSelectItem(val => {
      return val.filter((item, index) => {
        return index !== itemIndex;
      })
    })
  }

  const addItem = () => {
    setWechatSelectItem(val => {
      val.push({selectValue: null});
      return [...val];
    })
  }

  const selectWechatItem = (value, item) => {
    setWechatSelectItem(val => {
      val[item.itemindex].selectValue = value;
      return [...val];
    })
  }

  const selectActivityTypeItem = (value) => {
    setActivityTypeValue(value);
    // console.log(value)
  }

  const selectActivityFlagItem = (value, option) => {
    setActivityFlagValue(value);
    setActivityFlagNameValue(option.title);
    // console.log(value, option.title);
  }

  const changeWechatCount = (val) => {
    setModalWechatCount(val);
  }

  const closeModal = () => {
    resetModal();
    setIsModalVisible(false);
  }

  const resetModal = () => {
    setModalActivityName('');
    setWechatSelectItem([]);
    setActivityTypeValue(null);
    setModalKeyWord('');
    setModalWechatCount(null);
    setActivityFlagValue(null);
    setCurrentEditItem(null);
    setCurrentWechatGroup([]);
  }

  const getIsModalSubmit = () => {
    let flag = false;
    if (
        modalActivityName !== '' &&
        activityTypeValue !== null &&
        activityFlagValue !== null &&
        wechatSelectItem.length !== 0 &&
        !wechatSelectItem.some(item => item.selectValue === null)
    ) {
      if (activityTypeValue === '1' || (activityTypeValue === '2' && modalKeyWord !== '') || (activityTypeValue === '3' && modalWechatCount !== null)) {
        flag = true;
      }else {
        flag = false;
      }
    }
    setIsModalSubmit(flag);
  }

  const modalOk = () => {
    // eslint-disable-next-line
    let result = {
      modalActivityName,
      activityTypeValue,
      activityFlagValue,
      wechatSelectItem,
      modalKeyWord,
      modalWechatCount,
    }
    // console.log(result);
    // console.log(currentEditItem);
    // return;
    // 微信 id 去重
    let wechatSelectItemIdArr = [...new Set(wechatSelectItem.map(item => item.selectValue))];
    let params = {
      activeTag: activityFlagValue,
      activityName: modalActivityName,
      activityTagName: activityFlagNameValue,
      createdAt: "2021-05-26T03:45:37.938Z",
      deleted: 0,
      hgWxGroupIds: wechatSelectItemIdArr,
      hiKeywords: [
        {
          activityId: (currentEditItem && currentEditItem.id) || null,
          createdAt: "2021-05-26T03:45:37.938Z",
          deleted: 0,
          id: (currentEditItem && currentEditItem.hiKeywords && currentEditItem.hiKeywords[0].id) || null,
          keyword: modalKeyWord,
          updatedAt: "2021-05-26T03:45:37.938Z"

        }
      ],
      hiSpeakCount: {
        activityId: (currentEditItem && currentEditItem.id) || null,
        count: +modalWechatCount,
        createdAt: "2021-05-26T03:45:37.938Z",
        deleted: 0,
        id: (currentEditItem && currentEditItem.hiSpeakCount && currentEditItem.hiSpeakCount.id) || null,
        updatedAt: "2021-05-26T03:45:37.938Z",
      },
      "hjWxGroups": [
        {
          "activityId": 0,
          "createdAt": "2021-05-26T03:45:37.938Z",
          "deleted": 0,
          "flag": 0,
          "groupId": "string",
          "groupName": "string",
          "heading": "string",
          "id": (currentEditItem && currentEditItem.hjWxGroups && currentEditItem.hjWxGroups[0].id) || null,
          "memberCount": 0,
          "projectBelong": 0,
          "saleWxId": "string",
          "updatedAt": "2021-05-26T03:45:37.938Z"
        }
      ],
      id: (currentEditItem && currentEditItem.id) || null,
      participateWay: +activityTypeValue,
      "updatedAt": "2021-05-26T03:45:37.938Z",
    }
    // console.log(params);
    getOrUpdateActivity(params);
  }


  return (
      <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
        <div className={Style.ezaLeadsActivityWrap}>
          <div className={Style.topBar}>
            <div className={Style.l}>
              <Button type='primary' icon={<PlusOutlined/>} onClick={() => {
                setCurrentWechatGroup([...wechatGroup]);
                setIsModalVisible(true);
              }}>新建活动</Button>
              <span className={Style.labelSpan}>活动ID：</span>
              <Input allowClear className={Style.inputBox} placeholder='请输入活动ID'
                     value={activityId} onChange={changeActivityId}
              />
              <span className={Style.labelSpan}>活动名称：</span>
              <Input allowClear className={Style.inputBox} placeholder='清输入活动名称'
                     value={activityName} onChange={changeActivityName}
              />
            </div>
            <div className={Style.r}>
              <Button type='primary' icon={<SearchOutlined/>} onClick={search}>查询</Button>
            </div>
          </div>
          <Divider/>
          <Table dataSource={tableSource} columns={columns} bordered rowKey={'id'}
                 pagination={{current: page, total, pageSize, showQuickJumper: true,
                   onChange: (_page, _pageSize) => {
                      setPage(_page);
                      setPageSize(_pageSize);
                   }
                 }}
          />
          <Modal title="新建/编辑微信群活动" visible={isModalVisible} getContainer={false} className={`${Style.activityModal} select-position`}
                 cancelButtonProps={{type: 'link', className: 'cancel-btn'}} width={450} onCancel={closeModal}
                 okButtonProps={{disabled: !isModalSubmit}}
                 onOk={modalOk}
          >
            <div className={Style.itemBox}>
              <div className={Style.itemTitle}>活动名称</div>
              <div>
                <Input placeholder='请输入活动名称' allowClear maxLength={50} onChange={getModalActivityName} value={modalActivityName}/>
              </div>
            </div>
            <div className={Style.itemBox}>
              <div className={Style.itemTitle}>关联微信群</div>
              {
                wechatSelectItem.map((selectItem, itemIndex) => {
                  return (
                      <div className={Style.itemMargin} key={itemIndex} id='select-position-1'>
                        <Select
                            showSearch
                            style={{width: '90%'}}
                            placeholder="请选择微信群"
                            optionFilterProp="children"
                            onChange={selectWechatItem}
                            filterOption={(input, option) =>
                                option.title.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                            value={selectItem.selectValue}
                            getPopupContainer={() => document.getElementById('select-position-1')}
                        >
                          {/*<Option value="jack" itemindex={itemIndex}>Jack</Option>*/}
                          {
                            currentWechatGroup.map(item => (
                                <Option value={item.id} key={item.id} itemindex={itemIndex} title={item.groupName}>
                                  <Tooltip title={item.groupName}>{item.groupName}</Tooltip>
                                </Option>
                            ))
                          }
                        </Select>
                        <Button type='text' icon={<MinusCircleOutlined style={{color: '#FF5500'}}/>}
                                className={Style.deleteItemBtn} onClick={() => {
                          minusItem(itemIndex)
                        }}/>
                      </div>
                  )
                })
              }
              <div>
                <Button type='dashed' icon={<PlusOutlined/>} block onClick={addItem}/>
              </div>
            </div>
            <div className={Style.itemBox}>
              <div className={Style.itemTitle}>参与活动方式</div>
              <div id='select-position-2'>
                <Select
                    showSearch
                    style={{width: '100%'}}
                    placeholder="请选择活动方式"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                        option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                    onChange={selectActivityTypeItem}
                    value={activityTypeValue}
                    getPopupContainer={() => document.getElementById('select-position-2')}
                >
                  {/*<Option value="0">加活动微信群</Option>*/}
                  {/*<Option value="1">在群内发言且有关键词</Option>*/}
                  {/*<Option value="2">在群内发言且发言次数达到</Option>*/}
                  {
                    participateWayMenu.map(item => {
                      if (item.id === 0) return '';
                      return <Option value={item.id+''} key={item.id} title={item.text}>{item.text}</Option>
                    })
                  }
                </Select>
              </div>
            </div>
            {
              activityTypeValue === '2' && (
                  <div className={Style.itemBox}>
                    <div className={Style.itemTitle}>关键词</div>
                    <div>
                      <Input value={modalKeyWord} placeholder='请填写关键词' allowClear maxLength={20} onChange={getModalKeyWord}/>
                    </div>
                  </div>
              )
            }
            {
              activityTypeValue === '3' && (
                  <div className={Style.itemBox}>
                    <div className={Style.itemTitle}>次数</div>
                    <div>
                      <InputNumber placeholder='请输入次数' min={1} max={10} onChange={changeWechatCount} style={{width: '30%'}} value={modalWechatCount}/>
                    </div>
                  </div>
              )
            }
            <div className={Style.itemBox}>
              <div className={Style.itemTitle}>活动标签</div>
              <div id='select-position-3'>
                <Select
                    showSearch
                    style={{width: '100%'}}
                    placeholder="请选择活动标签"
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                        option.title.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                    onChange={selectActivityFlagItem}
                    value={activityFlagValue}
                    getPopupContainer={() => document.getElementById('select-position-3')}
                >
                  {
                    tags.map(item => (
                        <Option value={item.id} key={item.id} title={item.name}>
                          <Tooltip title={item.name}>{item.name}</Tooltip>
                        </Option>
                    ))
                  }
                </Select>
              </div>
            </div>
          </Modal>
        </div>
      </Spin>
  )
}

export default connect(store => store)(Activity);