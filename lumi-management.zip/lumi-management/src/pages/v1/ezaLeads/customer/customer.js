import React, {useEffect, useState} from 'react';
import {connect} from 'react-redux';
import {Spin, DatePicker, Select, Button, Divider, Table, Tooltip, Pagination, message} from 'antd';
import {LoadingOutlined} from '@ant-design/icons';
import Style from './customer.module.less';
import moment from 'moment';
import api from "../../../../utils/api";

const {RangePicker} = DatePicker;
const {Option, OptGroup} = Select;

function Customer() {
  const defaultColumns = [
    {
      title: '微信号',
      dataIndex: 'wechatAlias',
      key: 'wechatAlias',
      align: 'center',
      width: 150,
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '微信昵称',
      dataIndex: 'wechatNickname',
      key: 'wechatNickname',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '客户姓名',
      dataIndex: 'customerName',
      key: 'customerName',
      align: 'center',
      width: 150,
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '客户等级',
      dataIndex: 'userLevel',
      key: 'userLevel',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '客户校区',
      dataIndex: 'userCampus',
      key: 'userCampus',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: 'EZA账号',
      dataIndex: 'ezaAccount',
      key: 'ezaAccount',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip title={text}>{text}</Tooltip>
    },
    {
      title: '客户标签',
      dataIndex: 'tagNameStr',
      key: 'tagNameStr',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip placement='topLeft' title={text}>{text}</Tooltip>
    },
    {
      title: '已加微信群',
      dataIndex: 'wxGroupNameStr',
      key: 'wxGroupNameStr',
      align: 'center',
      ellipsis: true,
      render: (text) => <Tooltip placement='topLeft' title={text}>{text}</Tooltip>
    },
    {
      title: '跟进销售',
      dataIndex: 'saleNameWechats',
      align: 'center',
      ellipsis: true,
      render: (text, item, index) => {
        return <Tooltip placement='topLeft' title={()=>{
          return item.saleNameWechats.map((el,i) => <div key={i + el.wxId}>{`${el.saleName} - ${el.wxId}`}</div>)
        }}>{item.saleNameWechatsStr}</Tooltip>
      }
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      align: 'center',
      width: 160,
      ellipsis: true,
      render: (text) => <Tooltip title={moment(text).format('YYYY/MM/DD hh:mm')}>{moment(text).format('YYYY/MM/DD hh:mm')}</Tooltip>
    },
  ];
  let [loading, setLoading] = useState(false);
  let [tableSource, setTableSource] = useState([
    // {
    //   id: '1',
    //   wechat: 'zyd-test-hello-a',
    //   wechatName: 'zyd',
    //   name: 'test-zyd',
    //   level: '2',
    //   campus: 'UTSG',
    //   ezaAccount: 'yudong.zhi@easygroup.ca',
    //   tags: '参加活动的标签',
    //   wechatGroups: '已经加入的微信群',
    //   sale: '宋珂 - Esc993221',
    //   createTime: '2021/05/12 11:14'
    // }
  ]);
  let [columns, setColumns] = useState(defaultColumns);
  let [page, setPage] = useState(1);
  let [pageSize, setPageSize] = useState(10);
  let [total, setTotal] = useState(0);
  let [columnsTitleList] = useState([
    {
      title: '微信号',
    },
    {
      title: '微信昵称',
    },
    {
      title: '客户姓名',
    },
    {
      title: '客户等级',
    },
    {
      title: '客户校区',
    },
    {
      title: 'EZA账号',
    },
    {
      title: '客户标签',
    },
    {
      title: '已加微信群',
    },
    {
      title: '跟进销售',
    },
    {
      title: '创建时间',
    },
  ]);
  let [columnsSelectedValues] = useState(["微信号", "微信昵称", "客户姓名", "客户等级", "客户校区", "EZA账号", "客户标签", "已加微信群", "跟进销售", "创建时间"]);

  let [dateArr, setDateArr] = useState([moment().subtract(6, 'days'), moment()]);
  let [saleManList, setSaleManList] = useState([]);
  let [selectSaleManValue, setSelectSaleManValue] = useState(null);
  let [wechatGroupList, setWechatGroupList] = useState([]);
  let [selectWechatGroupValue, setSelectWechatGroupValue] = useState(null);
  let [tags, setTags] = useState([]);
  let [selectTagValue, setSelectTagValue] = useState(null);
  let [userLevel] = useState([
    {
      id: 1,
      name: '可触达用户',
    },
    {
      id: 2,
      name: '意向用户',
    },
    {
      id: 3,
      name: '关系用户',
    }
  ]);
  let [selectUserLevel, setSelectUserLevel] = useState(null);
  let [school] = useState([
    {
      id: 1,
      name: 'UTSG'
    },
    {
      id: 2,
      name: 'UTM'
    },
    {
      id: 3,
      name: 'UTSC'
    },
    {
      id: 4,
      name: 'UW'
    },
    {
      id: 5,
      name: 'UA'
    },
    {
      id: 6,
      name: 'Western'
    },
    {
      id: 7,
      name: 'UBC'
    },
    {
      id: 8,
      name: 'Queens'
    },
    {
      id: 9,
      name: 'McMaster'
    },
    {
      id: 10,
      name: 'York'
    },
    {
      id: 11,
      name: 'McGill'
    }
  ]);
  let [selectSchool, setSelectSchool] = useState(null);

  useEffect(() => {
    getSalesManData();
    getAllWechatGroups();
    getTags();
  }, []);

  useEffect(() => {
    getTableData();
  //  eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, pageSize])

  // 导出解题工单
  // const exportOrder = () => {
  //   // this.setState({ loading: true }, () => {
  //   //   let params = { start: this.state.createStartTime, end: this.state.createEndTime, orderId: this.state.orderNum, subId: this.state.subjectId, solverId: this.state.expertId, orderStatus: this.state.orderStatusId, userId: this.state.userID, isPop: this.state.greatOrderId, isRemark: this.state.remarkStatusId, difficultyLevel: this.state.orderDifficultyId, commentType: this.state.userCommentId }
  //   //   api.exportOrder(params, { responseType: 'arraybuffer' })
  //   //       .then(async (response) => {
  //   //         let parse_result = await fun.ab2str(response);
  //   //         if (parse_result === false) {
  //   //           fun.download(response, `工单数据-${moment(new Date()).format('YYYYMMDD')}.xlsx`);
  //   //           this.setState({ loading: false });
  //   //           message.success('导出成功！');
  //   //         } else {
  //   //           if (parse_result.ret === 20000) {
  //   //             message.success(parse_result.msg);
  //   //             this.setState({ loading: false });
  //   //           } else {
  //   //             return Promise.reject(parse_result);
  //   //           }
  //   //         }
  //   //       })
  //   //       .catch((err) => {
  //   //         message.error(err.msg);
  //   //         this.setState({ loading: false })
  //   //       })
  //   // })
  // }

  const disabledDate = (current) => {
    return current && current > moment().endOf('day');
  }

  const selectColumns = (value) => {
    let _arr = defaultColumns.filter(item => {
      return value.some(str => {
        return str === item.title;
      })
    });
    setColumns(_arr);
  }

  const getTableData = () => {
    // when the time is null
    let _dateArr = [];
    if (dateArr === null) {
      _dateArr = [moment().subtract(6, 'days'), moment()];
    } else {
      _dateArr = dateArr;
    }

    setLoading(true);
    api.getCustomerList_Leads({
      createdAtEnd: _dateArr[1].format('YYYY-MM-DD'),
      createdAtStart: _dateArr[0].format('YYYY-MM-DD'),
      groupId: selectWechatGroupValue,
      id: null,
      idisplayLength: pageSize,
      idisplayStart: page - 1,
      saleId: selectSaleManValue,
      startId: null,
      tagId: selectTagValue,
      tagName: null,
      userCampus: selectSchool,
      userLevel: selectUserLevel
    }).then(res => {
      if (res.code === 0) {
        if (res.data) {
          setTotal(res.data.total);
          if (res.data.data) {
            let result = res.data.data;
            result = processResTagsList(result);
            result = processResWxGroupList(result);
            result = processResSaleWechatList(result);
            result = processWechatAlias(result);
            // console.log(result);
            setTableSource(result);
            setLoading(false);
          } else {
            setTableSource([]);
            setLoading(false);
          }
        } else {
          setTotal(0);
          setTableSource([]);
          setLoading(false);
        }
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      setLoading(false);
    })
  }

  const processResTagsList = (data) => {
    let res = [...data];
    let resultStr = '';
    res.forEach(item => {
      item.customerTagNamesList && item.customerTagNamesList.forEach((tagName, tagNameIndex) => {
        if (tagNameIndex === 0) {
          resultStr += `${tagName}`
        } else {
          resultStr += `, ${tagName}`
        }
      })
      item.tagNameStr = resultStr;
      resultStr = '';
    })
    return res;
  }

  const processResWxGroupList = (data) => {
    let res = [...data];
    let resultStr = '';
    res.forEach(item => {
      item.wxGroupNamesList && item.wxGroupNamesList.forEach((groupName, groupNameIndex) => {
        if (groupNameIndex === 0) {
          resultStr += `${groupName}`
        } else {
          resultStr += `, ${groupName}`
        }
      })
      item.wxGroupNameStr = resultStr;
      resultStr = '';
    })
    return res;
  }

  const processResSaleWechatList = (data) => {
    let res = [...data];
    let resultStr = '';
    res.forEach(item => {
      item.saleNameWechats && item.saleNameWechats.forEach((saleItem) => {
        resultStr += `${saleItem.saleName} - ${saleItem.wxId}\n`;
      })
      item.saleNameWechatsStr = resultStr;
      resultStr = '';
    })
    return res;
  }

  const processWechatAlias = (data) => {
    let res = [...data];
    res.forEach(item => {
      if (!item.wechatAlias) {
        item.wechatAlias = item.wechatNumber;
      }
    })
    return res;
  }

  const getTags = () => {
    setLoading(true);
    api.getActivityTagList().then(res => {
      // console.log(res);
      if (res.code === 0) {
        let tags = [];
        if (res.data && res.data.data) {
          tags = res.data.data;
        }
        // console.log(tags);
        setTags(tags);
        setLoading(false);
      } else {
        return Promise.reject(res);
      }
    }).catch(err => {
      message.error(err.message);
      setLoading(false);
    })
  }

  const getSalesManData = () => {
    setLoading(true);
    api.getSalesMan_Leads().then(res => {
      // console.log(res);
      if (res.code === 0) {
        setSaleManList(res.data);
        setLoading(false);
      }
    }).catch(err => {
      message.error(err.message);
      setLoading(false);
    })
  }

  const getAllWechatGroups = () => {
    setLoading(true);
    api.getAllWechatGroups_Leads().then(res => {
      // console.log(res);
      if (res.code === 0) {
        setWechatGroupList(res.data);
        setLoading(false);
      }
    }).catch(err => {
      message.error(err.message);
      setLoading(false);
    })
  }

  const changeDateSelect = (date, dateString) => {
    // console.log(date, dateString);
    setDateArr(date);
  }

  const changeSaleManSelect = (val) => {
    // console.log(val);
    setSelectSaleManValue(val);
  }

  const changeWechatGroupSelect = (val) => {
    // console.log(val);
    setSelectWechatGroupValue(val);
  }

  const changeTagSelect = (val) => {
    // console.log(val);
    setSelectTagValue(val);
  }

  const changeUserLevelSelect = (val) => {
    // console.log(val);
    setSelectUserLevel(val);
  }

  const changeSchoolSelect = (val) => {
    // console.log(val);
    setSelectSchool(val);
  }


  return (
      <Spin spinning={loading} indicator={<LoadingOutlined/>} tip='请稍后...' size='large'>
        <div className={Style.ezaLeadsCustomerWrap}>
          <div className={Style.topBar}>
            <div className={Style.Row}>
              <div className={Style.item}>
                <span className={Style.labelSpan}>创建时间：</span>
                <RangePicker className={Style.timePickerBox} disabledDate={disabledDate} onChange={changeDateSelect} defaultValue={dateArr}/>
              </div>
              <div className={Style.item}>
                <span className={Style.labelSpan}>客户标签：</span>
                <Select value={selectTagValue} className={Style.customerLabelBox} placeholder='请选择' allowClear onChange={changeTagSelect}>
                  {
                    tags.map(tagItem => (
                        <OptGroup label={tagItem.name} key={tagItem.id}>
                          {
                            tagItem.tagContent.map(item => (
                                <Option value={item.id} key={item.id}>{item.name}</Option>
                            ))
                          }
                        </OptGroup>
                    ))
                  }
                </Select>
              </div>
              <div className={Style.item}>
                <span className={Style.labelSpan}>客户等级：</span>
                <Select value={selectUserLevel} placeholder='请选择' className={Style.customerLabelBox} allowClear onChange={changeUserLevelSelect}>
                  {
                    userLevel.map(item => (
                        <Option key={item.id} value={item.name}>{item.name}</Option>
                    ))
                  }
                </Select>
              </div>
              <div className={Style.item}/>
            </div>

            <div className={Style.Row}>
              <div className={Style.item}>
                <span className={Style.labelSpan}>客户校区：</span>
                <Select value={selectSchool} placeholder='请选择' allowClear className={Style.customerLabelBox} onChange={changeSchoolSelect}>
                  {
                    school.map(item => (
                        <Option key={item.id} value={item.name}>{item.name}</Option>
                    ))
                  }
                </Select>
              </div>
              <div className={Style.item}>
                <span className={Style.labelSpan}>跟进销售：</span>
                <Select
                    placeholder='请选择'
                    allowClear
                    showSearch
                    optionFilterProp='children'
                    filterOption={(input, option) => {
                      return option.title.toLowerCase().indexOf(input.toLowerCase()) >= 0;
                    }}
                    className={Style.customerLabelBox}
                    value={selectSaleManValue}
                    onChange={changeSaleManSelect}
                >
                  {
                    saleManList.map(item => (
                        <Option key={item.saleId} value={item.saleId} title={item.saleName}>
                          <Tooltip title={item.saleName}>{item.saleName}</Tooltip>
                        </Option>
                    ))
                  }
                </Select>
              </div>
              <div className={Style.item}>
                <span className={Style.labelSpan}>微信群：</span>
                <Select
                    className={Style.customerLabelBox}
                    placeholder='请选择'
                    allowClear
                    showSearch
                    optionFilterProp='children'
                    filterOption={(input, option) => {
                      return option.title.toLowerCase().indexOf(input.toLowerCase()) >= 0;
                    }}
                    value={selectWechatGroupValue}
                    onChange={changeWechatGroupSelect}
                >
                  {
                    wechatGroupList.map(item => (
                        <Option key={item.groupId} value={item.groupId} title={item.groupName}>
                          <Tooltip title={item.groupName}>
                            {item.groupName}
                          </Tooltip>
                        </Option>
                    ))
                  }
                </Select>
              </div>
              <div className={`${Style.item} ${Style.ButtonItem}`}>
                <Button type='primary' className={Style.searchBtn} onClick={() => {setPage(1);getTableData();}}>查 询</Button>
                {/*<Button type='primary' className={Style.searchBtn}>导 出</Button>*/}
              </div>
            </div>
          </div>
          <Divider/>
          <div className={Style.selectColumnsBox}>
            <span>列表显示字段：</span>
            <Select mode='multiple' placeholder='请选择字段' maxTagCount={0} className={Style.selectColumns}
                    onChange={selectColumns} defaultValue={columnsSelectedValues}>
              {
                columnsTitleList.map((opt, index) => {
                  return (
                      <Option value={opt.title} key={index}>
                        <Tooltip title={opt.title}>
                          {opt.title}
                        </Tooltip>
                      </Option>
                  )
                })
              }
            </Select>
          </div>
          <Table
              dataSource={tableSource} columns={columns} bordered rowKey={'id'}
              pagination={false}
          />
          <div className={Style.bottomPaginationBox}>
            <div className={Style.totalBox}><span>Total</span> {total} <span>items</span></div>
            <Pagination current={page} total={total} pageSize={pageSize} showQuickJumper
                        onChange={(_page, _pageSize) => {
                          setPage(_page);
                          setPageSize(_pageSize);
                        }}
            />
          </div>
        </div>
      </Spin>
  )
}

export default connect(store => store)(Customer);