import React, { Component, Fragment } from 'react';
import { Spin, Button, Table, Pagination, Select, Tooltip, Transfer, Divider, message } from 'antd';
import { SearchOutlined, LoadingOutlined, SettingOutlined } from '@ant-design/icons';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import Style from './userPower.module.less';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';

const { Option } = Select;
class UserPower extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            showPowerModal: false,//权限配置弹框
            transferData: [],//穿梭框左侧数据
            targetData: [],//穿梭框 右侧数据
            userName: '',//input用户名
            userNameList: [],//用户列表
            departmentList: [],//部门列表
            departmentSel: '',//下拉所选部门id
            userNameSel: '',//下拉所选用户姓名
            userId: '',//所点击行的员工id
            dataSource: [],
            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '员工头像',
            dataIndex: 'avatarUrl',
            align: 'center',
            render: (avatarUrl, record) => (
                <Tooltip placement="top" title={record.userName}>
                    <img src={avatarUrl} alt='员工头像' />
                </Tooltip>

            ),
        },
        {
            title: '员工姓名',
            dataIndex: 'userName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: name => (
                <Tooltip placement="top" title={name}>
                    {name}
                </Tooltip>
            ),
        },
        {
            title: '所属部门',
            align: 'center',
            render: (record) => {
                return (
                    <div>
                        {record.departName.map((item, index) => {
                            return (
                                <Tooltip placement="top" title={item} key={index}>
                                    <span>{item}&emsp;</span>
                                </Tooltip>
                            )
                        })}
                    </div>
                )
            }
        },
        {
            title: '所在城市',
            dataIndex: 'city',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: city => (
                <Tooltip placement="top" title={city}>
                    {city}
                </Tooltip>
            ),
        },
        {
            title: '操作项',
            align: 'center',
            render: record => (
                <Button type='primary' icon={<SettingOutlined />} onClick={() => { this.powerModal(record) }}>权限配置</Button>
            ),
        },
    ]
    componentDidMount = () => {
        this.getUserList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        this.getDepartmentList();
        this.getUserNameList()
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取用户姓名下拉列表
    getUserNameList = () => {
        this.setState({ loadnig: true }, () => {
            api.getUserNameList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ userNameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取部门下拉列表
    getDepartmentList = () => {
        this.setState({ loadnig: true }, () => {
            api.getDeparmentList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ departmentList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取员工列表
    getUserList = (params) => {
        this.setState({ loading: true }, () => {
            api.getUserList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取用户姓名
    getUserName = (value, option) => {
        if (value && option) {
            this.refs.userName.blur();
            this.setState({ userNameSel: option.key });
        } else {
            this.setState({ userNameSel: '' });
        }
    }
    //获取员工部门下拉
    getDepartment = (value, option) => {
        if (value && option) {
            this.refs.department.blur();
            this.setState({ departmentSel: option.key });
        } else {
            this.setState({ departmentSel: '' });
        }
    }
    //搜索查询
    search = () => {
        this.getUserList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, userId: this.state.userNameSel, deptId: this.state.departmentSel });
    }
    //权限配置按钮 显示弹框
    powerModal = (record) => {
        this.setState({ showPowerModal: true, userId: record.userId, transferData: [], targetData: [], loading: true }, () => {
            api.getLeftPowerList({ userId: record.userId })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ transferData: data.result, loading: false }, () => {
                            api.getRightPowerList({ userId: record.userId })
                                .then((data) => {
                                    if (data.ret === 20000) {
                                        data.result.map((item) => {
                                            this.setState({ transferData: this.state.transferData.concat(item), targetData: this.state.targetData.concat(item.key) });
                                            return null
                                        })
                                    } else {
                                        return Promise.reject(data);
                                    }
                                })
                                .catch((err) => {
                                    message.error(err.msg);
                                    this.setState({ loading: false });
                                })
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    //穿梭框改变
    transferChange = (targetKeys, direction, moveKeys) => {
        this.setState({ loading: true });
        if (direction === "right") {
            this.alllotRole(1, JSON.stringify(moveKeys).slice(1, -1), this.state.userId, targetKeys);
        } else if (direction === "left") {
            this.alllotRole(2, JSON.stringify(moveKeys).slice(1, -1), this.state.userId, targetKeys);
        }
    }
    //分配角色
    alllotRole = (type, roleId, userId, targetKeys) => {
        api.allotRole({ type: type, roleIds: roleId, userId: userId })
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ targetData: targetKeys, loading: false });
                    message.success(data.msg);
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                this.setState({ loading: false });
                message.error(err.msg);
            })
    }
    //关闭弹框
    close = () => {
        this.setState({ showPowerModal: false });
    }
    //分页
    pageChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getUserList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, userName: this.state.userName, deptId: this.state.departmentSel })
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <Select className={Style.select} ref='userName' placeholder='请选择员工姓名' onChange={this.getUserName} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.userNameList.map((item) => {
                                    return <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                })}
                            </Select>
                            <Select className={Style.select} ref='department' placeholder='请选择所属部门' onChange={this.getDepartment} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.departmentList.map((item) => {
                                    return <Option key={item.deptId} value={item.deptName}>{item.deptName}</Option>
                                })}
                            </Select>
                        </div>
                        <Button type='primary' icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    >
                    </Table>
                    <Pagination className={Style.pagination} showQuickJumper hideOnSinglePage current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.pageChange} showTotal={total => `Total ${total} items`}> </Pagination>
                    {this.state.showPowerModal ? <Modal title='权限配置' close={this.close}>
                        <Transfer
                            dataSource={this.state.transferData}//穿梭框左数据
                            targetKeys={this.state.targetData}//穿梭框右数据
                            listStyle={{
                                width: 300,
                                height: 300,
                            }}
                            operations={['添加权限', '移除权限']}
                            onChange={this.transferChange}
                            render={record => record.name}
                        />
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default UserPower;