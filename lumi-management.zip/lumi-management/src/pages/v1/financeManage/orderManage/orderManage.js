import React, { Component, Fragment } from 'react';
import { Button, Table, Pagination, Input, Select, Spin, Tooltip, Divider, DatePicker, InputNumber, message } from 'antd';
import { LoadingOutlined, SearchOutlined, DownloadOutlined } from '@ant-design/icons';
import Style from './orderManage.module.less';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import moment from 'moment';

const { Option } = Select;
const { RangePicker } = DatePicker;

class OrderManage extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,
            //搜索
            orderTypeID: '',//订单类型ID
            orderTypeList: [],//订单类型下拉列表
            productNameList: [],//商品名称列表
            productName: null,//商品名称
            productNameID: null,//商品名称ID
            orderNumber: '',//订单号
            userNumber: '',//用户账号
            userID: null,//用户ID
            orderStatusList: [],//订单状态下拉列表
            orderStatus: null,//订单状态
            orderStatusID: '',//订单状态ID
            payStartTime: moment(moment()).format('YYYY-MM-DD'),//支付开始时间
            payEndTime: moment(moment()).format('YYYY-MM-DD'),//支付结束时间
            columns: this.columns,//列表展示字段
            dataSource: [],
            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        fun.getColumnItem('订单号', 'orderNo', '220px'),
        fun.getColumnItem('用户账号', 'email'),
        fun.getColumnItem('用户ID', 'userId'),
        fun.getColumnItem('商品名称', 'productName'),
        fun.getColumnItem('支付渠道', 'payChannel'),
        {
            title: <Tooltip placement="topLeft" title='设备类型'>设备类型</Tooltip>,
            dataIndex: 'orderPlatform',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: orderPlatform => {
                return (
                    <Tooltip placement="topLeft" title={orderPlatform}>
                        {orderPlatform}
                    </Tooltip>
                )
            },
        },
        fun.getColumnTimeItem('创建时间（美东）', 'createdAt', 2),
        fun.getColumnTimeItem('支付时间（美东）', 'paidAt', 2),
        {
            title: <Tooltip placement="topLeft" title='订单金额（USD）'>订单金额（USD）</Tooltip>,
            dataIndex: 'payAmount',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: payAmount => {
                let pay = payAmount !== 0 ? (payAmount / 100).toFixed(2) : 0;
                return (
                    <Tooltip placement="topLeft" title={payAmount !== 0 ? (payAmount / 100).toFixed(2) : 0}>
                        {pay}
                    </Tooltip>
                )
            },
        },
        fun.getColumnItem('订单状态', 'orderStatus'),
    ]
    componentDidMount() {
        this.getOrderList({ email: '', end: this.state.payEndTime, idisplayLength: 10, idisplayStart: 0, orderNo: '', productId: '', productType: '', start: this.state.payStartTime, userId: null, orderStatus: '' });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取订单列表
    getOrderList = (params) => {
        this.setState({ loading: true }, () => {
            api.getOrderList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取商品名称列表
    getProductNameList = () => {
        this.setState({ loading: true }, () => {
            api.getProductNameList({ type: this.state.orderTypeID })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ productNameList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    // 获取订单类型
    getOrderType = (value, option) => {
        if (value && option) {
            this.refs.orderType.blur();
            this.setState({ orderTypeID: option.key, productName: null, productNameID: null }, () => {
                this.getProductNameList();
            });
        } else {
            this.setState({ orderTypeID: '', productNameList: [], productName: null, productNameID: null });
        }
    }
    // 获取商品名称
    getProductName = (value, option) => {
        if (value && option) {
            this.refs.productName.blur();
            this.setState({ productName: value, productNameID: option.key, });
        } else {
            this.setState({ productName: null, productNameID: null });
        }
    }
    //获取订单号
    getOrderNumber = (e) => {
        this.setState({ orderNumber: e.target.value });
    }
    //获取用户账号
    getUserNumber = (e) => {
        this.setState({ userNumber: e.target.value });
    }
    // 获取用户ID
    getUserID = (value) => {
        this.setState({ userID: value });
    }
    //获取订单状态
    getOrderStatus = (value, option) => {
        if (value && option) {
            this.refs.orderStatus.blur();
            this.setState({ orderStatus: value, orderStatusID: option.key });
        } else {
            this.refs.orderStatus.blur();
            this.setState({ orderStatus: null, orderStatusID: '' });
        }
    }
    //获取支付时间
    getPayTime = (date, dateString) => {
        if (date && dateString) {
            this.refs.payTime.blur();
            let startAt = date[0] ? moment(date[0]).format('YYYY-MM-DD') : '';
            let endAt = date[1] ? moment(date[1]).format('YYYY-MM-DD') : '';
            this.setState({ payStartTime: startAt, payEndTime: endAt });
        }
        else {
            this.refs.payTime.blur();
            this.setState({ payStartTime: '', payEndTime: '' });
        }
    }
    //查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getOrderList({ email: this.state.userNumber, end: this.state.payEndTime, idisplayLength: this.state.pageSize, idisplayStart: this.state.page - 1, orderNo: this.state.orderNumber, productId: this.state.productNameID, productType: this.state.orderTypeID, start: this.state.payStartTime, userId: this.state.userID, orderStatus: this.state.orderStatusID });
        })
    }
    // 导出订单
    orderImport = () => {
        this.setState({ loading: true }, () => {
            let params = { email: this.state.userNumber, end: this.state.payEndTime, orderNo: this.state.orderNumber, productId: this.state.productNameID, productType: this.state.orderTypeID, start: this.state.payStartTime, userId: this.state.userID, orderStatus: this.state.orderStatusID };
            api.orderExport(params, { responseType: 'arraybuffer' })
                .then(async (response) => {
                    fun.download(response, `订单数据-${moment(new Date()).format('YYYYMMDD')}.xlsx`);
                    this.setState({ loading: false });
                    message.success('导出成功！');
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false })
                })
        })
    }
    // 设置列表显示字段
    setTable = (value, option) => {
        if (value && option) {
            let arr = this.columns.filter((item) => value.includes(item.title) || item.title === '订单号')
            this.setState({ columns: arr })
        }
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getOrderList({ email: this.state.userNumber, end: this.state.payEndTime, idisplayLength: this.state.pageSize, idisplayStart: this.state.page - 1, orderNo: this.state.orderNumber, productId: this.state.productNameID, productType: this.state.orderTypeID, start: this.state.payStartTime, userId: this.state.userID, orderStatus: this.state.orderStatusID });
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.box}>
                            <span className={Style.span}>订单类型：</span>
                            <Select className={Style.input} ref='orderType' placeholder='全部' onChange={this.getOrderType} allowClear={true} optionLabelProp="label" showSearch={true}>
                                <Option key={1} value='会员订阅订单'>会员订阅订单</Option>
                                <Option key={2} value='钱包充值订单'>钱包充值订单</Option>
                                <Option key={3} value='备考课订单'>备考课订单</Option>
                                <Option key={4} value='Q&A订单'>Q&A订单</Option>
                                <Option key={5} value='AP课程订单'>AP课程订单</Option>
                            </Select>
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>商品名称：</span>
                            <Select className={Style.input} ref='productName' placeholder='全部' onChange={this.getProductName} allowClear={true} optionLabelProp="label" showSearch={true} value={this.state.productName}>
                                {this.state.productNameList.length > 0 ? this.state.productNameList.map((item,) => {
                                    return (
                                        <Option key={item.id} value={item.title}>{item.title}</Option>
                                    )
                                }) : ''}
                            </Select>
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>订单号：</span>
                            <Input className={Style.input} placeholder='请输入订单号' maxLength='100' value={this.state.orderNumber} onChange={this.getOrderNumber}></Input>
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>用户账号：</span>
                            <Input className={Style.input} placeholder='请输入用户Email账号' maxLength='100' value={this.state.userNumber} onChange={this.getUserNumber}></Input>
                        </div>
                    </div>
                    <div className={Style.searchWrap}>
                        <div className={Style.box}>
                            <span className={Style.span}>用户ID：</span>
                            <InputNumber className={Style.input} placeholder='请输入用户ID' maxLength='10' value={this.state.userID} onChange={this.getUserID}></InputNumber>
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>订单状态：</span>
                            <Select className={Style.input} placeholder='全部' ref='orderStatus' onChange={this.getOrderStatus} allowClear={true} optionLabelProp="label" showSearch={true} >
                                <Option key={0} value='未支付'>未支付</Option>
                                <Option key={1} value='已支付'>已支付</Option>
                                <Option key={2} value='已取消'>已取消</Option>
                                {/* <Option key={3} value='已超时'>已超时</Option>
                                <Option key={4} value='已退款'>已退款</Option> */}
                            </Select>
                        </div>
                        <div className={Style.boxTime}>
                            <span className={Style.spanTime}>支付时间(美东)：</span>
                            <RangePicker className={Style.input} 
                            defaultValue={[moment(Date.now() - 14400000).utc(), moment(Date.now() - 14400000).utc()]}
                             ref='payTime' onCalendarChange={this.getPayTime}
                                disabledDate={(current) => {
                                    if (this.state.payStartTime === null && this.state.payStartTime === null) {
                                        return false;
                                    }
                                    const tooLate = this.state.payStartTime && current.diff(moment(this.state.payStartTime), 'months') > 2;
                                    const tooEarly = this.state.payEndTime && moment(this.state.payEndTime).diff(current, 'months') > 2;
                                    return tooEarly || tooLate;
                                }} renderExtraFooter={() => '日期范围最多支持3个月'} />
                        </div>
                        <div className={Style.boxSearch}>
                            <Button icon={<SearchOutlined />} className={Style.input} type='primary' onClick={this.search}>查询</Button>
                            <Button icon={<DownloadOutlined />} className={Style.input} type='primary' onClick={this.orderImport}>导出</Button>
                        </div>
                    </div>
                    <Divider />
                    <div className={Style.middle}>
                        <div className={Style.box}>
                            <span className={Style.spanTime}>列表显示字段：</span>
                            <Select className={Style.input} placeholder='全部' allowClear={true} optionLabelProp="label" showSearch={true} mode='multiple' onChange={this.setTable} maxTagCount={0}
                                defaultValue={() => {
                                    let arr = this.columns.map((item) => {
                                        if (item.title === '订单号') return null;
                                        return item.title;
                                    })
                                    return arr;
                                }}>
                                {this.columns.map((item) => item.title).map((item, index) => {
                                    if (item === '订单号') return null;
                                    return (
                                        <Option key={index} value={item}>{item}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                    </div>
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.state.columns}
                        rowKey={dataSource => dataSource.orderNo}
                        bordered={true}
                        pagination={false}
                    ></Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                </Spin>
            </Fragment >
        )
    }
}

export default OrderManage;