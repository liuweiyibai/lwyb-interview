import React, { Component, Fragment } from 'react';
import {
  Select,
  Spin,
  Statistic,
  Row,
  Col,
  Input,
  Divider,
  Table,
  Button,
  Drawer,
  Descriptions,
  Tooltip,
  Tag,
  Typography,
  Space,
  Image,
} from 'antd';
import {
  LoadingOutlined,
  SearchOutlined,
  LeftOutlined,
  RightOutlined,
} from '@ant-design/icons';
import fun from '../../../../utils/funSum.js';
import {
  OrderStatus,
  PaymentStatus,
  SearchViews,
  Stores,
  TimeFilters,
} from '../../../../global/const/shopify.const';
import api from '../../../../utils/api';
import Style from './coursesInOrder.module.less';
import moment from 'moment';

const { Option } = Select;
const { Title, Text } = Typography;

const PageDirection = {
  NEXT: 'next',
  PREVIOUS: 'prev',
};
class CoursesInOrder extends Component {
  constructor() {
    super();
    this.state = {
      selectedView: SearchViews[0].value, // 当前视图
      columns: this.columns, // 表格列
      dataSource: [], // 表格数据
      currentStore: Stores[0].value, // 当前商铺
      currentTimeFilter: TimeFilters[2].value, // 当前筛选时间
      // 统计数据
      statistical: {
        orderCount: 0,
        orderedItems: 0,
        returnedItems: 0,
        fulfilledOrders: 0,
        timeToFulfill: null,
      },
      // 搜索条件
      searchData: {
        ids: '',
        status: null, //OrderStatus[0].value,
        financialStatus: [],
      },
      searching: false, // 搜索状态
      loading: false, // 加载统计数据状态
      showDetail: false, // 显示详情开关
      // 分页
      pagination: {
        after: null,
        before: null,
        lastTime: null,
        size: 50,
        direction: PageDirection.NEXT,
      },
      // 详情页
      detail: {},
    };
  }
  columns = [
    fun.getColumnItem('Order', 'name'),
    fun.getColumnItem('ID', 'id', '180px'),
    fun.getColumnTimeItem('Date', 'created_at', '120px'),
    {
      title: 'Customer',
      align: 'center',
      dataIndex: 'customer',
      ellipsis: {
        showTitle: false,
      },
      render: (customer, record) => {
        return (
          <Tooltip
            placement='top'
            key={record.id}
            title={`${customer.first_name} ${customer.last_name}`}
          >
            {`${customer.first_name} ${customer.last_name}`}
          </Tooltip>
        );
      },
    },
    fun.getColumnItem('Email', 'email', '160px'),
    {
      title: 'Total',
      align: 'center',
      width: '80px',
      dataIndex: 'total_price',
      ellipsis: {
        showTitle: false,
      },
      render: (text, record) => {
        return (
          <Tooltip placement='top' key={record.id} title={`$${text}`}>
            {`$${text}`}
          </Tooltip>
        );
      },
    },
    fun.getColumnItem('Payment', 'financial_status'),
    {
      title: 'Fulfillment',
      align: 'center',
      dataIndex: 'fulfillment_status',
      ellipsis: {
        showTitle: false,
      },
      render: (text, record) => {
        const label = text ? text : 'Unfulfilled';
        return (
          <Tooltip placement='top' key={record.id} title={label}>
            {label}
          </Tooltip>
        );
      },
    },
    {
      title: 'Items',
      align: 'center',
      width: '60px',
      dataIndex: 'line_items',
      ellipsis: {
        showTitle: false,
      },
      render: (text, record) => {
        return (
          <Tooltip placement='top' key={record.id} title={`${text.length}`}>
            {`${text.length}`}
          </Tooltip>
        );
      },
    },
    // fun.getColumnItem('Delivery method'),
    // fun.getColumnItem('Tags', 'tags'),
  ];
  componentDidMount() {
    this.search();
    this.loadDashboard();
    fun.addKeyboardListener(); //监听回车查询事件
  }
  componentWillUnmount() {
    fun.removeKeyboardListener();
    this.setState = () => {
      return;
    };
  }
  // 切换商铺
  onStoreChange(event) {
    this.setState(
      {
        currentStore: event,
      },
      () => {
        this.search();
        this.loadDashboard();
      }
    );
  }
  // 切换统计数据筛查条件
  onTimeFilterChange(event) {
    this.setState(
      {
        currentTimeFilter: event,
      },
      () => {
        this.loadDashboard();
      }
    );
  }
  // 查询条件变更
  onQueryChange(event) {
    let { searchData } = this.state;
    searchData.ids = event.target.value;
    this.setState(
      {
        searchData,
      },
      fun.debounce(() => {
        this.search();
      }, 500)
    );
  }
  // 切换订单视图
  onChangeView(view) {
    this.setState({ selectedView: view.value }, () => {
      this.search(view.params);
    });
  }
  // 订单状态筛选
  onStatusChange(value) {
    let { searchData } = this.state;
    searchData.status = value;
    this.setState(
      {
        searchData,
      },
      () => {
        this.search();
      }
    );
  }
  // 完成状态筛选
  onFinancialStatusChange(value) {
    let { searchData } = this.state;
    searchData.financialStatus = value;
    this.setState(
      {
        searchData,
      },
      () => {
        this.search();
      }
    );
  }
  // 查询订单列表
  search(param = {}) {
    this.setState(
      () => ({ searching: true }),
      () => {
        const { searchData, currentStore, pagination } = this.state;
        const queryParam = {
          financialStatus: searchData.financialStatus.join(' '),
          ids: searchData.ids,
          limit: pagination.size,
          status: searchData.status,
          store: currentStore,
          ...param,
        };
        if (pagination.direction === PageDirection.PREVIOUS) {
          queryParam.createdAtMin = pagination.lastTime;
        } else {
          queryParam.createdAtMax = pagination.lastTime;
        }
        api
          .getShopifyOrderList(queryParam)
          .then((data) => {
            const { orders } = data.result || {};
            this.setState({ dataSource: orders });
          })
          .finally(() => {
            this.setState({ searching: false });
          });
      }
    );
  }
  // 加载统计数据
  loadDashboard() {
    this.setState(
      () => ({ loading: true }),
      () => {
        const { currentStore, currentTimeFilter } = this.state;
        const currentTime = moment().utc();
        let createdAtMin = null;
        switch (currentTimeFilter) {
          case TimeFilters[1].value:
            createdAtMin = currentTime.subtract(7, 'days');
            break;
          case TimeFilters[2].value:
            createdAtMin = currentTime.subtract(1, 'months');
            break;
          default:
            createdAtMin = currentTime;
            break;
        }
        api
          .getShopifyCount({
            createdAtMin: createdAtMin.format('YYYY-MM-DD HH:mm:ss'),
            store: currentStore,
          })
          .then((data) => {
            if (data.result) {
              this.setState({ loading: false, statistical: data.result });
            }
          })
          .catch((err) => {
            this.setState({ loading: false });
          });
      }
    );
  }
  // 分页切换
  paginationChange(direction = PageDirection.NEXT) {
    const { dataSource } = this.state;
    let { pagination } = this.state;
    let lastItem = null;
    console.log(dataSource.length, dataSource[0].id);
    if (dataSource.length) {
      if (direction === PageDirection.NEXT) {
        lastItem = dataSource[dataSource.length - 1];
        if (!pagination.after) {
          pagination.after = dataSource[0].id;
          pagination.before = null;
        }
      } else {
        lastItem = dataSource[0];
        if (pagination.after) {
          pagination.before = pagination.after;
          pagination.after = null;
        }
      }
    }
    if (lastItem) {
      pagination.lastTime = moment
        .parseZone(lastItem.created_at)
        .utc()
        .format('YYYY-MM-DD HH:mm:ss');
    } else {
      pagination.lastTime = moment().utc().format('YYYY-MM-DD HH:mm:ss');
    }
    pagination.direction = direction;
    this.setState({ pagination }, () => {
      this.search();
    });
  }

  downloadFile() {

    const store = Stores.find(item => item.value === this.state.currentStore);
    if(store){
      const { download, label } = store;
      let a = document.createElement('a');
      a.setAttribute('href', download);
      a.setAttribute('download', label);
      a.setAttribute('target', '_self');
      a.setAttribute('style', 'display:none');
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  }

  render() {
    const {
      columns,
      selectedView,
      searchData,
      searching,
      currentStore,
      loading,
      showDetail,
      pagination,
      currentTimeFilter,
      dataSource,
      statistical,
      detail,
    } = this.state;
    const timeToFulfill = statistical.timeToFulfill
      ? `${statistical.timeToFulfill}days`
      : '-';
    const hasPrev =
      pagination.after ||
      (pagination.before &&
        pagination.before !== (dataSource[0] && dataSource[0].id));
    const hasNext = dataSource.length >= pagination.size || pagination.before;
    return (
      <Fragment>
        <div className={Style.storeName}>
          <Select
            defaultValue={currentStore}
            bordered={false}
            optionLabelProp='label'
            size='large'
            dropdownStyle={{ minWidth: '320px' }}
            onChange={(event) => this.onStoreChange(event)}
          >
            {Stores.map((item) => (
              <Option key={item.value} value={item.value} label={item.label}>
                <div className={Style.option}>
                  <p className={Style.optionName}>{item.label}</p>
                  {/* <p className={Style.optionDescribe}>{item.describe}</p> */}
                </div>
              </Option>
            ))}
          </Select>
        </div>
        <Spin
          spinning={loading}
          indicator={<LoadingOutlined />}
          tip='请稍候...'
          size='large'
        >
          <div className={Style.dashboard}>
            <div>
              <Select
                className={Style.compareTime}
                defaultValue={currentTimeFilter}
                bordered={false}
                size='large'
                optionLabelProp='label'
                dropdownStyle={{ minWidth: '360px' }}
                onChange={(event) => this.onTimeFilterChange(event)}
              >
                {TimeFilters.map((item) => (
                  <Option
                    key={item.value}
                    value={item.value}
                    label={item.label}
                  >
                    <div className={Style.option}>
                      <p className={Style.optionName}>{item.label}</p>
                      <p className={Style.optionDescribe}>{item.describe}</p>
                    </div>
                  </Option>
                ))}
              </Select>
            </div>
            <div>
              <Statistic
                title='Orders'
                value={statistical.orderCount}
              ></Statistic>
            </div>
            <div>
              <Statistic
                title='Ordered items'
                value={statistical.orderedItems}
              ></Statistic>
            </div>
            <div>
              <Statistic
                title='Returned items'
                value={statistical.returnedItems}
              ></Statistic>
            </div>
            <div>
              <Statistic
                title='Fulfilled orders'
                value={statistical.fulfilledOrders}
              ></Statistic>
            </div>
            <div>
              <Statistic
                title='Time to fulfill'
                value={timeToFulfill}
              ></Statistic>
            </div>
          </div>
        </Spin>
        <ul className={Style.viewTabs}>
          {SearchViews.map((item) => (
            <li
              key={item.value}
              className={item.value === selectedView ? Style.selected : null}
              onClick={() => this.onChangeView(item)}
            >
              <span>{item.label}</span>
            </li>
          ))}
          <div className={Style.download}>
            <Button type='link' onClick={() => this.downloadFile()}>
              Export
            </Button>
          </div>
        </ul>
        <Divider />
        <Row className={Style.searchBar} gutter={15}>
          <Col span={6}>
            <Input
              prefix={<SearchOutlined />}
              defaultValue={searchData.ids}
              placeholder='Filter orders'
              onChange={(event) => {
                this.onQueryChange(event);
              }}
            />
          </Col>
          <Col span={4}>
            <Select
              defaultValue={searchData.status}
              className={Style.filterSelect}
              placeholder='Status'
              allowClear={true}
              optionLabelProp='label'
              onChange={(event) => this.onStatusChange(event)}
            >
              {OrderStatus.map((item) => (
                <Option key={item.value} value={item.value} label={item.label}>
                  {item.label}
                </Option>
              ))}
            </Select>
          </Col>
          <Col span={14}>
            <Select
              defaultValue={searchData.financialStatus}
              className={Style.filterSelect}
              mode='multiple'
              optionLabelProp='label'
              placeholder='Payment status'
              allowClear={true}
              maxTagCount={4}
              onChange={(event) => this.onFinancialStatusChange(event)}
            >
              {PaymentStatus.map((item) => (
                <Option key={item.value} value={item.value} label={item.label}>
                  {item.label}
                </Option>
              ))}
            </Select>
          </Col>
        </Row>
        <Spin
          spinning={searching}
          indicator={<LoadingOutlined />}
          tip='Loading orders...'
          size='large'
        >
          <Table
            columns={columns}
            dataSource={dataSource}
            pagination={false}
            rowKey={(dataSource) => dataSource.id}
            onRow={(record) => {
              return {
                onClick: () => {
                  this.setState({ showDetail: true, detail: record });
                },
              };
            }}
          />
          <div className={Style.pagination}>
            <Button
              disabled={!hasPrev}
              onClick={() => this.paginationChange(PageDirection.PREVIOUS)}
            >
              <LeftOutlined />
            </Button>
            <Button
              disabled={!hasNext}
              style={{ marginLeft: '10px' }}
              onClick={() => this.paginationChange(PageDirection.NEXT)}
            >
              <RightOutlined />
            </Button>
          </div>
        </Spin>
        <Drawer
          width={640}
          placement='right'
          visible={showDetail}
          onClose={() => {
            this.setState({ showDetail: false });
          }}
        >
          <h3>{detail.name}</h3>
          <Space direction='vertical' size='middle'>
            <div>
              <Tag>{detail.financial_status}</Tag>
              <Tag>{detail.fulfillment_status || 'Unfulfilled'}</Tag>
            </div>
            <div>
              <Title level={4}>Customer</Title>
              <Text>
                {detail.customer
                  ? `${detail.customer.first_name} ${detail.customer.last_name}`
                  : '-'}
              </Text>
            </div>
            <div>
              <Title level={4}>Created by</Title>
              <Text>
                {detail.created_at
                  ? moment(detail.created_at).format('YYYY-MM-DD HH:mm:ss')
                  : '-'}
              </Text>
            </div>
            <div>
              <Title level={4}>Items</Title>
              <div>
                {detail.line_items &&
                  detail.line_items.map((item) => (
                    <div key={item.product_id} className={Style.product}>
                      <Image
                        width={64}
                        height={64}
                        placeholder
                        src={item.productSrc}
                      />
                      <div>{item.name}</div>
                      <div>{`$${item.price} x ${item.quantity}`}</div>
                      <div>${item.price * item.quantity}</div>
                    </div>
                  ))}
              </div>
            </div>
            <div>
              <Title level={4}>Paid</Title>
              <table style={{ width: '100%' }}>
                <tbody>
                  {detail.discount_codes &&
                    detail.discount_codes.map((item) => (
                      <tr key={item.code}>
                        <td>Discount</td>
                        <td>
                          <Text type='secondary'>{item.code}</Text>
                        </td>
                        <td style={{ textAlign: 'right' }}>-${item.amount}</td>
                      </tr>
                    ))}
                  <tr>
                    <td>Subtotal</td>
                    <td>
                      <Text type='secondary'>
                        {detail.line_items ? detail.line_items.length : 0} item
                      </Text>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      ${detail.subtotal_price}
                    </td>
                  </tr>
                  <tr>
                    <td>Total</td>
                    <td></td>
                    <td style={{ textAlign: 'right' }}>
                      ${detail.total_price_usd}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan='3'>
                      <Divider />
                    </td>
                  </tr>
                  <tr>
                    <td>Paid by customer</td>
                    <td></td>
                    <td style={{ textAlign: 'right' }}>
                      ${detail.total_price_usd}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div>
              <Title level={4}>Card</Title>
              <Descriptions bordered column={1}>
                <Descriptions.Item label='Card details'>
                  {detail.payment_details &&
                    `${detail.payment_details.credit_card_company} ${detail.payment_details.credit_card_number}`}
                </Descriptions.Item>
                <Descriptions.Item label='Name on card'>
                  {detail.customer
                    ? `${detail.customer.first_name} ${detail.customer.last_name}`
                    : '-'}
                </Descriptions.Item>
                <Descriptions.Item label='Authorization key'>
                  pi_1J0rDqS3kd0ijoFpDt9Vb6J3
                </Descriptions.Item>
                <Descriptions.Item label='Message'>
                  Transaction approved
                </Descriptions.Item>
                <Descriptions.Item label='Amount'>
                  ${detail.total_price_usd}
                </Descriptions.Item>
                <Descriptions.Item label='Gateway'>
                  {detail.gateway}
                </Descriptions.Item>
                <Descriptions.Item label='Status'>success</Descriptions.Item>
                <Descriptions.Item label='Type'>sale</Descriptions.Item>
                <Descriptions.Item label='Created'>
                  {detail.created_at
                    ? moment(detail.created_at).format('MMMM Do YYYY, h:mm a')
                    : '-'}
                </Descriptions.Item>
              </Descriptions>
            </div>
          </Space>
        </Drawer>
      </Fragment>
    );
  }
}

export default CoursesInOrder;
