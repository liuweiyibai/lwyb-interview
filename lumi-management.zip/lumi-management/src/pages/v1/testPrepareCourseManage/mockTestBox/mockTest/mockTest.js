import React, { Component, Fragment } from 'react';
import { Button, Table, Pagination, Input, Select, Spin, Tooltip, Divider, InputNumber, message, Popconfirm } from 'antd';
import { LoadingOutlined, SearchOutlined, PlusOutlined, DeleteOutlined, EditOutlined, CopyOutlined } from '@ant-design/icons';
import moment from 'moment';
import api from '../../../../../utils/api';
import fun from '../../../../../utils/funSum.js';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import Style from './mockTest.module.less';

const { Option } = Select;
class MockTest extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,
            addTestModal: false,
            editTestModal: false,
            subjectList: [],
            courseId: '',
            testName: '',
            subjectId: '',
            //新建、编辑、复制
            rowId: '',//所点击行id
            modalTestName: '',//考试名称
            testDuration: '',//考试时长
            modalSubjectName: null,//所选学科名
            modalSubjectId: '',//所选学科id

            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '考试ID',
            dataIndex: 'id',
            align: 'center',
            width: '80px',
            ellipsis: {
                showTitle: false,
            },
            render: id => (
                <Tooltip placement="top" title={id}>
                    {id}
                </Tooltip>
            ),
        },
        {
            title: '考试名称',
            dataIndex: 'name',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: name => (
                <Tooltip placement="top" title={name}>
                    {name}
                </Tooltip>
            ),
        },
        {
            title: '考试时长',
            dataIndex: 'examDuration',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: examDuration => {
                return (
                    <Tooltip placement="top" title={examDuration ? examDuration + 'min' : '无'}>
                        {examDuration ? examDuration + ' min' : '无'}
                    </Tooltip>
                )
            }
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName ? subjectName : '暂无学科'}>
                    {subjectName ? subjectName : '暂无学科'}
                </Tooltip>
            ),
        },
        {
            title: '创建时间',
            dataIndex: 'createdAt',
            align: 'center',
            width: 180,
            ellipsis: {
                showTitle: false,
            },
            render: createdAt => {
                let date = createdAt ? moment(new Date(new Date(createdAt).getTime() - new Date().getTimezoneOffset() * 60000)).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '关联备考课',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return (
                    Array.isArray(record.title) && record.title.length > 0 ? <Button type='link' onClick={() => { this.lookUp(record) }}>查看</Button> : '无'
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: '390px',
            render: (record) => (
                <div>
                    <Button type='primary' icon={<EditOutlined />} className={Style.btn} onClick={() => { this.edit(record) }}>编辑</Button>

                    <Popconfirm title="你确认要复制该考试吗？" okText="确定" cancelText="取消" onConfirm={() => { this.copy(record) }}>
                        <Button type='primary' icon={<CopyOutlined />} className={Style.btn} >复制</Button>
                    </Popconfirm>

                    <Popconfirm title="确认要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.delete(record) }}>
                        <Button icon={<DeleteOutlined />} className={Style.btn} type='primary'>删除</Button>
                    </Popconfirm>
                    <Button type='link' onClick={() => { this.props.history.push(`/admin/v1/testPrepareCourseManage/topicConfigure?id=${record.id}&name=${record.name}&duration=${record.examDuration}`) }}>题目配置</Button>
                </div>
            ),
        },
    ]
    componentDidMount() {
        this.getSubjectList();
        this.getMockTestList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取学科列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取模拟考试列表
    getMockTestList = (params) => {
        this.setState({ loading: true }, () => {
            api.getMockTestList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取资料id
    getCourseId = (value) => {
        this.setState({ courseId: value });
    }
    //获取考试名称
    getTestName = (e) => {
        this.setState({ testName: e.target.value });
    }
    //获取考试学科
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectId: option.key });
        } else {
            this.setState({ subjectId: '' });
        }
    }
    //查询
    search = () => {
        this.getMockTestList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.testName, subId: this.state.subjectId });
    }
    //获取考试名称
    getModalTestName = (e) => {
        this.setState({ modalTestName: e.target.value });
    }
    //获取考试时长
    getTestDuration = (value) => {
        this.setState({ testDuration: value });
    }
    //获取下拉所选学科
    getModalSubject = (value, option) => {
        if (value && option) {
            this.setState({ modalSubjectName: value, modalSubjectId: option.key });
        } else {
            this.setState({ modalSubjectName: null, modalSubjectId: '' });
        }
    }
    //新增、编辑 保存考试公用api
    editMockTest = (params, page) => {
        this.setState({ loading: true }, () => {
            api.editMockTest(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.paginationChange(page, this.state.pageSize);
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //复制考试api
    copyMockTest = (params) => {
        this.setState({ loading: true }, () => {
            api.copyMockTest(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //点击新建
    addTest = () => {
        this.setState({
            modalTestName: '',
            modalSubjectName: null,
            modalSubjectId: '',
            testDuration: '',
            addTestModal: true
        });
    }
    //新增确定
    addSubmit = () => {
        this.editMockTest({
            id: null,
            examName: this.state.modalTestName,
            subId: this.state.modalSubjectId,
            examDuration: this.state.testDuration
        }, 1);
    }
    //编辑
    edit = (record) => {
        this.setState({
            rowId: record.id,
            modalTestName: record.name,
            modalSubjectName: record.subjectName,
            modalSubjectId: record.subId,
            testDuration: record.examDuration,
            editTestModal: true
        });
    }
    //编辑确定
    editSubmit = () => {
        this.editMockTest({
            id: this.state.rowId,
            examName: this.state.modalTestName,
            subId: this.state.modalSubjectId,
            examDuration: this.state.testDuration
        }, this.state.page);
    }
    //复制
    copy = (record) => {
        this.setState({
            rowId: record.id,
            modalTestName: record.name,
            modalSubjectName: record.subjectName,
            modalSubjectId: record.subId,
            testDuration: record.examDuration,
        }, () => {
            this.copyMockTest({
                id: this.state.rowId,
                examName: `copy-${this.state.modalTestName}`,
                subId: this.state.modalSubjectId,
                examDuration: this.state.testDuration
            });
        });
    }
    //点击查看
    lookUp = (record) => {
        this.setState({ titleList: record.title, showLookUpModal: true });
    }
    //点击关联备考课名 跳转
    goPage = (item) => {
        window.open(api.pageURL + `/admin/v1/testPrepareCourseManage/courseOutline?id=${item.id}`);
    }
    //删除
    delete = (record) => {
        this.setState({ loading: true }, () => {
            api.deleteMockTest({ id: record.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭弹框
    close = () => {
        this.setState({ addTestModal: false, editTestModal: false, showLookUpModal: false, });
    }
    getJSX = () => {
        return (
            <Fragment>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>考试名称<span className={Style.red}>*</span>：</span>
                    <Input placeholder='请输入考试名称' className={Style.input} maxLength='200' value={this.state.modalTestName} onChange={this.getModalTestName} />
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>考试时长<span className={Style.red}>*</span>：</span>
                    <InputNumber placeholder='请输入考试时长' maxLength='3' className={Style.input} value={this.state.testDuration} onChange={this.getTestDuration} />&nbsp;&nbsp;min
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>学科：</span>
                    <Select placeholder='全部' className={Style.input} value={this.state.modalSubjectName} onChange={this.getModalSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                        {this.state.subjectList.map((item) => {
                            return (
                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                            )
                        })}
                    </Select>
                </div>
                <Divider />
            </Fragment>
        )
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getMockTestList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.testName, subId: this.state.subjectId });
        });
    }
    render() {
        let disabled = (this.state.modalTestName === '' || this.state.testDuration === '');
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <Button type='primary' icon={<PlusOutlined />} className={Style.text} onClick={() => { this.addTest() }}>新增考试</Button>
                            <span>资料ID：</span>
                            <InputNumber placeholder='请输入资料ID' maxLength='8' className={Style.input} onChange={this.getCourseId} />
                            <span>考试名称：</span>
                            <Input placeholder='请输入考试名称' maxLength='50' className={Style.input} onChange={this.getTestName} />
                            <span>考试学科：</span>
                            <Select className={Style.input} ref='subject' placeholder='全部' onChange={this.getSubject} allowClear={true} optionLabelProp="label" showSearch={true}>
                                {this.state.subjectList.length > 0 ? this.state.subjectList.map((item, index) => {
                                    return (
                                        <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                    )
                                }) : ''}
                            </Select>
                        </div>
                        <Button icon={<SearchOutlined />} type='primary' onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    ></Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    {this.state.addTestModal ? <Modal title='新增考试信息' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.addSubmit}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                    {this.state.editTestModal ? <Modal title='编辑考试信息' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.editSubmit}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                    {this.state.showLookUpModal ? <Modal title='关联备考课' close={this.close}>
                        <div className={Style.titleList}>
                            {this.state.titleList.map((item, index) => {
                                return (
                                    <Button type='link' className={Style.title} key={index} onClick={() => { this.goPage(item) }}>{item.title}</Button>
                                )
                            })}
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default MockTest;