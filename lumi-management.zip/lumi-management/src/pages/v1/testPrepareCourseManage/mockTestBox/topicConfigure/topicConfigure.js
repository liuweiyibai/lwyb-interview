import React, { Component, Fragment } from 'react';
import { Button, Table, Pagination, Input, Spin, Tooltip, Divider, InputNumber, message, Popconfirm, Upload } from 'antd';
import { LoadingOutlined, SearchOutlined, DoubleLeftOutlined, CloudUploadOutlined, CloudDownloadOutlined, MenuOutlined, UploadOutlined, PlusOutlined, DeleteOutlined, EditOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import api from '../../../../../utils/api';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import Style from './topicConfigure.module.less';

import { sortableContainer, sortableElement, sortableHandle } from 'react-sortable-hoc';
import arrayMove from 'array-move';

const DragHandle = sortableHandle(() => (
    <MenuOutlined style={{ cursor: 'pointer', color: '#999' }} />
));
const SortableItem = sortableElement(props => <tr {...props} />);
const SortableContainer = sortableContainer(props => <tbody {...props} />);
class TopicConfigure extends Component {
    constructor() {
        super()
        this.state = {
            id: '',
            testName: '',//考试名称
            testDuration: '',//考试时长
            loading: false,
            addTestModal: false,
            clickSearch: false,
            editTestTopicModal: false,
            addTestTopicModal: false,
            fileList: [],
            topicInfo: '',//题目id、内容
            searchData: [],
            page: 1,
            pageSize: 5,
            total: 0,
            //编辑、添加
            editAble: false,
            rowId: '',//所点击行id
            topicId: '',//题目id
            topicScore: '',//题目分数

            dataSource: [],
            totalPage: 0,
            totalScore: 0,
        }
    }
    searchColumns = [
        {
            title: '题目ID',
            dataIndex: 'id',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: id => (
                <Tooltip placement="top" title={id}>
                    {id}
                </Tooltip>
            ),
        },
        {
            title: '题干内容',
            dataIndex: 'content',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: content => (
                <Tooltip placement="top" title={content}>
                    {content}
                </Tooltip>
            ),
        },
        {
            title: '操作项',
            align: 'center',
            render: record => (
                <Button type='primary' icon={<PlusOutlined />} onClick={() => { this.addMockTest(record) }}>添加到考试</Button>
            ),
        }
    ]
    columns = [
        {
            title: 'Sort',
            width: 70,
            align: 'center',
            className: 'drag-visible',
            render: (record) => <DragHandle onClick={() => { this.getSortRowId(record) }} />,
        },
        {
            title: '题目序号',
            dataIndex: 'serialNumber',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: serialNumber => (
                <Tooltip placement="top" title={serialNumber + 1}>
                    {serialNumber + 1}
                </Tooltip>
            ),
        },
        {
            title: '题目ID',
            dataIndex: 'qid',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: qid => {
                return (
                    <Tooltip placement="top" title={qid}>
                        {qid}
                    </Tooltip>
                )
            },
        },
        {
            title: '题目分数',
            dataIndex: 'score',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: score => {
                return (
                    <Tooltip placement="top" title={score ? score : 0}>
                        {score ? score : 0}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            render: (record) => (
                <div>
                    <Button type='primary' icon={<EditOutlined />} className={Style.btn} onClick={() => { this.edit(record) }}>编辑</Button>
                    <Popconfirm title="确认要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.delete(record) }}>
                        <Button className={Style.btn} icon={<DeleteOutlined />} type='primary'>删除</Button>
                    </Popconfirm>
                </div>
            ),
        },
    ]
    componentDidMount() {
        this.setState({ id: this.props.location.search.split('=')[1].split('&')[0], testName: decodeURI(this.props.location.search.split('=')[2].split('&')[0]), testDuration: this.props.location.search.split('=')[3].split('&')[0] })
        this.getTestTopicsList();
        document.body.addEventListener('keyup', this.keyboardListener);
    }
    componentWillUnmount() {
        document.body.removeEventListener('keyup', this.keyboardListener);
        this.setState = () => {
            return;
        };
    }
    //监听回车事件
    keyboardListener = (e) => {
        if (window.event) {
            e = window.event;
        }
        if (e.keyCode === 13 || e.charCode === 13) {
            if (this.state.topicInfo === '') {
                message.warning('请输入题目信息！');
                return;
            }
            this.setState({ clickSearch: true }, () => {
                this.getSearchList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, content: this.state.topicInfo });
            })
        }
    }
    //获取题目列表
    getTestTopicsList = () => {
        this.setState({ loading: true }, () => {
            api.getTestTopicsList({ id: this.state.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.questionList, totalPage: data.result.totalCount, totalScore: data.result.totalScore, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //点击上传
    importTopics = () => {
        this.setState({ addTestModal: true });
    }
    //上传文件改变时的状态
    handleChange = ({ file, fileList }) => {
        if (file.name.split('.')[file.name.split('.').length - 1] !== 'xlsx' && file.name.split('.')[file.name.split('.').length - 1] !== 'xls') {
            message.warning('仅可上传Excel文件！');
            this.setState({ fileList: [] });
            return;
        }
        this.setState({ fileList });
    }
    //确定上传
    importSubmit = async () => {
        this.setState({ loading: true });
        for (let item of this.state.fileList) {
            let formData = new FormData();
            formData.append('file', item.originFileObj);
            await api.uploadCSV(formData)
                .then(async (data) => {
                    if (data.ret === 20000) {
                        this.setState({ loading: true });
                        await api.saveMockTestTopic({ fileName: data.result, id: this.state.id })
                            .then((data) => {
                                if (data.ret === 20000) {
                                    message.success(data.msg);
                                } else {
                                    return Promise.reject(data);
                                }
                            })
                            .catch((err) => {
                                message.error(err.msg);
                                this.setState({ loading: false });
                            })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ fileList: [], loading: false });
                })
        }
        this.setState({ fileList: [], addTestModal: false, loading: false });
        this.getTestTopicsList();
    }
    //获取题目id或内容
    getSearchInfo = (e) => {
        this.setState({ topicInfo: e.target.value });
    }
    //获取查询题目列表
    getSearchList = (params) => {
        this.setState({ loading: true }, () => {
            api.searchTopic(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ searchData: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //查询
    search = () => {
        if (this.state.topicInfo === '') {
            message.warning('请输入题目信息！');
            return;
        }
        this.setState({ clickSearch: true }, () => {
            this.getSearchList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, content: this.state.topicInfo });
        })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getSearchList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, content: this.state.topicInfo });
        })
    }

    //新建、编辑公共api
    editMockTestTopic = (params) => {
        this.setState({ loading: true }, () => {
            api.editMockTestTopic(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getTestTopicsList();
                        this.setState({ editTestTopicModal: false, addTestTopicModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //编辑
    edit = (record) => {
        this.setState({
            rowId: record.id,
            topicId: record.qid,
            topicScore: record.score,
            editTestTopicModal: true,
            editAble: false
        }, () => { })
    }
    //获取题目id
    getModalTopicId = (value) => {
        this.setState({ topicId: value });
    }
    //获取题目分数
    getModalTopicScore = (value) => {
        this.setState({ topicScore: value });
    }
    //确定编辑
    editSubmit = () => {
        this.editMockTestTopic({ id: this.state.rowId, pid: this.state.id, qid: this.state.topicId, score: this.state.topicScore });
    }
    //添加到考试
    addMockTest = (record) => {
        this.setState({
            topicId: record.id,
            topicScore: '',
            editAble: true,
            addTestTopicModal: true
        })
    }
    //添加题目
    addMockTestTopic = () => {
        this.setState({
            topicId: '',
            topicScore: '',
            editAble: false,
            addTestTopicModal: true
        })
    }
    //添加题目 确定
    addSubmit = () => {
        this.editMockTestTopic({ id: null, pid: this.state.id, qid: this.state.topicId, score: this.state.topicScore });
    }
    //删除
    delete = (record) => {
        this.setState({ loading: true }, () => {
            api.deleteMockTestTopic({ id: record.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.getTestTopicsList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭弹窗
    close = () => {
        this.setState({ addTestModal: false, editTestTopicModal: false, addTestTopicModal: false, fileList: [] });
    }
    getJSX = () => {
        return (
            <Fragment>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>题目ID<span className={Style.red}>*</span>：</span>
                    <InputNumber placeholder='请输入题目ID' min={1} maxLength='10' className={Style.input} value={this.state.topicId} disabled={this.state.editAble} onChange={this.getModalTopicId} />
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>题目分数<span className={Style.red}>*</span>：</span>
                    <InputNumber placeholder='请输入题目分数' maxLength='2' className={Style.input} value={this.state.topicScore} onChange={this.getModalTopicScore} />
                </div>
                <Divider />
            </Fragment>
        )
    }

    //获取拖拽行的id
    getSortRowId = (record) => {
        this.setState({ rowId: record.id });
    }
    //鼠标松开后
    onSortEnd = ({ oldIndex, newIndex }) => {
        const { dataSource } = this.state;
        if (oldIndex !== newIndex) {
            const newData = arrayMove([].concat(dataSource), oldIndex, newIndex).filter(el => !!el);
            let id = newData[newIndex].id;
            this.setState({ loading: true }, () => {
                api.sortMockTestTopic({ fromIndex: oldIndex, toIndex: newIndex, id: id, pid: this.state.id })
                    .then((data) => {
                        if (data.ret === 20000) {
                            this.getTestTopicsList();
                        } else {
                            return Promise.reject(data);
                        }
                    })
                    .catch((err) => {
                        message.error(err.msg);
                        this.setState({ loading: false });
                    })
            })
        }
    };
    DraggableBodyRow = ({ className, style, ...restProps }) => {
        const { dataSource } = this.state;
        const index = dataSource.findIndex(x => x.serialNumber === restProps['data-row-key']);
        return <SortableItem index={index} {...restProps} />;
    };
    render() {
        const DraggableContainer = props => (
            <SortableContainer
                useDragHandle
                helperClass="row-dragging"
                onSortEnd={this.onSortEnd}
                {...props}
            />
        );
        let disabled = this.state.topicId === '' || this.state.topicScore === '';
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.goBack}>
                        <Button type='link' icon={<DoubleLeftOutlined />} onClick={() => { this.props.history.push('/admin/v1/testPrepareCourseManage/mockTest') }}>返回模拟考试</Button>
                    </div>
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <Button type='primary' icon={<CloudUploadOutlined />} className={Style.text} onClick={() => { this.importTopics() }}>批量导入题目</Button>
                            <Button type='primary' className={Style.text}><a href='https://cdn.lumiclass.com/file/2020/08/14/a74a995a-a5e6-472a-b674-571e9f8b3715.xlsx' target='_self' className={Style.aTag}><CloudDownloadOutlined />&nbsp;下载导入模版</a></Button>
                            <Input placeholder='请输入题目 ID 或题目内容搜题' maxLength='50' className={Style.input} onChange={this.getSearchInfo} />
                        </div>
                        <Button icon={<SearchOutlined />} type='primary' disabled={this.state.topicInfo === ''} onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    {this.state.topicInfo !== '' && this.state.clickSearch ? <Fragment>
                        <Table
                            dataSource={this.state.searchData}
                            columns={this.searchColumns}
                            rowKey={searchData => searchData.id}
                            pagination={false}
                        ></Table>
                        <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} pageSizeOptions={[5, 10, 20, 50, 100]} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                        <Divider />
                    </Fragment> : ''}
                    <div className={Style.topicsTotal}>
                        <span className={Style.span}><b>题目总数：</b>{this.state.totalPage}</span>
                        <span className={Style.span}><b>题目总分：</b>{this.state.totalScore}</span>
                    </div>
                    <div className={Style.topicsTotal}>
                        <Tooltip placement="top" title={this.state.testName}>
                            <span className={Style.span}><b>考试名称：</b>{this.state.testName}</span>
                        </Tooltip>
                        <span className={Style.span}><b>考试时长：</b>{this.state.testDuration}</span>
                    </div>
                    <div className={Style.explain}>
                        <h4>列表中的题目顺序即试卷中的题目顺序</h4>
                        <Button type='primary' icon={<PlusOutlined />} onClick={this.addMockTestTopic}>添加题目</Button>
                    </div>
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.serialNumber}
                        pagination={false}
                        components={{
                            body: {
                                wrapper: DraggableContainer,
                                row: this.DraggableBodyRow,
                            },
                        }}
                    ></Table>
                    {this.state.addTestModal ? <Modal title='考试题目批量导入' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.importSubmit}>确定</Button>]}>
                        <div className={Style.text}><ExclamationCircleOutlined />&emsp;选择你制作好的考试题目配置 Excel 文件</div>
                        <Upload
                            className={Style.upload}
                            accept='.xlsx,.xls'
                            beforeUpload={()=>false}
                            onChange={this.handleChange}
                            fileList={this.state.fileList}
                            progress={
                                {
                                    strokeColor: {
                                        '0%': '#108ee9',
                                        '100%': '#87d068',
                                    },
                                    strokeWidth: 3,
                                    format: percent => `${parseFloat(percent.toFixed(2))}%`,
                                }
                            }
                        >
                            <Button icon={<UploadOutlined />}>选择文件</Button>
                        </Upload>
                    </Modal> : ''}
                    {this.state.editTestTopicModal ? <Modal title='编辑题目' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.editSubmit}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                    {this.state.addTestTopicModal ? <Modal title='添加题目' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.addSubmit}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default TopicConfigure;