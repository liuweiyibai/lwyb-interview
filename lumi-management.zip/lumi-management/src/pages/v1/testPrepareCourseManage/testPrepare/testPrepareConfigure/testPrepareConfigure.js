import React, { Component, Fragment } from 'react';
import {
  Button,
  Table,
  Pagination,
  Switch,
  Input,
  Select,
  Spin,
  Tooltip,
  Divider,
  InputNumber,
  message,
  Badge,
} from 'antd';
import {
  LoadingOutlined,
  SearchOutlined,
  EditOutlined,
  PlusOutlined,
  CloseCircleOutlined,
  DownloadOutlined,
  QrcodeOutlined,
} from '@ant-design/icons';
import UserSelect from '../../../../../components/userSelect/userSelect';
import Viewer from 'viewerjs';
import 'viewerjs/dist/viewer.css';
import Style from './testPrepareConfigure.module.less';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import Editor from 'wangeditor';
import api from '../../../../../utils/api';
import fun from '../../../../../utils/funSum.js';
import moment from 'moment';
import UserList from './components/userList';

const { Option } = Select;
class TestPrepareConfigure extends Component {
  constructor() {
    super();
    this.editor = null;
    this.editorRef = React.createRef();
    this.state = {
      loading: false,
      modalAdd: false, //新建 弹框
      modalEdit: false, //编辑 弹框
      subjectList: [],
      schoolList: [],
      dataSource: [],
      //搜索
      courseId: '', //备考课id
      courseTitle: '', //备考课标题
      subjectVal: null, //备考课学科名
      subjectId: '', //备考课学科id
      schoolVal: null, //备考课学校名
      schoolId: '', //备考课学校id
      //弹框
      modalCourseId: '', //所点击行的id
      courseName: '', //课程名称
      courseType: null, //课程类型名称
      subjectPic: '', //课程封面
      subjectIcon: '', //课程封面
      courseTypeId: null, //课程类型id
      checked: false, //课程状态
      schoolName: null, //学校名
      schoolSelId: '', //学校id
      subjectName: null, //学科名
      subjectSel: '', //学科id
      courseNum: '', //课号
      testYear: null, //目标考试年份
      testYearId: '', //目标考试年份id
      testDate: '', //考试时间
      deadDate: '', //有效期截止时间
      originalPrice: '', //课程原价
      presentPrice: '', //真实价格
      courseCover: '', //编辑新增时传的课程封面
      //二维码弹框
      showQRImgModal: false, //二维码 弹框
      qrImgSrc: '', //二维码链接
      inSelectUser: false, // 用户选择中
      currentCourse: null, // 当前选中课程
      page: 1,
      pageSize: 10,
      total: 0,
    };
  }
  columns = [
    {
      title: '课程ID',
      dataIndex: 'id',
      align: 'center',
      width: '80px',
      ellipsis: {
        showTitle: false,
      },
      render: (id) => (
        <Tooltip placement='top' title={id}>
          {id}
        </Tooltip>
      ),
    },
    {
      title: '课程标题',
      dataIndex: 'title',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (title) => (
        <Tooltip placement='top' title={title}>
          {title}
        </Tooltip>
      ),
    },
    {
      title: '课程类型',
      dataIndex: 'courseType',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (courseType) => (
        <Tooltip
          placement='top'
          title={courseType === 1 ? '公开课' : courseType === 2 ? '备考课' : ''}
        >
          {courseType === 1 ? '公开课' : courseType === 2 ? '备考课' : ''}
        </Tooltip>
      ),
    },
    {
      title: '学科',
      dataIndex: 'subjectName',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (subjectName) => (
        <Tooltip placement='top' title={subjectName}>
          {subjectName}
        </Tooltip>
      ),
    },
    {
      title: '学校',
      dataIndex: 'schoolName',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (schoolName) => (
        <Tooltip placement='topLeft' title={schoolName}>
          {schoolName}
        </Tooltip>
      ),
    },
    {
      title: '课号',
      dataIndex: 'courseNumber',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (courseNumber) => (
        <Tooltip placement='top' title={courseNumber}>
          {courseNumber}
        </Tooltip>
      ),
    },
    {
      title: '课程价格（美元）',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (record) => (
        <Tooltip
          placement='top'
          title={() =>
            `真实价格：${record.payPrice / 100} 课程原价：${
              record.originalPrice / 100
            }`
          }
        >
          {Number(record.payPrice) / 100}&emsp;
          <del>{Number(record.originalPrice) / 100}</del>
        </Tooltip>
      ),
    },
    {
      title: '课程状态',
      dataIndex: 'courseStatus',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (courseStatus) => (
        <Tooltip
          placement='top'
          title={
            courseStatus === 1 ? '开启' : courseStatus === 0 ? '关闭' : '关闭'
          }
        >
          {courseStatus === 1 ? '上线' : courseStatus === 0 ? '下线' : '下线'}
        </Tooltip>
      ),
    },
    {
      title: '操作项',
      align: 'center',
      width: '220px',
      render: (record) => (
        <div>
          <Button
            type='primary'
            size='small'
            className={Style.button}
            icon={<EditOutlined />}
            onClick={() => {
              this.edit(record);
            }}
          >
            编辑
          </Button>
          <Button
            type='link'
            size='small'
            onClick={() => {
              this.openCourses(record.id);
            }}
          >
            开通权限
          </Button>
          <Button
            type='link'
            size='small'
            onClick={() => {
              this.props.history.push(
                '/admin/v1/testPrepareCourseManage/courseOutline?id=' +
                  record.id
              );
            }}
          >
            课程大纲
          </Button>
          <Tooltip placement='top' title='二维码'>
            <Button
              type='link'
              size='small'
              onClick={() => {
                this.showQRImg(record);
              }}
            >
              <QrcodeOutlined />
            </Button>
          </Tooltip>
        </div>
      ),
    },
  ];
  componentDidMount() {
    this.getSubjectList();
    this.getSchoolList();
    this.getCourseList({
      iDisplayStart: this.state.page - 1,
      iDisplayLength: this.state.pageSize,
    });
    fun.addKeyboardListener(this.search); //监听回车查询事件
  }
  componentWillUnmount() {
    fun.removeKeyboardListener();
    this.setState = () => {
      return;
    };
  }
  // 显示用户选择/记录开课id
  openCourses(currentCourse) {
    this.setState({
      inSelectUser: true,
      currentCourse
    });
  }
  //获取学科列表
  getSubjectList = () => {
    this.setState({ loading: true }, () => {
      api
        .getSubjectList()
        .then((data) => {
          if (data.ret === 20000) {
            this.setState({ subjectList: data.result, loading: false });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          this.setState({ loading: false });
          message.error(err.msg);
        });
    });
  };
  //获取学校列表
  getSchoolList = () => {
    this.setState({ loading: true }, () => {
      api
        .getSchoolList()
        .then((data) => {
          if (data.ret === 20000) {
            this.setState({ schoolList: data.result, loading: false });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          message.error(err.msg);
          this.setState({ loading: false });
        });
    });
  };
  //获取table课程列表
  getCourseList = (params) => {
    this.setState({ loading: true }, () => {
      api
        .getTestPrepareCourseList(params)
        .then((data) => {
          if (data.ret === 20000) {
            this.setState({
              dataSource: data.result.data,
              page: data.result.start + 1,
              total: data.result.total,
              loading: false,
            });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          message.error(err.msg);
          this.setState({ loading: false });
        });
    });
  };
  //创建富文本实例
  editorInit = () => {
    this.editor = new Editor(this.editorRef.current);
    // 自定义菜单配置
    this.editor.customConfig.menus = [
      'head', // 标题
      'bold', // 粗体
      'fontSize', // 字号
      'fontName', // 字体
      'italic', // 斜体
      'underline', // 下划线
      'strikeThrough', // 删除线
      'foreColor', // 文字颜色
      'backColor', // 背景颜色
      'list', // 列表
      'justify', // 对齐方式
      'quote', // 引用
      'image', // 插入图片
      'undo', // 撤销
      'redo', // 重复
    ];
    // 隐藏“网络图片”tab
    this.editor.customConfig.showLinkImg = false;
    // 使用 base64 保存图片
    this.editor.customConfig.uploadImgShowBase64 = true;
    // 自定义字体
    this.editor.customConfig.fontNames = [
      '宋体',
      '微软雅黑',
      'Arial',
      'Tahoma',
      'Verdana',
    ];
    // 自定义配置颜色（字体颜色、背景色）
    this.editor.customConfig.colors = [
      '#000000',
      '#eeece0',
      '#1c487f',
      '#4d80bf',
      '#c24f4a',
      '#8baa4a',
      '#7b5ba1',
      '#46acc8',
      '#ffffff',
      '#f9963b',
    ];
    // 将图片大小限制为 100M
    this.editor.customConfig.uploadImgMaxSize = 100 * 1024 * 1024;
    // 限制一次最多上传 1 张图片
    this.editor.customConfig.uploadImgMaxLength = 1;
    //
    this.editor.customConfig.customUploadImg = (files, insert) => {
      // files 是 input 中选中的文件列表
      // insert 是获取图片 url 后，插入到编辑器的方法
      this.setState({ loading: true }, () => {
        api
          .getUploadPicUrl()
          .then((data) => {
            if (data.ret === 20000) {
              api
                .uploadAWS(data.result.url, files[0])
                .then((res) => {
                  insert(data.result.cmsCloudfront + '/' + data.result.key);
                  this.setState({ loading: false });
                })
                .catch((err) => {
                  message.error(err);
                });
            } else {
              return Promise.reject(data);
            }
          })
          .catch((err) => {
            message.error(err);
            this.setState({ loading: false });
          });
      });
      // 上传代码返回结果之后，将图片插入到编辑器中
    };
    //自定义错误提示方法
    this.editor.customConfig.customAlert = function (info) {
      // info 是需要提示的内容
      message.error(info);
    };
    this.editor.create();
  };
  //获取备考课id
  getCourseId = (e) => {
    this.setState({ courseId: e.target.value });
  };
  //获取备考课标题
  getCourseTitle = (e) => {
    this.setState({ courseTitle: e.target.value });
  };
  //获取备考课学科
  getSubject = (value, option) => {
    if (value && option) {
      this.refs.subject.blur();
      this.setState({ subjectId: option.key });
    } else {
      this.setState({ subjectId: '' });
    }
  };
  //获取备考课学校
  getSchool = (value, option) => {
    if (value && option) {
      this.refs.school.blur();
      this.setState({ schoolVal: value, schoolId: option.key });
    } else {
      this.setState({ schoolVal: null, schoolId: '' });
    }
  };
  //查询
  search = () => {
    this.getCourseList({
      iDisplayStart: 0,
      iDisplayLength: this.state.pageSize,
      id: this.state.courseId,
      title: this.state.courseTitle,
      subId: this.state.subjectId,
      schoolId: this.state.schoolId,
    });
  };
  //----------------弹框
  //获取备考课程名称
  getCourseName = (e) => {
    this.setState({ courseName: e.target.value });
  };
  //获取课程类型
  getCourseType = (value, option) => {
    if (value && option) {
      this.setState({ courseType: value, courseTypeId: option.key });
    } else {
      this.setState({ courseType: null, courseTypeId: '' });
    }
  };
  //switch课程状态
  changeStatus = (checked) => {
    this.setState({ checked });
  };
  //获取学校
  getSchoolSel = (value, option) => {
    if (value && option) {
      this.setState({ schoolName: value, schoolSelId: option.key });
    } else {
      this.setState({ schoolName: null, schoolSelId: '' });
    }
  };
  //获取学科
  getSubjectSel = (value, option) => {
    if (value && option) {
      this.setState({ subjectName: value, subjectSel: option.key });
    } else {
      this.setState({ subjectName: null, subjectSel: '' });
    }
  };
  //获取课号
  getCourseNum = (e) => {
    this.setState({ courseNum: e.target.value });
  };
  //获取目标考试年份
  getTestYear = (value, option) => {
    if (value && option) {
      this.setState({ testYear: value, testYearId: option.key });
    } else {
      this.setState({ testYear: null, testYearId: '' });
    }
  };
  //获取考试时间
  getTestDate = (date, dateString) => {
    this.setState({ testDate: dateString });
  };
  //获取有效期截止时间
  getDeadDate = (date, dateString) => {
    this.setState({ deadDate: dateString });
  };
  //获取课程原价
  getOriginalPrice = (value) => {
    this.setState({ originalPrice: value });
  };
  //获取真实价格
  getPresentPrice = (value) => {
    this.setState({ presentPrice: value });
  };
  //点击新建课程
  add = () => {
    this.setState(
      {
        modalCourseId: '',
        courseName: '',
        courseType: null,
        courseTypeId: null,
        checked: false,
        schoolName: null,
        schoolSelId: '',
        subjectName: null,
        subjectSel: '',
        courseNum: '',
        testYear: null,
        testYearId: '',
        testDate: null,
        deadDate: null,
        originalPrice: '',
        presentPrice: '',
        subjectPic: '',
        modalAdd: true,
      },
      () => {
        this.editorInit();
      }
    );
  };
  //弹框公用jsx
  getJSX = () => {
    return (
      <Fragment>
        <div className={Style.modalWrap}>
          <span>
            课程名称<span className={Style.red}>*</span>：
          </span>
          <Input
            maxLength='200'
            className={Style.modalInput}
            placeholder='请输入课程名称'
            value={this.state.courseName}
            onChange={this.getCourseName}
          />
        </div>
        <div className={Style.modalWrap}>
          <span>
            课程类型<span className={Style.red}>*</span>：
          </span>
          <Select
            placeholder='全部'
            className={Style.modalInput}
            value={this.state.courseType}
            onChange={this.getCourseType}
            allowClear={true}
            optionLabelProp='label'
            showSearch={true}
          >
            <Option key='1' value='公开课'>
              公开课
            </Option>
            <Option key='2' value='备考课'>
              备考课
            </Option>
          </Select>
        </div>

        <div className={Style.modalWrap}>
          <span>
            课程状态<span className={Style.red}>*</span>：
          </span>
          <Switch
            checked={this.state.checked}
            onChange={this.changeStatus}
            checkedChildren='上线'
            unCheckedChildren='下线'
          />
        </div>
        <div className={Style.modalWrap}>
          <span>
            学校<span className={Style.red}>*</span>：
          </span>
          <Select
            placeholder='全部'
            className={Style.modalInput}
            value={this.state.schoolName}
            onChange={this.getSchoolSel}
            allowClear={true}
            optionLabelProp='label'
            showSearch={true}
          >
            {this.state.schoolList.map((item, index) => {
              return (
                <Option key={item.id} value={item.name}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        </div>
        <div className={Style.modalWrap}>
          <span>
            学科<span className={Style.red}>*</span>：
          </span>
          <Select
            placeholder='全部'
            className={Style.modalInput}
            value={this.state.subjectName}
            onChange={this.getSubjectSel}
            allowClear={true}
            optionLabelProp='label'
            showSearch={true}
          >
            {this.state.subjectList.map((item, index) => {
              return (
                <Option key={item.id} value={item.subjectName}>
                  {item.subjectName}
                </Option>
              );
            })}
          </Select>
        </div>
        <div className={Style.modalWrap}>
          <span>课号：</span>
          <Input
            placeholder='请输入课号'
            maxLength='50'
            className={Style.modalInput}
            value={this.state.courseNum}
            onChange={this.getCourseNum}
          />
        </div>
        <div className={Style.modalWrap}>
          <span>目标考试年份：</span>
          <Select
            placeholder='全部'
            className={Style.modalInput}
            value={this.state.testYear}
            onChange={this.getTestYear}
            allowClear={true}
            optionLabelProp='label'
            showSearch={true}
          >
            <Option
              key={new Date().getFullYear() - 1}
              value={new Date().getFullYear() - 1}
            >
              {new Date().getFullYear() - 1}
            </Option>
            <Option
              key={new Date().getFullYear()}
              value={new Date().getFullYear()}
            >
              {new Date().getFullYear()}
            </Option>
            <Option
              key={new Date().getFullYear() + 1}
              value={new Date().getFullYear() + 1}
            >
              {new Date().getFullYear() + 1}
            </Option>
            <Option
              key={new Date().getFullYear() + 2}
              value={new Date().getFullYear() + 2}
            >
              {new Date().getFullYear() + 2}
            </Option>
          </Select>
        </div>
        {/* <div className={Style.modalWrap}>
                    <span>考试时间（美东时间）{this.state.courseType === '备考课' ? <span className={Style.red}>*</span> : ''}：</span>
                    <DatePicker
                        format="YYYY-MM-DD HH:mm:ss"
                        defaultValue={this.state.testDate ? moment(this.state.testDate) : ''}
                        onChange={this.getTestDate}
                        showTime={true}
                    />
                </div>
                <div className={Style.modalWrap}>
                    <span>有效期截止时间（美东时间）<span className={Style.red}>*</span>：</span>
                    <DatePicker
                        format="YYYY-MM-DD HH:mm:ss"
                        defaultValue={this.state.deadDate ? moment(this.state.deadDate) : ''}
                        onChange={this.getDeadDate}
                        showTime={true}
                    />
                </div> */}
        <div className={Style.wrapper}>
          <div className={Style.left}>
            <div className={Style.modalWrap}>
              <span>课程原价（美元）：</span>
              <InputNumber
                placeholder='请输入课程原价'
                min={0}
                maxLength='10'
                value={this.state.originalPrice}
                step={0.01}
                precision={2}
                onChange={this.getOriginalPrice}
              />
            </div>
            <div className={Style.modalWrap}>
              <span>
                真实价格（美元）<span className={Style.red}>*</span>：
              </span>
              <InputNumber
                placeholder='请输入真实价格'
                min={0}
                maxLength='10'
                value={this.state.presentPrice}
                step={0.01}
                precision={2}
                onChange={this.getPresentPrice}
              />
            </div>
          </div>
          <div className={Style.right}>
            <div className={Style.modalWrap}>
              <span className={Style.coursePicSpan}>
                课程封面<span className={Style.red}>*</span>：
              </span>
              {this.state.subjectPic.length > 0 ? (
                <span>
                  <img
                    className={Style.zmage}
                    ref={'course' + this.state.subjectPic}
                    src={this.state.subjectPic}
                    alt='题目图片'
                  ></img>
                  <Badge
                    count={
                      <CloseCircleOutlined
                        onClick={() => {
                          this.setState({ subjectPic: '' });
                        }}
                        className={Style.popconfirm}
                      />
                    }
                  ></Badge>
                </span>
              ) : (
                <Button
                  type='primary'
                  icon={<PlusOutlined />}
                  size='default'
                  onClick={() => {
                    this.refs.coverInput.click();
                  }}
                >
                  添加封面
                </Button>
              )}
            </div>
          </div>
        </div>
        <div className={Style.modalWrap}>
          <span>
            课程简介<span className={Style.red}>*</span>：
          </span>
          <div ref={this.editorRef}></div>
        </div>
      </Fragment>
    );
  };
  // input的onchange事件-添加课程封面
  inputChange = async (e) => {
    if (!e.target.files[0]) return;
    const file = e.target.files[0];
    const fileType = file ? file.type.split('/')[0] : '';
    if (fileType !== 'image') {
      message.error('只能上传图片');
      return false;
    } else {
      this.setState({ loading: true });
      // 图片上传预签名  获取AWS上传地址
      await api
        .getPicAwsAddress()
        .then(async (data) => {
          if (data.ret === 20000) {
            let newFile = await fun.removeExif(file);
            //往aws上传
            // await api.uploadAWS(data.result.url, file, { headers: { 'Content-Type': 'image/png' } })
            await api
              .uploadAWS(data.result.url, newFile, {
                headers: { 'Content-Type': 'image/png' },
              })
              .then(async (result) => {
                message.success(file.name + '上传成功');
                this.setState(
                  {
                    subjectPic:
                      data.result.cmsCloudfront + '/' + data.result.key,
                    subjectIcon: data.result.key,
                    loading: false,
                  },
                  () => {
                    if (this.refs['course' + this.state.subjectPic]) {
                      new Viewer(
                        this.refs['course' + this.state.subjectPic],
                        {}
                      );
                    }
                  }
                );
              })
              .catch((err) => {
                message.error(err.msg);
              });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          message.error(err.msg);
        });
    }
  };
  //新建确定
  sureAdd = () => {
    if (this.editor.txt.html() === '<p><br></p>') {
      message.warning('请输入课程简介！');
      return;
    }
    this.setState({ loading: true }, () => {
      api
        .editTestPrepareCourse({
          courseCover: this.state.subjectIcon,
          id: null,
          title: this.state.courseName,
          courseType: this.state.courseTypeId,
          courseStatus: this.state.checked === true ? 1 : 0,
          schoolId: this.state.schoolSelId,
          subId: this.state.subjectSel,
          courseNumber: this.state.courseNum,
          examYear: this.state.testYear,
          examAtStr: this.state.testDate,
          viewDeadlineStr: this.state.deadDate,
          originalPrice: Number((this.state.originalPrice * 100).toFixed()),
          payPrice: Number((this.state.presentPrice * 100).toFixed()),
          courseIntroduction: this.editor.txt.html(),
        })
        .then((data) => {
          if (data.ret === 20000) {
            this.paginationChange(1, this.state.pageSize);
            this.setState({ modalAdd: false });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          message.error(err.msg);
          this.setState({ modalAdd: false, loading: false });
        });
    });
  };
  //点击编辑
  edit = (record) => {
    this.setState(
      {
        modalCourseId: record.id,
        courseName: record.title,
        courseType:
          record.courseType === 1
            ? '公开课'
            : record.courseType === 2
            ? '备考课'
            : '',
        courseTypeId: record.courseType,
        checked: record.courseStatus === 1 ? true : false,
        schoolName: record.schoolName,
        schoolSelId: record.schoolId,
        subjectName: record.subjectName,
        subjectSel: record.subId,
        courseNum: record.courseNumber,
        testYear: record.examYear === 0 ? '' : record.examYear,
        testYearId: record.examYear,
        testDate: record.examAt
          ? moment(record.examAt).format('YYYY-MM-DD HH:mm:ss')
          : '',
        deadDate: record.viewDeadline
          ? moment(record.viewDeadline).format('YYYY-MM-DD HH:mm:ss')
          : '',
        originalPrice: record.originalPrice / 100,
        presentPrice: record.payPrice / 100,
        subjectPic: record.cloudFrontUrl + '/' + record.courseCover,
        subjectIcon: record.courseCover,
        modalEdit: true,
      },
      () => {
        if (this.refs['course' + this.state.subjectPic]) {
          new Viewer(this.refs['course' + this.state.subjectPic], {});
        }
        this.editorInit();
        this.editor.txt.html(record.courseIntroduction);
      }
    );
  };
  //编辑确定
  sureEdit = () => {
    if (this.editor.txt.html() === '<p><br></p>') {
      message.warning('请输入课程简介！');
      return;
    }
    this.setState({ loading: true }, () => {
      api
        .editTestPrepareCourse({
          courseCover: this.state.subjectIcon,
          id: this.state.modalCourseId,
          title: this.state.courseName,
          courseType: this.state.courseTypeId,
          courseStatus: this.state.checked === true ? 1 : 0,
          schoolId: this.state.schoolSelId,
          subId: this.state.subjectSel,
          courseNumber: this.state.courseNum,
          examYear: this.state.testYear,
          examAtStr: this.state.testDate,
          viewDeadlineStr: this.state.deadDate,
          originalPrice: Number((this.state.originalPrice * 100).toFixed()),
          payPrice: Number((this.state.presentPrice * 100).toFixed()),
          courseIntroduction: this.editor.txt.html(),
        })
        .then((data) => {
          if (data.ret === 20000) {
            message.success(data.msg);
            this.paginationChange(this.state.page, this.state.pageSize);
            this.setState({ modalEdit: false });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          message.error(err.msg);
          this.setState({ modalEdit: false, loading: false });
        });
    });
  };
  //展示二维码弹框
  showQRImg = (record) => {
    this.setState({
      showQRImgModal: true,
      qrImgSrc: record.cloudFrontUrl + '/' + record.qrCode,
    });
  };
  //关闭弹框
  close = () => {
    this.setState({ modalAdd: false, modalEdit: false, showQRImgModal: false });
  };
  //分页
  paginationChange = (page, pageSize) => {
    this.setState({ page, pageSize }, () => {
      this.getCourseList({
        iDisplayStart: this.state.page - 1,
        iDisplayLength: this.state.pageSize,
        id: this.state.courseId,
        title: this.state.courseTitle,
        subId: this.state.subjectId,
        schoolId: this.state.schoolId,
      });
    });
  };
  // 给用户开课
  openCoursesWithUser = (users) => {
    const { currentCourse } = this.state;
    this.setState({ inSelectUser: false, loading:true },()=>{
      api.addUserToCourse({ preExamCourseId:currentCourse, userIds: users }).then(res => {
        const { ret, msg } = res;
        if(ret === 20000){
          message.success(`用户开课成功!`);
        } else {
          message.error(msg);
        }
        this.setState({loading: false, currentCourse: null});
      })
    });
  }
  render() {
    let disabled = !(
      Boolean(this.state.courseName) &&
      this.state.courseType &&
      Boolean(this.state.courseTypeId) &&
      Boolean(this.state.schoolName) &&
      this.state.schoolSelId !== '' &&
      Boolean(this.state.subjectName) &&
      Boolean(this.state.subjectSel) &&
      Boolean(this.state.subjectPic) &&
      this.state.presentPrice !== ''
    );
    return (
      <Fragment>
        <Spin
          spinning={this.state.loading}
          indicator={<LoadingOutlined />}
          tip='请稍候...'
          size='large'
        >
          <input
            type='file'
            id='cover-input'
            ref='coverInput'
            accept='image/png, image/jpeg, image/jpg'
            style={{ display: 'none' }}
            onChange={(e) => this.inputChange(e)}
          />
          <div className={Style.searchWrap}>
            <div className={Style.left}>
              <Button
                type='primary'
                icon={<PlusOutlined />}
                className={Style.box}
                onClick={this.add}
              >
                新建课程
              </Button>
              <span>备考课ID：</span>
              <Input
                placeholder='请输入备考课ID'
                className={Style.infoBox}
                value={this.state.courseId}
                onChange={this.getCourseId}
              />
              <span>备考课标题：</span>
              <Input
                placeholder='请输入备考课标题'
                className={Style.infoBox}
                value={this.state.courseTitle}
                onChange={this.getCourseTitle}
              />
              <span>学科：</span>
              <Select
                className={Style.infoBox}
                ref='subject'
                placeholder='全部'
                onChange={this.getSubject}
                allowClear={true}
                optionLabelProp='label'
                showSearch={true}
              >
                {this.state.subjectList.length > 0
                  ? this.state.subjectList.map((item) => {
                      return (
                        <Option key={item.id} value={item.subjectName}>
                          {item.subjectName}
                        </Option>
                      );
                    })
                  : ''}
              </Select>
              <span>学校：</span>
              <Select
                className={Style.infoBox}
                ref='school'
                placeholder='全部'
                onChange={this.getSchool}
                allowClear={true}
                optionLabelProp='label'
                showSearch={true}
              >
                {this.state.schoolList.length > 0
                  ? this.state.schoolList.map((item) => {
                      return (
                        <Option key={item.id} value={item.name}>
                          {item.name}
                        </Option>
                      );
                    })
                  : ''}
              </Select>
            </div>
            <Button
              type='primary'
              icon={<SearchOutlined />}
              onClick={this.search}
            >
              查询
            </Button>
          </div>
          <Divider />
          <Table
            dataSource={this.state.dataSource}
            expandable={{
                expandedRowRender: record => <UserList id={record.id} />,
                rowExpandable: record => record.id
            }}
            columns={this.columns}
            rowKey={(dataSource) => dataSource.id}
            bordered={true}
            pagination={false}
          ></Table>
          <Pagination
            showQuickJumper
            hideOnSinglePage
            className={Style.pagination}
            current={this.state.page}
            pageSize={this.state.pageSize}
            total={this.state.total}
            onChange={this.paginationChange}
            showTotal={(total) => `Total ${total} items`}
          ></Pagination>
          {this.state.modalAdd ? (
            <Modal
              title='新建课程'
              close={this.close}
              actions={[
                <Button onClick={this.close}>取消</Button>,
                <Button
                  type='primary'
                  disabled={disabled}
                  onClick={this.sureAdd}
                >
                  确定
                </Button>,
              ]}
            >
              {this.getJSX()}
            </Modal>
          ) : (
            ''
          )}
          {this.state.modalEdit ? (
            <Modal
              title='编辑课程'
              close={this.close}
              actions={[
                <Button onClick={this.close}>取消</Button>,
                <Button
                  type='primary'
                  disabled={disabled}
                  onClick={this.sureEdit}
                >
                  确定
                </Button>,
              ]}
            >
              {this.getJSX()}
            </Modal>
          ) : (
            ''
          )}
          {this.state.showQRImgModal ? (
            <Modal title='显示二维码' close={this.close}>
              <img src={this.state.qrImgSrc} alt='二维码图片' />
              <div className={Style.btnWrap}>
                <a className={Style.download} href={this.state.qrImgSrc}>
                  {' '}
                  <Button type='primary' icon={<DownloadOutlined />}>
                    下载
                  </Button>
                </a>
              </div>
            </Modal>
          ) : (
            ''
          )}
          <UserSelect
            visible={this.state.inSelectUser}
            isMultiple
            onCancel={() => this.setState({ inSelectUser: false, currentCourse: null })}
            onOk={this.openCoursesWithUser}
          ></UserSelect>
        </Spin>
      </Fragment>
    );
  }
}

export default TestPrepareConfigure;
