import React from 'react';
import { Table } from 'antd';
import api from '../../../../../../utils/api';
import funSum from '../../../../../../utils/funSum';

export default class UserList extends React.Component {
  columns = [
    funSum.getColumnItem('用户ID', 'id', '80px'),
    funSum.getColumnItem('邮箱', 'email', '160px'),
    funSum.getColumnItem('手机号', 'phoneNumber'),
    funSum.getColumnItem('昵称', 'nickname'),
    funSum.getColumnTimeItem('开课时间', 'createdAt', 1, 'auto')
  ];
  constructor(props) {
    super();
    this.state = {
      courseId: props.id,
      columns: this.columns,
      dataSource: [],
      loading: false,
      pagination: {
        size: 10,
        total: 0,
        current: 1,
      },
    };
  }

  componentDidMount() {
    this.upload();
  }

  upload() {
    this.setState({
      loading: true
    }, () => {
      const { courseId, pagination } = this.state;
      api
        .getUserListForCourse({
          id: courseId,
          iDisplayLength: pagination.size,
          iDisplayStart: pagination.size * (pagination.current - 1),
        })
        .then((res) => {
          const { data, total } = res.result || {};
          pagination.total = total;
          this.setState({ loading:false, dataSource: data, pagination })
        });
    });
  }

  onPageChange(page){
    const { pagination } = this.state;
    pagination.current = page;
    this.setState({pagination}, ()=> {
      this.upload();
    });
  }

  render() {
    const { loading, columns, dataSource, pagination } = this.state;
    return (
      <React.Fragment>
        <Table
          pagination={{
            hideOnSinglePage: true,
            total: pagination.total,
            defaultPageSize: pagination.size,
            onChange: (page)=> this.onPageChange(page)
          }}
          style={{ padding: '15px' }}
          rowKey={(record) => record.id}
          loading={loading}
          columns={columns}
          dataSource={dataSource}
        />
      </React.Fragment>
    );
  }
}
