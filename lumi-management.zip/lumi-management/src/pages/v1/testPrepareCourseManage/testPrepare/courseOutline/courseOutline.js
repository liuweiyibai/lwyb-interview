import React, { Component, Fragment } from 'react';
import { Button, Table, Pagination, Tooltip, Checkbox, Input, Select, Popconfirm, Spin, message, Radio } from 'antd';
import { DoubleLeftOutlined, YoutubeOutlined, VideoCameraOutlined, FilePdfOutlined, ContainerOutlined, LoadingOutlined, DeleteOutlined, SearchOutlined, PlusOutlined } from '@ant-design/icons';
import Style from './courseOutline.module.less';
import Sortable from "sortablejs";
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import api from '../../../../../utils/api';

const { Option } = Select;
class CourseOutline extends Component {
    constructor() {
        super()
        this.state = {
            id: '',
            courseInfo: {},//题目信息
            loading: false,
            showModal: false,
            clickSearch: false,
            List: [],
            radioValue: '',//radio所选value
            courseId: '',//资源id
            courseName: '',//资源名
            subjectList: [],
            subjectId: '',//学科id
            dataSource: [],
            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '资源ID',
            dataIndex: 'id',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: id => (
                <Tooltip placement="top" title={id}>
                    {id}
                </Tooltip>
            ),
        },
        {
            title: '资源名称',
            dataIndex: 'name',
            align: 'center',
            render: name => (
                <Tooltip placement="top" title={name}>
                    {name}
                </Tooltip>
            )
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            )
        },
        {
            title: '操作项',
            align: 'center',
            render: record => (
                <Button type='primary' icon={<PlusOutlined />} onClick={() => { this.joinCourse(record) }}>加入课程</Button>
            )
        },
    ]

    componentDidMount() {
        this.setState({ id: this.props.location.search !== '' ? this.props.location.search.split('=')[1] : '' });
        new Sortable(this.refs.box, {
            swapThreshold: 1,//交换区阈值
            animation: 300,//排序动画时间
            ghostClass: 'blue-background-class',
            onEnd: (evt) => {
                //解决插件移动后调用接口，数据顺序改变，dom顺序不改变问题
                this.sort({ pre: evt.item.previousSibling !== null ? evt.item.previousSibling.getAttribute('data-sortnum') : 0, after: evt.item.nextSibling !== null ? evt.item.nextSibling.getAttribute('data-sortnum') : -1, id: evt.item.getAttribute('data-id'), pid: evt.item.getAttribute('data-pid') });
            },
        })
        this.getCourseInfo();
        this.getCourseList();
        this.getSubjectList();
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    //解决数据与dom元素顺序不同步bug
    initDom = (evt, box) => {
        let $tr = box.children[evt.newIndex];
        let $oldTr = box.children[evt.oldIndex];
        // 先删除移动的节点
        box.removeChild($tr);
        // 再插入移动的节点到原有节点，还原了移动的操作
        if (evt.newIndex > evt.oldIndex) {
            box.insertBefore($tr, $oldTr);
        } else {
            box.insertBefore($tr, $oldTr.nextSibling);
        }
    }
    //排序
    sort = (params) => {
        this.setState({ loading: true }, () => {
            api.courseSort(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getCourseList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取题目信息
    getCourseInfo = () => {
        this.setState({ loading: true }, () => {
            api.getCourseInfo({ id: this.state.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ courseInfo: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取课程大纲
    getCourseList = () => {
        this.setState({ loading: true }, () => {
            api.getCourseList({ id: this.state.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ List: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取学科列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //获取radio
    getRadioChange = (e) => {
        this.setState({ radioValue: e.target.value });
    }
    //获取资id
    getCourseId = (e) => {
        this.setState({ courseId: e.target.value })
    }
    //获取资源名
    getCourseName = (e) => {
        this.setState({ courseName: e.target.value })
    }
    //获取备考课学科
    getSubject = (value, option) => {
        if (value && option) {
            this.setState({ subjectId: option.key });
        } else {
            this.setState({ subjectId: '' });
        }
    }
    //获取录播、知识点视频列表
    getKnowledgeVideoList = (params) => {
        this.setState({ loading: true }, () => {
            api.getVideoList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //获取直播课列表
    getLiveCourseList = (params) => {
        this.setState({ loading: true }, () => {
            api.getLiveCourseList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //获取课程资料列表
    getCourseMaterialsList = (params) => {
        this.setState({ loading: true }, () => {
            api.getCourseMaterialsList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //获取模拟考试列表
    getMockTestList = (params) => {
        this.setState({ loading: true }, () => {
            api.getMockTestList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //查询、分页 公共方法封装
    witchRadio = () => {
        switch (this.state.radioValue) {
            case 1: //获取录播视频列表
                this.getKnowledgeVideoList({ videoType: 1, iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, videoName: this.state.courseName, subId: this.state.subjectId });
                break;
            case 2: //获取直播课列表
                this.getLiveCourseList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
                break;
            case 3: //获取知识点视频列表
                this.getKnowledgeVideoList({ videoType: 0, iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, videoName: this.state.courseName, subId: this.state.subjectId });
                break;
            case 4: //获取课程资料列表
                this.getCourseMaterialsList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
                break;
            case 5: //获取模拟考试列表
                this.getMockTestList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
                break;
            default:
                break;
        }
    }
    //查询
    search = () => {
        this.setState({ page: 1, pageSize: 10, clickSearch: true, loading: true }, () => {
            this.witchRadio();
        })
    }
    //加入课程
    joinCourse = (record) => {
        this.setState({ loading: true }, () => {
            api.joinCourse({ pid: this.state.id, sourceId: record.id, sourceType: this.state.radioValue })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.getCourseList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //关闭弹窗
    close = () => {
        this.setState({ showModal: false, clickSearch: false });
    }
    //确定删除
    sureDelete = (item) => {
        this.setState({ loading: true }, () => {
            api.deleteCourse({ id: item.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getCourseList();
                        this.setState({ loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //checkbox试看
    checkedChange = (e, item) => {
        this.setState({ loading: true }, () => {
            api.changeCourseIsView({ id: item.id, videoMarker: e.target.checked === true ? 1 : 0 })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getCourseList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            switch (this.state.radioValue) {
                case 1: //获取录播视频列表
                    this.getKnowledgeVideoList({ videoType: 1, iDisplayStart: page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, videoName: this.state.courseName, subId: this.state.subjectId });
                    break;
                case 2: //获取直播课列表
                    this.getLiveCourseList({ iDisplayStart: page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
                    break;
                case 3: //获取知识点视频列表
                    this.getKnowledgeVideoList({ videoType: 0, iDisplayStart: page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, videoName: this.state.courseName, subId: this.state.subjectId });
                    break;
                case 4: //获取课程资料列表
                    this.getCourseMaterialsList({ iDisplayStart: page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
                    break;
                case 5: //获取模拟考试列表
                    this.getMockTestList({ iDisplayStart: page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
                    break;
                default:
                    break;
            }
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.goBack}>
                        <Button type='link' icon={<DoubleLeftOutlined />} onClick={() => { this.props.history.push('/admin/v1/testPrepareCourseManage/testPrepareConfigure') }}>返回备考课配置</Button>
                    </div>
                    <div className={Style.infoBox}>
                        <div className={Style.info}>
                            <h4>课程名称：</h4>
                            <span>{this.state.courseInfo.title !== '' ? this.state.courseInfo.title : '暂无数据'}</span>
                        </div>
                        <div className={Style.info}>
                            <h4>学科：</h4>
                            <span>{this.state.courseInfo.subjectName !== '' ? this.state.courseInfo.subjectName : '暂无数据'}</span>
                        </div>
                    </div>
                    <div className={Style.infoBox}>
                        <div className={Style.info}>
                            <h4>学校：</h4>
                            <span>{this.state.courseInfo.schoolName !== '' ? this.state.courseInfo.schoolName : '暂无数据'}</span>
                        </div>
                        <div className={Style.info}>
                            <h4>课号：</h4>
                            <span>{this.state.courseInfo.courseNumber !== '' ? this.state.courseInfo.courseNumber : '暂无数据'}</span>
                        </div>
                    </div>
                    <div className={Style.addBtn}>
                        <Button type='primary' icon={<PlusOutlined />} onClick={() => { this.setState({ showModal: true, radioValue: '' }) }}>添加资源</Button>
                    </div>
                    <div className={Style.listHeader} >
                        <span className={Style.operation}>操作</span>
                        <span className={Style.courseType}>资源类型 </span>
                        <div className={Style.courseId}>
                            <span className={Style.courseType}>资源ID</span>
                        </div>
                        <div className={Style.courseType}>
                            <Tooltip placement="top" > 资源名称 </Tooltip>
                        </div>
                        <span className={Style.checkBox}></span>

                    </div>
                    <div ref='box'>
                        {this.state.List.map((item) => {
                            return (
                                <div key={item.serialNumber} className={Style.listWrap} data-sortnum={item.serialNumber} data-id={item.id} data-pid={item.pid}>
                                    <Popconfirm title="确定要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.sureDelete(item) }}>
                                        <Button type='primary' icon={<DeleteOutlined />} className={Style.delete}>删除</Button>
                                    </Popconfirm>
                                    <span className={Style.courseType}>
                                        {(item.sourceType === 1 || item.sourceType === 3) ? <YoutubeOutlined className={Style.icon} /> : item.sourceType === 2 ? <VideoCameraOutlined className={Style.icon} /> : item.sourceType === 4 ? <FilePdfOutlined className={Style.icon} /> : item.sourceType === 5 ? <ContainerOutlined className={Style.icon} /> : '暂无资源类型'}
                                    </span>
                                    <div className={Style.courseId}>
                                        {item.sourceId ? item.sourceId : <span className={Style.courseType}>暂无资源ID</span>}
                                    </div>
                                    <div className={Style.courseType}>
                                        <Tooltip placement="top" title={item.sourceName}>
                                            {item.sourceName}
                                        </Tooltip>
                                    </div>
                                    {(item.sourceType === 1 || item.sourceType === 3) ? <Checkbox className={Style.checkBox} checked={item.videoMarker === 1 ? true : false} onChange={(e) => { this.checkedChange(e, item) }}>试看</Checkbox> : <span className={Style.checkBox}></span>}
                                </div>
                            )
                        })}
                    </div>
                    {this.state.showModal ? <Modal title='添加资源' close={this.close}>
                        <Radio.Group onChange={this.getRadioChange}>
                            <Radio value={1}>录播视频</Radio>
                            <Radio value={2}>直播课</Radio>
                            <Radio value={3}>知识点视频</Radio>
                            <Radio value={4}>课程资料</Radio>
                            <Radio value={5}>模拟考试</Radio>
                        </Radio.Group>
                        <div className={Style.modalSearch}>
                            <div>
                                <span>资源ID：</span>
                                <Input placeholder='请输入资源ID' className={Style.text} onChange={this.getCourseId} />
                                <span>资源名称：</span>
                                <Input placeholder='请输入资源名称' className={Style.text} onChange={this.getCourseName} />
                                <span>学科：</span>
                                <Select className={Style.text} placeholder='全部' onChange={this.getSubject} allowClear={true} optionLabelProp="label" showSearch={true}>
                                    {this.state.subjectList.length > 0 ? this.state.subjectList.map((item) => {
                                        return (
                                            <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                        )
                                    }) : ''}
                                </Select>
                            </div>
                            <Button type='primary' icon={<SearchOutlined />} onClick={this.search} disabled={this.state.radioValue === ''}>查询</Button>
                        </div>
                        {this.state.radioValue !== '' && this.state.clickSearch ? <Table
                            className={Style.table}
                            dataSource={this.state.dataSource}
                            columns={this.columns}
                            rowKey={dataSource => dataSource.id}
                            bordered={true}
                            pagination={false}
                            loading={this.state.loading}
                        ></Table> : ''}
                        <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default CourseOutline;