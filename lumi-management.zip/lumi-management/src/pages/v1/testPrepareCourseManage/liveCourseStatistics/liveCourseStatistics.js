import React, { Component, Fragment } from 'react';
import { Table, Pagination, Spin, Tooltip, DatePicker, message } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import Style from './liveCourseStatistics.module.less';
import moment from 'moment';
import api from '../../../../utils/api';

class LiveCourseStatistics extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,
            liveCourseData: [],//直播课周统计
            date: '',
            courseTotal: 0,
            dataSource: [],
            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '直播课名称',
            dataIndex: 'name',
            align: 'center',
            render: name => (
                <Tooltip placement="top" title={name}>
                    {name}
                </Tooltip>
            )
        },
        {
            title: '直播开始时间（美东时间）',
            dataIndex: 'liveAt',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: liveAt => {
                let date = liveAt ? moment(new Date(liveAt).getTime() - 14400000).format('YYYY/MM/DD HH:mm:ss') : '';//西四区
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '课程时长',
            dataIndex: 'liveDuration',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: liveDuration => (
                <Tooltip placement="top" title={liveDuration ? liveDuration + 'min' : '暂无数据'}>
                    {liveDuration ? liveDuration + ' min' : '暂无数据'}
                </Tooltip>
            ),
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            )
        },
        {
            title: '授课老师',
            dataIndex: 'teacherName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: teacherName => (
                <Tooltip placement="top" title={teacherName ? teacherName : '无'}>
                    {teacherName ? teacherName : '无'}
                </Tooltip>
            ),
        },
        {
            title: '直播状态',
            dataIndex: 'liveStatus',
            align: 'center',
            render: liveStatus => (
                <span>{liveStatus === 1 ? '未开始' : liveStatus === 2 ? '直播中' : liveStatus === 3 ? '已结束' : '未开始'}</span>
            )
        }
    ]
    componentDidMount() {
        this.getLiveCourseData({ time: moment().startOf('week').format('YYYY-MM-DD') });
    }
    componentWillUnmount(){
        this.setState = () => {
            return;
        };
    }
    //获取直播课统计总计
    getLiveCourseData = (params) => {
        this.setState({ loading: true }, () => {
            api.getLiveCourseData(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        let arr = data.result.weekList;
                        for (let item of arr) {
                            item.checked = false;
                        }
                        this.setState({ liveCourseData: arr, courseTotal: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取所选周
    getWeek = (date) => {
        let startDate = moment(date).startOf('week').format("YYYY-MM-DD");
        this.getLiveCourseData({ time: startDate });
        this.getLiveCourseList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, day: date });
    }
    //获取直播课列表
    getLiveCourseList = (params) => {
        this.setState({ loading: true }, () => {
            api.getLiveCourseList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //点击星期
    chooseDay = (item, index) => {
        let arr = this.state.liveCourseData;
        for (let item of arr) {
            item.checked = false;
        }
        arr[index].checked = true;
        this.setState({ liveCourseData: arr, date: item.date });
        this.getLiveCourseList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, day: item.date });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getLiveCourseList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, day: this.state.date });
        })
    }
    render() {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <h4 className={Style.text}>以下时间均显示美东（多伦多）时间</h4>
                    <div className={Style.text}>
                        <span>统计时间段：</span>
                        <DatePicker picker="week" className={Style.select} allowClear={false} onChange={this.getWeek} defaultValue={moment()} />
                    </div>
                    <div className={Style.text}>
                        <b>本周直播课共{this.state.courseTotal}节</b>
                    </div>
                    <div className={Style.weekWrap}>
                        {this.state.liveCourseData.map((item, index) => {
                            let day = new Date(item.date).getDay() === 0 ? '日' : new Date(item.date).getDay() === 1 ? '一' : new Date(item.date).getDay() === 2 ? '二' : new Date(item.date).getDay() === 3 ? '三' : new Date(item.date).getDay() === 4 ? '四' : new Date(item.date).getDay() === 5 ? '五' : new Date(item.date).getDay() === 6 ? '六' : '';
                            return (
                                <div className={!item.checked ? Style.day : Style.checkedDay} key={index} onClick={() => { this.chooseDay(item, index) }}>
                                    <span className={Style.date}>{item.date}</span>
                                    <span className={Style.count}>{item.count}</span>
                                    <span className={Style.week}>周{day}</span>
                                </div>
                            )
                        })}
                    </div>
                    <Table
                        className={Style.table}
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    ></Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                </Spin>
            </Fragment>
        )
    }
}

export default LiveCourseStatistics;