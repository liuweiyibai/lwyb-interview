import React, { Component, Fragment } from 'react';
import { Button, Table, Pagination, Input, Select, Spin, Tooltip, Divider, DatePicker, InputNumber, message, Popconfirm, Upload } from 'antd';
import { LoadingOutlined, PlusOutlined, CloudDownloadOutlined, DeleteOutlined, SearchOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import Style from './liveCourse.module.less';
import api from '../../../../utils/api';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import moment from 'moment';
import fun from '../../../../utils/funSum.js';

const { Option } = Select;
const { TextArea } = Input;
class LiveCourse extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,
            addModal: false,
            editModal: false,
            copyModal: false,
            uploadModal: false,
            subjectList: [],
            //搜索
            courseId: '',//课程id
            courseName: '',//课程名
            subjectName: null,//学科名
            subjectId: '',//学科id
            //新增、复制、编辑弹框
            modalCourseId: '',//所点击行的id
            modalCourseName: '',//课程名称
            modalSubjectName: null,//课程学科名
            modalSubjectId: '',//课程学科id
            teacherList: [],//授课老师列表
            modalTeacherName: null,//授课老师名
            modalTeacherId: '',//授课老师id
            startTime: '',//直播开始时间
            modalDuration: '',//时长
            //上传课件弹框
            coursewareList: [],
            fileList: [],

            dataSource: [],
            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '课程ID',
            dataIndex: 'id',
            align: 'center',
            width: '80px',
            ellipsis: {
                showTitle: false,
            },
            render: id => (
                <Tooltip placement="top" title={id}>
                    {id}
                </Tooltip>
            ),
        },
        {
            title: '课程名称',
            dataIndex: 'name',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: name => (
                <Tooltip placement="top" title={name}>
                    {name}
                </Tooltip>
            ),
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            ),
        },
        {
            title: '开始时间（美东时间）',
            dataIndex: 'liveAt',
            align: 'center',
            width: 180,
            ellipsis: {
                showTitle: false,
            },
            render: liveAt => {
                let date = liveAt ? moment(liveAt).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '课程时长',
            dataIndex: 'liveDuration',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: liveDuration => (
                <Tooltip placement="top" title={liveDuration ? liveDuration + 'min' : '暂无数据'}>
                    {liveDuration ? liveDuration + ' min' : '暂无数据'}
                </Tooltip>
            ),
        },
        {
            title: '授课老师',
            dataIndex: 'teacherName',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: teacherName => (
                <Tooltip placement="top" title={teacherName ? teacherName : '无'}>
                    {teacherName ? teacherName : '无'}
                </Tooltip>
            ),
        },
        {
            title: '关联备考课',
            align: 'center',
            render: record => {
                return (
                    <Tooltip placement="top" title={record.title && record.title.title ? record.title.title : '无'}>
                        {record.title && record.title.title ? <div className={Style.button} onClick={() => { this.goPage(record) }}>{record.title.title}</div> : '无'}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: '310px',
            render: (record) => (
                <Fragment>
                    <Button type='primary' className={Style.btn} onClick={() => { this.edit(record) }}>编辑</Button>
                    <Button type='primary' className={Style.btn} onClick={() => { this.copy(record) }}>复制</Button>
                    <Popconfirm title="确认要删除该直播课吗？" okText="确定" cancelText="取消" onConfirm={() => { this.delete(record) }}>
                        <Button type='primary' className={Style.btn}>删除</Button>
                    </Popconfirm>
                    <Button type='primary' onClick={() => { this.upload(record) }}>课件</Button>
                </Fragment>
            ),
        },
    ]
    componentDidMount() {
        this.getLiveCourseList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize });
        this.getSubjectList();
        this.getTeacherList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取直播课列表
    getLiveCourseList = (params) => {
        this.setState({ loading: true }, () => {
            api.getLiveCourseList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取学科列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //获取授课老师列表
    getTeacherList = () => {
        this.setState({ loading: true }, () => {
            api.getTeacherList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ teacherList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }
    //点击关联课程 跳转
    goPage = (record) => {
        window.open(api.pageURL + `/admin/v1/testPrepareCourseManage/courseOutline?id=${record.title.id}`);
    }
    //获取课程id
    getCourseId = (value) => {
        this.setState({ courseId: value });
    }
    //获取课程名称
    getCourseName = (e) => {
        this.setState({ courseName: e.target.value });
    }
    //获取课程学科
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //查询
    search = () => {
        this.getLiveCourseList({ iDisplayStart: 0, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
    }
    //新建直播课
    addLiveCourse = () => {
        this.setState({
            modalCourseName: '',
            modalSubjectName: null,
            modalSubjectId: '',
            modalTeacherName: null,
            modalTeacherId: '',
            startTime: '',
            modalDuration: '',
            addModal: true
        });
    }
    //获取课程名称
    getModalCourseName = (e) => {
        this.setState({ modalCourseName: e.target.value });
    }
    //获取课程学科下拉value
    getModalSubject = (value, option) => {
        if (value && option) {
            this.setState({ modalSubjectName: value, modalSubjectId: option.key });
        } else {
            this.setState({ modalSubjectName: null, modalSubjectId: '' });
        }
    }
    //获取授课老师下拉value
    getModalTeacher = (value, option) => {
        if (value && option) {
            this.setState({ modalTeacherName: value, modalTeacherId: option.key });
        } else {
            this.setState({ modalTeacherName: null, modalTeacherId: '' });
        }
    }
    //获取直播开始时间
    getStartTime = (dateString) => {
        this.setState({ startTime: moment(dateString).format("YYYY-MM-DD HH:mm:ss") });
    }
    //获取时长
    getModalDuration = (value) => {
        this.setState({ modalDuration: value });
    }
    //确定新建
    sureAdd = () => {
        this.setState({ loading: true }, () => {
            api.editLiveCourse({
                id: null,
                courseName: this.state.modalCourseName,
                subId: this.state.modalSubjectId,
                teacherId: this.state.modalTeacherId,
                liveAtStr: this.state.startTime,
                liveDuration: this.state.modalDuration,
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(1, this.state.pageSize);
                        this.setState({ addModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ addModal: false, loading: false });
                })
        })
    }
    //编辑
    edit = (record) => {
        this.setState({
            modalCourseId: record.id,
            modalCourseName: record.name,
            modalSubjectId: record.subId,
            modalSubjectName: record.subjectName,
            modalTeacherId: record.teacherId,
            modalTeacherName: record.teacherName,
            startTime: record.liveAt ? moment(record.liveAt).format('YYYY-MM-DD HH:mm:ss') : '',
            modalDuration: record.liveDuration,
            editModal: true
        });
    }
    //确定编辑
    sureEdit = () => {
        this.setState({ loading: true }, () => {
            api.editLiveCourse({
                id: this.state.modalCourseId,
                courseName: this.state.modalCourseName,
                subId: this.state.modalSubjectId,
                teacherId: this.state.modalTeacherId,
                liveAtStr: this.state.startTime,
                liveDuration: this.state.modalDuration,
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.setState({ editModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ editModal: false, loading: false });
                })
        })
    }
    //复制
    copy = (record) => {
        this.setState({
            modalCourseName: 'Copy-' + record.name,
            modalSubjectId: record.subId,
            modalSubjectName: record.subjectName,
            modalTeacherId: record.teacherId,
            modalTeacherName: record.teacherName,
            startTime: record.liveAt ? moment(record.liveAt).format('YYYY-MM-DD HH:mm:ss') : '',
            modalDuration: record.liveDuration,
            copyModal: true
        });
    }
    //确定复制
    sureCopy = () => {
        this.setState({ loading: true }, () => {
            api.editLiveCourse({
                id: null,
                courseName: this.state.modalCourseName,
                subId: this.state.modalSubjectId,
                teacherId: this.state.modalTeacherId,
                liveAtStr: this.state.startTime,
                liveDuration: this.state.modalDuration,
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(1, this.state.pageSize);
                        this.setState({ copyModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ copyModal: false, loading: false });
                })
        })
    }
    //删除
    delete = (record) => {
        this.setState({ loading: true }, () => {
            api.deleteLiveCourse({ id: record.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取已上传课件列表
    getUploadCoursewareList = () => {
        api.getUploadCoursewareList({ id: this.state.modalCourseId })
            .then((data) => {
                if (data.ret === 20000) {
                    this.setState({ coursewareList: data.result, loading: false });
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false });
            })
    }
    //点击课件显示弹框
    upload = (record) => {
        this.setState({
            modalCourseId: record.id,
            modalCourseName: record.name,
            fileList: [],
            uploadModal: true,
            loading: true
        }, () => {
            this.getUploadCoursewareList();
        });
    }
    handleChange = ({ file, fileList }) => {
        for (let item of fileList) {
            if (item.name) {
                let pictureType = item.name.split('.')[item.name.split('.').length - 1]
                if (pictureType !== 'pdf' && pictureType !== 'ppt' && pictureType !== 'pptx') {
                    message.warning('只支持 pdf、ppt、pptx 文件！');
                    this.setState({ loading: false, uploadModal: false });
                    return;
                }
            }
        }
        if (this.state.coursewareList.length + fileList.length > 10) {
            message.error('文件总数不能大于10个！');
            this.setState({ loading: false, uploadModal: false });
            return;
        }
        this.setState({ fileList: fileList, loading: true }, () => {
            let formData = new FormData();
            formData.append('files', file, file.name);
            api.uploadLiveCourseware(`/v1/preExam/upload?id=${this.state.modalCourseId}`, formData, { headers: { 'Content-Type': 'multipart/form-data' } })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getUploadCoursewareList();
                        this.setState({ uploadModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    //下载课件
    download = (item) => {
        window.location.href(item.fileUrl);
    }
    //删除课件
    deleteCourseware = (item) => {
        this.setState({ loading: true }, () => {
            api.deleteCourseware({ id: item.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.getUploadCoursewareList();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭弹窗
    close = () => {
        this.setState({ addModal: false, editModal: false, copyModal: false, uploadModal: false });
    }
    //获取新建、编辑、复制弹框jsx
    getJSX = () => {
        return (
            <Fragment>
                <div className={Style.infoBox}>
                    <span>课程名称<span className={Style.red}>*</span>：</span>
                    <TextArea placeholder='请输入课程名称' className={Style.textarea} maxLength='200' rows={1} value={this.state.modalCourseName} onChange={this.getModalCourseName} />
                    <span className={Style.length}>已输入{this.state.modalCourseName.length}/200字</span>
                </div>
                <div className={Style.infoBox}>
                    <span>课程学科<span className={Style.red}>*</span>：</span>
                    <Select className={Style.input} placeholder='全部' value={this.state.modalSubjectName} onChange={this.getModalSubject} allowClear={true} optionLabelProp="label" showSearch={true}>
                        {this.state.subjectList.length > 0 ? this.state.subjectList.map((item, index) => {
                            return (
                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                            )
                        }) : ''}
                    </Select>
                </div>
                <div className={Style.infoBox}>
                    <span>授课老师<span className={Style.red}>*</span>：</span>
                    <Select className={Style.input} placeholder='全部' value={this.state.modalTeacherName} onChange={this.getModalTeacher} allowClear={true} optionLabelProp="label" showSearch={true}>
                        {this.state.teacherList.length > 0 ? this.state.teacherList.map((item, index) => {
                            return (
                                <Option key={item.teacherId} value={item.teacherName}>{item.teacherName}</Option>
                            )
                        }) : ''}
                    </Select>
                </div>
                <div className={Style.infoBox}>
                    <span>直播开始时间（美东时间）<span className={Style.red}>*</span>：</span>
                    <DatePicker
                        format="YYYY-MM-DD HH:mm:ss"
                        defaultValue={this.state.startTime ? moment(this.state.startTime) : ''}
                        onChange={this.getStartTime}
                        showTime={true}
                    />
                </div>
                <div className={Style.infoBox}>
                    <span>课程时长（min）<span className={Style.red}>*</span>：</span>
                    <InputNumber placeholder='请输入课程时长' min={0} maxLength='3' value={this.state.modalDuration} onChange={this.getModalDuration} />
                </div>
            </Fragment>
        )
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getLiveCourseList({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, id: this.state.courseId, name: this.state.courseName, subId: this.state.subjectId });
        })
    }
    render() {
        let disabled = !(Boolean(this.state.modalCourseName) && Boolean(this.state.modalSubjectId) && Boolean(this.state.modalTeacherId) && Boolean(this.state.startTime) && Boolean(this.state.modalDuration) && Boolean(this.state.modalSubjectName) && Boolean(this.state.modalTeacherName));
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <Button type='primary' icon={<PlusOutlined />} className={Style.text} onClick={() => { this.addLiveCourse() }}>新建直播课</Button>
                            <span>课程ID：</span>
                            <InputNumber placeholder='请输入课程ID' maxLength='8' className={Style.input} onChange={this.getCourseId} />
                            <span>课程名称：</span>
                            <Input placeholder='请输入课程名称' maxLength='50' className={Style.input} onChange={this.getCourseName} />
                            <span>课程学科：</span>
                            <Select className={Style.input} ref='subject' placeholder='全部' onChange={this.getSubject} allowClear={true} optionLabelProp="label" showSearch={true}>
                                {this.state.subjectList.length > 0 ? this.state.subjectList.map((item, index) => {
                                    return (
                                        <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                    )
                                }) : ''}
                            </Select>
                        </div>
                        <Button icon={<SearchOutlined />} type='primary' onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    ></Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    {this.state.addModal ? <Modal title='新建直播课' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.sureAdd}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                    {this.state.editModal ? <Modal title='编辑直播课' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.sureEdit}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                    {this.state.copyModal ? <Modal title={this.state.modalCourseName} close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={disabled} onClick={this.sureCopy}>确定</Button>]}>
                        {this.getJSX()}
                    </Modal> : ''}
                    {this.state.uploadModal ? <Modal title='直播课课件' close={this.close}>
                        <Tooltip placement="topLeft" title={this.state.modalCourseName}>
                            <div className={Style.coursewareName}><b>{this.state.modalCourseName}</b></div>
                        </Tooltip>
                        <div className={Style.coursewareText}><ExclamationCircleOutlined />&emsp;只支持 pdf、ppt、pptx 文件，最多 10 个。课件用于教师上课，不对学生开放下载</div>
                        {this.state.coursewareList.map((item, index) => {
                            return (
                                <div className={Style.coursewareWrap} key={index}>
                                    <div className={Style.coursewareBox}>
                                        <span>课件{index + 1}：</span>
                                        <Tooltip placement="top" title={item.fileName}>
                                            <div className={Style.coursewareName}>{item.fileName}</div>
                                        </Tooltip>
                                        <div>{item.fileTransStatus === 0 ? '转换中' : item.fileTransStatus === 1 ? '成功' : '转换中'}</div>
                                    </div>
                                    <div>
                                        <Button type='link' className={Style.down}><a href={item.fileUrl} target='_self'><CloudDownloadOutlined /></a></Button>
                                        <Popconfirm title="确认删除此课件吗？" okText="确定" cancelText="取消" onConfirm={() => { this.deleteCourseware(item) }}>
                                            <DeleteOutlined />
                                        </Popconfirm>
                                    </div>
                                </div>
                            )
                        })}
                        <Upload
                            accept='.pdf,.ppt,.pptx'
                            method='post'
                            data={(file) => { return { files: file } }}
                            headers={
                                { 'authorization': 'Bearer ' + JSON.parse(fun.getItem('token')) }
                            }
                            beforeUpload={()=>false}
                            onChange={this.handleChange}
                            multiple={true}
                            showUploadList={false}
                            className={Style.coursewareUpload}
                        >
                            {this.state.coursewareList.length >= 10 ? null : <Button type="dashed" className={Style.uploadBtn}><PlusOutlined /></Button>}
                        </Upload>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default LiveCourse;