//课程资料
import React, { useState, useEffect, Fragment } from 'react';
import { Spin, Button, Input, Select, Divider, Table, Pagination, Upload, Tooltip, Popconfirm, message } from 'antd';
import { LoadingOutlined, FolderOpenOutlined, SearchOutlined, ExclamationCircleOutlined, UploadOutlined, FilePdfOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import Style from './APCourseMaterials.module.less';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import fun from '../../../../utils/funSum';
import moment from 'moment';
import api from '../../../../utils/api';

const { Option } = Select;
const { TextArea } = Input;
const APCourseMaterials = (props) => {
    const [loading, setLoading] = useState(false);
    const [subjectList, setSubjectList] = useState([]);
    const [materialsID, setMaterialsID] = useState('');
    const [materialsName, setMaterialsName] = useState('');
    const [courseSubjectValue, setCourseSubjectValue] = useState(null);
    const [dataSource, setDataSource] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);
    const [titleList, setTitleList] = useState([]);
    const [showLookUpModal, setShowLookUpModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [editModalMaterialsName, setEditModalMaterialsName] = useState(false);
    const [editModalSubjectName, setEditModalSubjectName] = useState('');
    const [editModalSubjectId, setEditModalSubjectId] = useState('');
    const [editModalReword, setEditModalReword] = useState('');
    const [rowId, setRowId] = useState('');
    const [editURL, setEditURL] = useState('');
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [fileList, setFileList] = useState([]);
    const columns = [
        fun.getColumnItem('资料ID', 'id', 80),
        {
            title: '资料名称',
            align: 'center',
            width: '300px',
            ellipsis: {
                showTitle: false,
            },
            render: record => (
                record.title ? <Fragment>
                    <Button type='link'><a href={record.url} target='_self'><FilePdfOutlined /></a></Button>
                    <Tooltip placement="top" title={record.title.split('.pdf')[0]}>{record.title.split('.pdf')[0]}</Tooltip>
                </Fragment> : ''
            ),
        },
        fun.getColumnItem('学科', 'lectureSubjectName'),
        {
            title: '关联备考课',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return (
                    Array.isArray(record.title) && record.title.length > 0 ? <Button type='link' onClick={() => { lookUp(record) }}>查看</Button> : '无'
                )
            }
        },
        fun.getColumnItem('备注', 'remark'),
        {
            title: '上传时间',
            dataIndex: 'createdAt',
            align: 'center',
            width: 180,
            ellipsis: {
                showTitle: false,
            },
            render: createdAt => {
                let date = createdAt ? moment(new Date(createdAt).getTime() - new Date().getTimezoneOffset() * 60000).format('YYYY/MM/DD HH:mm:ss') : '';
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: '210px',
            render: (record) => (
                <div>
                    <Button type='primary' icon={<EditOutlined />} className={Style.btn} onClick={() => { edit(record) }}>编辑</Button>
                    <Popconfirm title="确认要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { deleted(record) }}>
                        <Button type='primary' icon={<DeleteOutlined />}>删除</Button>
                    </Popconfirm>
                </div>
            ),
        },
    ];
    useEffect(() => {
        getAPCourseMaterialsList({ idisplayStart: 0, idisplayLength: pageSize });
        getAPSubjectList();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    // 获取课程资料列表
    const getAPCourseMaterialsList = (params) => {
        setLoading(true);
        api.getAPCourseMaterialsList(params)
            .then(res => {
                // console.log(res.result.data);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result && res.result.data ? res.result.data : [];
                let count = res.result && res.result.total ? res.result.total : 0;
                setDataSource(data);
                setTotal(count);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取资料学科 下拉
    const getAPSubjectList = () => {
        setLoading(true);
        api.getAPSubjectList()
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result ? res.result : [];
                setSubjectList(data);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 资料上传
    const uploadVideo = () => {
        setShowUploadModal(true);
    }
    const getSubject = (value, option) => {
        if (value && option) {
            setCourseSubjectValue(option.key);
        } else {
            setCourseSubjectValue(null);
        }
    }
    const search = () => {
        getAPCourseMaterialsList({ id: materialsID, lectureSubjectId: courseSubjectValue, title: materialsName, idisplayStart: page - 1, idisplayLength: pageSize });
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
        getAPCourseMaterialsList({ id: materialsID, lectureSubjectId: courseSubjectValue, title: materialsName, idisplayStart: pageParameter - 1, idisplayLength: pageSizeParameter });
    }
    const goPage = () => { }
    const handleChange = ({ file, fileList }) => {
        if (file.name.split('.')[file.name.split('.').length - 1].toLowerCase() !== 'pdf') {
            message.warning('仅可上传PDF文件！');
            setFileList([]);
            return;
        }
        setFileList(fileList);
    }
    // 确认上传
    const submit = async () => {
        if (fileList.length <= 0) {
            message.error('请至少选择一个文件！');
            return;
        } else if (fileList.length > 10) {
            message.error('一次上传数量不能超过10个！');
            return;
        }
        setLoading(true);
        for (let item of fileList) {
            let res, res1;
            try {
                //获取aws上传地址
                res = await api.getAddress({ fileName: '.' + item.originFileObj.name.split('.')[1], type: 2 });
            } catch (err) {
                message.error(err.msg);
                return;
            }
            if (res.ret === 20000) {
                try {
                    //往aws上传视频
                    await api.uploadAWS(res.result.url, item.originFileObj, { headers: { 'Content-Type': 'application/pdf' } })
                    //资料上传aws 成功回调
                    // res1 = await api.courseMaterialsNotice({ materialName: item.originFileObj.name, materialUrl: res.result.key });
                    res1 = await api.saveAPCourseMaterial({ title: item.originFileObj.name, url: res.result.key, })
                    if (res1.ret === 20000) {
                        message.success(item.originFileObj.name + '上传成功');
                    } else {
                        throw new Error(res.msg);
                    }
                } catch (err) {
                    message.error(err.msg);
                }

            } else {
                message.error(res.msg);
                setLoading(false);
            }
        }
        getAPCourseMaterialsList({ idisplayStart: 0, idisplayLength: pageSize });
        setShowUploadModal(false);
        setLoading(false);
    }
    const lookUp = (record) => {
        setShowLookUpModal(true);
        setTitleList(record.title);
    }
    // 编辑
    const edit = (record) => {
        // console.log(record);
        setShowEditModal(true);
        setEditModalMaterialsName(record.title);
        setEditModalSubjectName(record.lectureSubjectName);
        setEditModalSubjectId(record.lectureSubjectId);
        setEditModalReword(record.remark);
        setRowId(record.id);
        setEditURL(record.url);
    }
    const getEditSubject = (value, option) => {
        if (value && option) {
            setEditModalSubjectName(value);
            setEditModalSubjectId(option.key);
        } else {
            setEditModalSubjectName(null);
            setEditModalSubjectId(null);
        }
    }
    // 编辑 确定
    const editSubmit = () => {
        setLoading(true);
        api.saveAPCourseMaterial({ id: rowId, lectureSubjectId: editModalSubjectId, remark: editModalReword, title: editModalMaterialsName, url: editURL, })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getAPCourseMaterialsList({ id: materialsID, lectureSubjectId: courseSubjectValue, title: materialsName, idisplayStart: 0, idisplayLength: pageSize });
                message.success(res.msg);
                setLoading(false);
                close();
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 删除课程资料
    const deleted = (record) => {
        setLoading(true);
        api.deleteAPCourseMaterial({ id: record.id })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getAPCourseMaterialsList({ id: materialsID, lectureSubjectId: courseSubjectValue, title: materialsName, idisplayStart: 0, idisplayLength: pageSize });
                message.success(res.msg);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const close = () => {
        setShowUploadModal(false);
        setShowLookUpModal(false);

        setShowEditModal(false);
        setEditModalMaterialsName(null);
        setEditModalSubjectName(null);
        setEditModalSubjectId(null);
        setEditModalReword(null);
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.searchWrap}>
                <div className={Style.left}>
                    <Button type='primary' className={Style.text} icon={<FolderOpenOutlined />} onClick={uploadVideo}>资料上传</Button>
                    <span>资料ID：</span>
                    <Input placeholder='请输入资料ID' className={Style.input} maxLength='8' onChange={(e) => { setMaterialsID(e.target.value); }} />
                    <span>资料名称：</span>
                    <Input placeholder='请输入资料名称' className={Style.input} maxLength='50' onChange={(e) => { setMaterialsName(e.target.value); }} />
                    <span>资料学科：</span>
                    <Select placeholder='全部' className={Style.input} onChange={getSubject} showSearch={true} allowClear={true}>
                        {subjectList.map((item) => {
                            return (
                                <Option key={item.id} value={item.title}>{item.title}</Option>
                            )
                        })}
                    </Select>
                </div>
                <Button icon={<SearchOutlined />} type='primary' onClick={search}>查询</Button>
            </div>
            <Divider />
            <Table
                dataSource={dataSource}
                columns={columns}
                rowKey={dataSource => dataSource.id}
                bordered={true}
                pagination={false}
            ></Table>
            <Pagination showQuickJumper className={Style.pagination} current={page} pageSize={pageSize} total={total} onChange={paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
            {/* table 关联备考课 查看 */}
            {showLookUpModal ? <Modal title='关联备考课' close={close}>
                <div className={Style.titleList}>
                    {titleList.map((item, index) => {
                        return (
                            <Button type='link' className={Style.title} key={index} onClick={() => { goPage(item) }}>{item.title}</Button>
                        )
                    })}
                </div>
            </Modal> : ''}
            {/* table 编辑 */}
            {showEditModal ? <Modal title='编辑资料信息' close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' onClick={editSubmit}>确定</Button>]}>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>资料名称：</span>
                    <Input placeholder='请输入资料名称' className={Style.input} maxLength='200' value={editModalMaterialsName} onChange={(e) => { setEditModalMaterialsName(e.target.value); }} />
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>资料学科：</span>
                    <Select placeholder='全部' className={Style.input} value={editModalSubjectName} onChange={getEditSubject} showSearch={true} allowClear={true}>
                        {subjectList.map((item) => {
                            return (
                                <Option key={item.id} value={item.title}>{item.title}</Option>
                            )
                        })}
                    </Select>
                </div>
                <div className={Style.rowWrap}>
                    <span className={Style.span}>编辑备注：</span>
                    <TextArea placeholder='请输入备注' className={Style.textarea} maxLength='200' showCount rows={1} value={editModalReword} onChange={(e) => { setEditModalReword(e.target.value); }} />
                </div>
            </Modal> : ''}
            {/* 资料上传 */}
            {showUploadModal ? <Modal title='上传视频' close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' onClick={submit}>确认上传</Button>]}>
                <div className={Style.contentTop}><ExclamationCircleOutlined />&emsp;仅可上传 PDF 文件，一次性最多上传 10 个</div>
                <Upload
                    className={Style.upload}
                    accept='application/pdf'
                    beforeUpload={() => false}
                    onChange={handleChange}
                    showUploadList={fileList.length > 0 ? { showRemoveIcon: false } : false}
                    multiple={true}
                    progress={
                        {
                            strokeColor: {
                                '0%': '#108ee9',
                                '100%': '#87d068',
                            },
                            strokeWidth: 3,
                            format: percent => `${parseFloat(percent.toFixed(2))}%`,
                        }
                    }
                >
                    <Button icon={<UploadOutlined />}>选择文件</Button>
                </Upload>
            </Modal> : ''}
        </Spin>
    )
}
export default APCourseMaterials;