//课程简介视频
import React, { useState, useEffect } from 'react';
import { Spin, Table, Pagination, Button, Popconfirm, Upload, message } from 'antd';
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import Style from './APCourseVideo.module.less';
import fun from '../../../../utils/funSum';
import Modal from '../../../../components/modalOfTree/modalOfTree';
import api from '../../../../utils/api';

const APCourseVideo = (props) => {
    const [loading, setLoading] = useState(false);
    const [videoList, setVideoList] = useState([]);
    const [showModelBool, setShowModelBool] = useState(false);
    const [dataSource, setDataSource] = useState([{ id: 0, name: '芜湖起飞' }]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);
    const columns = [
        fun.getColumnItem('视频ID', 'id', 90),
        fun.getColumnItem('视频名称', 'videoTitle'),
        {
            title: '操作项',
            align: 'center',
            width: 300,
            render: (record) => {
                return (
                    <Popconfirm title="确认要删除吗？" onConfirm={() => { confirm(record) }} okText="确认" cancelText="取消">
                        <Button type='primary'>删除</Button>
                    </Popconfirm>
                )
            }
        }
    ];
    useEffect(() => {
        getAPCourseIntroduceVideoList({ idisplayStart: 0, idisplayLength: pageSize });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    // 获取课程简介视频列表
    const getAPCourseIntroduceVideoList = (params) => {
        setLoading(true);
        api.getCourseIntroductVideoList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result && res.result.data ? res.result.data : [];
                let count = res.result && res.result.total ? res.result.total : 0;
                setDataSource(data);
                setTotal(count);
                setLoading(false);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 确认删除
    const confirm = (record) => {
        setLoading(true);
        api.deleteAPCourseIntroduceVideo({ id: record.id })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getAPCourseIntroduceVideoList({ idisplayStart: 0, idisplayLength: pageSize });
                // setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const showModel = () => {
        setShowModelBool(true);
    }
    const close = () => {
        setShowModelBool(false);
    }
    const uploadChange = ({ file, fileList }) => {
        if (fileList.length > 30) {
            message.error('上传文件数量超过限制！');
            return
        }
        if (file.name.split('.')[file.name.split('.').length - 1].toLowerCase() !== 'mp4') {
            message.warning('仅可上传视频文件！');
            setVideoList([]);
            return;
        }
        console.log(fileList);
        setVideoList(fileList);
    }
    // 上传视频确认
    const upload = async () => {
        if (videoList.length > 30) {
            message.error('上传文件数量超过限制！');
            return
        } else if (videoList.length <= 0) {
            message.error('请至少选择一个文件！');
            return
        }
        setLoading(true);
        for (let item of videoList) {
            let res, res1;
            try {
                //获取aws上传地址
                res = await api.getAddress({ fileName: '.' + item.originFileObj.name.split('.')[1], type: 2 });
            } catch (err) {
                message.error(err.msg);
                return;
            }
            if (res.ret === 20000) {
                try {
                    //往aws上传视频
                    await api.uploadAWS(res.result.url, item.originFileObj, { headers: { 'Content-Type': 'application/pdf' } })
                    //资料上传aws 成功回调
                    res1 = await api.saveAPCourseIntroduceVideo({ videoTitle: item.originFileObj.name, videoUrl: res.result.key })
                    if (res1.ret === 20000) {
                        message.success(item.originFileObj.name + '上传成功');
                    } else {
                        throw new Error(res.msg);
                    }
                } catch (err) {
                    message.error(err.msg);
                }

            } else {
                message.error(res.msg);
                setLoading(false);
            }
        }
        getAPCourseIntroduceVideoList({ idisplayStart: 0, idisplayLength: pageSize });
        setShowModelBool(false);
        setLoading(false);
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.wrap}>
                <Button type='primary' icon={<PlusOutlined />} className={Style.btn} onClick={showModel}>视频上传</Button>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    rowKey={dataSource => dataSource.id}
                    pagination={false}
                ></Table>
                <Pagination className={Style.pagination} pageSize={pageSize} showQuickJumper total={total} current={page} onChange={paginationChange}></Pagination>
                {showModelBool ? <Modal title='上传视频' close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' disabled={videoList.length <= 0 || videoList.length > 30} onClick={upload}>确定</Button>]}>
                    <Upload
                        beforeUpload={() => false}
                        onChange={uploadChange}
                        multiple={true}
                    >
                        <Button type='primary' icon={<PlusOutlined />}>选择视频</Button>
                    </Upload>
                </Modal> : ''}
            </div>
        </Spin >
    )
}

export default APCourseVideo;