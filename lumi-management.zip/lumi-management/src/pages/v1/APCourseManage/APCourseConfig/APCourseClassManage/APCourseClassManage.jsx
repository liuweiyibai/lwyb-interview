//ap课程配置>>>班级管理
import React, { useState, useEffect } from 'react';
import { Spin, Table, Pagination, Button, Tag, message, Switch, Input, Tooltip, Select } from 'antd';
import { LoadingOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons';
import Style from './APCourseClassManage.module.less';
import fun from '../../../../../utils/funSum';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import api from '../../../../../utils/api';
import moment from 'moment';

const { TextArea } = Input;
const { Option } = Select;
const APCourseClassManage = (props) => {
    const [loading, setLoading] = useState(false);
    const [id, setID] = useState('');
    const [title, setTitle] = useState('');
    const [subName, setSubName] = useState('');
    const [dataSource, setDataSource] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);

    const [addClassModal, setAddClassModal] = useState(false);
    const [modalTitle, setModalTitle] = useState('');
    const [modalClassName, setModalClassName] = useState('');
    const [checked, setChecked] = useState(false);
    const [classID, setClassID] = useState(null);

    const [linkLiveCourseModal, setLinkLiveCourseModal] = useState(false);
    const [modalLiveCourseList, setModalLiveCourseList] = useState([]);
    const [liveCourseText, setLiveCourseText] = useState(null);
    const [liveCourseValue, setLiveCourseValue] = useState([]);
    const [modalLiveCourseBeginTimeList, setModalLiveCourseBeginTimeList] = useState([]);
    const [liveCourseTimeText, setLiveCourseTimeText] = useState(null);
    const [liveCourseTimeValue, setLiveCourseTimeValue] = useState('');
    const [showModalTable, setShowModalTable] = useState(false);
    const [modalDataSource, setModalDataSource] = useState([]);
    const [modalPage, setModalPage] = useState(1);
    const [modalPageSize, setModalPageSize] = useState(10);
    const [modalTotal, setModalTotal] = useState(0);

    const [relieveLiveCourseModal, setRelieveLiveCourseModal] = useState(false);
    const [linkedLiveCourseList, setLinkedLiveCourseList] = useState([]);
    const columns = [
        fun.getColumnItem('班级ID', 'id', 90),
        fun.getColumnItem('班级名称', 'sessionName'),
        fun.getColumnTimeItem('班级开课时间（美东时间）', 'earlyLiveAt',null,200),
        {
            title: '关联的直播课',
            dataIndex: 'liveList',
            align: 'center',
            render: (liveList) => {
                return <div>
                    {
                        liveList && liveList.map((item, index) => {
                            return (
                                <Tag color='#979797' key={index}>{moment(item.liveAt).format('YYYY-MM-DD HH:mm:ss')}&emsp;{item.title}</Tag>
                            )
                        })
                    }
                </div>
            }
        },
        {
            title: '班级状态',
            dataIndex: 'onlineStatus',
            align: 'center',
            render: (onlineStatus) => {
                let text = onlineStatus === 1 ? '上架' : '下架';
                return (
                    <Tooltip placement="top" title={text}>{text}</Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: 300,
            render: (record) => {
                return (
                    <div className={Style.tableOperation}>
                        <Button type='primary' onClick={() => { edit(record); }}>编辑</Button>
                        <Button type='primary' onClick={() => { setClassID(record.id); setLinkLiveCourseModal(true); }}>关联直播课</Button>
                        <Button type='primary' onClick={() => { setClassID(record.id); setRelieveLiveCourseModal(true); setLinkedLiveCourseList(record.liveList); }}>解除关联</Button>
                    </div>
                )
            }
        }
    ];
    const modalColumns = [
        fun.getColumnItem('直播课ID', 'id', 90),
        fun.getColumnItem('直播课主题', 'title'),
        fun.getColumnTimeItem('直播开始时间', 'liveAt'),
        {
            title: '操作项',
            align: 'center',
            width: 300,
            render: (record) => {
                return (
                    <Button type='primary' icon={<PlusOutlined />} onClick={() => { linkAPLiveCourse(record); }}>加入班级</Button>
                )
            }
        }
    ]
    useEffect(() => {
        let ID = props.location.search.split('=')[1].split('&')[0];
        let text = decodeURI(props.location.search.split('=')[2].split('&')[0]);
        let subText = decodeURI(props.location.search.split('=')[3]);
        setID(ID);
        setTitle(text);
        setSubName(subText);
        getClassList({ lectureId: ID, idisplayStart: 0, idisplayLength: pageSize });
        getLiveCourseSelect({ id: ID });
        getLiveCourseBeginTimeSelect({ id: ID });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    // 获取班级列表
    const getClassList = (params) => {
        setLoading(true);
        api.getClassList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result && res.result.data ? res.result.data : [];
                // let linkedList = res.result && res.result.data && res.result.data.liveList ? res.result.data.liveList : [];
                setDataSource(data);
                setTotal(res.result.total);
                // console.log(linkedList, res.result)
                // setLinkedLiveCourseList(linkedList);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取直播课主题 下拉
    const getLiveCourseSelect = (params) => {
        setLoading(true);
        api.getLiveCourseSelect(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result ? res.result : [];
                let arr = data.length > 0 && data.map(item => {
                    return item.id
                })
                setModalLiveCourseList(data);
                setLiveCourseValue(arr);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取直播课开始时间 下拉
    const getLiveCourseBeginTimeSelect = (params) => {
        setLoading(true);
        api.getLiveCourseBeginTimeSelect(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result ? res.result : [];
                setModalLiveCourseBeginTimeList(data);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
        getClassList({ lectureId: id, idisplayStart: pageParameter - 1, idisplayLength: pageSizeParameter });
    }
    // 编辑
    const edit = (record) => {
        let online = record.onlineStatus === 1;
        setAddClassModal(true);
        setModalTitle('编辑班级');
        setModalClassName(record.sessionName);
        setChecked(online);
        setClassID(record.id);
    }
    const changeStatus = (checked) => {
        setChecked(checked);
    }
    const saveClass = () => {
        setLoading(true);
        let online = checked ? 1 : 2;
        api.saveAPClass({ id: classID, lectureId: id, onlineStatus: online, sessionName: modalClassName })
            .then(res => {
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                message.success(res.msg);
                getClassList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
                close();
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 关联直播课
    // 获取直播课列表
    const getAPLiveCourseLayoutList = (params) => {
        setLoading(true);
        api.getAPLiveCourseLayoutList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result.data ? res.result.data : [];
                setModalDataSource(data);
                setModalTotal(res.result.total);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取直播课主题 下拉
    const getLiveCourseType = (value, option) => {
        if (value && option) {
            setLiveCourseText(value);
            setLiveCourseValue([Number(option.key)]);
        } else {
            setLiveCourseText(null);
            setLiveCourseValue([]);
        }
    }
    // 获取直播开始时间
    const getLiveCourseTimeType = (value, option) => {
        if (value && option) {
            setLiveCourseTimeText(value);
            setLiveCourseTimeValue(value);
        } else {
            setLiveCourseTimeText(null);
            setLiveCourseTimeValue('');
        }
    }
    // 查询
    const modalSearch = () => {
        setShowModalTable(true);
        getAPLiveCourseLayoutList({ idisplayStart: 0, idisplayLength: modalPageSize, lectureLiveTopicIdList: liveCourseValue, liveAt: liveCourseTimeValue });
    }
    // 加入班级
    const linkAPLiveCourse = (record) => {
        setLoading(true);
        api.linkAPLiveCourse({ id: classID, preLiveCourseId: record.id })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                message.success(res.msg);
                getClassList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const modalPaginationChange = (pageParameter, pageSizeParameter) => {
        setModalPage(pageParameter);
        setModalPageSize(pageSizeParameter);
        getAPLiveCourseLayoutList({ idisplayStart: pageParameter - 1, idisplayLength: modalPageSize, lectureLiveTopicIdList: liveCourseValue, liveAt: liveCourseTimeValue });
    }
    // 解除直播课关联
    const relieveAPLiveCourse = (params) => {
        setLoading(true);
        api.relieveAPLiveCourse({ courseId: params.preliveCourseId, classId: classID })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                message.success(res.msg);
                getClassList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
                close();
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const close = () => {
        setAddClassModal(false);
        setModalTitle('');
        setModalClassName('');
        setChecked(false);

        setLinkLiveCourseModal(false);
        setShowModalTable(false);
        setModalDataSource([]);
        setLiveCourseText(null);
        setLiveCourseValue([]);
        setLiveCourseTimeText(null);
        setLiveCourseTimeValue('');
        setClassID(null);

        setRelieveLiveCourseModal(false);
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.wrap}>
                <Button type='primary' className={Style.goBack} onClick={() => {
                    props.history.push('/admin/v1/ap-coursemanage/ap-courseconfig')
                }}>返回上一级</Button>
                <div className={Style.courseTitle}>班级管理：{title}</div>
                <div className={Style.detail}>
                    <div className={Style.detailLeft}>
                        <span className={Style.detailTitle}>学科：</span>
                        <span className={Style.detailContent}>{subName}</span>
                    </div>
                </div>
                <Button type='primary' icon={<PlusOutlined />} className={Style.addLiveCoursetheme} onClick={() => { setAddClassModal(true); setModalTitle('新建班级'); setClassID(null) }}>新建班级</Button>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    rowKey={dataSource => dataSource.id}
                    pagination={false}
                ></Table>
                <Pagination className={Style.pagination} pageSize={pageSize} showQuickJumper total={total} current={page} onChange={paginationChange}></Pagination>
                {/* 新建/编辑班级 */}
                {addClassModal ? <Modal title={modalTitle} close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' onClick={saveClass}>确定</Button>]}>
                    <div className={Style.lineWrap}>
                        <span>班级名称<span className={Style.red}>*</span>：</span>
                        <TextArea className={Style.formEl} placeholder='请输入班级名称' rows={1} maxLength='50' showCount value={modalClassName} onChange={(e) => { setModalClassName(e.target.value); }} />
                    </div>
                    <div className={Style.lineWrap}>
                        <span>班级状态：</span>
                        <Switch checked={checked} onChange={changeStatus} checkedChildren="上架" unCheckedChildren="下架" />
                    </div>
                </Modal> : ''}
                {/* 关联直播课 */}
                {linkLiveCourseModal ? <Modal title='关联直播课' close={close}>
                    <div className={Style.modalSearchWrap}>
                        <div className={Style.lineWrap}>
                            <span className={Style.formText}>直播课主题：</span>
                            <Select className={Style.formEl} placeholder='全部' value={liveCourseText} onChange={getLiveCourseType} allowClear={true} showSearch={true} dropdownMatchSelectWidth={600}>
                                {modalLiveCourseList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.title}>{item.title}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.lineWrap}>
                            <span className={Style.formText}>直播开始时间：</span>
                            <Select className={Style.formEl} placeholder='全部' value={liveCourseTimeText} onChange={getLiveCourseTimeType} allowClear={true} showSearch={true}>
                                {modalLiveCourseBeginTimeList.map((item, index) => {
                                    let date = item.liveTime ? moment(item.liveTime).format('YYYY-MM-DD HH:mm:ss') : '';
                                    return (
                                        <Option key={index} value={date}>{date}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <Button type="primary" icon={<SearchOutlined />} onClick={modalSearch}>查询</Button>
                    </div>
                    {showModalTable ? <div>
                        <Table
                            columns={modalColumns}
                            dataSource={modalDataSource}
                            rowKey={modalDataSource => modalDataSource.id}
                            pagination={false}
                        ></Table>
                        <Pagination className={Style.pagination} pageSize={modalPageSize} showQuickJumper total={modalTotal} current={modalPage} onChange={modalPaginationChange}></Pagination>
                    </div> : ''}
                </Modal> : ''}
                {/* 解除关联直播课 */}
                {relieveLiveCourseModal ? <Modal title='解除直播课关联' close={close}>
                    {linkedLiveCourseList.map((item, index) => {
                        let date = item.liveAt ? moment(item.liveAt).format('YYYY-MM-DD HH:mm:ss') : '';
                        return (
                            <div className={Style.relieveWrap} key={index}>
                                <div>
                                    <div>{date}</div>
                                    <div className={Style.relieveTitle}>{item.title}</div>
                                </div>
                                <Button type='primary' onClick={() => { relieveAPLiveCourse(item); }}>解绑</Button>
                            </div>
                        )
                    })}
                </Modal> : ''}
            </div>
        </Spin >
    )
}

export default APCourseClassManage;