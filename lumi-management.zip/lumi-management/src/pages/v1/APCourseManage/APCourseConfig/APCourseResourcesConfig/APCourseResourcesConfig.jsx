//ap课程配置>>>课程资源管理
import React, { useState } from 'react';
import { Spin, Table, Pagination, Button, Popconfirm, Radio, Input, message, Tooltip } from 'antd';
import { LoadingOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons';
import Style from './APCourseResourcesConfig.module.less';
import fun from '../../../../../utils/funSum';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import { useEffect } from 'react';
import api from '../../../../../utils/api';

const APCourseResourcesConfig = (props) => {
    const [loading, setLoading] = useState(false);
    const [id, setID] = useState('');
    const [title, setTitle] = useState('');
    const [subName, setSubName] = useState('');
    const [dataSource, setDataSource] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);

    const [modalDataSource, setModalDataSource] = useState([]);
    const [modalPage, setModalPage] = useState(1);
    const [modalPageSize, setModalPageSize] = useState(10);
    const [modalTotal, setModalTotal] = useState(0);
    const [resourceId, setResourceId] = useState('');
    const [resourceName, setResourceName] = useState('');

    const [addResourcesModal, setAddResourcesModal] = useState(false);
    const [radioValue, setRadioValue] = useState('');
    const [showTableBool, setShowTableBool] = useState(false);
    const columns = [
        fun.getColumnItem('资源ID', 'id', 90),
        {
            title: '资源类型',
            dataIndex: 'type',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: (type) => {
                let text = type === 1 ? '直播课主题' : type === 2 ? '课程资料' : type === 3 ? '录播视频' : '';
                return (
                    <Tooltip placement="top" title={text}>
                        {text}
                    </Tooltip>
                )
            }
        },
        fun.getColumnItem('资源名称', 'name'),
        {
            title: '操作项',
            align: 'center',
            render: (record) => {
                return (
                    <Popconfirm title="确认要删除吗？" onConfirm={() => { confirm(record); }} okText="确认" cancelText="取消">
                        <Button type='primary'>删除</Button>
                    </Popconfirm>
                )
            }
        }
    ];
    const modalColumns = [
        fun.getColumnItem('资源ID', 'id', 90),
        {
            title: '资源名称',
            align: 'center',
            render: (record) => {
                return (
                    <div>{record.title || record.videoName}</div>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            render: (record) => {
                return (
                    <Button type='primary' onClick={() => { joinCourse(record) }}>加入课程</Button>
                )
            }
        }
    ];
    useEffect(() => {
        let id = props.location.search.split('=')[1].split('&')[0];
        let titleText = decodeURI(props.location.search.split('=')[2].split('&')[0]);
        let subName = decodeURI(props.location.search.split('=')[3]) !== 'null' ? decodeURI(props.location.search.split('=')[3]) : '暂无';
        setID(id);
        setTitle(titleText);
        setSubName(subName);
        getCourseResourcesList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    // 获取课程资源列表
    const getCourseResourcesList = (params) => {
        setLoading(true);
        api.getCourseResourcesList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result.data ? res.result.data : [];
                setDataSource(data);
                setTotal(res.result.total);
                setLoading(false);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 确认删除
    const confirm = (record) => {
        setLoading(true);
        api.deleteCourseResources({ id: record.id })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getCourseResourcesList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
                setLoading(false);
                message.success(res.msg);
            })
            .catch(err => {
                // console.log(err);
                setLoading(false);
                message.error(err.msg);
            })
    }
    const getResourceId = (e) => {
        setResourceId(e.target.value);
    }
    const getResourceName = (e) => {
        setResourceName(e.target.value);
    }
    // 添加资源 课程资料 查询
    const searchAPCourseResourcesList = (params) => {
        setLoading(true);
        api.searchAPCourseResourcesList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                setModalDataSource(res.result.data);
                setModalTotal(res.result.total);
                setLoading(false);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 添加资源 录播视频 查询
    const searchAPRecordResourcesList = (params) => {
        setLoading(true);
        api.searchAPRecordResourcesList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                setModalDataSource(res.result.data);
                setModalTotal(res.result.total);
                setLoading(false);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    const search = () => {
        setShowTableBool(true);
        setLoading(true);
        switch (radioValue) {
            case 2:
                searchAPCourseResourcesList({ id: resourceId, title: resourceName, idisplayStart: 0, idisplayLength: modalPageSize });
                break;
            case 3:
                searchAPRecordResourcesList({ id: resourceId, videoName: resourceName, idisplayStart: 0, idisplayLength: modalPageSize, videoType: 2 });
                break;
            default:
                break;
        }
    }
    // 加入课程
    const joinCourse = (record) => {
        setLoading(true);
        api.joinAPCourse({ lectureId: id, resId: record.id, type: radioValue, })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getCourseResourcesList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
                message.success(res.msg);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const close = () => {
        setAddResourcesModal(false);
        setRadioValue('');
        setShowTableBool(false);
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
        getCourseResourcesList({ lectureId: id, idisplayStart: pageParameter - 1, idisplayLength: pageSizeParameter });
    }
    const modalPaginationChange = (pageParameter, pageSizeParameter) => {
        setModalPage(pageParameter);
        setModalPageSize(pageSizeParameter);
        switch (radioValue) {
            case 2:
                searchAPCourseResourcesList({ id: resourceId, title: resourceName, idisplayStart: pageParameter - 1, idisplayLength: modalPageSize });
                break;
            case 3:
                searchAPRecordResourcesList({ id: resourceId, videoName: resourceName, idisplayStart: pageParameter - 1, idisplayLength: modalPageSize, videoType: 2 });
                break;
            default:
                break;
        }
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.wrap}>
                <Button type='primary' className={Style.goBack} onClick={() => {
                    props.history.push('/admin/v1/ap-coursemanage/ap-courseconfig')
                }}>返回上一级</Button>
                <div className={Style.courseTitle}>课程资源：{title}</div>
                <div className={Style.describe}>管理AP课程下的资源，包括录播视频、课程资料、模拟考试等。</div>
                <div className={Style.detail}>
                    <div className={Style.detailLeft}>
                        <span className={Style.detailTitle}>学科：</span>
                        <span className={Style.detailContent}>{subName}</span>
                    </div>
                </div>
                <Button type='primary' icon={<PlusOutlined />} className={Style.addResources} onClick={() => { setAddResourcesModal(true); }}>添加资源</Button>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    rowKey={dataSource => dataSource.id}
                    pagination={false}
                ></Table>
                <Pagination className={Style.pagination} pageSize={pageSize} showQuickJumper total={total} current={page} onChange={paginationChange}></Pagination>
                {addResourcesModal ? <Modal title='添加资源' close={close}>
                    <Radio.Group onChange={(e) => { setRadioValue(e.target.value); }}>
                        <Radio value={2}>课程资料</Radio>
                        <Radio value={3}>录播视频</Radio>
                        {/* <Radio value={4}>模拟考试</Radio> */}
                    </Radio.Group>
                    <div className={Style.modalSearch}>
                        <div>
                            <span>资源ID：</span>
                            <Input placeholder='请输入资源ID' className={Style.text} onChange={getResourceId} />
                            <span>资源名称：</span>
                            <Input placeholder='请输入资源名称' className={Style.text} onChange={getResourceName} />
                        </div>
                        <Button type='primary' icon={<SearchOutlined />} onClick={search} disabled={radioValue === ''}>查询</Button>
                    </div>
                    {radioValue !== '' && showTableBool ? <div>
                        <Table
                            columns={modalColumns}
                            dataSource={modalDataSource}
                            rowKey={modalDataSource => modalDataSource.id}
                            pagination={false}
                        ></Table>
                        <Pagination className={Style.pagination} pageSize={modalPageSize} showQuickJumper total={modalTotal} current={modalPage} onChange={modalPaginationChange}></Pagination>
                    </div> : ''}
                </Modal> : ''}
            </div>
        </Spin>
    )
}

export default APCourseResourcesConfig;