//ap课程配置
import React, { useState, useEffect, useRef, Fragment } from 'react';
// import { useHistory } from 'react-router-dom';
import { Spin, Table, Pagination, Button, Input, Select, message, Switch, InputNumber, Tooltip } from 'antd';
import { LoadingOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons';
import Style from './APCourseConfig.module.less';
import fun from '../../../../utils/funSum';
import api from '../../../../utils/api';
import Modal from '../../../../components/modalOfTree/modalOfTree';
// import moment from 'moment';
import Editor from 'wangeditor';

const { Option } = Select;
const { TextArea } = Input;
const APCourseConfig = (props) => {
    const [loading, setLoading] = useState(false);

    const [addCourseModalBool, setAddCourseModalBool] = useState(false);
    const [editCourseModalBool, setEditCourseModalBool] = useState(false);
    let [editor, setEditor] = useState({});
    const [modalCourseName, setModalCourseName] = useState('');
    const [modalCourseID, setModalCourseID] = useState(null);
    const [courseTypeText, setCourseTypeText] = useState(null);
    const [courseTypeValue, setCourseTypeValue] = useState('');
    const [checked, setChecked] = useState(false);
    const [modalAPSubjectText, setModalAPSubjectText] = useState(null);
    const [modalAPSubjectValue, setModalAPSubjectValue] = useState('');
    // const [examinationDate, setExaminationDate] = useState('');
    const [originalPrice, setOriginalPrice] = useState('');
    const [presentPrice, setPresentPrice] = useState('');
    const [modalAPCourseThemeText, setModalAPCourseThemeText] = useState(null);
    const [modalAPCourseThemeValue, setModalAPCourseThemeValue] = useState('');
    const [courseIntroductVideoList, setCourseIntroductVideoList] = useState([]);
    const [modalCourseIntroductVideoText, setModalCourseIntroductVideoText] = useState('');
    const [modalCourseIntroductVideoValue, setModalCourseIntroductVideoValue] = useState('');
    const [modalCourseDescription, setModalCourseDescription] = useState('');
    const editorRef = useRef(null);

    const [courseID, setCourseID] = useState('');
    const [courseName, setCourseName] = useState('');
    const [APSubjectValue, setAPSubjectValue] = useState('');
    const [apSubjectList, setApSubjectList] = useState([]);
    const [dataSource, setDataSource] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);
    const columns = [
        fun.getColumnItem('课程ID', 'id', 90),
        {
            title: '课程名称',
            dataIndex: 'title',
            align: 'center',
            render: (title) => {
                return (
                    <Tooltip placement="topLeft" title={title}>{title}</Tooltip>
                )
            }
        },
        {
            title: '课程类型',
            dataIndex: 'type',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: (type) => {
                let text = type === 1 ? '钩子课' : type === 2 ? '正价课' : '';
                return (
                    <Tooltip placement="top" title={text}>
                        {text}
                    </Tooltip>
                )
            }
        },
        {
            title: '课程主题',
            align: 'center',
            render: (record) => {
                let text = record.lectureTheme === 1 ? 'Exam-Cracking Workshop' : record.lectureTheme === 2 ? 'AP Problem-solving Workshop' : record.lectureTheme === 3 ? 'Ultimate AP Prep Pass' : null;
                return (
                    <Tooltip placement="top" title={text}>{text}</Tooltip>
                )
            }
        },
        fun.getColumnItem('学科', 'lectureSubjectTitle'),
        {
            title: '课程价格',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: (record) => {
                return (
                    <Tooltip placement="top" title={() => (`真实价格：${record.price / 100} 课程原价：${record.displayPrice / 100}`)}>
                        {Number(record.price) / 100}&emsp;<del>{Number(record.displayPrice) / 100}</del>
                    </Tooltip>
                )
            }
        },
        {
            title: '课程状态',
            dataIndex: 'onlineStatus',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: (onlineStatus) => {
                let text = onlineStatus === 1 ? '上架' : '下架';
                return (
                    <Tooltip placement="top" title={text}>
                        {text}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作',
            align: 'center',
            width: 360,
            ellipsis: {
                showTitle: false,
            },
            render: (record) => {
                return (
                    <div className={Style.tableOperation}>
                        <Button type='primary' onClick={() => { showEditModal(record) }}>编辑</Button>
                        <Button type='link' onClick={() => { goPage(`/admin/v1/ap-coursemanage/ap-courseresourcesconfig?id=${record.id}&title=${encodeURI(record.title)}&sub=${record.lectureSubjectTitle}`) }}>课程资源</Button>
                        <Button type='link' onClick={() => { goPage(`/admin/v1/ap-coursemanage/ap-livecourseconfig?id=${record.id}&title=${encodeURI(record.title)}&sub=${record.lectureSubjectTitle}`) }}>直播课管理</Button>
                        <Button type='link' onClick={() => { goPage(`/admin/v1/ap-coursemanage/ap-courseclassmanage?id=${record.id}&title=${encodeURI(record.title)}&sub=${record.lectureSubjectTitle}`) }}>班级管理</Button>
                    </div>
                )
            }
        },
    ]
    useEffect(() => {
        getAPCourseList({ idisplayStart: 0, idisplayLength: pageSize });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    useEffect(() => {
        getAPSubjectList();
        getModalCourseIntroductVideoList();
    }, [])
    // 获取课程列表
    const getAPCourseList = (params) => {
        setLoading(true);
        api.getAPCourseList(params)
            .then((res) => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                setDataSource(res.result.data);
                setTotal(res.result.total);
                setLoading(false);
            })
            .catch((err) => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取ap学科 下拉
    const getAPSubjectList = () => {
        setLoading(true);
        api.getAPSubjectList()
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result ? res.result : [];
                setApSubjectList(data);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取课程简介视频 下拉
    const getModalCourseIntroductVideoList = () => {
        api.getCourseIntroductVideoList()
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result.data ? res.result.data : [];
                setCourseIntroductVideoList(data);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
            })
    }
    // 获取课程id input
    const getCourseID = (e) => {
        setCourseID(e.target.value);
    }
    // 获取课程名称 input
    const getCourseName = (e) => {
        setCourseName(e.target.value);
    }
    // 获取AP学科 select
    const getAPSubject = (value, option) => {
        if (value && option) {
            setAPSubjectValue(option.key);
        } else {
            setAPSubjectValue('');
        }
    }
    // 查询
    const search = () => {
        getAPCourseList({ id: courseID, title: courseName, lectureSubjectId: APSubjectValue, idisplayStart: 0, idisplayLength: pageSize });
    }
    // const history = useHistory();
    const goPage = (url) => {
        props.history.push(url);
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        // console.log(pageParameter, pageSizeParameter);
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
        getAPCourseList({ id: courseID, title: courseName, lectureSubjectId: APSubjectValue, idisplayStart: pageParameter - 1, idisplayLength: pageSizeParameter });
    }
    //---新建/编辑课程 弹框---
    const showEditModal = (record) => {
        // console.log(record);
        setModalCourseID(record.id);
        setModalCourseName(record.title);
        setCourseTypeText(record.type === 1 ? '钩子课' : '正价课');
        setCourseTypeValue(record.type);
        setChecked(record.onlineStatus === 1);
        setModalAPSubjectText(record.lectureSubjectTitle);
        setModalAPSubjectValue(record.lectureSubjectId);
        // setExaminationDate(record.examTime);
        setOriginalPrice(Number(record.price) / 100);
        setPresentPrice(Number(record.displayPrice) / 100);
        setModalAPCourseThemeText(record.lectureTheme === 1 ? 'Exam-Cracking Workshop' : record.lectureTheme === 2 ? 'AP Problem-solving Workshop' : record.lectureTheme === 3 ? 'Ultimate AP Prep Pass' : null);
        setModalAPCourseThemeValue(record.lectureTheme ? record.lectureTheme : '');
        setModalCourseIntroductVideoText(courseIntroductVideoList.filter(item => item.id === record.courseDescriptionVideoId)[0] && courseIntroductVideoList.filter(item => item.id === record.courseDescriptionVideoId)[0].videoTitle);
        setModalCourseIntroductVideoValue(record.courseDescriptionVideoId);
        setEditCourseModalBool(true);
        setModalCourseDescription(record.courseDescription);
    }
    const getJSX = (bool) => {
        return (
            <Fragment>
                <div className={Style.lineWrap}>
                    <span>课程主题<span className={Style.red}>*</span>：</span>
                    <Select className={Style.formEl} placeholder='请选择课程主题' value={modalAPCourseThemeText} onChange={getModalAPCourseTheme} allowClear>
                        <Option key={1} value='Exam-Cracking Workshop'>Exam-Cracking Workshop</Option>
                        <Option key={2} value='AP Problem-solving Workshop'>AP Problem-solving Workshop</Option>
                        <Option key={3} value='Ultimate AP Prep Pass'>Ultimate AP Prep Pass</Option>
                    </Select>
                </div>
                <div className={Style.lineWrap}>
                    <span>AP学科<span className={Style.red}>*</span>：</span>
                    <Select className={Style.formEl} placeholder='请选择AP学科' value={modalAPSubjectText} onChange={getModalAPSubject} allowClear>
                        {apSubjectList.map((item) => {
                            return (
                                <Option key={item.id} value={item.title}>{item.title}</Option>
                            )
                        })}
                    </Select>
                </div>
                <div className={`${Style.lineWrap} ${Style.lineWrap1}`}>
                    <span>课程名称<span className={Style.red}>*</span>：</span>
                    <TextArea className={Style.formEl} placeholder='请输入课程名称' rows={1} maxLength='200' showCount value={modalCourseName} onChange={getModalCourseName} />
                </div>
                <div className={Style.lineWrap}>
                    <span>课程类型<span className={Style.red}>*</span>：</span>
                    <Select className={Style.formEl} placeholder='请选择课程类型' disabled value={courseTypeText} onChange={getCourseType} allowClear={true} optionLabelProp="label" showSearch={true}>
                        <Option key={1} value='钩子课'>钩子课</Option>
                        <Option key={2} value='正价课'>正价课</Option>
                    </Select>
                </div>
                <div className={Style.lineWrap}>
                    <span>课程状态<span className={Style.red}>*</span>：</span>
                    <Switch checked={checked} onChange={changeStatus} checkedChildren="上线" unCheckedChildren="下线" />
                </div>
                {/* <div className={Style.lineWrap}>
                    <span>考试时间<span className={Style.red}>*</span>：</span>
                    <DatePicker
                        format="YYYY-MM-DD HH:mm:ss"
                        defaultValue={examinationDate ? moment(examinationDate) : ''}
                        onChange={getTestDate}
                        showTime={true}
                    />
                </div> */}
                <div className={Style.lineWrap}>
                    <span>真实价格（美元）<span className={Style.red}>*</span>：</span>
                    <InputNumber className={Style.formInputEl} placeholder='请输入真实价格' min={0} maxLength='10' value={originalPrice} step={0.01} precision={2} onChange={getPresentPrice} />
                </div>
                <div className={Style.lineWrap}>
                    <span>课程原价（美元）：</span>
                    <InputNumber className={Style.formInputEl} placeholder='请输入课程原价' min={0} maxLength='10' value={presentPrice} step={0.01} precision={2} onChange={getOriginalPrice} />
                </div>
                {bool ? <div className={Style.lineWrap}>
                    <span>课程简介视频：</span>
                    <Select placeholder='请输入视频ID' className={Style.formEl} value={modalCourseIntroductVideoText} onChange={getModalCourseIntroductVideo}>
                        {courseIntroductVideoList.map((item) => {
                            return (
                                <Option key={item.id} value={item.videoTitle}>{item.videoTitle}</Option>
                            )
                        })}
                    </Select>
                </div> : ''}
                <div className={Style.lineWrap}>
                    <span>课程简介（请用一句话描述）<span className={Style.red}>*</span>：</span>
                    <div ref={editorRef}></div>
                </div>
            </Fragment>
        )
    }
    useEffect(() => {
        editorInit();
        if (editCourseModalBool) {
            editor.txt.html(modalCourseDescription);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [addCourseModalBool, editCourseModalBool]);
    const editorInit = () => {
        if (!addCourseModalBool && !editCourseModalBool) return;
        editor = new Editor(editorRef.current);
        // 设置编辑区域高度为 200px
        // editor.customConfig.height = 200
        // 自定义菜单配置
        editor.customConfig.menus = [
            'head',  // 标题
            'bold',  // 粗体
            'fontSize',  // 字号
            'fontName',  // 字体
            'italic',  // 斜体
            'underline',  // 下划线
            'strikeThrough',  // 删除线
            'foreColor',  // 文字颜色
            'backColor',  // 背景颜色
            'list',  // 列表
            'justify',  // 对齐方式
            'quote',  // 引用
            'image',  // 插入图片
            'undo',  // 撤销
            'redo'  // 重复
        ]
        // 隐藏“网络图片”tab
        editor.customConfig.showLinkImg = false
        // 使用 base64 保存图片
        editor.customConfig.uploadImgShowBase64 = true
        // 自定义字体
        editor.customConfig.fontNames = [
            '宋体',
            '微软雅黑',
            'Arial',
            'Tahoma',
            'Verdana'
        ]
        // 自定义配置颜色（字体颜色、背景色）
        editor.customConfig.colors = [
            '#000000',
            '#eeece0',
            '#1c487f',
            '#4d80bf',
            '#c24f4a',
            '#8baa4a',
            '#7b5ba1',
            '#46acc8',
            '#ffffff',
            '#f9963b',
        ]
        // 将图片大小限制为 100M
        editor.customConfig.uploadImgMaxSize = 100 * 1024 * 1024
        // 限制一次最多上传 1 张图片
        editor.customConfig.uploadImgMaxLength = 1
        //
        editor.customConfig.customUploadImg = (files, insert) => {
            // files 是 input 中选中的文件列表
            // insert 是获取图片 url 后，插入到编辑器的方法
            setLoading(true);
            api.getUploadPicUrl()
                .then((data) => {
                    if (data.ret === 20000) {
                        api.uploadAWS(data.result.url, files[0])
                            .then((res) => {
                                insert(data.result.cmsCloudfront + '/' + data.result.key);
                                setLoading(false);
                            })
                            .catch((err) => {
                                message.error(err);
                            })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err);
                    setLoading(false);
                })
            // 上传代码返回结果之后，将图片插入到编辑器中
        }
        //自定义错误提示方法
        editor.customConfig.customAlert = function (info) {
            // info 是需要提示的内容
            message.error(info);
        }
        editor.create();
        setEditor(editor);
    }
    // 获取课程名称
    const getModalCourseName = (e) => {
        setModalCourseName(e.target.value);
    }
    // 获取课程类型
    const getCourseType = (value, option) => {
        if (value && option) {
            setCourseTypeText(value);
            setCourseTypeValue(option.key);
        } else {
            setCourseTypeText(null);
            setCourseTypeValue(null);
        }
    }
    //课程状态 switch
    const changeStatus = (checked) => {
        setChecked(checked);
    }
    // 获取ap学科
    const getModalAPSubject = (value, option) => {
        if (value && option) {
            setModalAPSubjectText(value);
            setModalAPSubjectValue(option.key);
            setModalCourseName((modalAPCourseThemeText ? `${modalAPCourseThemeText} for ` : '') + value);
        } else {
            let text = modalAPSubjectText;
            setModalAPSubjectText(null);
            setModalAPSubjectValue('');
            if (editCourseModalBool && !modalCourseName.includes(text)) return;
            setModalCourseName((modalAPCourseThemeText ? modalAPCourseThemeText : ''));
        }
    }
    //考试时间
    // const getTestDate = (date, dateString) => {
    //     setExaminationDate(dateString);
    // }
    // 课程原价
    const getOriginalPrice = (value) => {
        setPresentPrice(value);
    }
    // 真实价格
    const getPresentPrice = (value) => {
        setOriginalPrice(value);
    }
    // 课程主题
    const getModalAPCourseTheme = (value, option) => {
        if (value && option) {
            setModalAPCourseThemeText(value);
            setModalAPCourseThemeValue(option.key);
            setModalCourseName(value + (modalAPSubjectText ? ` for ${modalAPSubjectText}` : ''));
            if (value === 'Exam-Cracking Workshop') {
                setCourseTypeText('钩子课');
                setCourseTypeValue(1);
            } else {
                setCourseTypeText('正价课');
                setCourseTypeValue(2);
            }
        } else {
            let text = modalAPCourseThemeText;
            setModalAPCourseThemeText(null);
            setModalAPCourseThemeValue('');
            setCourseTypeText(null);
            setCourseTypeValue(null);
            if (editCourseModalBool && !modalCourseName.includes(text)) return;
            setModalCourseName((modalAPSubjectText ? modalAPSubjectText : ''));
        }
    }
    // 获取课程简介视频
    const getModalCourseIntroductVideo = (value, option) => {
        if (value && option) {
            setModalCourseIntroductVideoText(value);
            setModalCourseIntroductVideoValue(option.key);
        } else {
            setModalCourseIntroductVideoText('');
            setModalCourseIntroductVideoValue('');
        }
    }
    //确定
    const courseSave = () => {
        setLoading(true);
        if (editor.txt.html() === '<p><br></p>') {
            setLoading(false);
            message.warning('请输入课程简介！');
            return;
        }
        // api.saveCourseInfo({ id: modalCourseID, courseDescription: editor.txt.html(), courseDescriptionVideoId: modalCourseIntroductVideoValue, displayPrice: Number((originalPrice * 100).toFixed()), examTime: examinationDate, lectureSubjectId: modalAPSubjectValue, onlineStatus: checked ? 1 : 2, price: Number((presentPrice * 100).toFixed()), projectId: 3, title: modalCourseName, type: courseTypeValue })
        api.saveCourseInfo({ id: modalCourseID, courseDescription: editor.txt.html(), courseDescriptionVideoId: modalCourseIntroductVideoValue, displayPrice: Number((presentPrice * 100).toFixed()), lectureSubjectId: modalAPSubjectValue, onlineStatus: checked ? 1 : 2, price: Number((originalPrice * 100).toFixed()), projectId: 3, title: modalCourseName, lectureTheme: modalAPCourseThemeValue, type: courseTypeValue })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                message.success(res.msg);
                getAPCourseList({ idisplayStart: 0, idisplayLength: pageSize });
                close();
            })
            .catch(err => {
                // console.log(err);
                setLoading(false);
                message.error(err.msg);
            })
    }
    const close = () => {
        setLoading(false);
        setAddCourseModalBool(false);
        setEditCourseModalBool(false);
        setModalCourseName('');
        setModalCourseID(null);
        setCourseTypeText(null);
        setCourseTypeValue('');
        setChecked(false);
        setModalAPSubjectText(null);
        setModalAPSubjectValue('');
        // setExaminationDate('');
        setOriginalPrice('');
        setPresentPrice('');
        setModalAPCourseThemeText(null);
        setModalAPCourseThemeValue(null);
        setModalCourseIntroductVideoText('');
        setModalCourseIntroductVideoValue('');
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.searchHead}>
                <div className={Style.searchHeadLeft}>
                    <Button type="primary" icon={<PlusOutlined />} onClick={() => { setAddCourseModalBool(true); }}>新建课程</Button>
                    <div className={Style.searchItem}>
                        <span className={Style.searchText}>课程ID:</span>
                        <Input className={Style.searchInput} placeholder='请输入AP课程ID' onChange={getCourseID} />
                    </div>
                    <div className={Style.searchItem}>
                        <span className={Style.searchText}>课程名称:</span>
                        <Input className={Style.searchInput} placeholder='请输入AP课程名称' onChange={getCourseName} />
                    </div>
                    <div className={Style.searchItem}>
                        <span className={Style.searchText}>AP学科:</span>
                        <Select className={Style.searchSelect} placeholder='全部' onChange={getAPSubject} allowClear>
                            {apSubjectList.map((item) => {
                                return (
                                    <Option key={item.id} value={item.title}>{item.title}</Option>
                                )
                            })}
                        </Select>
                    </div>
                </div>
                <Button type="primary" icon={<SearchOutlined />} onClick={search}>查询</Button>
            </div>
            <Table
                columns={columns}
                dataSource={dataSource}
                rowKey={dataSource => dataSource.id}
                pagination={false}
            ></Table>
            <Pagination className={Style.pagination} pageSize={pageSize} showQuickJumper total={total} current={page} onChange={paginationChange}></Pagination>
            {/* 新建 */}
            {addCourseModalBool ? <Modal title='新建课程' close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' onClick={courseSave}>确定</Button>]}>
                {getJSX()}
            </Modal> : ''}
            {/* 编辑 */}
            {editCourseModalBool ? <Modal title='编辑课程' close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' onClick={courseSave}>确定</Button>]}>
                {getJSX(true)}
            </Modal> : ''}
        </Spin>
    )
}

export default APCourseConfig;