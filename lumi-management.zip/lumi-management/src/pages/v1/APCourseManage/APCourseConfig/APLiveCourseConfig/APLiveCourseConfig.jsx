//ap课程配置>>>直播课管理
import React, { useState, useEffect } from 'react';
import { Spin, Table, Pagination, Button, Popconfirm, message, InputNumber, Input, Tooltip } from 'antd';
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import Style from './APLiveCourseConfig.module.less';
import fun from '../../../../../utils/funSum';
import api from '../../../../../utils/api';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
const { TextArea } = Input;

const APLiveCourseConfig = (props) => {
    const [loading, setLoading] = useState(false);
    const [id, setID] = useState('');
    const [title, setTitle] = useState('');
    const [subName, setSubName] = useState('');

    const [dataSource, setDataSource] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);
    const [showAddLiveCourseModal, setShowAddLiveCourseModal] = useState(false);
    const [modalLiveCourseID, setModalLiveCourseID] = useState(null);
    const [modalLiveCourseName, setModalLiveCourseName] = useState('');
    const [modalLiveTime, setModalLiveTime] = useState('');
    const columns = [
        fun.getColumnItem('主题ID', 'id', 90),
        fun.getColumnItem('主题名称', 'title'),
        {
            title: '时长（min）',
            dataIndex: 'idealDurationS',
            align: 'center',
            render: (idealDurationS) => {
                return (
                    <Tooltip placement="top" title={idealDurationS}>{idealDurationS}</Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: 240,
            render: (record) => {
                return (
                    <div className={Style.tableOperation}>
                        <Button type='primary' onClick={() => {
                            props.history.push(`/admin/v1/ap-coursemanage/ap-livecourseplan?id=${record.id}&lectureId=${id}&title=${encodeURI(record.title)}&time=${record.idealDurationS}`)
                        }}>排课</Button>
                        <Button type='primary' onClick={() => { edit(record) }}>编辑</Button>
                        <Popconfirm title="确认要删除吗？" onConfirm={() => { confirm(record); }} okText="确认" cancelText="取消">
                            <Button type='primary'>删除</Button>
                        </Popconfirm>
                    </div>
                )
            }
        }
    ];
    useEffect(() => {
        let id = props.location.search.split('=')[1].split('&')[0];
        let titleText = decodeURI(props.location.search.split('=')[2].split('&')[0]);
        let subName = decodeURI(props.location.search.split('=')[3]) !== 'null' ? decodeURI(props.location.search.split('=')[3]) : '暂无';
        setID(id);
        setTitle(titleText);
        setSubName(subName);
        getAPLiveCourseList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
    }, [pageSize, props.location.search])
    // 获取ap直播课主题列表
    const getAPLiveCourseList = (params) => {
        setLoading(true);
        api.getAPLiveCourseList(params)
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result.data ? res.result.data : [];
                setDataSource(data);
                setTotal(res.result.total);
                setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 确认删除
    const confirm = (record) => {
        // console.log(record)
        setLoading(true);
        api.deleteAPLiveCourse({ id: record.id })
            .then(res => {
                console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                message.success(res.msg);
                getAPLiveCourseList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize });
                // setLoading(false);
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        // console.log(pageParameter, pageSizeParameter)
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
        getAPLiveCourseList({ lectureId: id, idisplayStart: pageParameter - 1, idisplayLength: pageSizeParameter })
    }
    const edit = (record) => {
        // console.log(record);
        setShowAddLiveCourseModal(true);
        setModalLiveCourseID(record.id);
        setModalLiveCourseName(record.title);
        setModalLiveTime(record.idealDurationS);
    }
    // 新建/编辑直播课主题
    const saveLiveCourse = () => {
        setLoading(true);
        api.saveLiveCourse({ id: modalLiveCourseID, idealDurationS: modalLiveTime, lectureId: id, title: modalLiveCourseName })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                message.success(res.msg);
                getAPLiveCourseList({ lectureId: id, idisplayStart: 0, idisplayLength: pageSize })
                // setLoading(false);
                close();
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const close = () => {
        setShowAddLiveCourseModal(false);
        setModalLiveCourseID(null);
        setModalLiveCourseName('');
        setModalLiveTime('');
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.wrap}>
                <Button type='primary' className={Style.goBack} onClick={() => {
                    props.history.push('/admin/v1/ap-coursemanage/ap-courseconfig')
                }}>返回上一级</Button>
                <div className={Style.courseTitle}>直播课管理：{title}</div>
                <div className={Style.detail}>
                    <div className={Style.detailLeft}>
                        <span className={Style.detailTitle}>学科：</span>
                        <span className={Style.detailContent}>{subName}</span>
                    </div>
                </div>
                <div className={Style.btnWrap}>
                    <Button type='primary' icon={<PlusOutlined />} className={Style.addLiveCoursetheme} onClick={() => { setShowAddLiveCourseModal(true); setModalLiveCourseID(null); }}>新建直播课主题</Button>
                    <Button type='primary' onClick={()=>{
                        props.history.push(`/admin/v1/ap-coursemanage/ap-courseclassmanage?id=${id}&title=${encodeURI(title)}&sub=${subName}`)
                    }}>前往班级管理</Button>
                </div>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    rowKey={dataSource => dataSource.id}
                    pagination={false}
                ></Table>
                <Pagination className={Style.pagination} pageSize={pageSize} showQuickJumper total={total} current={page} onChange={paginationChange}></Pagination>
                {showAddLiveCourseModal ? <Modal title='新建/编辑直播课主题' close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' onClick={saveLiveCourse}>确定</Button>]}>
                    <div className={Style.lineWrap}>
                        <span className={Style.modalName}>直播课主题名称<span className={Style.red}>*</span>：</span>
                        <TextArea className={Style.formEl} placeholder='请输入直播课主题名称' rows={1} maxLength='200' showCount value={modalLiveCourseName} onChange={(e) => { setModalLiveCourseName(e.target.value); }} />
                    </div>
                    <div className={Style.lineWrap}>
                        <span className={Style.modalName}>直播时长（min）<span className={Style.red}>*</span>：</span>
                        <InputNumber className={Style.formEl} placeholder='请输入直播时长' min={0} maxLength='3' value={modalLiveTime} step={1} precision={0} onChange={(value) => { setModalLiveTime(value); }} />
                    </div>
                </Modal> : ''}
            </div>
        </Spin>
    )
}

export default APLiveCourseConfig;