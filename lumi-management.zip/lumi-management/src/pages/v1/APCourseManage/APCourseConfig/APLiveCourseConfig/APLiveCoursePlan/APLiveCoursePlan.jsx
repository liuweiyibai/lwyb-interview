//ap课程配置>>>直播课管理>>>排课
import React, { useState, useEffect } from 'react';
import { Spin, Table, Pagination, Button, Popconfirm, Select, DatePicker, message } from 'antd';
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import Style from './APLiveCoursePlan.module.less';
import fun from '../../../../../../utils/funSum';
import Modal from '../../../../../../components/modalOfTree/modalOfTree';
import api from '../../../../../../utils/api';
import moment from 'moment';

const { Option } = Select;
const APLiveCoursePaln = (props) => {
    const [loading, setLoading] = useState(false);
    const [id, setID] = useState('');
    const [lectureId, setLectureId] = useState('');
    const [title, setTitle] = useState('');
    const [time, setTime] = useState('');
    const [addLiveCourseModal, setAddLiveCourseModal] = useState(false);
    const [modalRowID, setModalRowID] = useState(null);
    const [liveCourseID, setLiveCourseID] = useState(null);
    const [modalTitle, setModalTitle] = useState('');
    const [teacherList, setTeacherList] = useState([]);
    const [teacherNameText, setTeacherNameText] = useState(null);
    const [teacherNameValue, setTeacherNameValue] = useState('');
    const [liveCourseBeginDate, setLiveCourseBeginDate] = useState('');

    const [dataSource, setDataSource] = useState([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [total, setTotal] = useState(0);
    const columns = [
        fun.getColumnItem('直播课ID', 'id', 90),
        fun.getColumnItem('直播课名称', 'title'),
        fun.getColumnTimeItem('直播课开始时间（美东时间）', 'liveAt',null,240),
        fun.getColumnItem('授课老师', 'teacherName'),
        {
            title: '操作项',
            align: 'center',
            width: 240,
            render: (record) => {
                return (
                    <div className={Style.tableOperation}>
                        <Button type='primary' onClick={() => { edit(record); }}>编辑</Button>
                        <Button type='primary' onClick={() => { copy(record); }}>复制</Button>
                        <Popconfirm title="确认要删除吗？" onConfirm={() => { confirm(record); }} okText="确认" cancelText="取消">
                            <Button type='primary'>删除</Button>
                        </Popconfirm>
                    </div>
                )
            }
        }
    ];
    useEffect(() => {
        let id = props.location.search.split('=')[1].split('&')[0];
        let lecID = props.location.search.split('=')[2].split('&')[0];
        let title = decodeURI(props.location.search.split('=')[3].split('&')[0]);
        let t = Number(props.location.search.split('=')[4]);
        setID(id);
        setLectureId(lecID);
        setTitle(title);
        setTime(t);
        getAPLiveCourseLayoutList({ lectureLiveTopicIdList: [Number(id)], idisplayStart: 0, idisplayLength: pageSize });
        getTeacherList({ roleIds: '20,21' })
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    // 获取直播课排课列表
    const getAPLiveCourseLayoutList = (params) => {
        setLoading(true);
        api.getAPLiveCourseLayoutList(params)
            .then((res) => {
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result.data ? res.result.data : [];
                setDataSource(data);
                setTotal(res.result.total);
                setLoading(false);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 获取授课老师列表 下拉
    const getTeacherList = (parmas) => {
        setLoading(true);
        api.getSupplyChainManageList(parmas)
            .then(res => {
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                let data = res.result ? res.result : [];
                setTeacherList(data);
                setLoading(false);
            })
            .catch(err => {
                // console.log(err);
                message.error(err.msg);
                setLoading(false);
            })
    }
    // 确定删除
    const confirm = (record) => {
        setLoading(true);
        api.deleteAPLiveCourseLayout({ id: record.id })
            .then(res => {
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getAPLiveCourseLayoutList({ lectureLiveTopicIdList: [Number(id)], idisplayStart: 0, idisplayLength: pageSize });
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const paginationChange = (pageParameter, pageSizeParameter) => {
        setPage(pageParameter);
        setPageSize(pageSizeParameter);
        getAPLiveCourseLayoutList({ lectureLiveTopicIdList: [Number(id)], idisplayStart: pageParameter - 1, idisplayLength: pageSizeParameter });
    }
    // 编辑
    const edit = (record) => {
        // console.log(record);
        setAddLiveCourseModal(true);
        setModalTitle('编辑直播课');
        setModalRowID(record.id);
        setLiveCourseID(record.lectureLiveTopicInstanceId);
        setLiveCourseBeginDate(record.liveAt);
        setTeacherNameText(record.teacherName);
        setTeacherNameValue(record.teacherId);
    }
    //复制
    const copy = (record) => {
        setAddLiveCourseModal(true);
        setModalTitle('复制直播课');
        setLiveCourseID(null);
        setModalRowID(null);
        setTeacherNameText(record.teacherName);
        setTeacherNameValue(record.teacherId);
    }
    // 获取授课老师
    const getTeacherName = (value, option) => {
        if (value && option) {
            setTeacherNameText(value);
            setTeacherNameValue(option.key);
        } else {
            setTeacherNameText(null);
            setTeacherNameValue('');
        }
    }
    // 获取直播开始时间
    const getLiveBeginDate = (date, dateString) => {
        setLiveCourseBeginDate(dateString);
    }
    // 确定
    const saveLiveCourse = () => {
        setLoading(true);
        api.saveLiveCourseLayout({ id: liveCourseID, lectureId: lectureId, lectureLiveTopicId: Number(id), preLiveCourseId: modalRowID, liveAt: moment(liveCourseBeginDate).format('YYYY-MM-DD HH:mm:ss'), teacherId: teacherNameValue, idealDurationS: time, title: title })
            .then(res => {
                // console.log(res);
                if (res.ret !== 20000) {
                    return Promise.reject(res);
                }
                getAPLiveCourseLayoutList({ lectureLiveTopicIdList: [Number(id)], idisplayStart: 0, idisplayLength: pageSize });
                close();
            })
            .catch(err => {
                message.error(err.msg);
                setLoading(false);
            })
    }
    const close = () => {
        setAddLiveCourseModal(false);
        setModalRowID(null);
        setLiveCourseID(null);
        setLiveCourseBeginDate('');
        setTeacherNameText(null);
        setTeacherNameValue('');
    }
    return (
        <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
            <div className={Style.wrap}>
                <Button type='primary' className={Style.goBack} onClick={() => {
                    // props.history.push('/admin/v1/ap-coursemanage/ap-livecourseconfig')
                    props.history.goBack()
                }}>返回上一级</Button>
                <div className={Style.themeName}>排课：{title}</div>
                <div className={Style.liveDurationWrap}>
                    <span>直播时长：</span>
                    <span>{time} min</span>
                </div>
                <Button type='primary' icon={<PlusOutlined />} className={Style.addLiveCoursetheme} onClick={() => { setAddLiveCourseModal(true); setModalTitle('新建直播课'); setLiveCourseID(null); setModalRowID(null); }}>新建直播课</Button>
                <Table
                    columns={columns}
                    dataSource={dataSource}
                    rowKey={dataSource => dataSource.id}
                    pagination={false}
                ></Table>
                <Pagination className={Style.pagination} pageSize={pageSize} showQuickJumper total={total} current={page} onChange={paginationChange}></Pagination>
                {/* 新建/编辑 */}
                {addLiveCourseModal ? <Modal title={modalTitle} close={close} actions={[<Button onClick={close}>取消</Button>, <Button type='primary' disabled={!teacherNameText || !teacherNameValue || !liveCourseBeginDate} onClick={saveLiveCourse}>确定</Button>]}>
                    <div className={Style.lineWrap}>
                        <span className={Style.modalName}>直播课主题<span className={Style.red}>*</span>：{title}</span>
                    </div>
                    <div className={Style.lineWrap}>
                        <span className={Style.modalName}>授课老师<span className={Style.red}>*</span>：</span>
                        <Select className={Style.formEl} placeholder='请选择授课老师' value={teacherNameText} onChange={getTeacherName} allowClear={true} showSearch={true}>
                            {teacherList.map(item => {
                                return (
                                    <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                )
                            })}
                        </Select>
                    </div>
                    <div className={Style.lineWrap}>
                        <span>直播开始时间（美东）<span className={Style.red}>*</span>：</span>
                        <DatePicker
                            format="YYYY-MM-DD HH:mm"
                            defaultValue={liveCourseBeginDate ? moment(liveCourseBeginDate) : ''}
                            onChange={getLiveBeginDate}
                            showTime={{ format: 'HH:mm' }}
                            minuteStep={15}
                        />
                    </div>
                </Modal> : ''}
            </div>
        </Spin>
    )
}

export default APLiveCoursePaln;