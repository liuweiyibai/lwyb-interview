import React, { Component, Fragment } from 'react';
import { Button, Table, Pagination, Input, Select, Spin, Tooltip, Divider, message, Popconfirm, Upload } from 'antd';
import { LoadingOutlined, FolderOpenOutlined, SearchOutlined, UploadOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons';
import Style from './APVideoManagement.module.less';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import moment from 'moment';
import Modal from '../../../../components/modalOfTree/modalOfTree';

const { Option } = Select;
const { TextArea } = Input;
class APVideoManagement extends Component {
    constructor() {
        super()
        this.state = {
            loading: false,
            showUploadModal: false,
            showLookUpModal: false,
            showEditModal: false,
            showVideoModal: false,
            dataSource: [],
            fileList: [],
            subjectList: [],
            titleList: [],//关联课列表
            videoId: '',//视频id
            videoName: '',//视频名称
            subjectName: null,//学科名
            subjectId: '',//学科id
            //编辑
            rowId: '',//所点击行的视频id
            editModalVideoName: '',//视频名称
            editModalReword: '',//备注
            editModalSubjectName: null,//所属学科名
            editModalSubjectId: '',//所属学科id

            page: 1,
            pageSize: 10,
            total: 0,
        }
    }
    columns = [
        {
            title: '视频ID',
            align: 'center',
            width: '80px',
            ellipsis: {
                showTitle: false,
            },
            render: (record) => {
                return (
                    <div>
                        <Button type='link' onClick={() => { this.videoPreview(record) }}>{record.id}</Button>
                    </div>
                )
            }
        },
        fun.getColumnItem('视频名称', 'videoName'),
        fun.getColumnItem('学科', 'subjectName'),
        fun.getColumnItem('备注', 'remark'),
        {
            title: '关联备考课',
            align: 'center',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return (
                    Array.isArray(record.title) && record.title.length > 0 ? <Button type='link' onClick={() => { this.lookUp(record) }}>查看</Button> : '无'
                )
            }
        },
        {
            title: '上传时间',
            dataIndex: 'createdAt',
            align: 'center',
            width: 180,
            ellipsis: {
                showTitle: false,
            },
            render: createdAt => {
                let date = createdAt ? moment(new Date(createdAt).getTime() - new Date().getTimezoneOffset() * 60000).format('YYYY/MM/DD HH:mm:ss') : '';//用户所在地时间
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '操作项',
            align: 'center',
            width: '210px',
            render: (record) => (
                <div>
                    <Button type='primary' className={Style.btn} icon={<EditOutlined />} onClick={() => { this.edit(record) }}>编辑</Button>
                    <Popconfirm title="确认要删除吗？" okText="确定" cancelText="取消" onConfirm={() => { this.delete(record) }}>
                        <Button type='primary' icon={<DeleteOutlined />}>删除</Button>
                    </Popconfirm>
                </div>
            ),
        },
    ]
    componentDidMount () {
        this.getSubjectList();
        this.getAPDelayedVideoList({ idisplayStart: 0, idisplayLength: this.state.pageSize, videoType: 2 });
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount () {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取学科列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getAPSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取ap录播课列表
    getAPDelayedVideoList = (params) => {
        this.setState({ loading: true }, () => {
            api.searchAPRecordResourcesList(params)
                .then((data) => {
                    // console.log(data)
                    if (data.ret === 20000) {
                        if (Array.isArray(data.result.data) && data.result.data.length <= 0 && this.state.page > 1) {
                            this.paginationChange(this.state.page - 1, this.state.pageSize);
                            return;
                        }
                        this.setState({ dataSource: data.result.data, page: data.result.start + 1, total: data.result.total, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //点击视频上传
    uploadVideo = () => {
        this.setState({ showUploadModal: true });
    }
    //上传文件改变时的状态
    handleChange = ({ fileList }) => {
        for (let item of fileList) {
            if (item.name) {
                let pictureType = item.name.split('.')[item.name.split('.').length - 1]
                if (pictureType !== 'mp4' && pictureType !== 'mov') {
                    message.error('仅可上传mov或mp4格式文件！!');
                    this.setState({ fileList: [] });
                    return;
                }
            }
        }
        this.setState({ fileList });
    }
    //确认上传视频
    submit = async () => {
        if (this.state.fileList.length <= 0) {
            message.error('请至少选择一个文件！');
            return;
        } else if (this.state.fileList.length > 30) {
            message.error('一次上传数量不能超过30个！');
            return;
        }
        this.setState({ loading: true });
        for (let item of this.state.fileList) {
            //获取aws上传地址
            await api.getAddress({ fileName: '.' + item.originFileObj.name.split('.')[1] })
                .then(async (data) => {
                    if (data.ret === 20000) {
                        let url = data.result.key;
                        //往aws上传视频
                        await api.uploadAWS(data.result.url, item.originFileObj)
                            .then(async (data) => {
                                //上传aws成功后通知服务端
                                let data2 = await api.notice({ fileName: item.originFileObj.name, key: url, type: 4 });
                                if (data2.ret === 20000) {
                                    message.success(item.originFileObj.name + '上传成功');
                                } else {
                                    return Promise.reject(data2);
                                }
                            })
                            .catch((err) => {
                                message.error(err.msg);
                            })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                })
        }
        this.getAPDelayedVideoList({ idisplayStart: this.state.page - 1, idisplayLength: this.state.pageSize, id: this.state.videoId, videoName: this.state.videoName, subId: this.state.subjectId, videoType: 2 });
        this.setState({ showUploadModal: false, loading: false, fileList: [] });
    }
    //获取视频id
    getVideoID = (e) => {
        this.setState({ videoId: e.target.value });
    }
    //获取视频名称
    getVideoName = (e) => {
        this.setState({ videoName: e.target.value });
    }
    //获取所选学科下拉
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur()
            this.setState({ subjectName: value, subjectId: option.key });
        } else {
            this.setState({ subjectName: null, subjectId: '' });
        }
    }
    //查询
    search = () => {
        this.getAPDelayedVideoList({ idisplayStart: 0, idisplayLength: this.state.pageSize, id: this.state.videoId, videoName: this.state.videoName, subId: this.state.subjectId, videoType: 2 });
    }
    //点击查看
    lookUp = (record) => {
        this.setState({ titleList: record.title, showLookUpModal: true });
    }
    //点击关联备考课名 跳转
    goPage = (item) => {
        window.open(api.pageURL + `/admin/v1/testPrepareCourseManage/courseOutline?id=${item.id}`);
    }
    //视频弹框
    //点击视频ID 显示弹框
    videoPreview = (record) => {
        this.setState({ showVideoModal: true, rowInfo: record })
    }
    //点击编辑
    edit = (record) => {
        this.setState({
            rowId: record.id,
            editModalVideoName: record.videoName,
            editModalReword: record.remark,
            editModalSubjectName: record.subjectName,
            editModalSubjectId: record.subId,
            showEditModal: true
        });
    }
    //获取编辑 视频名称
    getModalVideoName = (e) => {
        this.setState({ editModalVideoName: e.target.value });
    }
    //获取编辑 备注
    getModalReword = (e) => {
        this.setState({ editModalReword: e.target.value });
    }
    //获取所属学科
    getEditSubject = (value, option) => {
        if (value && option) {
            this.setState({ editModalSubjectName: value, editModalSubjectId: option.key });
        } else {
            this.setState({ editModalSubjectName: null, editModalSubjectId: '' });
        }
    }
    //编辑确定
    editSubmit = () => {
        this.setState({ loading: true }, () => {
            api.editAPVideo({ videoName: this.state.editModalVideoName, remark: this.state.editModalReword, id: this.state.rowId, lectureSubjectId: this.state.editModalSubjectId })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                        this.setState({ showEditModal: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭弹框
    close = () => {
        if (this.state.showVideoModal) {
            let videoDom = document.getElementById('video');
            videoDom.pause();
        }
        this.setState({ showUploadModal: false, showLookUpModal: false, showEditModal: false, showVideoModal: false, fileList: [] });
    }
    //点击删除
    delete = (record) => {
        this.setState({ loading: true }, () => {
            // console.log(record)
            api.delAPDelayedVideo({ id: record.id })
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.paginationChange(this.state.page, this.state.pageSize);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        });
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getAPDelayedVideoList({ idisplayStart: this.state.page - 1, idisplayLength: this.state.pageSize, id: this.state.videoId, videoName: this.state.videoName, subId: this.state.subjectId, videoType: 2 });
        });
    }
    render () {
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.left}>
                            <Button type='primary' className={Style.text} icon={<FolderOpenOutlined />} onClick={this.uploadVideo}>视频上传</Button>
                            <span>视频ID：</span>
                            <Input placeholder='输入视频ID查询' className={Style.input} onChange={this.getVideoID} />
                            <span>视频名称：</span>
                            <Input placeholder='输入视频名称查询' className={Style.input} onChange={this.getVideoName} />
                            <span>学科：</span>
                            <Select placeholder='全部' ref='subject' className={Style.input} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.subjectList.map((item, index) => {
                                    return (
                                        <Option key={item.id} value={item.title}>{item.title}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <Button icon={<SearchOutlined />} type='primary' onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <Table
                        dataSource={this.state.dataSource}
                        columns={this.columns}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                    ></Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`}></Pagination>
                    {this.state.showUploadModal ? <Modal title='上传视频' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.submit}>确认上传</Button>]}>
                        <div className={Style.contentTop}>请选择本地视频文件，支持常见的视频格式，可以批量上传（不超过30个）</div>
                        <Upload
                            className={Style.upload}
                            accept='.mov,.mp4'
                            beforeUpload={() => false}
                            onChange={this.handleChange}
                            fileList={this.state.fileList}
                            multiple={true}
                            progress={
                                {
                                    strokeColor: {
                                        '0%': '#108ee9',
                                        '100%': '#87d068',
                                    },
                                    strokeWidth: 3,
                                    format: percent => `${parseFloat(percent.toFixed(2))}%`,
                                }
                            }
                        >
                            <Button icon={<UploadOutlined />}>选择文件</Button>
                        </Upload>
                    </Modal> : ''}
                    {this.state.showVideoModal ? <Modal title='播放视频' close={this.close}>
                        <div >
                            <video id='video' src={this.state.rowInfo.videoUrl} width='700px' height='500px' autoPlay="autoplay" controls="controls"></video>
                        </div>
                    </Modal> : ''}
                    {this.state.showLookUpModal ? <Modal title='关联备考课' close={this.close}>
                        <div className={Style.titleList}>
                            {this.state.titleList.map((item, index) => {
                                return (
                                    <Button type='link' className={Style.title} key={index} onClick={() => { this.goPage(item) }}>{item.title}</Button>
                                )
                            })}
                        </div>
                    </Modal> : ''}
                    {this.state.showEditModal ? <Modal title='编辑视频信息' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.editSubmit}>确定</Button>]}>
                        <div className={Style.rowWrap}>
                            <span className={Style.span}>视频名称：</span>
                            <Input placeholder="请输入视频名称" className={Style.input} maxLength='200' value={this.state.editModalVideoName} onChange={this.getModalVideoName} />
                        </div>
                        <div className={Style.rowWrap}>
                            <span className={Style.span}>备注：</span>
                            <TextArea placeholder="请输入备注" className={Style.textarea} maxLength='200' rows={1} value={this.state.editModalReword} onChange={this.getModalReword} />
                            <span className={Style.length}>已输入{this.state.editModalReword.length}/200字</span>
                        </div>
                        <div className={Style.rowWrap}>
                            <span className={Style.span}>所属学科：</span>
                            <Select placeholder='全部' className={Style.input} value={this.state.editModalSubjectName} onChange={this.getEditSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.subjectList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.title}>{item.title}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                    </Modal> : ''}
                </Spin>
            </Fragment>
        )
    }
}

export default APVideoManagement;