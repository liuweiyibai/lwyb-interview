import React, { Component, Fragment } from 'react';
import { Upload, message } from 'antd';
import { LoadingOutlined, PlusOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { connect } from 'react-redux';
import Style from './topicsBulkUpload.module.less';
import api from '../../../../utils/api';
import { createWebSocket, closeWebSocket } from '../../../../utils/websocket';

class TopicsBulkUpload extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
        }
    }
    beforeUpload = (file) => {
        if (file.type !== 'application/zip') {
            message.error(`${file.name}不是压缩文件！`);
        }
        this.refs.text.innerHTML = '';
        createWebSocket(api.websocket + this.props.userid, this);
        let formData = new FormData();
        formData.append('file', file);
        this.setState({ loading: true }, () => {
            api.bulkUploadZipFile(formData)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.setState({ loading: false });
                        closeWebSocket();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                    closeWebSocket();
                })
        })
        return false;
    }
    handleChange = info => { };
    componentWillUnmount() {
        closeWebSocket();
    }
    render() {
        return (
            <Fragment>
                <div >
                    <div className={Style.introduction}> <ExclamationCircleOutlined />
						&emsp;使用ZIP压缩文件上传题目及其图片，需包含一个Latex/Excel文件以及一个pic文件夹</div>
                    <div className={Style.uploadButton}>
                        <Upload
                            name="avatar"
                            listType="picture-card"
                            className="avatar-uploader"
                            showUploadList={false}
                            accept='application/zip'
                            beforeUpload={this.beforeUpload}
                            onChange={this.handleChange}
                            disabled={this.state.loading}
                        >
                            <div>
                                {this.state.loading ? <LoadingOutlined /> : <PlusOutlined />}
                                <div className="ant-upload-text">上传ZIP文件</div>
                            </div>
                        </Upload>
                    </div>
                    <div>
                        <h3 className={Style.topicsEntryLogTitle}>题目入库日志</h3>
                        <div ref='text' className={Style.journal}></div>
                    </div>
                </div>
            </Fragment>
        )
    }
}

export default connect(store => store)(TopicsBulkUpload);