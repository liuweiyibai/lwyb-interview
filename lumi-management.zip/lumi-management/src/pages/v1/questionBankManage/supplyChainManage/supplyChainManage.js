import React, { Component, Fragment } from 'react';
import { Spin, Button, Table, Divider, Tooltip, Input, message, Select, DatePicker, Badge, Radio, Pagination, Timeline, InputNumber } from 'antd';
import { LoadingOutlined, SearchOutlined, DownloadOutlined, PlusOutlined, ExclamationCircleOutlined, CloseCircleOutlined, MinusOutlined, EditOutlined } from '@ant-design/icons';
import api from '../../../../utils/api';
import fun from '../../../../utils/funSum.js';
import Style from './supplyChainManage.module.less'
import Modal from '../../../../components/modalOfTree/modalOfTree.js';
import moment from 'moment';
import Viewer from 'viewerjs';
import 'viewerjs/dist/viewer.css';
// import SearchTable from '../../../../components/searchTable/searchTable.js'

const { Option } = Select;
const { TextArea } = Input;

class SupplyChainManage extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            supplyChainStatus: ['待处理', '待分配', '教研中', '录入中', '教研完成', '待质检', '已回收', '已放弃'], // 状态
            supplyChainSourceFrom: ['textbook', 'past test', 'lumi original', '3-party test bank'], // 状态
            // 查询项
            schoolList: [],//学校列表
            gradeList: [],//年级列表
            supplyChainSubjectList: [],//学科列表
            supplyChainEvaluationList: [],//评价体系列表
            supplyChainManageList: [],//供应链经理列表
            topicSourceType: null,//题源类型
            topicSourceTypeId: null,//题源类型ID
            topicSourceStatus: null,//题源状态
            topicSourceStatusId: null,//题源状态ID
            subject: null,//学科
            subjectId: '',//学科ID
            topicSourceID: null,//题源ID
            searchVersion: null,//版本
            searchSchool: null,//学校
            searchSchoolId: null,//学校ID
            searchClassNumber: '',//课号
            source: null,//来源
            sourceId: null,//来源ID
            ISBN: '',//ISBN
            grade: null,//年级
            gradeId: null,//年级的ID
            evaluation: null,//评价体系
            evaluationId: null,//评价体系的ID
            startYear: null,//开始年份
            bringOwnAnswer: null,//自带答案
            bringOwnAnswerId: null,//自带答案的ID
            cheggAnswer: null,// Chegg答案
            cheggAnswerId: null,// Chegg答案的ID
            teachHead: null,//教研负责人
            teachHeadId: '',//教研负责人的ID
            inputHead: null,//录入负责人
            inputHeadId: '',//录入负责人的ID
            qualityHead: null,//质检负责人
            qualityHeadId: null,//质检负责人的ID
            topicSourceName: '',//题源名称
            // 新增题源编辑
            showAddTopicSourceModal: false,//显示新增题源弹框
            showEditTopicSourceModal: false,//显示编辑题源弹框
            editId: '',//编辑ID
            recordInfo: null,
            editTopicSourceType: null,//题源类型
            editTopicSourceTypeId: '',//题源类型ID
            editSource: null,//来源
            editSourceId: '',//来源ID
            editOrderNumber: '',//订单号
            editFileName: '',//文件路径
            editTopicSourceName: '',//题源名称
            editAuthor: '',//作者
            editISBN: '',//isbn
            editTextBookVersion: '',//教材版本
            editGrade: '',//年级
            editSchoolClassNumber: [{ schoolId: null, school: null, classNumber: '' }],//学习和课号
            editSubject: null,//学科
            editSubjectId: '',//学科ID
            editYear: null,//年份
            editEvaluation: null,//评价体系
            editEvaluationId: '',//评价体系ID
            editBringOwnAnswer: null,//自带答案
            editBringOwnAnswerId: '',//自带答案ID
            editCheggAnswer: null,//chegg答案
            editCheggAnswerId: '',//chegg答案ID
            editTeachHead: null,//教研负责人
            editTeachHeadId: '',//教研负责人的ID
            editInputHead: null,//录入负责人
            editInputHeadId: '',//录入负责人的ID
            editQualityHead: null,//质检负责人
            editQualityHeadId: '',//质检负责人的ID
            editRemark: '',//备注
            coverImgUrlKey: '',//广告URL的key，用于确定时
            coverImgUrl: '',//广告URL，用于展示图片/上传图片

            // 查看学校课号列表
            showSchoolClassNumberListModal: false,
            schoolClassNumberList: [],//学校课号列表
            // 质检弹框
            showQualityModal: false,    // 质检弹框
            editQuality: '',
            // 题源完成录入弹框
            showFinishTopicInputModal: false,
            // 完成教研弹框
            showFinishTeachModal: false,
            // 分配题源弹框
            showDistributeTopicSourceModal: false,
            editTopicFlow: null,
            editTopicFlowId: '',
            editSelectDistribute: null,
            editSelectDistributeId: '',
            // 处理题源弹框
            showProcessTopicSourceModal: false,

            // 操作记录弹框
            showOperationRecord: false,
            operationLogList: [],
            operationPage: 1,//当前页码
            operationPageSize: 10,//每页显示条数
            operationTotal: 0,//总条数

            dataSource: [],//广告资源
            page: 1,//当前页码
            pageSize: 10,//每页显示条数
            total: 0,//总条数
            showColumn: [],//显示的column
            showColumnTitle: [],//显示的column
            scrollX: 2800,//x轴长度
        }
    }
    //广告列表
    columns = [
        {
            title: '编辑',
            align: 'center',
            width: '90px',
            render: record => {
                return (
                    <EditOutlined onClick={() => { this.editTopicSource(record) }} />
                )
            }
        },
        fun.getColumnItem('题源ID', 'id'),
        {
            title: '题源类型',
            dataIndex: 'sourceType',
            align: 'center',
            width: '100px',
            render: sourceType => (
                <Tooltip placement="top" title={Number(sourceType) === 1 ? 'SKU' : Number(sourceType) === 2 ? 'PT' : ''}>
                    {Number(sourceType) === 1 ? 'SKU' : Number(sourceType) === 2 ? 'PT' : Number(sourceType) === 3 ? '其他' : ''}
                </Tooltip>
            )
        },
        fun.getColumnItem('订单号', 'orderNo'),
        {
            title: '题源封面',
            align: 'center',
            width: '100px',
            render: (record) => {
                if (record.pic.split(':')[0] === 'https') {
                    return (
                        record.pic ? <a href={record.pic} target='_blank' rel="noopener noreferrer">封面</a> : ''
                    )
                }
                return (
                    record.pic ? <img className={Style.zmage} id={'coverImage' + record.pic} key={record.imgUrl} src={record.cloudFrontUrl + '/' + record.pic} alt='图片'></img> : ''
                )
            },
        },
        fun.getColumnItem('题源名称', 'sourceName'),
        fun.getColumnItem('版本', 'version'),
        fun.getColumnItem('作者', 'author'),
        fun.getColumnItem('ISBN', 'isbn'),
        fun.getColumnItem('学科', 'subjectName'),
        {
            title: '来源',
            dataIndex: 'sourceFrom',
            align: 'center',
            width: '150px',
            render: sourceFrom => (
                <Tooltip placement="top" title={this.state.supplyChainSourceFrom[sourceFrom - 1] ? this.state.supplyChainSourceFrom[sourceFrom - 1] : ''}>
                    {this.state.supplyChainSourceFrom[sourceFrom - 1] ? this.state.supplyChainSourceFrom[sourceFrom - 1] : ''}
                </Tooltip>
            ),
        },
        {
            title: '学校&课号',
            dataIndex: 'collegeClassNumberList',
            align: 'center',
            render: collegeClassNumberList => (
                collegeClassNumberList.length === 0 ? '无' : <Button type='primary' className={Style.button} onClick={() => {
                    this.lookSchoolClassNumberList(collegeClassNumberList)
                }} >查看</Button>

            ),
        },
        {
            title: '自带答案',
            dataIndex: 'containsAnswer',
            align: 'center',
            width: '90px',
            render: containsAnswer => (
                <Tooltip placement="top" title={containsAnswer === 1 ? '有' : containsAnswer === 0 ? '无' : containsAnswer === 2 ? '答案不全' : ''}>
                    {containsAnswer === 1 ? '有' : containsAnswer === 0 ? '无' : containsAnswer === 2 ? '答案不全' : ''}
                </Tooltip>
            ),
        },
        {
            title: 'Chegg答案',
            dataIndex: 'cheggAnswer',
            align: 'center',
            width: '110px',
            render: cheggAnswer => (
                <Tooltip placement="top" title={cheggAnswer === 1 ? '有' : cheggAnswer === 0 ? '无' : cheggAnswer === 2 ? '答案不全' : ''}>
                    {cheggAnswer === 1 ? '有' : cheggAnswer === 0 ? '无' : cheggAnswer === 2 ? '答案不全' : ''}
                </Tooltip>
            ),
        },
        {
            title: '年份',
            dataIndex: 'yearFrom',
            align: 'center',
            width: '70px',
            render: yearFrom => (
                <Tooltip placement="top" title={Number(yearFrom) === 0 ? '' : yearFrom}>
                    {Number(yearFrom) === 0 ? '' : yearFrom}
                </Tooltip>
            ),
        },
        fun.getColumnItem('评价体系', 'examClassification'),
        fun.getColumnItem('年级', 'grade'),
        fun.getColumnItem('文件路径', 'filePath'),
        fun.getColumnItem('备注', 'remark'),
        {
            title: '题源状态',
            align: 'center',
            render: record => (
                < Tooltip placement="top" title={this.state.supplyChainStatus[record.qsStatus] ? this.state.supplyChainStatus[record.qsStatus] : ''} >
                    {this.state.supplyChainStatus[record.qsStatus] ? this.state.supplyChainStatus[record.qsStatus] : ''}
                </Tooltip>
            ),
        },
        fun.getColumnItem('教研负责人', 'researchUserName'),
        fun.getColumnItem('录入负责人', 'enterUserName'),
        fun.getColumnItem('质检负责人', 'inspectionUserName'),
        {
            title: '操作项目',
            align: 'center',
            fixed: 'right',
            width: '225px',
            render: (text, record, index) => {
                return (
                    <span className={Style.buttonWrap}>
                        <Button type='primary' className={Style.logButton} onClick={() => {
                            this.operationRecord(record)
                        }} >操作记录</Button>
                        {record.qsStatus === 6 || record.qsStatus === 7 ? '' : <Button type='primary' className={Style.rightButton} onClick={() => {
                            record.qsStatus === 0 && this.showProcessTopicSource(record)
                            record.qsStatus === 1 && this.showDistributeTopicSource(record)
                            record.qsStatus === 2 && this.showFinishTeach(record)
                            record.qsStatus === 3 && this.showFinishTopicInput(record)
                            record.qsStatus === 4 && this.showDistributeTopicSource(record)
                            record.qsStatus === 5 && this.showQuality(record)
                        }
                        }>
                            {record.qsStatus === 0 ? '处理题源' : record.qsStatus === 1 ? '分配题源' : record.qsStatus === 2 ? '完成教研' : record.qsStatus === 3 ? '完成录入' : record.qsStatus === 4 ? '分配题源' : record.qsStatus === 5 ? '质检' : record.qsStatus === 6 ? '' : record.qsStatus === 7 ? '' : ''}
                        </Button>}
                    </span>
                )
            }
        }
    ]
    componentDidMount() {
        let obj = fun.getItem('supplyChainSearchList');
        obj = JSON.parse(obj);
        if (obj && obj.showColumnTitle && obj.showColumnTitle.length > 0) {
            obj.showColumn = this.columns.filter((item) => obj.showColumnTitle.includes(item.title))
        } else {
            this.setState({ showColumn: this.columns });
        }

        this.setState(obj, () => {
            this.getSupplyChainManageList();//获取供应链经理列表
            this.getGradeList();//获取年级列表
            this.getSupplyChainSubjectList();//获取学科列表
            this.getSupplyChainEvaluationList();//获取评价体系列表
            this.getSchoolList();//获取学校列表
            this.getSupplyChainList();//获取供应链题源列表
            fun.addKeyboardListener(this.search);//监听回车查询事件
            this.computeSearchList()
        });
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    computeSearchList = () => {
        let { topicSourceType, topicSourceTypeId, topicSourceStatus, topicSourceStatusId, subject, subjectId, topicSourceID, searchVersion, searchSchoolId, searchSchool, searchClassNumber, source, sourceId, ISBN, grade, gradeId, evaluation, evaluationId, startYear, bringOwnAnswer, bringOwnAnswerId, cheggAnswer, cheggAnswerId, teachHead, teachHeadId, inputHead, inputHeadId, qualityHead, qualityHeadId, topicSourceName, scrollX, showColumnTitle } = this.state;
        let obj = { topicSourceType, topicSourceTypeId, topicSourceStatus, topicSourceStatusId, subject, subjectId, topicSourceID, searchVersion, searchSchoolId, searchSchool, searchClassNumber, source, sourceId, ISBN, grade, gradeId, evaluation, evaluationId, startYear, bringOwnAnswer, bringOwnAnswerId, cheggAnswer, cheggAnswerId, teachHead, teachHeadId, inputHead, inputHeadId, qualityHead, qualityHeadId, topicSourceName, scrollX, showColumnTitle }
        fun.setItem('supplyChainSearchList', obj)
    }
    //获取题源供应链列表
    getSupplyChainList = () => {
        this.apiPacking('getSupplyChainList', {
            cheggAnswer: this.state.cheggAnswerId,
            classNumber: this.state.searchClassNumber,
            containsAnswer: this.state.bringOwnAnswerId,
            enterBy: this.state.inputHeadId,
            ecId: this.state.evaluationId,
            grade: this.state.grade ? this.state.grade : '',
            id: this.state.topicSourceID,
            idisplayLength: this.state.pageSize,
            idisplayStart: this.state.page - 1,
            inspectionBy: this.state.qualityHeadId,
            isbn: this.state.ISBN,
            qsStatus: this.state.topicSourceStatusId,
            researchBy: this.state.teachHeadId,
            schoolId: this.state.searchSchoolId,
            sourceFrom: this.state.sourceId,
            sourceName: this.state.topicSourceName,
            sourceType: this.state.topicSourceTypeId,
            subjectId: this.state.subjectId,
            version: this.state.searchVersion ? this.state.searchVersion : '',
            yearFrom: this.state.startYear
        }, (data) => {
            this.setState({ loading: false, dataSource: data.result.data, total: data.result.total }, () => {
                this.state.dataSource && this.state.dataSource.forEach((item) => {
                    if (document.getElementById('coverImage' + item.pic)) {
                        new Viewer(document.getElementById('coverImage' + item.pic), {});
                    }
                })
            });
        })
    }
    //获取学校列表
    getSchoolList = () => {
        this.apiPacking('getSchoolList', {}, (data) => {
            this.setState({ schoolList: data.result, loading: false })
        })
    }
    //获取年级列表
    getGradeList = () => {
        this.apiPacking('getGradeList', {}, (data) => {
            this.setState({ gradeList: data.result, loading: false })
        })
    }
    //获取学科列表
    getSupplyChainSubjectList = () => {
        this.apiPacking('getSupplyChainSubjectList', {}, (data) => {
            this.setState({ supplyChainSubjectList: data.result, loading: false })
        })
    }
    //获取评价体系列表
    getSupplyChainEvaluationList = () => {
        this.apiPacking('getSupplyChainEvaluationList', {}, (data) => {
            this.setState({ supplyChainEvaluationList: data.result, loading: false })
        })
    }
    // 获取供应链管理者列表
    getSupplyChainManageList = () => {
        this.apiPacking('getSupplyChainManageList', { roleIds: '13,14' }, (data) => {
            this.setState({ supplyChainManageList: data.result, loading: false })
        })
    }
    // 改变下拉框所选值与ID
    changeSelect = (value, option, type, typeId) => {
        let obj = {};
        if (value && option) {
            obj[type] = value
            obj[typeId] = option.key
            this.refs[type].blur();
            this.setState(obj, () => {
                this.computeSearchList();
            });
        } else {
            obj[type] = null
            obj[typeId] = null
            this.setState(obj, () => {
                this.computeSearchList();
            });
        }
    }
    // 改变下拉框所选值
    changeSelectValue = (value, option, type) => {
        let obj = {}
        if (value && option) {
            obj[type] = value
            this.refs[type].blur();
            this.setState(obj, () => {
                this.computeSearchList();
            });
        } else {
            obj[type] = null
            this.setState(obj, () => {
                this.computeSearchList();
            });
        }
    }
    // 改变输入框内容
    changeInput = (e, type) => {
        let obj = {}
        obj[type] = e.target.value;
        this.setState(obj, () => {
            this.computeSearchList();
        });
    }
    // 改变数字输入框内容
    changeInputNumber = (e, type) => {
        let obj = {}
        obj[type] = e;
        this.setState(obj, () => {
            this.computeSearchList();
        });
    }

    // 改变年份
    changeYear = (date, dateString, type) => {
        let obj = {}
        if (date && dateString) {
            this.refs.startYear.blur();
            obj[type] = dateString;
            this.setState(obj, () => {
                this.computeSearchList();
            });
        }
        else {
            obj[type] = null;
            this.setState(obj, () => {
                this.computeSearchList();
            });
        }
    }
    // 改变学习课号组合中学校
    changeEditSchoolNumber = (value, option, select) => {
        let arr = this.state.editSchoolClassNumber
        arr = arr.map((item, index) => {
            let nowItem = item
            if (select === index) {
                if (value && option) {
                    nowItem.schoolId = option.key
                    nowItem.school = value
                } else {
                    nowItem.schoolId = null
                    nowItem.school = ''
                }
            }
            return item
        })
        this.computeSearchList('editSchoolClassNumber', arr)
        this.setState({ editSchoolClassNumber: arr })
    }
    // 改变学习课号组合中课号
    changeEditClassNumber = (e, select) => {
        let arr = this.state.editSchoolClassNumber
        arr = arr.map((item, index) => {
            let nowItem = item
            if (select === index) {
                nowItem.classNumber = e.target.value
            }
            return item
        })
        this.computeSearchList('editSchoolClassNumber', arr);
        this.setState({ editSchoolClassNumber: arr })
    }
    // 删除一个学习课号组合
    deleteEditSchoolClassNumber = (select) => {
        let arr = this.state.editSchoolClassNumber;
        arr = arr.filter((item, index) => index !== select);
        this.computeSearchList('editSchoolClassNumber', arr);
        this.setState({ editSchoolClassNumber: arr })
    }
    // 增加一个学习课号组合
    addSchoolClassNumber = () => {
        let arr = this.state.editSchoolClassNumber;
        arr.push({ schoolId: null, school: null, classNumber: '' });
        this.computeSearchList('editSchoolClassNumber', arr);
        this.setState({ editSchoolClassNumber: arr })
    }
    //点击图片
    imgUploadClick = () => {
        this.refs.inputUpload.click();
    };
    //upload图片
    upload = async (e) => {
        if (!e.target.files[0]) return;
        const file = e.target.files[0];
        const fileType = file ? file.type.split('/')[0] : '';
        if (fileType !== 'image') {
            message.error('只能上传图片');
            return false;
        } else {
            this.setState({ loading: true });
            // 图片上传预签名  获取AWS上传地址
            await api.getPicAwsAddress()
                .then(async (data) => {
                    if (data.ret === 20000) {
                        let newFile;
                        try {
                            newFile = await fun.removeExif(file);
                        } catch (err) {
                            message.error(err.msg);
                            throw err;
                        }
                        try {
                            //往aws上传
                            // await api.uploadAWS(data.result.url, file, { headers: { 'Content-Type': 'image/png' } })
                            await api.uploadAWS(data.result.url, newFile, { headers: { 'Content-Type': 'image/png' } });
                            message.success(newFile.name + '上传成功');
                            this.setState({ coverImgUrl: data.result.cmsCloudfront, coverImgUrlKey: data.result.key, loading: false }, () => {
                                if (this.refs['coverImgUrl' + this.state.coverImgUrl + '/' + this.state.coverImgUrlKey]) {
                                    new Viewer(this.refs['coverImgUrl' + this.state.coverImgUrl + '/' + this.state.coverImgUrlKey], {});
                                }
                            })
                        } catch (err) {
                            message.error(err.msg);
                            throw err;
                        }
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                })
        }
    }
    //删除图片
    deleteImg = () => {
        this.setState({ coverImgUrl: '', coverImgUrlKey: '' });
    }
    // 新增题源
    addTopicSource = () => {
        this.setState({ showAddTopicSourceModal: true })
    }
    // 新增题源确定
    addTopicSourceSubmit = () => {
        let arr = this.state.editSchoolClassNumber.filter((item) => {
            return item.schoolId.length !== 0 || item.classNumber.length !== 0;
        })
        arr = arr.map((item) => {
            return { classNumber: item.classNumber, schoolId: item.schoolId }
        })
        let params = {
            sourceName: this.state.editTopicSourceName,
            sourceType: this.state.editTopicSourceTypeId,
            sourceFrom: this.state.editSourceId,
            orderNo: this.state.editOrderNumber,
            filePath: this.state.editFileName,
            pic: this.state.coverImgUrlKey,
            author: this.state.editAuthor,
            isbn: this.state.editISBN,
            version: this.state.editTextBookVersion,
            grade: this.state.editGrade,
            collegeClassNumberList: arr.length === 0 ? null : arr,
            remark: this.state.editRemark,
            cheggAnswer: '',
            containsAnswer: '',
            ecId: this.state.editEvaluationId,
            subjectName: '',
            yearFrom: this.state.editYear,
        }
        this.apiPacking('addTopicSource', params, () => {
            message.success('题源新增成功！');
            this.close();
            this.getSupplyChainList();
        })
    }
    // 编辑题源确定
    editTopicSourceSubmit = () => {
        let arr = this.state.editSchoolClassNumber.filter((item) => {
            return item.schoolId || item.classNumber.length !== 0;
        })
        arr = arr.map((item) => {
            return { classNumber: item.classNumber, schoolId: item.schoolId }
        })
        let params = {
            id: this.state.editId,
            sourceName: this.state.editTopicSourceName,
            sourceType: this.state.editTopicSourceTypeId,
            sourceFrom: this.state.editSourceId,
            orderNo: this.state.editOrderNumber,
            filePath: this.state.editFileName,
            pic: this.state.coverImgUrlKey,
            author: this.state.editAuthor,
            isbn: this.state.editISBN,
            version: this.state.editTextBookVersion,
            grade: this.state.editGrade,
            collegeClassNumberList: arr.length === 0 ? null : arr,
            remark: this.state.editRemark,
            cheggAnswer: this.state.editCheggAnswerId,
            containsAnswer: this.state.editBringOwnAnswerId,
            ecId: this.state.editEvaluationId,
            subjectId: this.state.editSubjectId,
            yearFrom: this.state.editYear,
            inspectionBy: this.state.editQualityHeadId,
            researchBy: this.state.editTeachHeadId,
            enterBy: this.state.editInputHeadId,
        }
        this.apiPacking('editTopicSource', params, () => {
            this.close();
            this.getSupplyChainList();
        })
    }
    // 编辑题源
    editTopicSource = (record) => {
        let arr = record.collegeClassNumberList
        arr = arr.map((item) => {
            return { schoolId: item.schoolId, school: item.schoolName, classNumber: item.classNumber }
        })
        this.setState({
            editId: record.id,
            showEditTopicSourceModal: true,//显示编辑题源弹框
            editTopicSourceType: Number(record.sourceType) === 1 ? 'SKU' : Number(record.sourceType) === 2 ? 'PT' : Number(record.sourceType) === 3 ? '其他' : '',//题源类型
            editTopicSourceTypeId: record.sourceType,//题源类型ID
            editSource: this.state.supplyChainSourceFrom[record.sourceFrom - 1] ? this.state.supplyChainSourceFrom[record.sourceFrom - 1] : '',//来源
            editSourceId: record.sourceFrom,//来源ID
            editOrderNumber: record.orderNo,//订单号
            editFileName: record.filePath,//文件路径
            editTopicSourceName: record.sourceName,//题源名称
            editAuthor: record.author,//作者
            editISBN: record.isbn,//isbn
            editTextBookVersion: record.version,//教材版本
            editGrade: record.grade,//年级
            editSchoolClassNumber: arr,//学习和课号
            editSubject: record.subjectName === '' ? null : record.subjectName,//学科
            editSubjectId: record.subjectId,//学科ID
            editYear: Number(record.yearFrom) === 0 ? null : record.yearFrom,//年份
            editEvaluation: record.examClassification === '' ? null : record.examClassification,//评价体系
            editEvaluationId: record.ecId,//评价体系id
            editBringOwnAnswer: record.containsAnswer === 1 ? '有' : record.containsAnswer === 0 ? '无' : record.containsAnswer === 2 ? '答案不全' : null,//自带答案
            editBringOwnAnswerId: record.containsAnswer,//自带答案ID
            editCheggAnswer: record.cheggAnswer === 1 ? '有' : record.cheggAnswer === 0 ? '无' : record.cheggAnswer === 2 ? '答案不全' : null,//chegg答案
            editCheggAnswerId: record.cheggAnswer,//chegg答案ID
            editTeachHead: record.researchUserName === '' ? null : record.researchUserName,//教研负责人
            editTeachHeadId: record.researchBy,//教研负责人的ID
            editInputHead: record.enterUserName === '' ? null : record.enterUserName,//录入负责人
            editInputHeadId: record.enterBy,//录入负责人的ID
            editQualityHead: record.inspectionUserName === '' ? null : record.inspectionUserName,//质检负责人
            editQualityHeadId: record.inspectionBy,//质检负责人的ID
            editRemark: record.remark,//备注
            coverImgUrlKey: record.pic,//广告URL的key，用于确定时
            coverImgUrl: record.cloudFrontUrl,//广告URL，用于展示图片/上传图片
        })
    }
    // 操作记录弹框
    operationRecord = (record) => {
        this.apiPacking('operationLog', {
            id: record.id,
            idisplayLength: 10,
            idisplayStart: 0
        }, (data) => {
            this.setState({ loading: false, operationLogList: data.result.data, showOperationRecord: true, operationTotal: data.result.total });
        })
    }
    // 操作记录分页
    operationPaginationChange = (operationPage, operationPageSize) => {
        this.setState({ operationPage, operationPageSize }, () => {
            this.setState({ loading: true }, () => {
                this.apiPacking('operationLog', {
                    id: this.state.recordInfo.id,
                    idisplayLength: this.state.operationPageSize,
                    idisplayStart: this.state.operationPage - 1
                }, (data) => {
                    this.setState({ loading: false, operationLogList: data.result.data, showOperationRecord: true });
                })
            })
        })
    }
    //查看学校课号
    lookSchoolClassNumberList = (collegeClassNumberList) => {
        collegeClassNumberList = collegeClassNumberList.map((item, index) => {
            item.id = index
            return item
        })
        this.setState({ loading: false, schoolClassNumberList: collegeClassNumberList, showSchoolClassNumberListModal: true });
    }
    // 改变是否通过质检
    onChangeQuality = (e) => {
        this.setState({ editQuality: e.target.value })
    }
    // 导出题源列表
    export = () => {
        let params = {
            id: this.state.topicSourceID,
            version: this.state.searchVersion,
            schoolId: this.state.searchSchoolId,
            classNumber: this.state.searchClassNumber,
            cheggAnswer: this.state.cheggAnswerId,
            containsAnswer: this.state.bringOwnAnswerId,
            enterBy: this.state.inputHeadId,
            ecId: this.state.evaluationId,
            grade: this.state.grade,
            idisplayLength: this.state.pageSize,
            // idisplayStart: this.state.page - 1,
            // inspectionBy: this.state.qualityHeadId,
            isbn: this.state.ISBN,
            qsStatus: this.state.topicSourceStatusId,
            researchBy: this.state.teachHeadId,
            sourceFrom: this.state.sourceId,
            sourceName: this.state.topicSourceName,
            sourceType: this.state.topicSourceTypeId,
            subjectId: this.state.subjectId,
            yearFrom: this.state.startYear
        }
        api.exportSupplyChainList(params, { responseType: 'arraybuffer' })
            .then(async (response) => {
                let parse_result = await fun.ab2str(response);
                if (parse_result === false) {
                    fun.download(response, `题源数据-${moment(new Date()).format('YYYYMMDD')}.xlsx`);
                    this.setState({ loading: false });
                    message.success('导出成功！');
                } else {
                    if (parse_result.ret === 20000) {
                        message.success(parse_result.msg);
                        this.setState({ loading: false });
                    } else {
                        return Promise.reject(parse_result);
                    }
                }
            })
            .catch((err) => {
                message.error(err.msg);
                this.setState({ loading: false })
            })
    }
    //显示处理题源弹框
    showProcessTopicSource = (record) => {
        this.setState({
            showProcessTopicSourceModal: true,
            recordInfo: record,
            editSubject: record.subjectName === '' ? null : record.subjectName,//学科
            editSubjectId: record.subjectId,
            editYear: Number(record.yearFrom) === 0 ? null : record.yearFrom,//年份
            editEvaluation: record.examClassification === '' ? null : record.examClassification,//评价体系
            editEvaluationId: record.ecId,//评价体系id
            editBringOwnAnswer: record.containsAnswer === 1 ? '有' : record.containsAnswer === 0 ? '无' : record.containsAnswer === 2 ? '答案不全' : null,//自带答案
            editBringOwnAnswerId: record.containsAnswer,//自带答案ID
            editCheggAnswer: record.cheggAnswer === 1 ? '有' : record.cheggAnswer === 0 ? '无' : record.cheggAnswer === 2 ? '答案不全' : null,//chegg答案
            editCheggAnswerId: record.cheggAnswer,//chegg答案ID
            editRemark: record.remark,//备注
        })
    }
    //处理题源弹框的确定
    processTopicSourceSubmit = () => {
        let params = {
            id: this.state.recordInfo.id,
            sourceName: '',
            sourceType: '',
            sourceFrom: '',
            orderNo: '',
            filePath: '',
            pic: '',
            author: '',
            isbn: '',
            version: '',
            grade: '',
            collegeClassNumberList: [],
            remark: this.state.editRemark,
            cheggAnswer: this.state.editCheggAnswerId,
            containsAnswer: this.state.editBringOwnAnswerId,
            ecId: this.state.editEvaluationId,
            subjectId: this.state.editSubjectId,
            yearFrom: this.state.editYear,
            inspectionBy: '',
            researchBy: '',
            enterBy: '',
            flowStatus: this.state.editTopicFlowId
        }
        this.apiPacking('processTopicSource', params, () => {
            this.close();
            this.getSupplyChainList();
        })
    }
    //显示分配题源弹框
    showDistributeTopicSource = (record) => {
        this.setState({
            showDistributeTopicSourceModal: true,
            recordInfo: record,
            editTopicFlow: record.flowStatus === 1 ? '教研' : record.flowStatus === 2 ? '录入' : record.flowStatus === 3 ? '放弃' : '',
            editTopicFlowId: record.flowStatus,
            editSelectDistribute: null,
            editSelectDistributeId: '',
        });
    }
    //分配题源弹框的确定
    distributeTopicSourceSbumit = () => {
        let params = {
            assignUserId: this.state.editSelectDistributeId,
            id: this.state.recordInfo.id,
            flowStatus: this.state.editTopicFlowId
        }
        this.apiPacking('distributeTopicSource', params, () => {
            this.close();
            this.getSupplyChainList();
        })
    }
    // 显示完成教研的弹框
    showFinishTeach = (record) => {
        this.setState({
            showFinishTeachModal: true,
            recordInfo: record,
        });
    }
    // 完成教研确定
    finishTeachSubmit = () => {
        this.apiPacking('changeTopicSourceStatus', {
            id: this.state.recordInfo.id,
            qsStatus: 4
        }, () => {
            this.close();
            this.getSupplyChainList();
        })
    }
    // 显示完成录入弹框
    showFinishTopicInput = (record) => {
        this.setState({
            showFinishTopicInputModal: true,
            recordInfo: record,
        });
    }
    // 完成录入确定
    finishTopicInputSubmit = () => {
        this.apiPacking('changeTopicSourceStatus', {
            id: this.state.recordInfo.id,
            qsStatus: 5
        }, () => {
            this.close();
            this.getSupplyChainList();
        })
    }
    // 显示质检弹框
    showQuality = (record) => {
        this.setState({
            showQualityModal: true,
            recordInfo: record,
        });
    }
    // 完成质检确定
    qualitySubmit = () => {
        let params = {
            id: this.state.recordInfo.id,
            qsStatus: this.state.editQuality === 1 ? 6 : this.state.editQuality === 2 ? 3 : ''
        }
        this.apiPacking('changeTopicSourceStatus', params, () => {
            this.close();
            this.getSupplyChainList();
        })
    }
    //关闭添加广告课程的弹框
    close = () => {
        this.setState({
            loading: false,
            // 新增题源编辑
            showAddTopicSourceModal: false,//显示新增题源弹框
            showEditTopicSourceModal: false,//显示编辑题源弹框
            editId: '',//编辑ID
            recordInfo: null,
            editTopicSourceType: null,//题源类型
            editTopicSourceTypeId: '',//题源类型ID
            editSource: null,//来源
            editSourceId: '',//来源ID
            editOrderNumber: '',//订单号
            editFileName: '',//文件路径
            editTopicSourceName: '',//题源名称
            editAuthor: '',//作者
            editISBN: '',//isbn
            editTextBookVersion: '',//教材版本
            editGrade: '',//年级
            editSchoolClassNumber: [{ schoolId: null, school: null, classNumber: '' }],//学习和课号
            editSubject: null,//学科
            editSubjectId: '',//学科ID
            editYear: null,//年份
            editEvaluation: null,//评价体系
            editEvaluationId: '',//评价体系id
            editBringOwnAnswer: null,//自带答案
            editBringOwnAnswerId: '',//自带答案ID
            editCheggAnswer: null,//chegg答案
            editCheggAnswerId: '',//chegg答案ID
            editTeachHead: null,//教研负责人
            editTeachHeadId: '',//教研负责人的ID
            editInputHead: null,//录入负责人
            editInputHeadId: '',//录入负责人的ID
            editQualityHead: null,//质检负责人
            editQualityHeadId: '',//质检负责人的ID
            editRemark: '',//备注
            coverImgUrlKey: '',//广告URL的key，用于确定时
            coverImgUrl: '',//广告URL，用于展示图片/上传图片

            // 查看学校课号列表
            showSchoolClassNumberListModal: false,
            schoolClassNumberList: [],//学校课号列表
            // 质检弹框
            showQualityModal: false,    // 质检弹框
            editQuality: '',
            // 题源完成录入弹框
            showFinishTopicInputModal: false,
            // 完成教研弹框
            showFinishTeachModal: false,
            // 分配题源弹框
            showDistributeTopicSourceModal: false,
            editTopicFlow: null,
            editTopicFlowId: '',
            editSelectDistribute: null,
            editSelectDistributeId: '',
            // 处理题源弹框
            showProcessTopicSourceModal: false,

            // 操作记录弹框
            showOperationRecord: false,
            operationLogList: [],
            operationPage: 1,//当前页码
            operationPageSize: 10,//每页显示条数
            operationTotal: 0,//总条数
        })
    }
    // 设置列表显示字段
    setTable = (value, option) => {
        if (value && option) {
            let arr = this.columns.filter((item) => value.includes(item.title) || item.title === '题源ID' || item.title === '编辑');
            let showColumnTitle = arr.map(item => item.title)
            this.setState({ showColumn: arr, scrollX: arr.length * 116, showColumnTitle: showColumnTitle }, () => {
                this.computeSearchList();
            })

        }
    }
    // 查询项的选择框
    searchSelectComponent = (obj) => {
        let { title, ref, value, keyList, valueList, onChangeValue, onChangeValueId, onChange, red, placeholder } = obj;
        return (
            <div className={Style.box}>
                <span className={Style.span}>{title}{red ? <span className={Style.red}>*</span> : ''}：</span>
                <Select placeholder={placeholder ? placeholder : '全部'} className={Style.select} ref={ref} value={value} onChange={onChange ? onChange : (value, option) => { this.changeSelect(value, option, onChangeValue, onChangeValueId) }} optionLabelProp="label" showSearch={true} allowClear={true}>
                    {keyList.map((item, index) => {
                        return <Option key={keyList[index]} value={valueList[index]}>{valueList[index]}</Option>
                    })}
                </Select>
            </div>
        )
    }
    // 弹框里的一条静态数据
    modalListStaticItemComponent = (title, value) => {
        return (
            <div className={Style.box}>
                <span className={Style.span}>{title}</span>
                <span className={Style.input} >{value}</span>
            </div>
        )
    }
    // 弹框里的一条input输入
    modalListInputComponent = (obj) => {
        let { title, placeholder, maxLength, value, red, onChangeValue } = obj;
        return (
            <div className={Style.box}>
                <span className={Style.span}>{title}{red ? <span className={Style.red}>*</span> : ''}：</span>
                <Input placeholder={placeholder} className={Style.input} maxLength={maxLength} value={value} onChange={(e) => { this.changeInput(e, onChangeValue) }} />
            </div>
        )
    }
    // api 封装
    apiPacking = (apiName, params, successCallback) => {
        this.setState({ loading: true }, () => {
            api[apiName](params)
                .then((data) => {
                    if (data.ret === 20000) {
                        successCallback(data);
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //分页
    paginationChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getSupplyChainList();
        })
    }
    //查询
    search = () => {
        this.setState({ page: 1 }, () => {
            this.getSupplyChainList();
        })
    }
    render() {
        let addDisabled = this.state.editTopicSourceType === null || this.state.editSource === null || this.state.editTopicSourceName.length === 0 || this.state.editEvaluation === null;
        let editDisabled = this.state.editTopicSourceName.length === 0 || this.state.editTopicSourceType === null || this.state.editSource === null || this.state.editSubject === null || this.state.editBringOwnAnswer === null || this.state.editEvaluation === null;
        let processTopicSourceDisabled = this.state.editSubject === null || this.state.editBringOwnAnswer === null || this.state.editEvaluation === null || this.state.editTopicFlow === null;
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    {/* <SearchTable name='tom'></SearchTable> */}
                    <div className={Style.searchWrapTop} >
                        {this.searchSelectComponent({ title: '题源类型', ref: 'topicSourceType', value: this.state.topicSourceType, keyList: [1, 2, 3], valueList: ['SKU', 'PT', '其他'], onChangeValue: 'topicSourceType', onChangeValueId: 'topicSourceTypeId' })}
                        {this.searchSelectComponent({ title: '题源状态', ref: 'topicSourceStatus', value: this.state.topicSourceStatus, keyList: this.state.supplyChainStatus.map((item, index) => index), valueList: this.state.supplyChainStatus.map(item => item), onChangeValue: 'topicSourceStatus', onChangeValueId: 'topicSourceStatusId' })}
                        {this.searchSelectComponent({ title: '学科', ref: 'subject', value: this.state.subject, keyList: this.state.supplyChainSubjectList.map(item => item.id), valueList: this.state.supplyChainSubjectList.map(item => item.subjectName), onChangeValue: 'subject', onChangeValueId: 'subjectId' })}
                        <div className={Style.boxButton}>
                            <Input placeholder='请输入题源名称' maxLength='100' className={Style.input} value={this.state.topicSourceName} onChange={(e) => { this.changeInput(e, 'topicSourceName') }} />
                        </div>
                    </div>
                    <div className={Style.searchWrapTop}>
                        <div className={Style.box}>
                            <span className={Style.span}>题源ID：</span>
                            <InputNumber placeholder='请输入题源ID' maxLength='6' className={Style.select} value={this.state.topicSourceID} onChange={(e) => { this.changeInputNumber(e, 'topicSourceID') }} />
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>版本：</span>
                            <Input placeholder='请输入版本号' maxLength='20' className={Style.select} value={this.state.searchVersion} onChange={(e) => { this.changeInput(e, 'searchVersion') }} />
                        </div>
                        <div className={Style.box}>
                            <span className={Style.span}>学校：</span>
                            <Select placeholder='全部' ref='searchSchool' className={Style.select} value={this.state.searchSchool} onChange={(value, option) => { this.changeSelect(value, option, 'searchSchool', 'searchSchoolId') }} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.schoolList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.name}>{item.name}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.boxButton}>
                            <Input placeholder='请输入课号' maxLength='20' className={Style.input} value={this.state.searchClassNumber} onChange={(e) => { this.changeInput(e, 'searchClassNumber') }} />
                        </div>
                    </div>
                    <div className={Style.searchWrapTop}>
                        {this.searchSelectComponent({ title: '来源', ref: 'source', value: this.state.source, keyList: this.state.supplyChainSourceFrom.map((item, index) => index + 1), valueList: this.state.supplyChainSourceFrom.map(item => item), onChangeValue: 'source', onChangeValueId: 'sourceId' })}
                        {this.searchSelectComponent({ title: '年级', ref: 'grade', value: this.state.grade, keyList: this.state.gradeList.map((item, index) => index), valueList: this.state.gradeList.map(item => item.grade), onChange: (value, option) => { this.changeSelectValue(value, option, 'grade') } })}
                        {this.searchSelectComponent({ title: '评价体系', ref: 'evaluation', value: this.state.evaluation, keyList: this.state.supplyChainEvaluationList.map((item) => item.id), valueList: this.state.supplyChainEvaluationList.map(item => item.examClassification), onChangeValue: 'evaluation', onChangeValueId: 'evaluationId' })}
                        <div className={Style.boxButton}>
                            <Input placeholder='请输入ISBN' maxLength='100' className={Style.input} value={this.state.ISBN} onChange={(e) => { this.changeInput(e, 'ISBN') }} />
                        </div>
                    </div>
                    <div className={Style.searchWrapTop}>
                        {this.searchSelectComponent({ title: '自带答案', ref: 'bringOwnAnswer', value: this.state.bringOwnAnswer, keyList: [1, 0, 2], valueList: ['有', '无', '答案不全'], onChangeValue: 'bringOwnAnswer', onChangeValueId: 'bringOwnAnswerId' })}
                        {this.searchSelectComponent({ title: 'Chegg答案', ref: 'cheggAnswer', value: this.state.cheggAnswer, keyList: [1, 0, 2], valueList: ['有', '无', '答案不全'], onChangeValue: 'cheggAnswer', onChangeValueId: 'cheggAnswerId' })}
                        <div className={Style.box}>
                            <span className={Style.span}>年份：</span>
                            <DatePicker value={this.state.startYear ? moment(this.state.startYear, 'YYYY') : ''} onChange={(date, dateString) => { this.changeYear(date, dateString, 'startYear') }} picker="year" ref='startYear' className={Style.select} disabledDate={(date) => {
                                return date > moment().startOf(1, 'year')
                            }} />
                        </div>
                        <div className={Style.boxButton}>
                            <Button type='primary' className={Style.button} icon={<DownloadOutlined />} onClick={this.export}>导出</Button>
                        </div>
                    </div>
                    <div className={Style.searchWrapTop}>
                        {this.searchSelectComponent({ title: '教研负责人', ref: 'teachHead', value: this.state.teachHead, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'teachHead', onChangeValueId: 'teachHeadId' })}
                        {this.searchSelectComponent({ title: '录入负责人', ref: 'inputHead', value: this.state.inputHead, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'inputHead', onChangeValueId: 'inputHeadId' })}
                        {this.searchSelectComponent({ title: '质检负责人', ref: 'qualityHead', value: this.state.qualityHead, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'qualityHead', onChangeValueId: 'qualityHeadId' })}
                        <div className={Style.boxButton}>
                            <Button type='primary' className={Style.button} icon={<SearchOutlined />} onClick={this.search}>查询</Button>
                        </div>
                    </div>

                    <Divider />
                    <div className={Style.searchWrapTop}>
                        <Button type='primary' icon={<PlusOutlined />} className={Style.button} onClick={this.addTopicSource}>新增题源</Button>
                        <div className={Style.box}>
                            <span className={Style.spanTime}>列表显示字段：</span>
                            <Select className={Style.input} placeholder='全部' allowClear={true} optionLabelProp="label" showSearch={true} mode='multiple' onChange={this.setTable} maxTagCount={0}
                                value={this.state.showColumn.map((item) => {
                                    if (item.title === '题源ID' || item.title === '编辑') return null;
                                    return item.title;
                                })}
                            >
                                {this.columns.map((item) => item.title).map((item, index) => {
                                    if (item === '题源ID' || item === '编辑') return null;
                                    return (
                                        <Option key={index} value={item}>{item}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                    </div>
                    <Table
                        columns={this.state.showColumn}
                        dataSource={this.state.dataSource}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                        scroll={{ x: this.state.scrollX }}
                    >
                    </Table>
                    <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.paginationChange} showTotal={total => `Total ${total} items`} ></Pagination>
                    {/* 新建/编辑题源弹框 */}
                    {this.state.showAddTopicSourceModal || this.state.showEditTopicSourceModal ? <Modal title={this.state.showAddTopicSourceModal ? '新建题源' : '编辑题源'} close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.state.showAddTopicSourceModal ? this.addTopicSourceSubmit : this.state.showEditTopicSourceModal ? this.editTopicSourceSubmit : ''} disabled={this.state.showAddTopicSourceModal ? addDisabled : editDisabled}>确定</Button>]}>
                        <div className={Style.addModal}>
                            {this.state.showEditTopicSourceModal ? <div className={Style.rowWrap}><ExclamationCircleOutlined />&emsp;修改编辑题源信息不会改变题源的状态</div> : ''}
                            <div className={Style.wrap}>
                                {this.modalListInputComponent({ red: true, title: '题源名称', placeholder: '请输入题源名称', maxLength: '100', value: this.state.editTopicSourceName, onChangeValue: 'editTopicSourceName' })}
                                {this.searchSelectComponent({ red: true, title: '来源', placeholder: '请选择来源', ref: 'editSource', value: this.state.editSource, keyList: this.state.supplyChainSourceFrom.map((item, index) => index + 1), valueList: this.state.supplyChainSourceFrom.map((item) => item), onChangeValue: 'editSource', onChangeValueId: 'editSourceId' })}
                            </div>
                            <div className={Style.wrap}>
                                {this.searchSelectComponent({ red: true, title: '题源类型', placeholder: '请选择题源类型', ref: 'editTopicSourceType', value: this.state.editTopicSourceType, keyList: [1, 2, 3], valueList: ['SKU', 'PT', '其他'], onChangeValue: 'editTopicSourceType', onChangeValueId: 'editTopicSourceTypeId' })}
                                {this.modalListInputComponent({ title: '订单号', placeholder: '请输入订单号', maxLength: '100', value: this.state.editOrderNumber, onChangeValue: 'editOrderNumber' })}
                            </div>
                            <div className={Style.wrap}>
                                {this.modalListInputComponent({ title: '文件路径', placeholder: '请输入文件路径', maxLength: '200', value: this.state.editFileName, onChangeValue: 'editFileName' })}
                                <div className={Style.box}>
                                    <span className={Style.span}>封面：</span>
                                    {this.state.coverImgUrlKey ?
                                        <span >
                                            <Badge count={<CloseCircleOutlined onClick={this.deleteImg} />}>
                                                <img className={Style.image} ref={'coverImgUrl' + this.state.coverImgUrl + '/' + this.state.coverImgUrlKey} src={this.state.coverImgUrl + '/' + this.state.coverImgUrlKey} alt='广告素材'></img>
                                            </Badge>
                                        </span>
                                        : <span>
                                            <Button onClick={this.imgUploadClick}>{this.state.loading ? <LoadingOutlined /> : <PlusOutlined />} Click to Upload</Button>
                                            <input type="file" accept="image/*"
                                                name="uploader-input"
                                                ref='inputUpload' style={{ display: 'none' }} onChange={this.upload}></input>
                                        </span>
                                    }
                                </div>
                            </div>
                            <div className={Style.wrap}>
                                {this.modalListInputComponent({ title: '作者', placeholder: '请输入作者', maxLength: '100', value: this.state.editAuthor, onChangeValue: 'editAuthor' })}
                                {this.modalListInputComponent({ title: 'ISBN', placeholder: '请输入ISBN', maxLength: '100', value: this.state.editISBN, onChangeValue: 'editISBN' })}
                            </div>
                            <div className={Style.wrap}>
                                {this.modalListInputComponent({ title: '教材版本', placeholder: '请输入教材版本', maxLength: '100', value: this.state.editTextBookVersion, onChangeValue: 'editTextBookVersion' })}
                                {this.modalListInputComponent({ title: '年级', placeholder: '请输入年级', maxLength: '100', value: this.state.editGrade, onChangeValue: 'editGrade' })}
                            </div>
                            <div className={Style.wrap}>
                                {this.searchSelectComponent({ red: true, title: '评价体系', placeholder: '请选择评价体系', ref: 'editEvaluation', value: this.state.editEvaluation, keyList: this.state.supplyChainEvaluationList.map((item) => item.id), valueList: this.state.supplyChainEvaluationList.map(item => item.examClassification), onChangeValue: 'editEvaluation', onChangeValueId: 'editEvaluationId' })}
                                <div className={Style.box}>
                                    <span className={Style.span}>年份：</span>
                                    <DatePicker value={this.state.editYear ? moment(this.state.editYear, 'YYYY') : ''} onChange={(date, dateString) => { this.changeYear(date, dateString, 'editYear') }} picker="year" ref='editYear' className={Style.select} disabledDate={(date) => {
                                        return date > moment().startOf(1, 'year')
                                    }} />
                                </div>
                            </div>
                            <div className={Style.rowWrapSchool}>
                                <span className={Style.span}>学校课号：</span>
                                <span className={Style.innerWrap}>
                                    <Button type='link' onClick={this.addSchoolClassNumber}><PlusOutlined /></Button>
                                    <span className={Style.wrap} >
                                        {this.state.editSchoolClassNumber.map((item, index) => {
                                            return (
                                                <span key={index} className={Style.list}>
                                                    <Select placeholder='请选择学校' className={Style.input} value={item.school} onChange={(value, option) => { this.changeEditSchoolNumber(value, option, index) }} optionLabelProp="label" showSearch={true} allowClear={true}>
                                                        {this.state.schoolList.map((item1) => {
                                                            return (
                                                                <Option key={item1.id} value={item1.name}>{item1.name}</Option>
                                                            )
                                                        })}
                                                    </Select>
                                                    <Input placeholder='请输入课号' maxLength='100' className={Style.input} value={item.classNumber} onChange={(e) => { this.changeEditClassNumber(e, index, 2) }} />
                                                    <Button type='link' onClick={() => { this.deleteEditSchoolClassNumber(index) }} ><MinusOutlined /></Button>
                                                </span>
                                            )
                                        })}
                                    </span>
                                </span>
                            </div>
                            {this.state.showEditTopicSourceModal ? <Fragment>
                                <div className={Style.wrap}>
                                    {this.searchSelectComponent({ red: true, title: '题源学科', placeholder: '请选择题源名称', ref: 'editSubject', value: this.state.editSubject, keyList: this.state.supplyChainSubjectList.map(item => item.id), valueList: this.state.supplyChainSubjectList.map(item => item.subjectName), onChangeValue: 'editSubject', onChangeValueId: 'editSubjectId' })}
                                    {this.searchSelectComponent({ red: true, title: '自带答案', placeholder: '请选择是否自带答案', ref: 'editBringOwnAnswer', value: this.state.editBringOwnAnswer, keyList: [1, 0, 2], valueList: ['有', '无', '答案不全'], onChangeValue: 'editBringOwnAnswer', onChangeValueId: 'editBringOwnAnswerId' })}
                                </div>
                                <div className={Style.wrap}>
                                    {this.searchSelectComponent({ title: 'Chegg答案', placeholder: '请选择是否有Chegg答案', ref: 'editCheggAnswer', value: this.state.editCheggAnswer, keyList: [1, 0, 2], valueList: ['有', '无', '答案不全'], onChangeValue: 'editCheggAnswer', onChangeValueId: 'editCheggAnswerId' })}
                                    {this.searchSelectComponent({ title: '教研负责人', placeholder: '请选择教研负责人', ref: 'editTeachHead', value: this.state.editTeachHead, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'editTeachHead', onChangeValueId: 'editTeachHeadId' })}
                                </div>
                                <div className={Style.wrap}>
                                    {this.searchSelectComponent({ title: '录入负责人', placeholder: '请选择录入负责人', ref: 'editInputHead', value: this.state.editInputHead, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'editInputHead', onChangeValueId: 'editInputHeadId' })}
                                    {this.searchSelectComponent({ title: '质检负责人', placeholder: '请选择质检负责人', ref: 'editQualityHead', value: this.state.editQualityHead, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'editQualityHead', onChangeValueId: 'editQualityHeadId' })}
                                </div>
                            </Fragment> : ''}
                            <div className={Style.rowWrapSchool}>
                                <span className={Style.span}>备注：</span>
                                <TextArea placeholder='请输入备注' maxLength='500' rows={4} className={Style.input} value={this.state.editRemark} onChange={(e) => { this.changeInput(e, 'editRemark') }} />
                                <div className={Style.spanRight}>{this.state.editRemark.length}/500</div>
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 题源操作记录弹框 */}
                    {this.state.showOperationRecord ? <Modal title='题源操作记录' close={this.close} actions={[]}>
                        <div className={Style.editModal}>
                            <Timeline mode='left'>
                                {this.state.operationLogList ? this.state.operationLogList.map((item, index) => {
                                    return (
                                        <Timeline.Item key={index}>
                                            <div className={Style.box} key={index}>
                                                <span className={Style.operation}>{item.createdAt ? moment(new Date(new Date(item.createdAt).getTime() + 28800000)).format("YYYY/MM/DD HH:mm:ss") : ''
                                                }</span>
                                                <span className={Style.operation}>{item.optName}</span>
                                                <span className={Style.operation}>{item.userName}</span>
                                            </div>
                                        </Timeline.Item>
                                    )
                                }) : ''}
                            </Timeline>
                            <Pagination showQuickJumper hideOnSinglePage className={Style.pagination} current={this.state.operationPage} pageSize={this.state.operationPageSize} total={this.state.operationTotal} onChange={this.operationPaginationChange} showTotal={total => `Total ${total} items`} ></Pagination>
                        </div>
                    </Modal> : ''}
                    {/* 查看学校课号弹框 */}
                    {this.state.showSchoolClassNumberListModal ? <Modal title='查看学校课号' close={this.close} actions={[]}>
                        <div className={Style.editModal}>
                            {/* {this.state.schoolClassNumberList.map((item, index) => {
                                return (
                                    <div className={Style.rowWrap} key={index}>
                                        学校：<span className={Style.operation}>{item.schoolName}</span>  
                                        &emsp;&emsp;&emsp;课号：<span className={Style.operation}>{item.classNumber}</span>
                                    </div>
                                )
                            })} */}
                            <Table
                                columns={[{
                                    title: '学校',
                                    align: 'center',
                                    render: record => {
                                        return (
                                            <span>{record.schoolName}</span>
                                        )
                                    }
                                }, {
                                    title: '课号',
                                    align: 'center',
                                    render: record => {
                                        return (
                                            <span>{record.classNumber}</span>
                                        )
                                    }
                                },]}
                                dataSource={this.state.schoolClassNumberList}
                                rowKey={dataSource => dataSource.id}
                                bordered={true}
                                pagination={false}
                            ></Table>
                        </div>
                    </Modal> : ''}
                    {/* 处理题源弹框 */}
                    {this.state.showProcessTopicSourceModal ? <Modal title='处理题源' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.processTopicSourceSubmit} disabled={processTopicSourceDisabled}>确定</Button>]}>
                        <div className={Style.editModal}>
                            {this.modalListStaticItemComponent('题源名称：', this.state.recordInfo.sourceName)}
                            {this.modalListStaticItemComponent('题源类型：', this.state.recordInfo.sourceType === 1 ? 'SKU' : this.state.recordInfo.sourceType === 2 ? 'PT' : this.state.recordInfo.sourceType === 3 ? '其他' : '')}
                            {this.modalListStaticItemComponent('订单号：', this.state.recordInfo.orderNo)}
                            {this.modalListStaticItemComponent('来源：', this.state.supplyChainSourceFrom[this.state.recordInfo.sourceFrom - 1] ? this.state.supplyChainSourceFrom[this.state.recordInfo.sourceFrom - 1] : '')}
                            {this.modalListStaticItemComponent('题源状态：', this.state.supplyChainStatus[this.state.recordInfo.qsStatus] ? this.state.supplyChainStatus[this.state.recordInfo.qsStatus] : '')}
                            {this.searchSelectComponent({ red: true, title: '题源学科', placeholder: '请选择题源名称', ref: 'editSubject', value: this.state.editSubject, keyList: this.state.supplyChainSubjectList.map(item => item.id), valueList: this.state.supplyChainSubjectList.map(item => item.subjectName), onChangeValue: 'editSubject', onChangeValueId: 'editSubjectId' })}
                            <div className={Style.box}>
                                <span className={Style.span}>年份：</span>
                                <DatePicker value={this.state.editYear ? moment(this.state.editYear, 'YYYY') : ''} onChange={(date, dateString) => { this.changeYear(date, dateString, 'editYear') }} picker="year" ref='editYear' className={Style.select} disabledDate={(date) => {
                                    return date > moment().startOf(1, 'year')
                                }} />
                            </div>
                            {this.searchSelectComponent({ red: true, title: '评价体系', placeholder: '请选择评价体系', ref: 'editEvaluation', value: this.state.editEvaluation, keyList: this.state.supplyChainEvaluationList.map((item) => item.id), valueList: this.state.supplyChainEvaluationList.map(item => item.examClassification), onChangeValue: 'editEvaluation', onChangeValueId: 'editEvaluationId' })}
                            {this.searchSelectComponent({ red: true, title: '自带答案', placeholder: '请选择是否自带答案', ref: 'editBringOwnAnswer', value: this.state.editBringOwnAnswer, keyList: [1, 0, 2], valueList: ['有', '无', '答案不全'], onChangeValue: 'editBringOwnAnswer', onChangeValueId: 'editBringOwnAnswerId' })}
                            {this.searchSelectComponent({ title: 'Chegg答案', placeholder: '请选择是否有Chegg答案', ref: 'editCheggAnswer', value: this.state.editCheggAnswer, keyList: [1, 0, 2], valueList: ['有', '无', '答案不全'], onChangeValue: 'editCheggAnswer', onChangeValueId: 'editCheggAnswerId' })}
                            {this.searchSelectComponent({ red: true, title: '题源流向', placeholder: '请选择题源流向', ref: 'editTopicFlow', value: this.state.editTopicFlow, keyList: [2, 1, 3], valueList: ['录入', '教研', '放弃'], onChangeValue: 'editTopicFlow', onChangeValueId: 'editTopicFlowId' })}
                            <div className={Style.box}>
                                <span className={Style.span}>备注：</span>
                                <TextArea placeholder='请输入备注' maxLength='500' rows={4} className={Style.input} value={this.state.editRemark} onChange={(e) => { this.changeInput(e, 'editRemark') }} />
                                <div className={Style.spanRight}>{this.state.editRemark.length}/500</div>
                            </div>
                        </div>
                    </Modal> : ''}
                    {/* 分配题源弹框 */}
                    {this.state.showDistributeTopicSourceModal ? <Modal title='分配题源' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.distributeTopicSourceSbumit} disabled={this.state.editSelectDistribute === null}>确定</Button>]}>
                        <div className={Style.editModal}>
                            {this.modalListStaticItemComponent('题源名称：', this.state.recordInfo.sourceName)}
                            {this.modalListStaticItemComponent('题源类型：', Number(this.state.recordInfo.sourceType) === 1 ? 'SKU' : Number(this.state.recordInfo.sourceType) === 2 ? 'PT' : Number(this.state.recordInfo.sourceType) === 3 ? '其他' : '')}
                            {this.modalListStaticItemComponent('订单号：', this.state.recordInfo.orderNo)}
                            {this.modalListStaticItemComponent('来源：', this.state.supplyChainSourceFrom[this.state.recordInfo.sourceFrom - 1] ? this.state.supplyChainSourceFrom[this.state.recordInfo.sourceFrom - 1] : '')}
                            {this.modalListStaticItemComponent('自带答案：', this.state.recordInfo.containsAnswer === 0 ? '无' : this.state.recordInfo.containsAnswer === 1 ? '有' : this.state.recordInfo.containsAnswer === 2 ? '答案不全' : '')}
                            {this.modalListStaticItemComponent('Chegg答案：', this.state.recordInfo.cheggAnswer === 0 ? '无' : this.state.recordInfo.cheggAnswer === 1 ? '有' : this.state.recordInfo.cheggAnswer === 2 ? '答案不全' : '')}
                            {this.modalListStaticItemComponent('题源状态：', this.state.supplyChainStatus[this.state.recordInfo.qsStatus] ? this.state.supplyChainStatus[this.state.recordInfo.qsStatus] : '')}
                            {this.searchSelectComponent({ red: true, title: '题源流向', placeholder: '请选择题源流向', ref: 'editTopicFlow', value: this.state.editTopicFlow, keyList: [2, 1, 3], valueList: ['录入', '教研', '放弃'], onChangeValue: 'editTopicFlow', onChangeValueId: 'editTopicFlowId' })}
                            {this.searchSelectComponent({ red: true, title: '分配人选择', placeholder: '全部', ref: 'editSelectDistribute', value: this.state.distributeUser, keyList: this.state.supplyChainManageList.map((item) => item.userId), valueList: this.state.supplyChainManageList.map((item) => item.userName), onChangeValue: 'editSelectDistribute', onChangeValueId: 'editSelectDistributeId' })}
                        </div>
                    </Modal> : ''}
                    {/* 完成教研弹框 */}
                    {this.state.showFinishTeachModal ? <Modal title='完成教研' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.finishTeachSubmit} >确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}><ExclamationCircleOutlined />&emsp;没有答案的题源完成教研之后，请点击确定按钮 题源将转为“教研完成”状态</div>
                        </div>
                    </Modal> : ''}
                    {/* 题源完成录入弹框 */}
                    {this.state.showFinishTopicInputModal ? <Modal title='题源完成录入' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.finishTopicInputSubmit} >确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}><ExclamationCircleOutlined />&emsp;题源中所有题目完成录入后，请点击确定按钮题源将转为“待质检”状态</div>
                        </div>
                    </Modal> : ''}
                    {/* 质检弹框 */}
                    {this.state.showQualityModal ? <Modal title='题源录入质检' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' onClick={this.qualitySubmit} disabled={this.state.editQuality.length === 0}>确定</Button>]}>
                        <div className={Style.editModal}>
                            <div className={Style.rowWrap}><ExclamationCircleOutlined />&emsp;题源录入内容通过质检后，题源将转为“已回收”状态</div>
                            <div className={Style.rowWrap}>&emsp;&emsp;题源录入内容未通过质检，题源将回到“录入中”状态</div>
                        </div>
                        <Radio.Group onChange={this.onChangeQuality} value={this.state.editQuality}>
                            <Radio value={1}>通过质检</Radio>
                            <Radio value={2}>未通过质检</Radio>
                        </Radio.Group>
                    </Modal> : ''}
                </Spin>
            </Fragment >
        )
    }
}

export default SupplyChainManage;
