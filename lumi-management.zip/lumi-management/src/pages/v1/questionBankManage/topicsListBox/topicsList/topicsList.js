import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { Input, Button, Table, message, Pagination, Select, InputNumber, Divider, Spin, Tooltip } from 'antd';
import { SearchOutlined, LoadingOutlined, PlusOutlined, ExportOutlined } from '@ant-design/icons';
import Style from './topicsList.module.less';
import api from '../../../../../utils/api';
import Modal from '../../../../../components/modalOfTree/modalOfTree';
import moment from 'moment';
import fun from '../../../../../utils/funSum.js';
import TextArea from 'antd/lib/input/TextArea';

const { Option } = Select;
class TopicsList extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            tableLoading: false,
            connectModal: false,//关联知识点弹框
            topicInfo: '',//题目ID或题目内容 input/value
            topicISBN: '',//题目ISBN
            startID: '',//起始id
            endID: '',//截止id
            operatorList: [],//操作人下拉列表
            operatorId: '',//操作人id
            operatorName: null,//操作人名字
            subjectList: [],//学科下拉列表
            subjectSel: '',//所选学科id
            subjectName: null,//所选学科名
            firKnowledgeList: [],//一级知识点下拉列表
            firPointSel: '',//一级知识点 下拉所选id
            firPointName: null,//一级知识点名
            secKnowledgeList: [],//二级知识点下拉列表
            secPointSel: '',//二级知识点 下拉所选value
            secPointName: null,//二级知识点名
            teachingMaterialList: [],//教材下拉列表
            teachingMaterialSel: '',//教材 下拉所选value
            chapterList: [],//章节下拉列表
            chapterSel: '',//章节 下拉所选value
            evaluateList: [],//评价下拉列表
            evaluateSel: '',//评价体系 下拉所选value
            classNumberList: [],//课号下拉列表
            classNumber: '',//课号下拉所选value
            schoolList: [],//学校下拉列表
            school: '',//学校下拉所选value
            topicStatusList: [{ type: '上线', id: 1 }, { type: '下线', id: 0 }],//题目状态列表
            topicStatus: null,//题目状态名
            topicStatusId: '',//题目状态id
            topicSourceList: [],//题源学科下拉列表
            topicSourceSel: '',//题源学科 下拉所选value
            dataSource: [],//table数据
            selectedRowKeys: [],//table所选中的行
            selectedRows: [],//table所选中的行的数据
            //显示题目内容搜索框
            showTopicContentSearchModal: false,//显示题目内容搜索框
            topicContentSearch: '',//题目内容搜索框搜索内容
            showTopicContentSearchList: false,//显示的列表是es搜索结果
            page: 1,//当前页
            pageSize: 10,//每页显示条数
            total: 0,//总条数
            //table控制
            columns: [
                {
                    title: '题目ID',
                    dataIndex: 'id',
                    align: 'center',
                    width: '100px',
                    key: 0,
                    render: (id) => {
                        return (
                            <Button type='link' onClick={() => { this.previewTopic(id) }}>{id}</Button>
                        )
                    }
                },
                {
                    title: '题号',
                    dataIndex: 'path',
                    align: 'center',
                    key: 1,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: (path) => {
                        return (
                            <Tooltip placement="topLeft" title={path}>
                                {path}
                            </Tooltip>
                        )
                    }
                },
                {
                    title: '题源学科',
                    dataIndex: 'subject',
                    align: 'center',
                    key: 2,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: subject => (
                        <Tooltip placement="topLeft" title={subject}>
                            {subject}
                        </Tooltip>
                    ),
                },
                {
                    title: '学科',
                    dataIndex: 'subjectName',
                    align: 'center',
                    key: 3,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: subjectName => (
                        <Tooltip placement="topLeft" title={subjectName}>
                            {subjectName}
                        </Tooltip>
                    ),
                },
                {
                    title: 'ISBN',
                    dataIndex: 'bookIsbn',
                    align: 'center',
                    key: 4,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: bookIsbn => (
                        <Tooltip placement="topLeft" title={bookIsbn}>
                            {bookIsbn}
                        </Tooltip>
                    ),
                },
                {
                    title: '一级知识点',
                    dataIndex: 'levelFirstName',
                    align: 'center',
                    key: 5,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: levelFirstName => (
                        <Tooltip placement="topLeft" title={levelFirstName}>
                            {levelFirstName}
                        </Tooltip>
                    ),
                },
                {
                    title: '二级知识点',
                    dataIndex: 'levelSecondName',
                    align: 'center',
                    key: 6,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: levelSecondName => (
                        <Tooltip placement="topLeft" title={levelSecondName}>
                            {levelSecondName}
                        </Tooltip>
                    ),
                },
                {
                    title: '教材名称',
                    dataIndex: 'bookTitle',
                    align: 'center',
                    key: 7,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: bookTitle => (
                        <Tooltip placement="topLeft" title={bookTitle}>
                            {bookTitle}
                        </Tooltip>
                    ),
                },
                {
                    title: '教材章节',
                    dataIndex: 'bookChapter',
                    align: 'center',
                    key: 8,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: bookChapter => (
                        <Tooltip placement="topLeft" title={bookChapter}>
                            {bookChapter}
                        </Tooltip>
                    ),
                },
                {
                    title: '评价体系',
                    dataIndex: 'evaluation',
                    align: 'center',
                    key: 9,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: evaluation => (
                        <Tooltip placement="topLeft" title={evaluation}>
                            {evaluation}
                        </Tooltip>
                    ),
                },
                {
                    title: '题目来源',
                    dataIndex: 'sourceType',
                    align: 'center',
                    key: 10,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: sourceType => {
                        return (
                            <Tooltip placement="topLeft" title={sourceType}>
                                {sourceType}
                            </Tooltip>
                        )
                    }
                },
                {
                    title: '课号',
                    dataIndex: 'classNumber',
                    align: 'center',
                    key: 11,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: classNumber => (
                        <Tooltip placement="topLeft" title={classNumber}>
                            {classNumber}
                        </Tooltip>
                    ),
                },
                {
                    title: '学校',
                    dataIndex: 'college',
                    align: 'center',
                    key: 12,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: college => (
                        <Tooltip placement="topLeft" title={college}>
                            {college}
                        </Tooltip>
                    ),
                },
                {
                    title: '年份',
                    dataIndex: 'year',
                    align: 'center',
                    key: 13,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: year => (
                        <Tooltip placement="topLeft" title={year}>
                            {year}
                        </Tooltip>
                    ),
                },
                {
                    title: '编辑时间',
                    align: 'center',
                    key: 14,
                    width: 180,
                    render: (record) => {
                        let date = record.updatedAt ? moment(new Date(record.updatedAt).getTime() - new Date().getTimezoneOffset() * 60000).format('YYYY/MM/DD HH:mm:ss') : '';//用户所在地时间
                        return (
                            <Tooltip placement="top" title={date}>
                                {date}
                            </Tooltip>
                        )
                    }
                },
                {
                    title: '题目状态',
                    dataIndex: 'status',
                    align: 'center',
                    key: 15,
                    width: '90px',
                    render: (status) => {
                        return (
                            <div>
                                {status === 0 ? '下线' : status === 1 ? '上线' : ''}
                            </div>
                        )
                    }
                },
                {
                    title: '操作人',
                    dataIndex: 'updatedBy',
                    align: 'center',
                    key: 16,
                    ellipsis: {
                        showTitle: false,
                    },
                    render: updatedBy => (
                        <Tooltip placement="top" title={updatedBy ? updatedBy : '无'}>
                            {updatedBy ? updatedBy : '无'}
                        </Tooltip>
                    ),
                },
            ],
            //弹框
            modalSubject: null,//关联知识点所选学科名
            modalSubjectID: '',
            modalFirKnowledgeList: [],
            modalFirstPoint: null,//关联知识点所选一级知识点名
            modalFirstPointID: '',
            modalSecKnowledgeList: [],
            modalSecondPoint: null,//关联知识点所选二级知识点名
            modalSecondPointID: '',
        }
    }
    columns = [
        {
            title: '题目ID',
            dataIndex: 'id',
            align: 'center',
            width: '100px',
            key: 0,
            render: (id) => {
                return (
                    <Button type='link' onClick={() => { this.previewTopic(id) }}>{id}</Button>
                )
            }
        },
        {
            title: '题号',
            dataIndex: 'path',
            align: 'center',
            key: 1,
            ellipsis: {
                showTitle: false,
            },
            render: (path) => {
                return (
                    <Tooltip placement="top" title={path}>
                        {path}
                    </Tooltip>
                )
            }
        },
        {
            title: '题源学科',
            dataIndex: 'subject',
            align: 'center',
            key: 2,
            ellipsis: {
                showTitle: false,
            },
            render: subject => (
                <Tooltip placement="top" title={subject}>
                    {subject}
                </Tooltip>
            ),
        },
        {
            title: '学科',
            dataIndex: 'subjectName',
            align: 'center',
            key: 3,
            ellipsis: {
                showTitle: false,
            },
            render: subjectName => (
                <Tooltip placement="top" title={subjectName}>
                    {subjectName}
                </Tooltip>
            ),
        },
        {
            title: 'ISBN',
            dataIndex: 'bookIsbn',
            align: 'center',
            key: 4,
            ellipsis: {
                showTitle: false,
            },
            render: bookIsbn => (
                <Tooltip placement="top" title={bookIsbn}>
                    {bookIsbn}
                </Tooltip>
            ),
        },
        {
            title: '一级知识点',
            dataIndex: 'levelFirstName',
            align: 'center',
            key: 5,
            ellipsis: {
                showTitle: false,
            },
            render: levelFirstName => (
                <Tooltip placement="top" title={levelFirstName}>
                    {levelFirstName}
                </Tooltip>
            ),
        },
        {
            title: '二级知识点',
            dataIndex: 'levelSecondName',
            align: 'center',
            key: 6,
            ellipsis: {
                showTitle: false,
            },
            render: levelSecondName => (
                <Tooltip placement="top" title={levelSecondName}>
                    {levelSecondName}
                </Tooltip>
            ),
        },
        {
            title: '教材名称',
            dataIndex: 'bookTitle',
            align: 'center',
            key: 7,
            ellipsis: {
                showTitle: false,
            },
            render: bookTitle => (
                <Tooltip placement="top" title={bookTitle}>
                    {bookTitle}
                </Tooltip>
            ),
        },
        {
            title: '教材章节',
            dataIndex: 'bookChapter',
            align: 'center',
            key: 8,
            ellipsis: {
                showTitle: false,
            },
            render: bookChapter => (
                <Tooltip placement="top" title={bookChapter}>
                    {bookChapter}
                </Tooltip>
            ),
        },
        {
            title: '评价体系',
            dataIndex: 'evaluation',
            align: 'center',
            key: 9,
            ellipsis: {
                showTitle: false,
            },
            render: evaluation => (
                <Tooltip placement="top" title={evaluation}>
                    {evaluation}
                </Tooltip>
            ),
        },
        {
            title: '题目来源',
            dataIndex: 'sourceType',
            align: 'center',
            key: 10,
            ellipsis: {
                showTitle: false,
            },
            render: sourceType => {
                return (
                    <Tooltip placement="top" title={sourceType}>
                        {sourceType}
                    </Tooltip>
                )
            }
        },
        {
            title: '课号',
            dataIndex: 'classNumber',
            align: 'center',
            key: 11,
            ellipsis: {
                showTitle: false,
            },
            render: classNumber => (
                <Tooltip placement="top" title={classNumber}>
                    {classNumber}
                </Tooltip>
            ),
        },
        {
            title: '学校',
            dataIndex: 'college',
            align: 'center',
            key: 12,
            ellipsis: {
                showTitle: false,
            },
            render: college => (
                <Tooltip placement="top" title={college}>
                    {college}
                </Tooltip>
            ),
        },
        {
            title: '年份',
            dataIndex: 'year',
            align: 'center',
            key: 13,
            ellipsis: {
                showTitle: false,
            },
            render: year => (
                <Tooltip placement="top" title={year}>
                    {year}
                </Tooltip>
            ),
        },
        {
            title: '编辑时间',
            align: 'center',
            key: 14,
            width: 180,
            render: (record) => {
                let date = record.updatedAt ? moment(new Date(record.updatedAt).getTime() - new Date().getTimezoneOffset() * 60000).format('YYYY/MM/DD HH:mm:ss') : '';//用户所在地时间
                return (
                    <Tooltip placement="top" title={date}>
                        {date}
                    </Tooltip>
                )
            }
        },
        {
            title: '题目状态',
            dataIndex: 'status',
            align: 'center',
            key: 15,
            width: '90px',
            render: (status) => {
                return (
                    <div>
                        {status === 0 ? '下线' : status === 1 ? '上线' : ''}
                    </div>
                )
            }
        },
        {
            title: '操作人',
            dataIndex: 'updatedBy',
            align: 'center',
            key: 16,
            ellipsis: {
                showTitle: false,
            },
            render: updatedBy => (
                <Tooltip placement="top" title={updatedBy ? updatedBy : '无'}>
                    {updatedBy ? updatedBy : '无'}
                </Tooltip>
            ),
        },
    ]
    componentDidMount() {
        // this.getTopicsList({ idisplayStart: this.state.page - 1, idisplayLength: this.state.pageSize });
        this.getOperatorList();
        this.getSubjectList();
        this.getTeachingMaterialList();
        this.getChapterList();
        this.getEvaluateList();
        this.getClassNumberList();
        this.getSchoolList();
        this.getTopicSourceList();
        fun.addKeyboardListener(this.search);//监听回车查询事件
    }
    componentWillUnmount() {
        fun.removeKeyboardListener();
        this.setState = () => {
            return;
        };
    }
    //获取操作人下拉列表
    getOperatorList = () => {
        this.setState({ loading: true }, () => {
            api.getOperatorList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ operatorList: data.result, operatorId: !(this.props.powerArr.indexOf(2) !== -1 || this.props.powerArr.indexOf(7) !== -1 || this.props.powerArr.indexOf(8) !== -1 || this.props.powerArr.indexOf(6) !== -1) ? data.result[0].userId : '', operatorName: !(this.props.powerArr.indexOf(2) !== -1 || this.props.powerArr.indexOf(7) !== -1 || this.props.powerArr.indexOf(8) !== -1 || this.props.powerArr.indexOf(6) !== -1) ? data.result[0].userName : null, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取教材下拉列表
    getTeachingMaterialList = () => {
        this.setState({ loading: true }, () => {
            api.getTeachingMaterialList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ teachingMaterialList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取章节下拉列表
    getChapterList = () => {
        this.setState({ loading: true }, () => {
            api.getChapterList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ chapterList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取评价体系下拉列表
    getEvaluateList = () => {
        this.setState({ loading: true }, () => {
            api.getEvaluateList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ evaluateList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取课号下拉列表
    getClassNumberList = () => {
        this.setState({ loading: true }, () => {
            api.getClassNumberList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ classNumberList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取学校下拉列表
    getSchoolList = () => {
        this.setState({ loading: true }, () => {
            api.getTopicSchoolList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ schoolList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取题源学科列表
    getTopicSourceList = () => {
        this.setState({ loading: true }, () => {
            api.getTopicSourceList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ topicSourceList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取题目列表
    getTopicsList = (params) => {
        this.setState({ tableLoading: true }, () => {
            api.getTopicsList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data ? data.result.data : [], page: data.result.start + 1, total: data.result.total, tableLoading: false, loading: false }, () => {
                            this.setState({ showTopicContentSearchList: false })
                        });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ tableLoading: false });
                })
        })
    }
    // 获取输入的ISBN
    getTopicISBN = (e) => {
        this.setState({ topicISBN: e.target.value });
    }
    //获取题目id或题目内容
    getTopicInfo = (value) => {
        this.setState({ topicInfo: value });
    }
    //获取起始id
    getStartID = (value) => {
        this.setState({ startID: value });
    }
    //获取截止id
    getEndID = (value) => {
        this.setState({ endID: value });
    }
    //获取下拉 操作人所选value
    getOperator = (value, option) => {
        if (value && option) {
            this.refs.operator.blur();
            this.setState({ operatorId: option.key, operatorName: value });
        } else {
            this.setState({ operatorId: '', operatorName: null });
        }
    }
    //点击下拉 获取所选学科同时加载一级知识点列表
    getSubject = (value, option) => {
        if (value && option) {
            this.refs.subject.blur();
            this.setState({ subjectSel: option.key, subjectName: value, firPointSel: '', firPointName: null, secPointSel: '', secPointName: null, firKnowledgeList: [], secKnowledgeList: [] }, () => {
                this.getFirstKnowledge(option.key);
            });
        } else {
            this.setState({ subjectSel: '', subjectName: null, firPointSel: '', firPointName: null, secPointSel: '', secPointName: null, firKnowledgeList: [], secKnowledgeList: [] });
        }
    }
    //获取一级知识点列表
    getFirstKnowledge = (key) => {
        this.setState({ loading: true }, () => {
            api.getFirstKnowledge('/v1/graph/get/level/first/' + key)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ firKnowledgeList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //下拉点击 获取所选一级知识点加载二级知识点列表
    getFirstPoint = (value, option) => {
        if (value && option) {
            this.refs.firPoint.blur();
            this.setState({ firPointSel: option.key, firPointName: value, secPointSel: '', secPointName: null, secKnowledgeList: [] }, () => {
                this.getSecondKnowledge(option.key);
            });
        } else {
            this.setState({ firPointSel: '', firPointName: null, secPointSel: '', secPointName: null, secKnowledgeList: [] });
        }
    }
    //获取二级知识点列表
    getSecondKnowledge = (key) => {
        this.setState({ loading: true }, () => {
            api.getSecondKnowledge('/v1/graph/get/level/second/' + key)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ secKnowledgeList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //下拉点击 获取所选二级知识点
    getSecondPoint = (value, option) => {
        if (value && option) {
            this.refs.secondPoint.blur();
            this.setState({ secPointSel: option.key, secPointName: value });
        } else {
            this.setState({ secPointSel: '', secPointName: value });
        }
    }
    //下拉获取题目来源
    getSourceType = (value, option) => {
        if (value && option) {
            this.refs.source.blur();
            this.setState({ sourceType: value });
        } else {
            this.setState({ sourceType: '' });
        }
    }
    //下拉点击 获取所选教材
    getTeachingMaterial = (value, option) => {
        if (value && option) {
            this.refs.teachingMaterial.blur();
            this.setState({ teachingMaterialSel: value });
        } else {
            this.setState({ teachingMaterialSel: '' });
        }
    }
    //下拉点击 获取所选章节
    getChapter = (value, option) => {
        if (value && option) {
            this.refs.chapter.blur();
            this.setState({ chapterSel: value });
        } else {
            this.setState({ chapterSel: '' });
        }
    }
    //下拉点击 获取所选评价体系
    getEvaluate = (value, option) => {
        if (value && option) {
            this.refs.evaluate.blur();
            this.setState({ evaluateSel: value });
        } else {
            this.setState({ evaluateSel: '' });
        }
    }
    //下拉点击 获取所选题源学科
    getTopicSource = (value, option) => {
        if (value && option) {
            this.refs.topicSource.blur();
            this.setState({ topicSourceSel: value });
        } else {
            this.setState({ topicSourceSel: '' });
        }
    }
    //下拉点击 获取所选课号
    getClassNumber = (value, option) => {
        if (value && option) {
            this.refs.classNumber.blur();
            this.setState({ classNumber: value });
        } else {
            this.setState({ classNumber: '' });
        }
    }
    //下拉点击 获取所选学校
    getSchool = (value, option) => {
        if (value && option) {
            this.refs.school.blur();
            this.setState({ school: value });
        } else {
            this.setState({ school: '' });
        }
    }
    //下拉点击 获取所选题目状态
    getTopicStatus = (value, option) => {
        if (value && option) {
            this.refs.topicStatus.blur();
            this.setState({ topicStatus: value, topicStatusId: option.key });
        } else {
            this.setState({ topicStatus: null, topicStatusId: '' });
        }
    }
    //查询
    search = () => {
        this.getTopicsList({ idisplayStart: 0, idisplayLength: this.state.pageSize, bookIsbn: this.state.topicISBN, id: this.state.topicInfo, startId: this.state.startID, endId: this.state.endID, classNumber: this.state.classNumber, college: this.state.school, status: this.state.topicStatusId, subId: this.state.subjectSel, fid: this.state.firPointSel, sid: this.state.secPointSel, bookTitle: this.state.teachingMaterialSel, bookChapter: this.state.chapterSel, evaluation: this.state.evaluateSel, sourceType: this.state.sourceType, userId: this.state.operatorId, subject: this.state.topicSourceSel });
    }
    // 题目数据导出
    exportExcel = () => {
        this.getExportData(
            { bookIsbn: this.state.topicISBN, id: this.state.topicInfo, startId: this.state.startID, endId: this.state.endID, classNumber: this.state.classNumber, college: this.state.school, status: this.state.topicStatusId, subId: this.state.subjectSel, fid: this.state.firPointSel, sid: this.state.secPointSel, bookTitle: this.state.teachingMaterialSel, bookChapter: this.state.chapterSel, evaluation: this.state.evaluateSel, sourceType: this.state.sourceType, userId: this.state.operatorId, subject: this.state.topicSourceSel });
    }
    // 获取要导出的数据
    getExportData = (params) => {
        this.setState({ loading: true }, () => {
            api.exportTopicList(params, { responseType: 'arraybuffer' })
                .then(async (response) => {
                    let parse_result = await fun.ab2str(response);
                    if (parse_result === false) {
                        fun.download(response, `题目数据-${new Date().getTime()}.xlsx`);  // 直接下载
                        this.setState({ loading: false });
                    } else {
                        if (parse_result.ret === 20000) {
                            message.success(parse_result.msg);
                            this.setState({ loading: false });
                        } else {
                            return Promise.reject(parse_result);
                        }
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                })
        })
    }

    //----------操作
    //关联知识点 弹框
    connectKnowledge = () => {
        if (!(this.props.powerArr.indexOf(7) !== -1 || this.props.powerArr.indexOf(2) !== -1 || this.props.powerArr.indexOf(6) !== -1)) {
            message.warning('无操作权限!');
            return;
        };
        if (this.state.selectedRows.length > 1) {
            this.setState({ connectModal: true });
        } else if (this.state.selectedRows.length <= 1) {
            this.setState({
                connectModal: true,
                topicID: this.state.selectedRows[0].id,
                modalSubject: this.state.selectedRows[0].subjectName,
                modalSubjectID: this.state.selectedRows[0].subId,
                modalFirstPoint: this.state.selectedRows[0].levelFirstName,
                modalFirstPointID: this.state.selectedRows[0].fid,
                modalSecondPoint: this.state.selectedRows[0].levelSecondName,
                modalSecondPointID: this.state.selectedRows[0].sid
            }, () => {
                if (!this.state.modalSubjectID) return;
                this.getModalFirKnowledgeList(this.state.modalSubjectID);
                if (!this.state.modalFirstPointID) return;
                this.getModalSecKnowledgeList(this.state.modalFirstPointID);
            });
        }
    }
    //点击弹框获取一级知识点列表
    getModalFirKnowledgeList = (key) => {
        this.setState({ loading: true }, () => {
            api.getFirstKnowledge('/v1/graph/get/level/first/' + key)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ modalFirKnowledgeList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //点击弹框获取二级知识点列表
    getModalSecKnowledgeList = (key) => {
        this.setState({ loading: true }, () => {
            api.getSecondKnowledge('/v1/graph/get/level/second/' + key)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ modalSecKnowledgeList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //关闭弹框
    close = () => {
        if (this.state.loading) return;
        // if (!this.state.connectModal) return
        this.setState({ connectModal: false, showTopicContentSearchModal: false, topicContentSearch: '' });
    }
    //确定关联知识点
    submitConnect = () => {
        if (this.state.modalSubjectID === '' || this.state.modalFirstPointID === '' || this.state.modalSecondPointID === '') {
            message.warning('选项不完整!');
            return;
        }
        this.setState({ loading: true }, () => {
            let arr = this.state.selectedRows.map((item) => {
                let obj = {};
                obj.qid = item.id;
                obj.subId = this.state.modalSubjectID;
                obj.fid = this.state.modalFirstPointID;
                obj.sid = this.state.modalSecondPointID;
                return obj;
            });
            this.apiConnectKnowledge(arr);
        })
    }
    //题目关联知识点接口
    apiConnectKnowledge = (arr) => {
        api.connectKnowledge(arr)
            .then((data) => {
                if (data.ret === 20000) {
                    this.pageChange(this.state.page, this.state.pageSize);
                    this.setState({ connectModal: false, selectedRowKeys: [], selectedRows: [], loading: false });
                } else {
                    return Promise.reject(data);
                }
            })
            .catch((err) => {
                message.error(err.data);
                this.setState({ loading: false });
            })
    }
    //获取关联知识点所选学科
    getModalSubject = (value, option) => {
        this.setState({ modalSubjectID: option.key, modalSubject: value, modalFirstPointID: '', modalFirstPoint: null, modalSecondPointID: '', modalSecondPoint: null, modalFirKnowledgeList: [], modalSecKnowledgeList: [] }, () => {
            this.getModalFirKnowledgeList(option.key);
        });
    }
    //获取关联知识点所选一级知识点
    getModalFirstPoint = (value, option) => {
        this.setState({ modalFirstPointID: option.key, modalFirstPoint: value, modalSecKnowledgeList: [] }, () => {
            this.getModalSecKnowledgeList(option.key);
        });
    }
    //获取关联知识点所选二级知识点
    getModalSecondPoint = (value, option) => {
        this.setState({ modalSecondPointID: option.key, modalSecondPoint: value });
    }
    //题目上/下线
    lineControl = () => {
        if (!(this.props.powerArr.indexOf(8) !== -1 || this.props.powerArr.indexOf(6) !== -1)) {
            message.warning('无操作权限!');
            return;
        };
        this.setState({ loading: true }, () => {
            let arr = this.state.selectedRows.map((item) => {
                let obj = {};
                obj.id = item.id;
                obj.status = (item.status === 0 ? 1 : 0);
                return obj;
            })
            api.topicLineControl(arr)
                .then((data) => {
                    if (data.ret === 20000) {
                        message.success(data.msg);
                        this.pageChange(this.state.page, this.state.pageSize);
                        this.setState({ selectedRowKeys: [], selectedRows: [] });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //设置table可见列
    setTable = (value, option) => {
        if (value.length > 0 && option.length > 0) {
            let arr = [];
            arr.push(this.columns[0]);
            option.forEach((item1) => {
                arr.push(...this.columns.filter(item => {
                    return item.title === item1.value
                }));
            })
            arr.sort((a, b) => {
                let val1 = a['key'];
                let val2 = b['key'];
                return val1 - val2;
            })
            this.setState({ columns: arr });
        } else {
            let arr = [];
            arr.push(this.columns[0]);
            this.setState({ columns: arr });
        }
    }
    //点击题目跳转
    previewTopic = (id) => {
        window.open(api.pageURL + `/admin/v1/questionBankManage/preview?id=${id}`);
    }
    //table选择行变化
    onSelectChange = (selectedRowKeys, selectedRows) => {
        this.setState({ selectedRowKeys, selectedRows });
    };
    // 显示搜索题目内容弹框
    showTopicContentSearch = () => {
        this.setState({ showTopicContentSearchModal: true })
    }
    // 改变搜索题目内容
    changeTopicContentSearch = (e) => {
        this.setState({ topicContentSearch: e.target.value })
    }
    // 搜索题干内容
    searchTopicContent = () => {
        this.setState({ loading: true, showTopicContentSearchModal: false }, () => {
            api.searchTopicContent({ content: this.state.topicContentSearch })
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ dataSource: data.result.data ? data.result.data : [], page: data.result.start + 1, total: data.result.total, tableLoading: false, loading: false }, () => {
                            this.setState({ showTopicContentSearchList: true })
                        });
                        this.close();
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //分页
    pageChange = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getTopicsList({ idisplayStart: this.state.page - 1, idisplayLength: this.state.pageSize, bookIsbn: this.state.topicISBN, id: this.state.topicInfo, startId: this.state.startID, endId: this.state.endID, classNumber: this.state.classNumber, college: this.state.school, status: this.state.topicStatusId, subId: this.state.subjectSel, fid: this.state.firPointSel, sid: this.state.secPointSel, bookTitle: this.state.teachingMaterialSel, bookChapter: this.state.chapterSel, evaluation: this.state.evaluateSel, sourceType: this.state.sourceType, userId: this.state.operatorId, subject: this.state.topicSourceSel });
        })
    }

    render() {
        /* 限制数字输入框只能输入整数 */
        const limitNumber = value => {
            if (typeof value === 'string') {
                return !isNaN(Number(value)) ? value.replace(/^(0+)|[^\d]/g, '') : ''
            } else if (typeof value === 'number') {
                return !isNaN(value) ? String(value).replace(/^(0+)|[^\d]/g, '') : ''
            } else {
                return ''
            }
        }
        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.onSelectChange,
        };
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.searchWrap}>
                        <div className={Style.wrap}>
                            <span className={Style.span}>题目学科：</span>
                            <Select placeholder='全部' ref='subject' className={Style.input} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.subjectList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>一级知识点：</span>
                            <Select placeholder='全部' ref='firPoint' className={Style.input} value={this.state.firPointName} onChange={this.getFirstPoint} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.firKnowledgeList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.levelFirstName}>{item.levelFirstName}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>二级知识点：</span>
                            <Select placeholder='全部' ref='secondPoint' className={Style.input} value={this.state.secPointName} onChange={this.getSecondPoint} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.secKnowledgeList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.levelSecondName}>{item.levelSecondName}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.inputContentSel}>
                            <span className={Style.span}>课号：</span>
                            <Select placeholder='全部' ref='classNumber' className={Style.input} onChange={this.getClassNumber} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.classNumberList.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.classNumber}>{item.classNumber}</Option>
                                    )
                                })}
                            </Select>
                        </div>

                    </div>
                    <div className={Style.searchWrap}>
                        <div className={Style.wrap}>
                            <span className={Style.span}>题目来源：</span>
                            <Select placeholder='全部' ref='source' className={Style.input} onChange={this.getSourceType} optionLabelProp="label" showSearch={true} allowClear={true}>
                                <Option key='Textbook' value='Textbook'>Textbook</Option>
                                <Option key='Past Test 1' value='Past Test 1'>Past Test 1</Option>
                                <Option key='Past Test 2' value='Past Test 2'>Past Test 2</Option>
                                <Option key='3-party test bank' value='3-party test bank'>3-party test bank</Option>
                                <Option key='Lumi original' value='Lumi original'>Lumi original</Option>
                                <Option key='LumistUser' value='LumistUser'>LumistUser</Option>
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>题源学科：</span>
                            <Select placeholder='全部' ref='topicSource' className={Style.input} onChange={this.getTopicSource} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.topicSourceList.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.subject}>{item.subject}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>操作人：</span>
                            <Select placeholder='全部' ref='operator' disabled={!(this.props.powerArr.indexOf(2) !== -1 || this.props.powerArr.indexOf(7) !== -1 || this.props.powerArr.indexOf(8) !== -1 || this.props.powerArr.indexOf(6) !== -1)} value={this.state.operatorName} className={Style.input} onChange={this.getOperator} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.operatorList.map((item) => {
                                    return (
                                        <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <InputNumber className={Style.inputContent} placeholder="请输入题目ID" maxLength="9" onChange={this.getTopicInfo} />
                    </div>
                    <div className={Style.searchWrap}>
                        <div className={Style.wrap}>
                            <span className={Style.span}>教材名称：</span>
                            <Select placeholder='全部' ref='teachingMaterial' className={Style.input} onChange={this.getTeachingMaterial} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.teachingMaterialList.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.bookTitle}>{item.bookTitle}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>教材章节：</span>
                            <Select placeholder='全部' ref='chapter' className={Style.input} onChange={this.getChapter} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.chapterList.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.bookChapter}>{item.bookChapter}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>评价体系：</span>
                            <Select placeholder='全部' ref='evaluate' className={Style.input} onChange={this.getEvaluate} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.evaluateList.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.evaluation}>{item.evaluation}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.inputContent} >
                            <InputNumber className={Style.inputId} placeholder="题目起始ID" formatter={limitNumber} parser={limitNumber} min="1" maxLength="11" onChange={this.getStartID} />
                            &nbsp;-&nbsp;
                            <InputNumber className={Style.inputId} placeholder="题目截止ID" formatter={limitNumber} parser={limitNumber} min="2" maxLength="11" onChange={this.getEndID} />
                        </div>
                    </div>
                    <div className={Style.searchWrap}>
                        <div className={Style.wrap}>
                            <span className={Style.span}>ISBN：</span>
                            <Input className={Style.input} placeholder="请输入ISBN" maxLength="200" onChange={this.getTopicISBN} />
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>学校：</span>
                            <Select placeholder='全部' ref='school' className={Style.input} onChange={this.getSchool} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.schoolList.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.college}>{item.college}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <div className={Style.wrap}>
                            <span className={Style.span}>题目状态：</span>
                            <Select placeholder='全部' ref='topicStatus' className={Style.input} onChange={this.getTopicStatus} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.topicStatusList.map((item) => {
                                    return (
                                        <Option key={item.id} value={item.type}>{item.type}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <Button className={Style.inputContent} icon={<SearchOutlined />} type='primary' onClick={this.search}>查询</Button>
                    </div>
                    <Divider />
                    <div className={Style.btnsWrap}>
                        <div className={Style.btns}>
                            <Button className={Style.input} icon={<PlusOutlined />} onClick={() => {
                                if (!(this.props.powerArr.indexOf(8) !== -1 || this.props.powerArr.indexOf(6) !== -1 || this.props.powerArr.indexOf(3) !== -1)) {
                                    message.warning('无操作权限!');
                                    return;
                                };
                                window.open(api.pageURL + '/admin/v1/questionBankManage/addTopic');
                            }}>新增题目</Button>
                            <Button type='primary' disabled={this.state.selectedRows.length <= 0} onClick={this.connectKnowledge}>关联知识点</Button>
                            <Button type='primary' disabled={this.state.selectedRows.length <= 0} onClick={this.lineControl}>题目上/下线</Button>
                            <Button type='primary' icon={<ExportOutlined />} disabled={this.state.dataSource.length <= 0 || this.state.showTopicContentSearchList} onClick={this.exportExcel}>题目导出</Button>
                            <Button type='primary' onClick={this.showTopicContentSearch}>题目内容搜索</Button>
                        </div>
                        <div className={Style.tableSearchWrap}>
                            <span>列表显示字段：</span>
                            <Select placeholder='全部' className={Style.tableSelect} defaultValue={() => {
                                let arr = JSON.parse(JSON.stringify(this.state.columns))
                                arr = arr.splice(1).map((item) => {
                                    return item.title;
                                })
                                return arr;
                            }} onChange={this.setTable} maxTagCount={0} optionLabelProp="label" showSearch={true} mode="multiple">
                                {this.columns.map((item, index) => {
                                    if (item.title === '题目ID') return null;
                                    return (
                                        <Option key={index} value={item.title}>{item.title}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                    </div>
                    <Table
                        columns={this.state.columns}
                        dataSource={this.state.dataSource}
                        rowSelection={rowSelection}
                        rowKey={dataSource => dataSource.id}
                        bordered={true}
                        pagination={false}
                        loading={this.state.tableLoading}
                    >
                    </Table>
                    <Pagination className={Style.pagination} showQuickJumper hideOnSinglePage current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.pageChange} showTotal={total => `Total ${total} items`}></Pagination>
                </Spin>
                {
                    this.state.showTopicContentSearchModal ? <Modal title='题目内容搜索' close={this.close} actions={[<Button onClick={this.close} >取消</Button>, <Button type='primary' onClick={this.searchTopicContent} disabled={this.state.topicContentSearch.length <= 0}>搜索</Button>]}>
                        <div className={Style.topicContentSearchModal}>
                            <div className={Style.topicContentSearchModalTop}>
                                <span>搜索说明：</span>
                                <span>填写题目题干内容，搜索匹配度最高的5个题目</span>
                            </div>
                            <div className={Style.topicContentSearchModalBottom}>
                                <TextArea placeholder='请输入题目题干内容' rows='4' maxLength='100' value={this.state.topicContentSearch} onChange={this.changeTopicContentSearch}></TextArea>
                            </div>
                        </div>
                    </Modal> : ''
                }
                {
                    this.state.connectModal ? <Modal title='选择知识点' loading={this.state.loading} close={this.close} actions={[<Button onClick={this.close} disabled={this.state.loading && this.state.connectModal}>取消</Button>, <Button type='primary' onClick={this.submitConnect} loading={this.state.loading && this.state.connectModal}>确定</Button>]}>
                        <span>学科：</span>
                        <Select placeholder='全部' className={Style.modalSelect} value={this.state.modalSubject} onChange={this.getModalSubject} optionLabelProp="label" showSearch={true}>
                            {this.state.subjectList.map((item) => {
                                return (
                                    <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                )
                            })}
                        </Select>
                        <span>一级知识点：</span>
                        <Select placeholder='全部' className={Style.modalSelect} value={this.state.modalFirstPoint} onChange={this.getModalFirstPoint} optionLabelProp="label" showSearch={true}>
                            {this.state.modalFirKnowledgeList.map((item) => {
                                return (
                                    <Option key={item.id} value={item.levelFirstName}>{item.levelFirstName}</Option>
                                )
                            })}
                        </Select>
                        <span>二级知识点：</span>
                        <Select placeholder='全部' className={Style.modalSelect} value={this.state.modalSecondPoint} onChange={this.getModalSecondPoint} optionLabelProp="label" showSearch={true}>
                            {this.state.modalSecKnowledgeList.map((item) => {
                                return (
                                    <Option key={item.id} value={item.levelSecondName}>{item.levelSecondName}</Option>
                                )
                            })}
                        </Select>
                    </Modal> : ''
                }
            </Fragment >
        )
    }
}

export default connect(store => store)(withRouter(TopicsList));