import React, { Component, Fragment } from 'react';
import { Spin, Button, Divider, Input, Select, message, Radio, Checkbox, InputNumber, } from 'antd';
import { LoadingOutlined, DeleteOutlined, PlusOutlined, SaveOutlined } from '@ant-design/icons';
import Style from './addTopic.module.less';
import api from '../../../../../utils/api';
import fun from '../../../../../utils/funSum.js';
import Modal from '../../../../../components/modalOfTree/modalOfTree.js';

const { TextArea } = Input;
const { Option } = Select;
class AddTopic extends Component {
    constructor() {
        super();
        let addTopicContent = fun.getItem('addTopicContent');
        addTopicContent = JSON.parse(addTopicContent);
        this.state = {
            loading: false,
            bulkEditIndex: null,
            showBulkEditOptionModal: false,//显示批量编辑选项弹框
            bulkEditOptionContent: '',
            checkedStatus: true,//题目状态
            checkedInteraction: true,//是否支持互动
            evaluateList: [],
            subjectList: [],
            firKnowledgeList: [],
            secKnowledgeList: [],
            topicID: '',//题目id
            questionList: addTopicContent ? addTopicContent.questionList : [{ type: 1, content: '', edit: true, questionArr: [{ isRight: 0, edit: true, content: '', seq: 1 }, { isRight: 0, edit: true, content: '', seq: 2 }, { isRight: 0, edit: true, content: '', seq: 3 }, { isRight: 0, edit: true, content: '', seq: 4 }] }],
            topicContent: addTopicContent ? addTopicContent.topicContent : '',//题干
            analyseContent: addTopicContent ? addTopicContent.analyseContent : '',//解析
            changeStem: true,//是否编辑题干
            changeAnalyse: true,//是否编辑解析
            inputId: '',//textarea id名
            topicIndex: '',//所点击小题在questionList中的的下标
            optionIndex: '',//所选小题选项的下标
            blur: false,//btn控制 textarea是否触发失焦
            //右
            showRight: fun.getItem('showRight') === null ? true : fun.getItem('showRight') === '1' ? true : false,//是否收起右侧
            subjectID: '',//题目学科id
            subjectName: null,//题目学科名
            firstPointID: '',//一级知识点id
            firstPointName: null,//一级知识点名
            secondPointID: '',//二级知识点id
            secondPointName: null,//二级知识点名
            sourceType: addTopicContent ? addTopicContent.sourceType : '',//题源标签
            ISBN: addTopicContent ? addTopicContent.ISBN : '',//ISBN
            teachingMaterial: addTopicContent ? addTopicContent.teachingMaterial : '',//教材名称
            author: addTopicContent ? addTopicContent.author : '',//教材作者
            chapter: addTopicContent ? addTopicContent.chapter : '',//教材章节
            topicNum: addTopicContent ? addTopicContent.topicNum : '',//题号
            topicPage: addTopicContent ? addTopicContent.topicPage : '',//题目页码
            parsePage: addTopicContent ? addTopicContent.parsePage : '',//解析页码
            evaluate: addTopicContent ? addTopicContent.evaluate : '',//评价体系
            classNumber: addTopicContent ? addTopicContent.classNumber : '',//课号
            year: addTopicContent ? addTopicContent.year : '',//年份
            college: addTopicContent ? addTopicContent.college : '',//学校
            subject: addTopicContent ? addTopicContent.subject : '',//题源学科
            //modal里的数据
            teachingMaterialModal: '',//教材名称
            sourceTypeModal: null,//题目来源
            ISBNModal: '',//ISBN
            authorModal: '',//教材作者
            chapterModal: '',//教材章节
            topicNumModal: '',//题号
            topicPageModal: '',//题目页码
            parsePageModal: '',//解析页面
            evaluateModal: '',//评价体系
            classNumberModal: '',//课号
            yearModal: '',//年份
            collegeModal: '',//大学
            subjectModal: '',//题源学科
            showModalTag: false,
            saveAgain: true,
        }
    }
    componentDidMount () {
        this.getSubjectList();
        this.getEvaluateList();
        let s = document.createElement('script');
        s.type = "text/javascript";
        s.async = true;
        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-AMS_HTML';
        // s.src='https://cdn.jsdelivr.net/npm/mathjax@3.0.1/es5/tex-mml-chtml.js';
        document.body.appendChild(s);
        window.MathJax = {
            tex2jax: {
                inlineMath: [["$", "$"], ["\\(", "\\)"]], //行内公式选择符
                displayMath: [["$$", "$$"], ["\\[", "\\]"]], //段内公式选择符
                skipTags: ["script", "noscript", "style", "textarea", "pre", "code", "a"] //避开某些标签
            },
            AuthorInit: function () {
                window.MathJax.Hub.Register.StartupHook("Begin", function () {
                    window.MathJax.Hub.Queue(
                        ["Typeset", window.MathJax.Hub, document.getElementById('root')]
                    )
                });
            },
            showProcessingMessages: false, //关闭js加载过程信息
            messageStyle: "none", //不显示信息
            jax: ["input/TeX", "output/HTML-CSS"],
            "HTML-CSS": {
                availableFonts: ["STIX", "TeX"], //可选字体
                showMathMenu: false //关闭右击菜单显示
            }
        };
        document.body.addEventListener('keydown', this.keyboardListener);//监听ctrl+s事件 
    }
    componentDidUpdate () {
        fun.setItem('addTopicContent', {
            //左边
            questionList: this.state.questionList,
            topicContent: this.state.topicContent,
            analyseContent: this.state.analyseContent,
            //右
            sourceType: this.state.sourceType,
            ISBN: this.state.ISBN,
            teachingMaterial: this.state.teachingMaterial,
            author: this.state.author,
            chapter: this.state.chapter,
            topicNum: this.state.topicNum,
            topicPage: this.state.topicPage,
            parsePage: this.state.parsePage,
            evaluate: this.state.evaluate,
            subject: this.state.subject,
            classNumber: this.state.classNumber,
            year: this.state.year,
            college: this.state.college,
        })
    }
    componentWillUnmount () {
        document.body.removeEventListener('keydown', this.keyboardListener);
        this.setState = () => {
            return;
        };
    }
    //监听ctrl+s事件
    keyboardListener = (e) => {
        //83为s键，通过判断metaKey和ctrlKey视频Mac和Windows
        if ((e.metaKey || e.ctrlKey) && e.keyCode === 83) {
            e.returnValue = false;//取消Ctrl+s的默认事件
            this.setState({
                changeStem: true,
                changeAnalyse: true,
                // loading: true
            }, () => {
                window.MathJax.Hub.Queue(["Typeset", window.MathJax.Hub, document.getElementById('root')]);
                this.save();
            });
        }
    }
    keyboardListenerNull = (e) => {
        if ((e.metaKey || e.ctrlKey) && e.keyCode === 83) {
            e.returnValue = false;//取消Ctrl+s的默认事件
            return;
        }
    }
    //获取学科下拉列表
    getSubjectList = () => {
        this.setState({ loading: true }, () => {
            api.getSubjectList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ subjectList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取一级知识点列表
    getFirstKnowledge = (key) => {
        this.setState({ loading: true }, () => {
            api.getFirstKnowledge('/v1/graph/get/level/first/' + key)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ firKnowledgeList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取二级知识点列表
    getSecondKnowledge = (key) => {
        this.setState({ loading: true }, () => {
            api.getSecondKnowledge('/v1/graph/get/level/second/' + key)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ secKnowledgeList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取评价体系下拉列表
    getEvaluateList = () => {
        this.setState({ loading: true }, () => {
            api.getEvaluateList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ evaluateList: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //switch获取题目状态
    changeStatus = (checked) => {
        this.setState({ checkedStatus: checked });
    }
    //switch获取是否支持互动
    changeInteraction = (checked) => {
        this.setState({ checkedInteraction: checked });
    }
    //获取外部题干
    getTopicStem = (e) => {
        this.setState({ topicContent: e.target.value });
    }
    //获取解析
    getAnalyseContent = (e) => {
        this.setState({ analyseContent: e.target.value });
    }
    //选择小题类型
    selectQuestionType = (e, index) => {
        let arr = this.state.questionList;
        arr[index].type = e.target.value === 'single' ? 1 : e.target.value === 'judeg' ? 2 : e.target.value === 'anwser' ? 3 : e.target.value === 'fill' ? 4 : e.target.value === 'multiple' ? 5 : 1;
        this.setState({ questionList: arr }, () => {
            window.MathJax.Hub.Queue(["Typeset", window.MathJax.Hub, document.getElementById('root')]);
        });
    }
    //获取小题题干
    getChildContent = (e, index) => {
        let arr = this.state.questionList;
        arr[index].content = e.target.value;
        this.setState({ questionList: arr });
    }
    //文件上传 插入图片
    uploadTopicStemFile = (e) => {
        console.log(e.target.files)
        let file = e.target.files[0];
        this.setState({ loading: true }, () => {
            // fun.removeExif(file)
            //     .then((res) => {
            //         let formData = new FormData();
            //         formData.append('file', res)
            //         api.uploadPic(formData)
            //             .then((res) => {
            //                 //在input框中光标所在位置插入文本内容
            //                 let input = document.getElementById(this.state.inputId);
            //                 input.value = input.value.substr(0, input.selectionStart) + `<img src="${'https://cdn.lumiclass.com/' + res.result}" />` + input.value.substr(input.selectionStart);
            //                 if (this.state.inputId === 'topicStemInput') {
            //                     this.setState({ changeStem: false, blur: false, topicContent: input.value, loading: false });
            //                 } else if (this.state.inputId === 'analyseInput') {
            //                     this.setState({ changeAnalyse: false, blur: false, analyseContent: input.value, loading: false });
            //                 } else {
            //                     let arr = this.state.questionList;
            //                     arr[this.state.topicIndex].content = input.value;
            //                     arr[this.state.topicIndex].edit = false;
            //                     this.setState({ blur: false, questionList: arr, loading: false });
            //                 }
            //             })
            //             .catch((err) => {
            //                 message.error(err.msg);
            //                 this.setState({ loading: false });
            //             })
            //     })
            api.getAddress({ fileName: '.png', type: 3 })
                .then((data) => {
                    if (data.ret === 20000) {
                        // console.log(file)
                        fun.removeExif(file)
                            .then((res) => {
                                // api.uploadAWS(data.result.url, file)
                                api.uploadAWS(data.result.url, res)
                                    .then(() => {
                                        //在input框中光标所在位置插入文本内容
                                        let input = document.getElementById(this.state.inputId);
                                        input.value = input.value.substr(0, input.selectionStart) + `<img src="${data.result.cmsCloudfront + '/' + data.result.key}" />` + input.value.substr(input.selectionStart);
                                        if (this.state.inputId === 'topicStemInput') {
                                            this.setState({ changeStem: false, blur: false, topicContent: input.value, loading: false });
                                        } else if (this.state.inputId === 'analyseInput') {
                                            this.setState({ changeAnalyse: false, blur: false, analyseContent: input.value, loading: false });
                                        } else {
                                            let arr = this.state.questionList;
                                            arr[this.state.topicIndex].content = input.value;
                                            arr[this.state.topicIndex].edit = false;
                                            this.setState({ blur: false, questionList: arr, loading: false });
                                        }
                                    })
                                    .catch((err) => {
                                        // console.log(err)
                                        message.error(err.msg);
                                        this.setState({ loading: false });
                                    })
                            })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false, blur: false });
                })
        })
    }
    //改变批量编辑选项内容
    changeBulkEditOptionContent = (e) => {
        this.setState({ bulkEditOptionContent: e.target.value })
    }
    //显示批量编辑选项弹框
    showBulkEditOption = (index) => {
        this.setState({ showBulkEditOptionModal: true, bulkEditIndex: index })
    }
    //右
    //获取题目学科
    getSubject = (value, option) => {
        if (value && option) {
            this.getFirstKnowledge(option.key);
            this.setState({ subjectName: value, subjectID: option.key });
        } else {
            this.setState({ subjectName: null, subjectID: '', firstPointName: null, firstPointID: '', secondPointName: null, secondPointID: '' });
        }
    }
    //获取一级知识点
    getFirstPoint = (value, option) => {
        if (value && option) {
            this.getSecondKnowledge(option.key);
            this.setState({ firstPointName: value, firstPointID: option.key });
        } else {
            this.setState({ firstPointName: null, firstPointID: '', secondPointName: null, secondPointID: '' });
        }
    }
    //获取二级知识点
    getSecondPoint = (value, option) => {
        if (value && option) {
            this.setState({ secondPointName: value, secondPointID: option.key });
        } else {
            this.setState({ secondPointName: null, secondPointID: '' });
        }
    }
    //---------------题源标签
    //获取题源标签
    getSourceType = (value, option) => {
        if (value && option) {
            this.setState({ sourceType: value });
        } else {
            this.setState({ sourceType: '' });
        }
    }
    //获取ISBN
    getISBN = (e) => {
        this.setState({ ISBN: e.target.value });
    }
    //获取教材名称
    getTeachingMaterial = (e) => {
        this.setState({ teachingMaterial: e.target.value });
    }
    //获取教材作者
    getAuthor = (e) => {
        this.setState({ author: e.target.value });
    }
    //获取教材章节
    getChapter = (e) => {
        this.setState({ chapter: e.target.value });
    }
    //获取题号
    getTopicNum = (e) => {
        this.setState({ topicNum: e.target.value });
    }
    //获取题目页码
    getTopicPage = (e) => {
        this.setState({ topicPage: e.target.value });
    }
    //获取解析页码
    getParsePage = (e) => {
        this.setState({ parsePage: e.target.value });
    }
    //获取评价体系
    getEvaluate = (e) => {
        this.setState({ evaluate: e.target.value });
    }
    //获取题源学科
    getSubject = (e) => {
        this.setState({ subject: e.target.value });
    }
    //获取课号
    getClassNumber = (e) => {
        this.setState({ classNumber: e.target.value });
    }
    //获取年份
    getYear = (e) => {
        this.setState({ year: e.target.value });
    }
    //获取学校
    getCollege = (e) => {
        this.setState({ college: e.target.value });
    }

    //---------------题源标签模板
    //获取modal教材名称
    getModalTeachingMaterial = (e) => {
        this.setState({ teachingMaterialModal: e.target.value })
    }
    //获取modal题目来源
    getModalSourceType = (value, option) => {
        if (value && option) {
            this.setState({ sourceTypeModal: value });
        } else {
            this.setState({ sourceTypeModal: null });
        }
    }
    //获取modalISBN
    getModalISBN = (e) => {
        this.setState({ ISBNModal: e.target.value })
    }
    //获取modal教材作者
    getModalAuthor = (e) => {
        this.setState({ authorModal: e.target.value })
    }
    //获取modal教材章节
    getModalChapter = (e) => {
        this.setState({ chapterModal: e.target.value })
    }
    //获取modal题号
    getModalTopicNum = (e) => {
        this.setState({ topicNumModal: e.target.value })
    }
    //获取modal题目页码
    getModalTopicPage = (e) => {
        this.setState({ topicPageModal: e.target.value })
    }
    //获取modal解析页面
    getModalParsePage = (e) => {
        this.setState({ parsePageModal: e.target.value })
    }
    //获取modal评价体系
    getModalEvaluate = (e) => {
        this.setState({ evaluateModal: e.target.value })
    }
    //获取modal课号
    getModalClassNumber = (e) => {
        this.setState({ classNumberModal: e.target.value })
    }
    //获取modal年份
    getModalYear = (e) => {
        this.setState({ yearModal: e.target.value })
    }
    //获取modal大学
    getModalCollege = (e) => {
        this.setState({ collegeModal: e.target.value })
    }
    //获取modal学科
    getModalSubject = (e) => {
        this.setState({ subjectModal: e.target.value })
    }
    // 保存modal数据
    saveModal = () => {
        let data = {
            teachingMaterialModal: this.state.teachingMaterialModal,//教材名称
            sourceTypeModal: this.state.sourceTypeModal,//题目来源
            ISBNModal: this.state.ISBNModal,//ISBN
            authorModal: this.state.authorModal,//教材作者
            chapterModal: this.state.chapterModal,//教材章节
            topicNumModal: this.state.topicNumModal,//题号
            topicPageModal: this.state.topicPageModal,//题目页码
            parsePageModal: this.state.parsePageModal,//解析页面
            evaluateModal: this.state.evaluateModal,//评价体系
            classNumberModal: this.state.classNumberModal,//课号
            yearModal: this.state.yearModal,//年份
            collegeModal: this.state.collegeModal,//大学
            subjectModal: this.state.subjectModal,//学科
        };
        let blank = data.teachingMaterialModal || data.sourceTypeModal || data.ISBNModal || data.authorModal || data.chapterModal || data.topicNumModal || data.topicPageModal || data.parsePageModal || data.evaluateModal || data.classNumberModal || data.yearModal || data.collegeModal || data.subjectModal;
        if (!blank) {
            message.warning('不能全部为空！');
            return;
        }
        fun.setItem('modal', data);
        this.close();
    }
    //展示题源标签模板弹框
    showTag = () => {
        let data = JSON.parse(fun.getItem('modal'));
        if (data === null) {
            this.setState({
                showModalTag: true,//开启弹窗
            });
            return;
        }
        this.setState({
            showModalTag: true,
            teachingMaterialModal: data.teachingMaterialModal,//教材名称
            sourceTypeModal: data.sourceTypeModal,//题目来源
            ISBNModal: data.ISBNModal,//ISBN
            authorModal: data.authorModal,//教材作者
            chapterModal: data.chapterModal,//教材章节
            topicNumModal: data.topicNumModal,//题号
            topicPageModal: data.topicPageModal,//题目页码
            parsePageModal: data.parsePageModal,//解析页面
            evaluateModal: data.evaluateModal,//评价体系
            classNumberModal: data.classNumberModal,//课号
            yearModal: data.yearModal,//年份
            collegeModal: data.collegeModal,//大学 });
            subjectModal: data.subjectModal,//学科});
        });
    }
    //应用到本题
    apply = () => {
        let data = JSON.parse(fun.getItem('modal'));
        if (data === null) {
            message.warning('尚未添加模板！');
            return;
        }
        this.setState({
            teachingMaterial: data.teachingMaterialModal,//教材名称
            sourceType: data.sourceTypeModal,//题目来源
            ISBN: data.ISBNModal,//ISBN
            author: data.authorModal,//教材作者
            chapter: data.chapterModal,//教材章节
            topicNum: data.topicNumModal,//题号
            topicPage: data.topicPageModal,//题目页码
            parsePage: data.parsePageModal,//解析页面
            evaluate: data.evaluateModal,//评价体系
            classNumber: data.classNumberModal,//课号
            year: data.yearModal,//年份
            college: data.collegeModal,//大学 
            subject: data.subjectModal,//学科 
        });
    }
    //关闭展示题源标签模板弹框
    close = () => {
        this.setState({
            showModalTag: false,//关闭弹窗
            //清空数据
            teachingMaterialModal: '',//教材名称
            sourceTypeModal: null,//题目来源
            ISBNModal: '',//ISBN
            authorModal: '',//教材作者
            chapterModal: '',//教材章节
            topicNumModal: '',//题号
            topicPageModal: '',//题目页码
            parsePageModal: '',//解析页面
            evaluateModal: '',//评价体系
            classNumberModal: '',//课号
            yearModal: '',//年份
            collegeModal: '',//大学
            subjectModal: '',//学科
            bulkEditOptionContent: '',//批量编辑选项弹框textareanr
            showBulkEditOptionModal: false,//关闭批量编辑选项弹框
        });
    }
    //插入图片和换行符的onmousedown事件
    insertMouseDown = (e) => {
        e.preventDefault();
        window.event.returnValue = false;
        this.setState({ blur: true });
    }
    //插入换行符的click事件
    insertBr = () => {
        //在input框中光标所在位置插入文本内容
        let input = document.getElementById(this.state.inputId);
        input.value = input.value.substr(0, input.selectionStart) + '<br>' + input.value.substr(input.selectionStart);
        if (this.state.inputId === 'topicStemInput') {
            this.setState({ changeStem: false, blur: false, topicContent: input.value, loading: false });
        } else if (this.state.inputId === 'analyseInput') {
            this.setState({ changeAnalyse: false, blur: false, analyseContent: input.value, loading: false });
        } else {
            let arr = this.state.questionList;
            arr[this.state.topicIndex].content = input.value;
            arr[this.state.topicIndex].edit = false;
            this.setState({ blur: false, questionList: arr, loading: false });
        }
    }
    //插入图片和换行符的按钮
    insertBrImg = () => {
        return (<div className={Style.insertBtn}>
            <Button onMouseDown={this.insertMouseDown} onClick={this.insertBr}>插入换行符</Button>
            <Button onMouseDown={this.insertMouseDown} onClick={() => { this.refs.upload.click(); }}>插入图片</Button>
        </div>);
    }
    //题干
    questionContent = (index, item, inputId) => {
        return item.edit ?
            // 题干
            <Fragment>
                <div
                    className={Style.topicWrap}
                    onClick={() => {
                        let arr = this.state.questionList;
                        arr[index].edit = false;
                        this.setState({ inputId: inputId, topicIndex: index, questionList: arr });
                    }}
                    dangerouslySetInnerHTML={{ __html: item.content }}
                ></div>
            </Fragment>
            :
            // 小题题干
            <Fragment>
                <TextArea
                    id={inputId}
                    maxLength='100000'
                    onBlur={() => {
                        if (this.state.blur) {
                            this.setState({ blur: false });
                            return false;//插入图片btn控制是否失焦
                        }
                        let arr = this.state.questionList;
                        arr[index].edit = true;
                        this.setState({ questionList: arr }, () => {
                            window.MathJax.Hub.Queue(
                                ["Typeset", window.MathJax.Hub, document.getElementById('root')]
                            )
                        });
                    }}
                    // 设置焦点
                    ref={input => {
                        if (!input) return; input.focus();
                    }}
                    style={{ paddingBottom: '80px' }}
                    autoSize
                    // rows={4}
                    value={item.content}
                    onChange={(e) => { this.getChildContent(e, index) }}
                />
                {/* 插入图片和换行符的button */}
                {this.insertBrImg()}
            </Fragment>
    }
    //选项编辑
    itemEdit = (item1, index, index1) => {
        return <Fragment> {item1.edit ?
            <div className={Style.optionContent} onClick={() => {
                let arr = this.state.questionList
                arr[index].questionArr[index1].edit = false;
                this.setState({ inputId: 'optionInput', topicIndex: index, optionIndex: index1, questionList: arr });
            }}>{item1.content}</div>
            :
            <Fragment>
                <TextArea id='optionInput' className={Style.optionContent} maxLength='2500' onBlur={() => {
                    if (this.state.blur) {
                        this.setState({ blur: false });
                        return false;//插入图片btn控制是否失焦
                    }
                    let arr = this.state.questionList;
                    arr[index].questionArr[index1].edit = true;
                    this.setState({ questionList: arr }, () => {
                        window.MathJax.Hub.Queue(
                            ["Typeset", window.MathJax.Hub, document.getElementById('root')]
                        )
                    });
                }} ref={input => {
                    if (!input) return;
                    input.focus();　　// 设置焦点
                }} rows={1} value={item1.content} onChange={(e) => {
                    let arr = this.state.questionList;
                    arr[index].questionArr[index1].content = e.target.value;
                    this.setState({ questionList: arr });
                }}
                />
            </Fragment>}
            <div className={Style.delOptionIcon}><DeleteOutlined className={Style.optionIcon} onClick={() => {
                let arr = this.state.questionList;
                if (arr[index].questionArr.length <= 2) {
                    message.warning("至少有两个选项！")
                    return;
                }
                arr[index].questionArr.splice(index1, 1);
                this.setState({ questionList: arr });
            }} />
            </div>
        </Fragment>
    }
    //添加选项
    addOptionBtn = (index) => {
        return this.state.questionList[index].questionArr.length < 26 ? <Button icon={<PlusOutlined />} className={Style.addOptionBtn} onClick={() => {
            let arr = this.state.questionList;
            let obj = {};
            obj.content = '';
            obj.isRight = 0;
            obj.seq = arr[index].questionArr.length + 1;
            obj.edit = true;
            arr[index].questionArr.push(obj);
            this.setState({ questionList: arr });
        }}>添加选项</Button> : ''
    }
    //题源标签
    topicSourceLabel = (str) => {
        let flag = (str === 'label');
        return <div className={flag ? Style.tagWrap : Style.tagWrapModal}>
            <div className={Style.box}>
                <span className={Style.title}>题目来源：</span>
                <Select placeholder='全部' className={Style.input} value={flag ? this.state.sourceType : this.state.sourceTypeModal} onChange={flag ? this.getSourceType : this.getModalSourceType} optionLabelProp="label" showSearch={true} allowClear={true}>
                    <Option key='Textbook' value='Textbook'>Textbook</Option>
                    <Option key='Past Test 1' value='Past Test 1'>Past Test 1</Option>
                    <Option key='Past Test 2' value='Past Test 2'>Past Test 2</Option>
                    <Option key='3-party test bank' value='3-party test bank'>3-party test bank</Option>
                    <Option key='Lumi original' value='Lumi original'>Lumi original</Option>
                    <Option key='LumistUser' value='LumistUser'>LumistUser</Option>
                </Select>
            </div>
            <div className={Style.box}>
                <span className={Style.title}>ISBN：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.ISBN : this.state.ISBNModal} onChange={flag ? this.getISBN : this.getModalISBN} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>教材名称：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.teachingMaterial : this.state.teachingMaterialModal} onChange={flag ? this.getTeachingMaterial : this.getModalTeachingMaterial} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>教材作者：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.author : this.state.authorModal} onChange={flag ? this.getAuthor : this.getModalAuthor} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>教材章节：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.chapter : this.state.chapterModal} onChange={flag ? this.getChapter : this.getModalChapter} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>题号：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.topicNum : this.state.topicNumModal} onChange={flag ? this.getTopicNum : this.getModalTopicNum} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>题目页码：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.topicPage : this.state.topicPageModal} onChange={flag ? this.getTopicPage : this.getModalTopicPage} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>解析页码：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.parsePage : this.state.parsePageModal} onChange={flag ? this.getParsePage : this.getModalParsePage} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>评价体系：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.evaluate : this.state.evaluateModal} onChange={flag ? this.getEvaluate : this.getModalEvaluate} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>课号：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.classNumber : this.state.classNumberModal} onChange={flag ? this.getClassNumber : this.getModalClassNumber} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>年份：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.year : this.state.yearModal} onChange={flag ? this.getYear : this.getModalYear} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>学校：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.college : this.state.collegeModal} onChange={flag ? this.getCollege : this.getModalCollege} />
            </div>
            <div className={Style.box}>
                <span className={Style.title}>题源学科：</span>
                <Input disabled={this.state.modifyTopic} className={Style.input} maxLength='100' value={flag ? this.state.subject : this.state.subjectModal} onChange={flag ? this.getSubject : this.getModalSubject} />
            </div>
            {!flag ? <div className={Style.buttonList}>
                <Button className={Style.modalSave} type='primary' onClick={this.saveModal}>保存</Button>
                <Button className={Style.modalSave} type='primary' onClick={this.close}>取消</Button>
            </div> : ''}
        </div>
    }
    //保存
    save = () => {
        if (!this.state.saveAgain) return;
        this.setState({ loaidng: true, saveAgain: false }, () => {
            api.saveAddTopic({
                analyse: this.state.analyseContent,//题目解析
                canMock: 1,//switch是否可以互动
                status: 0,//switch是否上下线
                content: this.state.topicContent,//外部题干
                label: {
                    examClassification: this.state.evaluate,//评价体系
                    knowledgeLabel: '',//学科id,一级id,二级id
                    bookTitle: this.state.teachingMaterial,//教材名称
                    bookIsbn: this.state.ISBN,//isbn
                    bookChapter: this.state.chapter,//题目章节
                    sourceType: this.state.sourceType,//题目来源
                    author: this.state.author,//教材作者
                    questionPage: this.state.topicPage,//题目页码
                    answerPage: this.state.parsePage,//解析页码
                    path: this.state.topicNum,//题号
                    classNumber: this.state.classNumber,//课号
                    college: this.state.college,//学校
                    year: this.state.year,//年份
                    subject: this.state.subject,//题源学科
                },
                questionList: (this.state.questionList.map((item) => {
                    if (item.type === 4) {
                        item.questionArr.splice(1);
                    } else if (item.type === 3) {
                        item.questionArr = null;
                    }
                    return item;
                }))
            })
                .then((data) => {
                    if (data.ret === 20000) {
                        window.MathJax.Hub.Queue(["Typeset", window.MathJax.Hub, document.getElementById('root')]);
                        message.success('新增成功！');
                        this.setState({ loading: false, saveAgain: true }, () => {
                            fun.setItem('addTopicContent', null);
                            window.location.reload();
                        })
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false, saveAgain: true });
                })
        })
    }
    //改变是否收起右侧
    changeShowRight = () => {
        this.setState({ showRight: !this.state.showRight }, () => {
            fun.setItem('showRight', this.state.showRight ? 1 : 0);
        });
    }
    render () {
        const limitDecimalsP = (value) => {
            let reg = /^(-)*(\d+)\.(\d+).*$/;
            return value.replace(/\s?|(,*)/g, '').replace(reg, '$1$2.$3');
        };
        return (
            <Fragment>
                <input type='file' ref='upload' accept="image/*" className={Style.uploadInput} onChange={this.uploadTopicStemFile} />
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div className={Style.topWrap}>
                        <div className={Style.left}>
                            <span className={Style.title}>题目ID：{this.state.topicID}</span>
                            <Button type='primary' icon={<SaveOutlined />} onClick={this.save}>保存</Button>
                        </div>
                        <div className={Style.right}>
                            <Button type='link' onClick={this.changeShowRight}>{this.state.showRight ? '收起标签' : '展开标签'}</Button>
                        </div>
                    </div>
                    <Divider />
                    <div className={Style.contentWrap}>
                        <div className={Style.leftWrap} style={{ width: this.state.showRight ? '60%' : '100%' }}>
                            <h3 className={Style.title}>题干</h3>
                            <span>当题目没有多道小题时，题干应该空置，不填写任何内容</span><br />
                            {this.state.changeStem ?
                                <div
                                    className={Style.topicWrap}
                                    onClick={() => { this.setState({ inputId: 'topicStemInput', changeStem: false }) }}
                                    dangerouslySetInnerHTML={{ __html: this.state.topicContent }}
                                ></div>
                                :
                                <Fragment>
                                    <TextArea id='topicStemInput' maxLength='100000' onBlur={() => {
                                        if (this.state.blur) {
                                            this.setState({ blur: false });
                                            return false;//插入图片btn控制是否失焦
                                        }
                                        this.setState({ changeStem: true }, () => {
                                            console.log(window.MathJax)
                                            window.MathJax.Hub.Queue(
                                                ["Typeset", window.MathJax.Hub, document.getElementById('root')]
                                            )
                                        });
                                    }} ref={input => {
                                        if (!input) return;
                                        input.focus();　　// 设置焦点
                                    }}
                                        style={{ paddingBottom: '80px' }}
                                        autoSize
                                        // rows={4}
                                        value={this.state.topicContent} onChange={this.getTopicStem} />
                                    {/* 插入图片和换行符的button */}
                                    {this.insertBrImg()}
                                </Fragment>
                            }
                            {this.state.questionList.map((item, index) => {
                                let questionType = item.type === 1 ? 'single' : item.type === 2 ? 'judeg' : item.type === 3 ? 'anwser' : item.type === 4 ? 'fill' : item.type === 5 ? 'multiple' : 'single';
                                return (
                                    <Fragment key={index}>
                                        <Divider dashed={true} className={Style.topicDivider} />
                                        {/* 小题类型 */}
                                        <div className={Style.typeWrap}>
                                            <span className={Style.delIcon}>{<DeleteOutlined onClick={() => {
                                                let arr = this.state.questionList;
                                                if (arr.length <= 1) {
                                                    message.warning("至少有一道题目！");
                                                    return;
                                                }
                                                arr.splice(index, 1);
                                                this.setState({ questionList: arr });
                                            }} />}</span>
                                            <span className={Style.topicNum}>题目{index + 1}</span>
                                            <Radio.Group
                                                value={questionType}
                                                onChange={(e) => { this.selectQuestionType(e, index) }}
                                            >
                                                <Radio.Button value='single'>单选</Radio.Button>
                                                <Radio.Button value='multiple'>多选</Radio.Button>
                                                <Radio.Button value='fill'>填空</Radio.Button>
                                                <Radio.Button value='judeg'>判断</Radio.Button>
                                                <Radio.Button value='anwser'>解答</Radio.Button>
                                            </Radio.Group>
                                            {(questionType === 'single' || questionType === 'multiple') ? <Button type='link' onClick={(e) => { this.showBulkEditOption(index) }}>批量编辑选项</Button> : ''}
                                        </div>
                                        {/* 单选 */}
                                        {questionType === 'single' ?
                                            <Fragment>
                                                {/*题干*/}
                                                {this.questionContent(index, item, 'singleStemInput')}
                                                {/* 选项 */}
                                                {item.questionArr.map((item1, index1) => {
                                                    return (
                                                        <div key={index1} className={Style.questionArrWrap}>
                                                            <Radio.Group
                                                                className={Style.radio}
                                                                value={this.state.questionList[index].questionArr[index1].isRight === 1 ? this.state.questionList[index].questionArr[index1].content : null}
                                                                onChange={(e) => {
                                                                    let arr = this.state.questionList;
                                                                    arr[index].questionArr.map((i) => {
                                                                        i.isRight = 0;
                                                                        return i;
                                                                    })
                                                                    arr[index].questionArr[index1].isRight = e.target.checked === true ? 1 : 0;
                                                                    this.setState({ questionList: arr });
                                                                }}
                                                            >
                                                                <Radio checked={item1.isRight === 1} value={item1.content}>{String.fromCharCode((index1 + 65))}</Radio>
                                                            </Radio.Group>
                                                            {/* 选项编辑 */}
                                                            {this.itemEdit(item1, index, index1)}
                                                        </div>
                                                    )
                                                })}
                                                {/* 添加选项 */}
                                                {this.addOptionBtn(index)}
                                                <Divider dashed={true} className={Style.topicDivider} />
                                            </Fragment> : ''}
                                        {/* 多选 */}
                                        {questionType === 'multiple' ?
                                            <Fragment>
                                                {/*题干*/}
                                                {this.questionContent(index, item, 'multipleStemInput')}
                                                {/* 选项 */}
                                                {item.questionArr.map((item1, index1) => {
                                                    return (
                                                        <div key={index1} className={Style.questionArrWrap}>
                                                            <Checkbox
                                                                className={Style.radio}
                                                                checked={(this.state.questionList[index].questionArr[index1].isRight === 1 ? true : false)}
                                                                onChange={(e) => {
                                                                    let arr = this.state.questionList;
                                                                    arr[index].questionArr[index1].isRight = e.target.checked === true ? 1 : 0;
                                                                    this.setState({ questionList: arr });
                                                                }}
                                                            >
                                                                {String.fromCharCode((index1 + 65))}
                                                            </Checkbox>
                                                            {/* 选项编辑 */}
                                                            {this.itemEdit(item1, index, index1)}
                                                        </div >
                                                    )
                                                })}
                                                {/* 添加选项 */}
                                                {this.addOptionBtn(index)}
                                                <Divider dashed={true} className={Style.topicDivider} />
                                            </Fragment > : ''}
                                        {/* 填空 */}
                                        {questionType === 'fill' ?
                                            <Fragment>
                                                {/*题干*/}
                                                {this.questionContent(index, item, 'fillStemInput')}
                                                <InputNumber className={Style.fillBlock} parser={limitDecimalsP} precision="3" step="0.001" value={item.questionArr.length > 0 ? item.questionArr[0].content : ''} onChange={(value) => {
                                                    let arr = this.state.questionList;
                                                    if (arr[index].questionArr.length <= 0) {
                                                        let obj = {};
                                                        obj.content = '';
                                                        obj.seq = 1;
                                                        obj.isRight = 0;
                                                        obj.edit = true;
                                                        arr[index].questionArr.push(obj);
                                                    }
                                                    arr[index].questionArr[0].content = value ? value.toString() : '';
                                                    this.setState({ questionList: arr });
                                                }}
                                                />
                                                <div>填空题答案必须为整数或浮点数。输入框中填写填空题的正确答案，保留3位有效数字</div>
                                                <Divider dashed={true} className={Style.topicDivider} />
                                            </Fragment> : ''}
                                        {/* 判断 */}
                                        {questionType === 'judeg' ?
                                            <Fragment>
                                                {/*题干*/}
                                                {this.questionContent(index, item, 'judegStemInput')}
                                                {/* 选项 */}
                                                {item.questionArr.map((item1, index1) => {
                                                    return (
                                                        <div key={index1} className={Style.questionArrWrap}>
                                                            <Radio.Group
                                                                style={{ width: '20%' }}
                                                                value={this.state.questionList[index].questionArr[index1].isRight === 1 ? 'T' : this.state.questionList[index].questionArr[index1].isRight === 0 ? 'F' : this.state.questionList[index].questionArr[index1].isRight === 2 ? 'U' : 'F'}
                                                                onChange={(e) => {
                                                                    let arr = this.state.questionList;
                                                                    arr[index].questionArr[index1].isRight = e.target.value === 'T' ? 1 : e.target.value === 'F' ? 0 : e.target.value === 'U' ? 2 : 0;
                                                                    this.setState({ questionList: arr });
                                                                }}
                                                            >
                                                                <Radio.Button checked={item1.isRight === 1} value='T'>T</Radio.Button>
                                                                <Radio.Button checked={item1.isRight === 0} value={'F'}>F</Radio.Button>
                                                                <Radio.Button checked={item1.isRight === 2} value={'U'}>U</Radio.Button>
                                                            </Radio.Group>
                                                            {/* 选项编辑 */}
                                                            {this.itemEdit(item1, index, index1)}
                                                        </div >
                                                    )
                                                })}
                                                {/* 添加选项 */}
                                                {this.addOptionBtn(index)}
                                                <Divider dashed={true} className={Style.topicDivider} />
                                            </Fragment > : ''}
                                        {/* 解答 */}
                                        {questionType === 'anwser' ?
                                            <Fragment>
                                                {/*题干*/}
                                                {this.questionContent(index, item, 'anwserStemInput')}
                                                <Divider dashed={true} className={Style.topicDivider} />
                                            </Fragment> : ''}
                                    </Fragment >
                                )
                            })}
                            <Button type='primary' icon={<PlusOutlined />} className={Style.addBtn} onClick={() => {
                                let arr = this.state.questionList;
                                let obj = {};
                                obj.type = 1;
                                obj.content = '';
                                obj.edit = true;
                                obj.questionArr = [{ edit: true, content: '', isRight: 0, seq: 1 }, { edit: true, content: '', isRight: 0, seq: 2 }];
                                arr.push(obj);
                                this.setState({ questionList: arr });
                            }}>新增题目</Button>
                            <h3 className={Style.title}>解析</h3>
                            <span>各个题目的解析统一都填写在这里</span><br />
                            {
                                this.state.changeAnalyse ? <div className={Style.topicWrap} dangerouslySetInnerHTML={{ __html: this.state.analyseContent }} onClick={() => { this.setState({ inputId: 'analyseInput', changeAnalyse: false }) }}></div> : <Fragment>
                                    <TextArea id='analyseInput' maxLength='100000' onBlur={() => {
                                        if (this.state.blur) {
                                            this.setState({ blur: false });
                                            return false;//插入图片btn控制是否失焦
                                        }
                                        this.setState({ changeAnalyse: true }, () => {
                                            window.MathJax.Hub.Queue(
                                                ["Typeset", window.MathJax.Hub, document.getElementById('root')]
                                            )
                                        });
                                    }} ref={input => {
                                        if (!input) return;
                                        input.focus();　　// 设置焦点
                                    }}
                                        style={{ paddingBottom: '80px' }}
                                        autoSize
                                        // rows={4}
                                        value={this.state.analyseContent} onChange={this.getAnalyseContent} />
                                    {/* 插入图片和换行符的button */}
                                    {this.insertBrImg()}
                                </Fragment>
                            }
                        </div >
                        {this.state.showBulkEditOptionModal ? <Modal title='批量编辑选项' close={this.close} actions={[<Button className={Style.modalSave} type='primary' onClick={() => {
                            let arr = this.state.questionList;
                            let reg = /[A-Z]\.|[A-Z]\)|\([A-Z]\)|[a-z]\.|[a-z]\)|\([a-z]\)/
                            let options = this.state.bulkEditOptionContent.split(reg).slice(1);
                            options = options.map((item2, index2) => {
                                return {
                                    content: item2,
                                    edit: true,
                                    isRight: 0,
                                    seq: index2
                                }
                            })
                            if (this.state.bulkEditIndex === null) return;
                            arr[this.state.bulkEditIndex].questionArr = options;
                            this.setState({ questionArr: arr }, () => {
                                window.MathJax.Hub.Queue(["Typeset", window.MathJax.Hub, document.getElementById('root')]);
                            });
                            this.close();
                        }}>应用</Button>, <Button className={Style.modalSave} type='primary' onClick={this.close}>取消</Button>]}>
                            <div className={Style.bulkEditOptionModal}>
                                <div className={Style.box}>
                                    <span> 批量编辑选项内容：</span>
                                    <TextArea className={Style.input}
                                        autoSize
                                        value={this.state.bulkEditOptionContent} onChange={this.changeBulkEditOptionContent} />
                                </div>
                            </div>
                        </Modal> : ''}
                        <Divider type='vertical' className={Style.divider} />
                        <div className={Style.rightWrap} style={{ display: this.state.showRight ? 'block' : 'none' }}>
                            <h3 className={Style.type}>知识点标签</h3>
                            <div className={Style.tagWrap}>
                                <div className={Style.box}>
                                    <span className={Style.title}>题目学科：</span>
                                    <Select className={Style.select} value={this.state.subjectName} onChange={this.getSubject} optionLabelProp="label" showSearch={true} allowClear={true} disabled>
                                        {this.state.subjectList.map((item, index) => {
                                            return (
                                                <Option key={item.id} value={item.subjectName}>{item.subjectName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                <div className={Style.box}>
                                    <span className={Style.title}>一级知识点：</span>
                                    <Select className={Style.select} value={this.state.firstPointName} onChange={this.getFirstPoint} optionLabelProp="label" showSearch={true} allowClear={true} disabled>
                                        {this.state.firKnowledgeList.map((item, index) => {
                                            return (
                                                <Option key={item.id} value={item.levelFirstName}>{item.levelFirstName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                <div className={Style.box}>
                                    <span className={Style.title}>二级知识点：</span>
                                    <Select className={Style.select} value={this.state.secondPointName} onChange={this.getSecondPoint} optionLabelProp="label" showSearch={true} allowClear={true} disabled>
                                        {this.state.secKnowledgeList.map((item, index) => {
                                            return (
                                                <Option key={item.id} value={item.levelSecondName}>{item.levelSecondName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div>
                                {/* <div className={Style.box}>
                                    <span className={Style.title}>三级知识点：</span>
                                    <Select className={Style.select} value={this.state.secondPointValue} onChange={this.getSecondPoint} optionLabelProp="label" showSearch={true} allowClear={true}>
                                        {this.state.secKnowledgeList.map((item,index)=>{
                                            return (
                                                <Option key={item.id} value={item.levelSecondName}>{item.levelSecondName}</Option>
                                            )
                                        })}
                                    </Select>
                                </div> */}
                            </div>
                            <div className={Style.tagTextWrap}>
                                <h3 className={Style.type}>题源标签</h3>
                                <div className={Style.right}>
                                    <Button type='link' onClick={this.showTag} >题源标签模版</Button>
                                    <Button type='primary' onClick={this.apply}>应用到本题</Button>
                                </div>
                            </div>
                            {/* 题源标签 */}
                            {this.topicSourceLabel('label')}
                            {/* 题源标签模板弹框 */}
                            {this.state.showModalTag ? <Modal title='题源标签模版' close={this.close}>{this.topicSourceLabel('model')}</Modal> : ''}
                        </div>
                    </div >
                </Spin >
            </Fragment >
        )
    }
}

export default AddTopic;