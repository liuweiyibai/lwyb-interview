import React, { Component, Fragment } from 'react';
import moment from "moment";
import { Table, DatePicker, Button, Select, Pagination, Tooltip, message, Divider, Spin } from 'antd';
import { SearchOutlined, LoadingOutlined } from '@ant-design/icons';
import api from '../../../../utils/api';
import Style from './questionBankStatistics.module.less';
const { Option } = Select;

class QuestionBankStatistics extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            tableLoading: false,
            weekDataLoading: false,
            questionBankEditLoading: false,
            // 上周的今天
            weekPickerDefaultValue: moment().subtract(7, "days"),
            weekTotalDatasStartDate: moment().week(moment().week() - 1).startOf('week').format('YYYY-MM-DD'),//所选周起始日期
            weekTotalDatasEndDate: moment().week(moment().week() - 1).endOf('week').format('YYYY-MM-DD'),//所选周结束日期
            questionBankEditStartDate: moment().week(moment().week() - 1).startOf('week').format('YYYY-MM-DD'),//所选周起始日期
            questionBankEditEndDate: moment().week(moment().week() - 1).endOf('week').format('YYYY-MM-DD'),//所选周结束日期
            totalData: [],//题库总体数据
            weekData: [],//周总量数据
            questionBankEditData: [],//题库
            operatorNamelist: [],//操作人列表
            operatorId: '',//操作人ID
            page: 1,//当前页数
            pageSize: 10,//总页数
            total: 0,
        }
    }
    //题库总体数据列表
    questionBankDataColumns = [
        {
            title: '',
            align: 'center',
            dataIndex: 'subject',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: subject => {
                return (
                    <Tooltip placement="top" title={subject ? subject : ''}>
                        {subject ? subject : ''}
                    </Tooltip>
                )
            }
        },
        {
            title: '题目数量',
            align: 'center',
            dataIndex: 'total',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: total => (
                <Tooltip placement="top" title={total} key={total}>
                    {total}
                </Tooltip>
            )
        },
        {
            title: '互动题目',
            align: 'center',
            dataIndex: 'canMock',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: canMock => {
                return (
                    <Tooltip placement="top" title={canMock}>
                        {canMock}
                    </Tooltip>
                )
            }
        },
        {
            title: '拍搜题目',
            align: 'center',
            dataIndex: 'noCanMock',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: noCanMock => {
                return (
                    <Tooltip placement="top" title={noCanMock}>
                        {noCanMock}
                    </Tooltip>
                )
            }
        },
        {
            title: '题源数量-教材',
            align: 'center',
            dataIndex: 'textbook',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: textbook => {
                return (<Tooltip placement="top" title={textbook}>
                    {textbook}
                </Tooltip>
                )
            }
        },
        {
            title: '题源数量-试卷',
            align: 'center',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: (record) => {
                return (
                    <Tooltip placement="top" title={record.p1 + record.p2}>
                        {record.p1 + record.p2}
                    </Tooltip>
                )
            }
        },
    ];
    //题库总体编辑数据列表
    questionBankEditColumns = [
        {
            title: '题库编辑',
            align: 'center',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return record.updatedBy
            }
        },
        {
            title: '新增/编辑题目数量',
            align: 'center',
            width: '150px',
            ellipsis: {
                showTitle: false,
            },
            render: record => {
                return record.total
            }
        },
    ]
    componentDidMount() {
        //获取题库总体数据列表
        this.getTotalDataList();
        //获取操作人列表
        this.getOperatorList();
    }
    componentWillUnmount() {
        this.setState = () => {
            return;
        };
    }

    //查询周增量数据
    searchWeekTotalData = () => {
        this.getweekTotalDataList({ startDate: this.state.weekTotalDatasStartDate, endDate: this.state.weekTotalDatasEndDate })
    }
    //查询题库编辑工作数据
    searchQuestionBankEdit = () => {
        this.getQuestionBankEdit({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, start: this.state.questionBankEditStartDate, end: this.state.questionBankEditEndDate, updatedBy: this.state.operatorId })
    }
    //调用总体数据API
    getTotalDataList = () => {
        this.setState({ tableLoading: true }, () => {
            api.getQuestionBankTotalDataList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ totalData: data.result, tableLoading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ tableLoading: false });
                })
        })
    }
    //调用周增量数据API
    getweekTotalDataList = (params) => {
        this.setState({ weekDataLoading: true }, () => {
            api.getQuestionBankTotalDataList(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ weekData: data.result, weekDataLoading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ weekDataLoading: false });
                })
        })
    }
    //改变周增量数据的统计时间
    changeWeekTotalDataWeek = (date) => {
        if (date) {
            let startDate = moment().week(date.week()).startOf('week').format("YYYY-MM-DD");
            let endDate = moment().week(date.week()).endOf('week').format("YYYY-MM-DD");
            this.setState({ weekTotalDatasStartDate: startDate, weekTotalDatasEndDate: endDate });
        } else {
            this.setState({ weekTotalDatasStartDate: '', weekTotalDatasEndDate: '' });
        }
    }
    //改变总体数据的统计时间
    changeQuestionBankEditWeek = (date) => {
        if (date) {
            let startDate = moment().week(date.week()).startOf('week').format("YYYY-MM-DD");
            let endDate = moment().week(date.week()).endOf('week').format("YYYY-MM-DD");
            this.setState({ questionBankEditStartDate: startDate, questionBankEditEndDate: endDate });
        } else {
            this.setState({ questionBankEditStartDate: '', questionBankEditEndDate: '' });
        }
    }
    //改变操作人
    changeOperator = (value, option) => {
        if (value && option) {
            this.setState({ operatorId: option.key });
        } else {
            this.setState({ operatorId: '' });
        }
    }
    //改变页数
    changePagination = (page, pageSize) => {
        this.setState({ page, pageSize }, () => {
            this.getQuestionBankEdit({ iDisplayStart: this.state.page - 1, iDisplayLength: this.state.pageSize, start: this.state.questionBankEditStartDate, end: this.state.questionBankEditEndDate, updatedBy: this.state.operatorId })
        })
    }
    //获取操作人下拉列表
    getOperatorList = () => {
        this.setState({ loading: true }, () => {
            api.getOperatorList()
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ operatorNamelist: data.result, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ loading: false });
                })
        })
    }
    //获取题库编辑工作数据
    getQuestionBankEdit = (params) => {
        this.setState({ questionBankEditLoading: true }, () => {
            api.getQuestionBankEdit(params)
                .then((data) => {
                    if (data.ret === 20000) {
                        this.setState({ questionBankEditData: data.result.data, page: data.result.start + 1, total: data.result.total, questionBankEditLoading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    message.error(err.msg);
                    this.setState({ questionBankEditLoading: false });
                })
        })
    }
    render() {
        const { weekPickerDefaultValue } = this.state;
        return (
            <Fragment>
                <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <h3 className={Style.title} >题库总体数据</h3>
                    <Table
                        columns={this.questionBankDataColumns}
                        dataSource={this.state.totalData}
                        rowKey={dataSource => dataSource.subId}
                        bordered={true}
                        pagination={false}
                        loading={this.state.tableLoading}
                    />
                    <Divider />
                    <h3 className={Style.title} >周增量数据</h3>
                    <div className={Style.weekData}>
                        <div className={Style.left}>
                            <span className={Style.span}> 统计时间段：</span>
                            <DatePicker
                                className={Style.selectTime}
                                onChange={this.changeWeekTotalDataWeek}
                                picker="week"
                                disabledDate={(date) => {
                                    return date > moment().startOf('week')
                                }}
                                defaultValue={weekPickerDefaultValue}
                            />
                        </div>
                        <Button className={Style.searchButton} icon={<SearchOutlined />} type="primary" onClick={this.searchWeekTotalData}>查询</Button>
                    </div>
                    <Table
                        columns={this.questionBankDataColumns}
                        dataSource={this.state.weekData}
                        rowKey={dataSource => dataSource.subId}
                        bordered={true}
                        pagination={false}
                        loading={this.state.weekDataLoading}
                    />
                    <Divider />
                    <h3 className={Style.title} >题库编辑工作数据统计</h3>
                    <div className={Style.weekData}>
                        <div className={Style.left}>
                            <span className={Style.span}>统计时间段：</span>
                            <DatePicker
                                className={Style.selectTime}
                                onChange={this.changeQuestionBankEditWeek}
                                picker="week"
                                disabledDate={(date) => {
                                    return date > moment().startOf('week')
                                }}
                                defaultValue={weekPickerDefaultValue}
                            />
                            <span className={Style.span}>操作人：</span>
                            <Select placeholder='全部' className={Style.select} onChange={this.changeOperator} optionLabelProp="label" showSearch={true} allowClear={true}>
                                {this.state.operatorNamelist.map((item, index) => {
                                    return (
                                        <Option key={item.userId} value={item.userName}>{item.userName}</Option>
                                    )
                                })}
                            </Select>
                        </div>
                        <Button type="primary" icon={<SearchOutlined />} onClick={this.searchQuestionBankEdit}>查询</Button>
                    </div>
                    <Table
                        columns={this.questionBankEditColumns}
                        dataSource={this.state.questionBankEditData}
                        rowKey={dataSource => dataSource.updatedBy}
                        bordered={true}
                        pagination={false}
                        loading={this.state.questionBankEditLoading}
                    />
                    <Pagination className={Style.pagination} showQuickJumper hideOnSinglePage current={this.state.page} pageSize={this.state.pageSize} total={this.state.total} onChange={this.changePagination} showTotal={total => `Total ${total} items`}></Pagination>
                </Spin>
            </Fragment>
        )
    }
}
export default QuestionBankStatistics;