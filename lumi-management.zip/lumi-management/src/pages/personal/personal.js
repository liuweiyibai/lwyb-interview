import React, { Component } from 'react';
import { connect } from 'react-redux';
import api from '../../utils/api';
import { message, Button, Input, Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import Style from './personal.module.less';
import fun from '../../utils/funSum.js';
import Modal from '../../components/modalOfTree/modalOfTree.js';
import actionCreator from '../../store/actionCeator.js';

@connect(state => state)
class Personal extends Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            userName: '',//获取用户名
            department: [],//获取用户部门
            isTeacher: false,
            showModal: false,//是否显示绑定账号的弹框
            accountNumber: '',
            password: ''
        }
    }
    componentDidMount () {
        this.getUser();
    }
    componentWillUnmount () {
        this.setState = () => {
            return;
        };
    }
    //获取用户信息
    getUser = () => {
        this.setState({ loading: true }, () => {
            api.login()
                .then((data) => {
                    if (data.ret === 20000) {
                        let bool = !data.result.isBindAcademy && Array.isArray(this.props.powerArr) && (this.props.powerArr.includes(23) || this.props.powerArr.includes(22) || this.props.powerArr.includes(16) || this.props.powerArr.includes(15) || this.props.powerArr.includes(19) || this.props.powerArr.includes(6));
                        let isTeacher = actionCreator.saveIsTeacher(bool);
                        this.props.dispatch(isTeacher);
                        this.setState({ userName: data.result.userName, userId: data.result.userId, department: data.result.dept, isTeacher: bool, loading: false });
                    } else {
                        return Promise.reject(data);
                    }
                })
                .catch((err) => {
                    this.setState({ loading: false });
                    message.error(err.msg);
                    let modal = JSON.parse(fun.getItem('modal'));
                    window.localStorage.clear();
                    fun.setItem('modal', modal);
                    this.props.history.replace('/login');
                })
        })
    }
    // getAccountNumber = (e)=>{
    //     this.setState({accountNumber:e.target.value});
    // }
    // getPassword = (e)=>{
    //     this.setState({password:e.target.value});
    // }
    // //绑定账号 确定
    // bind = (params)=>{
    //     this.setState({loading:true},()=>{
    //         api.bindEDUTeacher(params)
    //         .then((res)=>{
    //             if(res.ret === 20000){
    //                 message.success(res.msg);
    //                 let isTeacher = actionCreator.saveIsTeacher(false);
    //                 this.props.dispatch(isTeacher);
    //                 this.setState({loading:false,showModal:false,isTeacher:false});
    //             }else{
    //                 return Promise.reject(res);
    //             }
    //         })
    //         .catch((err)=>{
    //             message.error(err.msg);
    //             this.setState({loading:false});
    //         })
    //     })
    // }
    // close = ()=>{
    //     this.setState({showModal:false});
    // }
    render () {
        let department = this.state.department
        return (
            <Spin spinning={this.state.loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                <div className={Style.wrap}>
                    {/* {this.state.isTeacher ? <Button className={Style.bindBtn} type="primary" danger onClick={()=>{this.setState({showModal:true});}}>绑定易维学院导师账号</Button> : ''} */}
                    <h3 className={Style.title}>日拱一卒，功不唐捐...</h3>
                    <div className={Style.introduction}>首次登录Lumist管理中台，只能访问「个人首页」。请联系你的部门负责人，为你配置权限</div>
                    <div className={Style.user}>
                        姓名：
                        <span className={Style.userName}>
                            {this.state.userName}
                        </span>
                        部门：
                        <div className={Style.department}>
                            {department.map((item, key) => {
                                return (<span key={item}>{item}</span>)
                            })}
                        </div>

                    </div>
                    <img src='https://cdn.lumiclass.com/cms/qm/2020/09/19/7985aab1-ec42-496d-bf31-d77f3ffc480b.png' alt='img' />
                    {this.state.showModal ? <Modal title='绑定易维学院导师' close={this.close} actions={[<Button onClick={this.close}>取消</Button>, <Button type='primary' disabled={this.state.accountNumber === '' || this.state.password === ''} onClick={() => { this.bind({ account: this.state.accountNumber, pwd: this.state.password }); }}>确定</Button>]}>
                        <Input placeholder='请输入账号' className={Style.input} onChange={this.getAccountNumber}></Input>
                        <Input placeholder='请输入密码' type='password' className={Style.input} onChange={this.getPassword}></Input>
                    </Modal> : ''}
                </div>
            </Spin>
        )
    }
}

// export default connect(store => store)(Personal);
export default Personal;