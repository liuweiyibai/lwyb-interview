import React, { Component } from 'react';
import { withRouter } from 'react-router-dom'; //使组件拥有路由对象
import { connect } from 'react-redux';
import { Layout, Menu, Button, Spin, message } from 'antd';
import {
  LoadingOutlined,
  UserOutlined,
  PoweroffOutlined,
  WindowsFilled,
  AppleFilled,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  createFromIconfontCN,
} from '@ant-design/icons';
import fun from '../../utils/funSum.js';
import Style from './admin.module.less';
import api from '../../utils/api';
import actionCreator from '../../store/actionCeator';
import { createWebSocket, closeWebSocket } from '../../utils/websocket';
import changeRouteTitle from '../../utils/title';

const { SubMenu } = Menu;
const { Header, Content, Footer, Sider } = Layout;
const IconFont = createFromIconfontCN({
  scriptUrl: [
    // '//at.alicdn.com/t/font_2364058_un48jizam3p.js'
    // '//at.alicdn.com/t/font_2364058_avpj14man.js'
    '//at.alicdn.com/t/font_2364058_xf86er1d2dl.js',
  ],
});
@connect((state) => state)
class Admin extends Component {
  constructor() {
    super();
    this.cancel = null;
    this.state = {
      menuList: [], //菜单列表
      selectedKeys: fun.getItem('selectedKeys')
        ? fun.getItem('selectedKeys')
        : [], //当前选中的菜单项 key 数组
      openKeys: fun.getItem('openKeys')
        ? JSON.parse(fun.getItem('openKeys'))
        : [], //当前展开的 SubMenu 菜单项 key 数组
      userName: '', //获取用户名
      userId: '', //获取用户id
      collapsed: false,
      inlineMenu: false, //侧边栏是否收起
      loading: false,
      tip: '请稍后...',
    };
  }
  componentDidMount() {
    changeRouteTitle(this); // 改变页面的title
    this.setState({ selectedKeys: this.props.location.pathname });
    //配置admin及其子路由 message 一次最多显示一条
    message.config({ maxCount: 1 });
    // 登录获取用户信息
    let token =
      this.props.location.search !== '' &&
      this.props.location.search.split('?')[1].split('=')[0] === 'token'
        ? this.props.location.search.split('?')[1].split('=')[1]
        : JSON.parse(fun.getItem('token'));
    fun.setItem('token', token);
    this.getUser();
  }
  //获取用户信息
  getUser = () => {
    this.setState({ loading: true, tip: '获取登录信息中，请稍后...' }, () => {
      api
        .login()
        .then((data) => {
          if (data.ret === 20000) {
            if (data.result.userName === '' || !data.result.userId) {
              return Promise.reject(data);
            }
            let level = actionCreator.saveLevel(data.result.level);
            this.props.dispatch(level); //权限等级
            let userid = actionCreator.saveUserId(data.result.userId);
            this.props.dispatch(userid); //用户id
            let powerArr = actionCreator.savePowerArr(data.result.roleIds);
            this.props.dispatch(powerArr); // 权限等级数组列表

            let bool =
              !data.result.isBindAcademy &&
              Array.isArray(this.props.powerArr) &&
              (this.props.powerArr.includes(15) ||
                this.props.powerArr.includes(16) ||
                this.props.powerArr.includes(6));
            let isTeacher = actionCreator.saveIsTeacher(bool);
            this.props.dispatch(isTeacher); //是否是易维导师
            this.setState(
              { userName: data.result.userName, userId: data.result.userId },
              () => {
                api
                  .getMenu()
                  .then((data) => {
                    if (data.ret === 20000) {
                      createWebSocket(api.websocket + this.state.userId);
                      this.setState({ menuList: data.result, loading: false });
                    } else {
                      return Promise.reject(data);
                    }
                  })
                  .catch(() => {
                    this.setState({ loading: false });
                    message.error('认证失败，请重新登录！');
                    let modal = JSON.parse(fun.getItem('modal'));
                    window.localStorage.clear();
                    fun.setItem('modal', modal);
                    this.props.history.replace('/login');
                  });
              }
            );
            fun.setItem('userName', data.result.userName);
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          this.setState({ loading: false });
          message.error(err.msg);
          let modal = JSON.parse(fun.getItem('modal'));
          window.localStorage.clear();
          fun.setItem('modal', modal);
          this.props.history.replace('/login');
        });
    });
  };
  componentWillUnmount() {
    if (this.timer !== null) {
      clearInterval(this.timer);
    }
    closeWebSocket();
    this.setState = () => {
      return;
    };
  }
  jump = (path) => {
    if (this.props.location.pathname === path) return;
    this.props.history.push(path);
  };
  //登出
  logout = () => {
    let modal = JSON.parse(fun.getItem('modal'));
    window.localStorage.clear();
    fun.setItem('modal', modal);
    this.props.history.replace('/login');
  };
  //SubMenu 展开/关闭的回调
  onOpenChange = (openKeys) => {
    fun.setItem('openKeys', openKeys);
    this.setState({ openKeys });
  };
  //点击 MenuItem 调用此函数
  menuClick = (obj) => {
    fun.setItem('selectedKeys', obj.key);
    this.setState({ selectedKeys: obj.key });
  };
  //递归菜单
  showMenu = (list) => {
    return list.map((item) => {
      if (Array.isArray(item.children) && item.children.length > 0) {
        let Icon = '';
        switch (item.icon) {
          case 'ApartmentOutlined':
            Icon = <IconFont type='icontupu'></IconFont>;
            break;
          case 'PlaySquareOutlined':
            Icon = <IconFont type='iconshipin1'></IconFont>;
            break;
          case 'BookOutlined':
            Icon = <IconFont type='icontiku'></IconFont>;
            break;
          case 'UsergroupAddOutlined':
            Icon = <IconFont type='iconzhongtaiyonghuguanli'></IconFont>;
            break;
          case 'HighlightOutlined':
            Icon = <IconFont type='iconrengongjieti'></IconFont>;
            break;
          case 'ReadOutlined':
            Icon = <IconFont type='iconbeikaoke'></IconFont>;
            break;
          case 'BarChartOutlined':
            Icon = <IconFont type='iconyunyingshuju'></IconFont>;
            break;
          case 'ProfileOutlined':
            Icon = <IconFont type='iconyonghuyunying'></IconFont>;
            break;
          case 'ToolOutlined':
            Icon = <IconFont type='iconzhishidian'></IconFont>;
            break;
          case 'PayCircleOutlined':
            Icon = <IconFont type='iconcaiwu'></IconFont>;
            break;
          case 'EZAClassOutlined':
            Icon = <IconFont type='iconketangguanli'></IconFont>;
            break;
          case 'AccountBookOutlined':
            Icon = <IconFont type='iconhuarenyewu'></IconFont>;
            break;
          case 'APCourseManage':
            Icon = <IconFont type='iconlogo'></IconFont>;
            break;
          case 'EZAOperationOutlined':
            Icon = <IconFont type='iconyunyingguanli'></IconFont>;
            break;
          case 'EZALeadsOutlined':
            Icon = <IconFont type='iconxiaoshou'></IconFont>;
            break;
          default:
            break;
        }
        return (
          <SubMenu key={item.key} title={<span>{item.title}</span>} icon={Icon}>
            {this.showMenu(item.children)}
          </SubMenu>
        );
      } else {
        return (
          <Menu.Item
            key={item.key}
            icon={item.icon}
            onClick={this.jump.bind(this, item.key)}
          >
            {item.title}
          </Menu.Item>
        );
      }
    });
  };
  onCollapse = (collapsed) => {
    this.setState({ collapsed });
  };
  inlineMenu = () => {
    this.setState({ inlineMenu: !this.state.inlineMenu });
  };
  //获取教师客户端下载地址
  getDownloadURL = (type) => {
    this.setState({ loading: true, tip: '获取下载链接中，请稍后...' }, () => {
      api
        .getDownloadURL({ type })
        .then((data) => {
          if (data.ret === 20000 && data.result) {
            let a = document.createElement('a');
            a.setAttribute('href', data.result);
            a.setAttribute('target', '_self');
            a.setAttribute('style', 'display:none');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            this.setState({ loading: false });
          } else {
            return Promise.reject(data);
          }
        })
        .catch((err) => {
          message.error(err.msg);
          this.setState({ loading: false });
        });
    });
  };
  render() {
    return (
      <Spin
        spinning={this.state.loading}
        indicator={<LoadingOutlined />}
        tip={this.state.tip}
        size='large'
      >
        <Layout>
          <Sider
            className={Style.sider}
            theme='light'
            collapsible
            collapsed={this.state.inlineMenu}
            trigger={null}
          >
            <div
              className={Style.title1}
              style={{ marginLeft: this.state.inlineMenu ? '10px' : '0px' }}
            >
              {this.state.inlineMenu ? (
                <MenuUnfoldOutlined onClick={this.inlineMenu} />
              ) : (
                <MenuFoldOutlined onClick={this.inlineMenu} />
              )}
              <span style={{ marginLeft: '10px' }}>Lumist管理中台</span>
            </div>
            <Menu
              mode='inline'
              theme='light' //主题颜色 light/dark
              // theme="dark"  //主题颜色 light/dark
              onOpenChange={this.onOpenChange}
              onClick={this.menuClick}
              selectedKeys={this.state.selectedKeys} //当前选中的菜单项 key 数组
              openKeys={this.state.openKeys} //当前展开的 SubMenu 菜单项 key 数组
            >
              <Menu.Item
                key='/admin/personal'
                onClick={this.jump.bind(this, '/admin/personal')}
                icon={<IconFont type='icongeren'></IconFont>}
              >
                个人首页
              </Menu.Item>
              {this.showMenu(this.state.menuList)}
            </Menu>
          </Sider>
          <Layout
            className={Style.layout}
            style={{
              marginLeft: `${this.state.inlineMenu ? '80px' : '200px'}`,
            }}
          >
            <Header className={Style.header}>
              <div className={Style.download}>
                <span>教师客户端下载：</span>
                <Button
                  type='link'
                  icon={<WindowsFilled />}
                  size='large'
                  style={{ marginRight: '10px' }}
                  onClick={() => {
                    this.getDownloadURL(2);
                  }}
                ></Button>
                <Button
                  type='link'
                  icon={<AppleFilled />}
                  size='large'
                  onClick={() => {
                    this.getDownloadURL(1);
                  }}
                ></Button>
              </div>
              {api.title ? <h3>{api.title}</h3> : ''}
              <div className={Style.logout}>
                <div className={Style.userName}>
                  <UserOutlined />
                  &emsp;{JSON.parse(fun.getItem('userName'))}
                </div>
                <div>
                  <Button
                    type='primary'
                    onClick={() => {
                      this.logout('/login');
                    }}
                    icon={<PoweroffOutlined />}
                  >
                    退出
                  </Button>
                </div>
              </div>
            </Header>
            <Content className={Style.contentWrap}>
              <div className={Style.content}>{this.props.children}</div>
            </Content>
            <Footer className={Style.footer}>
              Lumist管理中台 ©2020 Created by EasyGroup
            </Footer>
          </Layout>
        </Layout>
      </Spin>
    );
  }
}

// export default connect(store => store)(withRouter(Admin));
export default withRouter(Admin);
