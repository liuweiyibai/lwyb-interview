const State={
    level:'',
    userid:'',
    powerArr:'',
    courseID:'',
    courseName:'',
    eduLessonInfo:'',
    isTeacher:''
}
export default (oldState=State,newState)=>{
    let newData=JSON.parse(JSON.stringify(oldState))
    let {type,params}=newState
    switch(type){
        case 'LEVEL':
            newData.level=params
            break;
        case 'USERID':
            newData.userid=params
            break;
        case 'POWERARR':
            newData.powerArr=params
            break;
        case 'COURSEID':
            newData.courseID=params
            break;
        case 'COURSENAME':
            newData.courseName=params;
            break;
        case 'ISTEACHER':
            newData.isTeacher=params;
            break;
        default:
            break;
    }
    return newData;
}