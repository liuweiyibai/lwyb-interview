import {createStore,applyMiddleware} from 'redux';
import thunk from 'redux-thunk';//异步中间件
import rootReducer from './reducer';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';// defaults to localStorage for web

const persistConfig = {
    key: 'root',// key是放入localStorage中的key
    storage,// storage is now required // storage简单就可以理解成localStorage的功能封装吧，不过有时候由于版本问题，必要在后一个storage上加一个default属性，可以在console中打出来判断是否需要加
    blacklist: [] // reducer 里不持久化的数据 //不会被存入缓存中，其他会，适用于少部分数据需要实时更新
    // whitelist: [''] // 会存入缓存，其他不会存，适用于大多数数据并不会实时从后台拿数据
}
const persistedReducer = persistReducer(persistConfig, rootReducer)


// export default createStore(rootReducer,applyMiddleware(thunk));
export default (() => {
  let store = createStore(persistedReducer,applyMiddleware(thunk))
  let persistor = persistStore(store)
  return { store, persistor }
})()
// let store = createStore(persistedReducer,applyMiddleware(thunk))
// let persistor = persistStore(store)
// export default {store,persistor}