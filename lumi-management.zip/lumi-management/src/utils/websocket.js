import api from './api';
let websocket, lockReconnect = false;
let createWebSocket = (url, that) => {
    websocket = new WebSocket(url);
    websocket.onopen = function () {
        heartCheck.reset().start();
    }
    websocket.onerror = function () {
        reconnect(url);
    };
    websocket.onclose = function (e) {
    }
    websocket.onmessage = function (event) {
        lockReconnect = true;
        if (that && that.refs.text) {
            that.refs.text.innerHTML += event.data + '<br>';
        } else {
            Notification.requestPermission();//获取通知权限
            if (Notification.permission === "granted" && event.data !== '连接成功' && event.data !== 'HeartBeat') {// denied (用户拒绝了通知的显示), granted (用户允许了通知的显示), 
                let notice = new Notification("工单系统通知", {
                    icon: '',
                    body: event.data,
                    silent: true,//通知是否静音，默认false，表示无声
                    renotify: false,//新通知是否覆盖旧的通知，默认为true，表示永远只显示一条通知；false不覆盖会多条通知叠加
                    requireInteraction: true, // 不自动关闭通知知道用户点击或关闭，默认false
                    sticky: true,//一个 Boolean 指明通知是否应该是“粘”, 即不易被用户清理。默认值为false，这意味着它不会粘。
                });
                notice.onshow = function () {

                }
                notice.onclick = function () {
                    // window.focus();//让浏览器到页面最顶层并且浏览器显示消息页面(前提当前页面没有关闭)
                    window.open(`${api.pageURL}#/admin/v1/artificialSolveProblem/solveProblemOrders`);//正式环境
                    notice.close();
                }
                notice.onerror = function () {
                    notice.close();
                }
                notice.onclose = function () {
                }
            } else if (Notification.permission === "default") {
                // '用户关闭授权 可以再次请求授权');
            } else {
                //'用户拒绝授权 不能显示通知');
            }
        };//获取通知权限
    }
    //event 为服务端传输的消息，在这里可以处理
}
let reconnect = (url) => {
    if (lockReconnect) return;
    //没连接上会一直重连，设置延迟避免请求过多
    setTimeout(function () {
        createWebSocket(url);
        lockReconnect = false;
    }, 60000);
}
let heartCheck = {
    timeout: 60000, //60秒
    timeoutObj: null,
    reset: function () {
        clearInterval(this.timeoutObj);
        return this;
    },
    start: function () {
        this.timeoutObj = setInterval(function () {
            //这里发送一个心跳，后端收到后，返回一个心跳消息，
            //onmessage拿到返回的心跳就说明连接正常
            // websocket.send("HeartBeat");
        }, this.timeout)
    }
}
//关闭连接
let closeWebSocket = () => {
    websocket && websocket.close();
}
export {
    websocket,
    createWebSocket,
    closeWebSocket
};