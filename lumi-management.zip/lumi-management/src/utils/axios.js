import axios from 'axios';
import fun from './funSum.js';
import api from './api';

axios.interceptors.request.use(function (config) {
    if (config.url.includes('https://lumi-class-dev.s3.ap-east-1.amazonaws.com')) return config;
    if (config.url.includes('https://lumi-class-dev.s3.amazonaws.com')) return config;
    //上传aws不加headers 否则报400
    if (config.url.includes('https://ez-lumi-class-cms.s3-accelerate.amazonaws.com')) return config; // 北美加速域名
    if (config.url.includes('https://ez-lumi-class-cms-cn.s3.cn-north-1.amazonaws.com.cn')) return config; // 国内不加速域名
    // config.data.token=fun.getItem('token') //全局获取token，并添加到请求里  添加token属性到config里
    config.headers.authorization = 'Bearer ' + JSON.parse(fun.getItem('token'))//获取登录后的token，添加到headers中
    return config;
}, function (error) {
    return Promise.reject(error);
});

axios.interceptors.response.use(function (response) {
    if (response.data.ret === 40000) {
        window.localStorage.clear();
        window.location.href = api.pageURL;
        return;
    }
    //所有接口都走拦截器
    return response.data;
}, function (error) {
    if (error && error.response) {
        switch (error.response.status) {
            case 400:
                error.msg = '请求参数错误'
                break
            case 401:
                error.msg = 'TOKEN失效，请重新登录';
                let modal = JSON.parse(fun.getItem('modal'));
                window.localStorage.clear();
                fun.setItem('modal', modal);
                window.location.href = `${api.pageURL}/login`;
                // window.close();
                break
            case 403:
                error.msg = '拒绝访问'
                window.location.href = `${api.pageURL}/admin/error`;
                break
            case 404:
                error.msg = `请求地址出错: ${error.response.config.url}`
                break
            case 408:
                error.msg = '请求超时'
                break
            case 500:
                error.msg = '服务器内部错误'
                break
            case 501:
                error.msg = '服务未实现'
                break
            case 502:
                error.msg = '网关错误'
                break
            case 503:
                error.msg = '服务不可用'
                break
            case 504:
                error.msg = '网关超时'
                break
            case 505:
                error.msg = 'HTTP版本不受支持'
                break
            default:
                break
        }
    }
    return Promise.reject(error);
});

const Axios = ((request) => {
    return {
        get(url, params = {}, headers = {}) {
            return request.get(url, { params }, headers)
        },
        post(url, options = {}, headers = {}) {
            return request.post(url, options, headers)
        },
        file(url, options = {}) {
            let formData = new FormData()
            for (let key in options) {
                formData.append(key, options[key])
            }
            return request.post(url, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
        },
        delete(url, data = {}) {
            return request.delete(url, { data })
        },
        put(url, options = {}, headers = {}) {
            return request.put(url, options, headers)
        }
    }
})(axios)

export default Axios;