import React from 'react';
import Loadable from 'react-loadable'; //路由懒加载，异步组件   解决首屏白屏问题（spa单页面应用中，首屏加载所有组件的js文件导致加载时间过长）
import {LoadingOutlined} from '@ant-design/icons';

const loadingComponent=()=>{
    return (
        <div style={{position:'relative',display:'flex',width:'100%',height:'100vh'}}>
            <div style={{margin:'auto',zIndex:'99',textAlign:'center'}}>
                <LoadingOutlined style={{fontSize:'40px',color:'#ff8800'}} />
                <div style={{color:'#ff8800'}}>数据加载中...</div>
            </div>
        </div>
    )
}

//这是一个方法(function)
//第一个参数loader传入异步加载的组件，第二个参数loading是传入的过场组件
export default (loader,loading=loadingComponent)=>{
    return Loadable({
        loader, //需要异步加载的组件
        loading //在等待过程中显示的过场组件
    });
}