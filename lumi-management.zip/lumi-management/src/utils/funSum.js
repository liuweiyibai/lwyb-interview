import React from 'react';
import { Tooltip } from 'antd';
import moment from 'moment';
import piexif from 'piexifjs';
//数字转换会计格式
const outputdollars = (number) => {
  if (number.length <= 3) return number === '' ? '0' : number;
  else {
    let mod = number.length % 3;
    let output = mod === 0 ? '' : number.substring(0, mod);
    for (let i = 0; i < Math.floor(number.length / 3); i++) {
      if (mod === 0 && i === 0)
        output += number.substring(mod + 3 * i, mod + 3 * i + 3);
      else output += ',' + number.substring(mod + 3 * i, mod + 3 * i + 3);
    }
    return output;
  }
};

// 下载文件的方法
function download(data, name) {
  if (!data) return;
  var blob = new Blob([data], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8',
  });
  var url = window.URL.createObjectURL(blob);
  var aLink = document.createElement('a');
  aLink.style.display = 'none';
  aLink.href = url;
  aLink.setAttribute('download', name);
  document.body.appendChild(aLink);
  aLink.click();
  document.body.removeChild(aLink); //下载完成移除元素
  window.URL.revokeObjectURL(url); //释放掉blob对象
}
// 下载Excel文件，数据流转换
function ab2str(u, f) {
  // 尝试将数据流转换成str
  return new Promise((resolve, reject) => {
    var b = new Blob([u]);
    var r = new FileReader();
    r.readAsText(b, 'utf-8');
    r.onload = () => {
      let parse = {};
      try {
        parse = JSON.parse(r.result);
      } catch (e) {
        parse = false;
      }
      resolve(parse);
    };
  });
}
// 监听回车事件
var fun;
function keyboardListener(e) {
  if (window.event) {
    e = window.event;
  }
  if (e.keyCode === 13 || e.charCode === 13) {
    if (!fun) return;
    fun();
  }
}
// 添加监听回车事件
function addKeyboardListener(search) {
  fun = search;
  document.body.addEventListener('keyup', keyboardListener);
}
// 去除监听回车事件
function removeKeyboardListener() {
  document.body.removeEventListener('keyup', keyboardListener);
}
// 替换字符串
function replaceStr(str) {
  if (!str) return;
  let newStr = str.replace(/(\${1,2}.*\${1,2}.*)?\\\\/g, '$1<br />');
  newStr = newStr.replace(/(\\begin.*\\end.*)?\\\\/g, '$1<br />');
  return newStr;
}
function getItem(key) {
  let value = window.localStorage.getItem(key);
  return JSON.parse(JSON.stringify(value));
}
function setItem(key, value) {
  let str = JSON.stringify(value);
  window.localStorage.setItem(key, str);
}
// 获得table里column的一项
function getColumnItem(title, dataIndex, width, titlePosition) {
  return {
    title: title,
    align: 'center',
    width: width,
    ellipsis: {
      showTitle: false,
    },
    render: (record) => {
      return (
        <Tooltip
          placement={titlePosition ? titlePosition : 'top'}
          title={record[dataIndex]}
        >
          {record[dataIndex]}
        </Tooltip>
      );
    },
  };
}
// 获得table里column的时间项
function getColumnTimeItem(title, dataIndex, flag, width) {
  return {
    title: title,
    align: 'center',
    width: width ? width : '188px',
    ellipsis: {
      showTitle: false,
    },
    render: (record) => {
      let plus = flag === 1 ? 28800000 : flag === 2 ? -14400000 : 0;
      let date = record[dataIndex]
        ? moment(new Date(new Date(record[dataIndex]).getTime() + plus)).format(
            'YYYY/MM/DD HH:mm:ss'
          )
        : '';
      return (
        <Tooltip placement='top' title={date}>
          {date}
        </Tooltip>
      );
    },
  };
}
//jpg/jpeg图片file文件删除exif返回新file
function removeExif(file) {
  return new Promise((resolve, reject) => {
    if (
      file.name.split('.').pop() !== 'jpg' &&
      file.name.split('.').pop() !== 'jpeg' &&
      file.name.split('.').pop() !== 'JPG' &&
      file.name.split('.').pop() !== 'JPEG'
    ) {
      resolve(file);
      // console.log('执行了1');
      return;
    }
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function (e) {
      let data = piexif.remove(e.target.result);
      let result = dataToFile(data, file);
      // console.log('执行了2');
      resolve(result);
    };
  });
}
/*
 * 图片base64转file文件
 * data:base64数据流
 * file：文件
 */
function dataToFile(data, file) {
  let arr = data.split(',');
  let mime = arr[0].match(/:(.*?);/)[1]; //image/jpeg
  // let suffix = mime.split('/')[1]; //jpeg
  let bstr = atob(arr[1]); //atob 方法用于解码使用 base-64 编码的字符串
  let n = bstr.length;
  let u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], `${file.name}`, {
    type: mime,
  });
  // console.log(data,arr,mime,suffix,n)
}

/**
 * 防抖动 函数
 * @param fn {Function}   实际要执行的函数
 * @param delay {Number}  延迟时间，也就是阈值，单位是毫秒（ms）
 * @return {Function}     返回一个“去弹跳”了的函数
 */
function debounce(fn, delay) {
  // 定时器，用来 setTimeout
  var timer;
  // 返回一个函数，这个函数会在一个时间区间结束后的 delay 毫秒时执行 fn 函数
  return function () {
    // 保存函数调用时的上下文和参数，传递给 fn
    var context = this;
    var args = arguments;
    // 每次这个返回的函数被调用，就清除定时器，以保证不执行 fn
    clearTimeout(timer);
    // 当返回的函数被最后一次调用后（也就是用户停止了某个连续的操作），
    // 再过 delay 毫秒就执行 fn
    timer = setTimeout(function () {
      fn.apply(context, args);
    }, delay);
  };
}
export default {
  outputdollars,
  download,
  ab2str,
  addKeyboardListener,
  removeKeyboardListener,
  replaceStr,
  getItem,
  setItem,
  getColumnItem,
  getColumnTimeItem,
  removeExif,
  dataToFile,
  debounce
};
