const routeInfo = [
    {
        path: '/admin/personal',
        title: 'Lumist管理中台'
    },
    {
        path: '/admin/v1/userManage/userPower',
        title: '中台用户权限'
    },
    {
        path: '/admin/v1/operationalData/userData',
        title: 'Lumist用户数据'
    },
    {
        path: '/admin/v1/operationalData/serviceData',
        title: 'Lumist业务数据'
    },
    {
        path: '/admin/v1/operationalData/businessData',
        title: 'Lumist商业数据'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/testPrepareConfigure',
        title: '备考课配置'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/courseOutline',
        title: '备考课大纲'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/liveCourse',
        title: '直播课'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/courseMaterials',
        title: '课程资料'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/mockTest',
        title: '模拟考试'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/topicConfigure',
        title: '模考题目配置'
    },
    {
        path: '/admin/v1/testPrepareCourseManage/classStatistics',
        title: '直播课统计'
    },
    {
        path: '/admin/v1/knowledgePointCourseManage/contentConfiguration',
        title: '知识点内容配置'
    },
    {
        path: '/admin/v1/knowledgePointCourseManage/personalizedConfiguration',
        title: '个性化配置'
    },
    {
        path: '/admin/v1/knowledgePointCourseManage/contentConfiguration',
        title: '知识点课程内容'
    },
    {
        path: '/admin/v1/knowledgePointCourseManage/personalizedConfiguration',
        title: '知识点课程个性化'
    },
    {
        path: '/admin/v1/artificialSolveProblem/subjectConfiguration',
        title: '人工解题学科'
    },
    {
        path: '/admin/v1/artificialSolveProblem/expertManage',
        title: '解题专家管理'
    },
    {
        path: '/admin/v1/artificialSolveProblem/expertTimeManage',
        title: '解题专家时间管理'
    },
    {
        path: '/admin/v1/artificialSolveProblem/orderHumanResourceMonitor',
        title: '工作中的解题专家'
    },
    {
        path: '/admin/v1/artificialSolveProblem/solveProblemOrders',
        title: '解题工单'
    },
    {
        path: '/admin/v1/artificialSolveProblem/ordersQualityTest',
        title: '工单质检'
    },
    {
        path: '/admin/v1/artificialSolveProblem/workOrdStatistical',
        title: '工单数据统计'
    },
    {
        path: '/admin/v1/artificialSolveProblem/solveProExpertDataStatistics',
        title: '解题专家数据统计'
    },
    {
        path: '/admin/v1/videoManage/knowledgeVideo',
        title: '知识点视频'
    },
    {
        path: '/admin/v1/videoManage/topicExplanationVideo',
        title: '题目视频'
    },
    {
        path: '/admin/v1/videoManage/delayedCourseVideo',
        title: '录播课视频'
    },
    {
        path: '/admin/v1/videoManage/videoDataStatistics',
        title: '视频数据统计'
    },
    {
        path: '/admin/v1/questionBankManage/topicsList',
        title: '题目列表'
    },
    {
        path: '/admin/v1/questionBankManage/addTopic',
        title: '新增题目'
    },
    // {
    //     path: '/admin/v1/questionBankManage/preview?id=1288110',
    //     title: `题目详情 - 题目ID`
    // },
    {
        path: '/admin/v1/questionBankManage/topicsBulkUpload',
        title: '批量传题'
    },
    {
        path: '/admin/v1/questionBankManage/questionBankStatistics',
        title: '题目数据统计'
    },
    {
        path: '/admin/v1/questionBankManage/supplyChainManage',
        title: '题源管理'
    },
    {
        path: '/admin/v1/userAcontentManage/customerManage',
        title: 'Lumist用户管理'
    },
    {
        path: '/admin/v1/userAcontentManage/advertisingManage',
        title: '拍搜广告'
    },
    {
        path: '/admin/v1/userAcontentManage/courseAdvertising',
        title: '课程广告'
    },
    {
        path: '/admin/v1/userAcontentManage/extensionCode',
        title: '推广码'
    },
    {
        path: '/admin/v1/userAcontentManage/schoolManage',
        title: '学校管理'
    },
    {
        path: '/admin/v1/financeManage/orderManage',
        title: '订单管理'
    },
    {
        path: '/admin/v1/financeManage/coursesInOrder',
        title: '课程订单'
    },
    {
        path: '/admin/v1/knowledgeGraphManage/knowledgeTree',
        title: '知识树'
    },
    {
        path: '/admin/v1/ap-coursemanage/ap-courseconfig',
        title: 'AP课程配置'
    },
    {
        path:'/admin/v1/ap-coursemanage/ap-coursematerials',
        title: 'AP课程资料'
    },
    {
        path:'/admin/v1/ap-coursemanage/ap-coursevideo',
        title: 'AP课程简介视频'
    },
    {
        path:'/admin/v1/EZAOperationMgt/wechat-group',
        title: '微信拉群'
    },
    {
        path:'/admin/v1/EZAOperationMgt/wechat-group-detail',
        title: '微信拉群'
    },
    {
        path:'/admin/v1/ezCollegeCourseManage/courseLive',
        title: '直播课排期'
    },
    {
        path:'/admin/v1/ezCollegeCourseManage/EDUCourseMaterials',
        title: '课程资料'
    },
    {
        path:'/admin/v1/ezCollegeCourseManage/courseMgt',
        title: '课程管理'
    },
    {
        path:'/admin/v1/ezCollegeCourseManage/liveCourseMgt',
        title: '直播课管理'
    },
    {
        path:'/admin/v1/EZAOperationMgt/statistics',
        title: '出勤统计'
    },
    {
        path:'/admin/v1/eza-leads/activity',
        title: '活动管理'
    },
    {
        path:'/admin/v1/eza-leads/customer',
        title: '客户详情'
    },
];

function changeTitle(route) {
    const routepath = route.pathname;
    for (let item of routeInfo) {
        if (routepath === '/admin/v1/questionBankManage/preview') {
            const paramId = route.search && route.search.split('=')[1];
            document.title = (paramId !== null && paramId !== '' && paramId !== undefined) ? `题目详情 - ${paramId}` : '题目详情';
            break;
        } else if (routepath === item.path) {
            document.title = item.title;
            break;
        }
    }
}

export default function (that) {
    let flag = true;
    if (flag) {
        const route = that.props.history.location;
        changeTitle(route);
        flag = false;
    }
    that.props.history.listen(route => {
        changeTitle(route);
    })
}
