import axios from './axios';

let baseURL, pageURL, websocket, loginUrl, title;
const env = process.env.NODE_ENV;
if (env === "production") {
    // 正式
    baseURL = 'https://api.lumiclass.com/admin/api';
    pageURL = 'https://cms.lumiclass.com/#';
    websocket = 'wss://api.lumiclass.com/admin/webSocket/';
    loginUrl = 'https://api.lumiclass.com/admin/login';
    title = 'v1.2.0';
} else if (env === "devProduction") {
    //测试
    baseURL = 'https://dev-api.lumiclass.com/admin/api';
    pageURL = 'https://dev-cms.lumiclass.com/#';
    websocket = 'wss://dev-api.lumiclass.com/admin/webSocket/';
    loginUrl = 'https://dev-api.lumiclass.com/admin/login';
    title = '测试中台 v1.2.0';
} else {
    //本地
    baseURL = '/api';
    pageURL = 'http://localhost:3000/#';
    websocket = 'wss://dev-api.lumiclass.com/admin/webSocket/';
    loginUrl = 'https://dev-api.lumiclass.com/admin/login';
}

// 登录
const login = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/user/name', params, headers)
}

//获取员工相应菜单
const getMenu = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/menu/list', params, headers)
}

//获取教师客户端下载地址
const getDownloadURL = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/file/clientUrl?type=${params.type}`, headers)
}

//-------------知识图谱管理模块
//个性化配置列表
const getPersionailizedConfigList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/graph/customConfig/list', params, headers)
}

//获取学科列表
const getSubjectList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/graph/subject/list', params, headers)
}

//选择学科获取tree数据
const getTreeData = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/graph/query', params, headers)
}

//新增学科
const addSubject = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/graph/save/subject', params, headers)
}

//上传csv文件
const uploadCSV = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/graph/upload', params, headers)
}
//上传csv文件后 校验文件格式并保存到数据库
const saveCSV = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/graph/save', params, headers)
}

//知识树拖拽排序
const knowledgeTreeSort = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/graph/graph/sort', params, headers)
}

//新增节点
const addNode = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/graph/save/level', params, headers)
}

//删除节点
const deleteNode = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/graph/del', params, headers)
}

//编辑节点
const editSubject = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/graph/mod/level', params, headers)
}

//---------------视频管理模块
//---------------知识点视频
//上传视频
const uploadVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/upload', params, headers)
}

//获取aws上传地址
const getAddress = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/video/preSign', params, headers)
}
//上传aws
const uploadAWS = (url, params = {}, headers = {}) => {
    return axios.put(url, params, headers)
}
//上传成功回调通知
const notice = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/save/info', params, headers)
}

//获取知识点视频列表 查询
const getVideoList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/video/knowledge/list', params, headers)
}

//根据学科查询一级知识点
const getFirstKnowledge = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers);
}

//根据一级知识点查询二级知识点
const getSecondKnowledge = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers);
}

//编辑知识点视频
const editKnowledgeVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/knowledge/mod', params, headers)
}

//删除知识点视频
const delKnowledgeVideo = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//-------------题目讲解视频
//获取题目讲解视频列表
const getTopicVideoList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/video/explain/list', params, headers)
}

//获取关联题目信息
const getTopicInfo = (url, params = {}, headers = {}) => {
    return axios.post(baseURL + url, params, headers)
}

//编辑 搜索获取题目信息
const searchTopic = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/video/question/content', params, headers)
}

//题目讲解视频编辑提交
const topicEditSubmit = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/explain/mod', params, headers)
}

//删除题目讲解视频
const delTopicVideo = (url, params = {}, headers = {}) => {
    return axios.post(baseURL + url, params, headers)
}

//-----------知识点课程管理
//----------课程配置
//获取课程配置列表
const getCourseConfigList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/learn/course/list', params, headers)
}

//上传课程图片asw后回调服务端
const uploadCoursePic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/course/cover/mod', params, headers)
}

//删除课程封面
const deleteCoursePic = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//改变课程状态
const changeCourseStatus = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/course/status', params, headers)
}

//新增/编辑课程内容 保存
const saveCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/course/save', params, headers)
}

//----------内容配置
// chapter排序
const chapterSort = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/chapter/sort', params, headers)
}

//lesson排序
const lessonSort = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/unit/sort', params, headers)
}

//获取chapter列表
const getCourseChapterList = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//根据chapter id 获取lesson列表
const getLessonList = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//删除chapter
const deleteChapter = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//编辑/添加chapter
const chapterSE = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/chapter/save', params, headers)
}

//添加/编辑 lesson
const addLesson = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/unit/save', params, headers)
}

//删除lesson
const deleteLesson = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//lesson 添加、替换视频
const configVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/unit/video/union', params, headers)
}

//-----个性化配置
//获取个性化配置列表
const getPersonalizedList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/school/course/list', params, headers)
}

//编辑课号/视频
const editClassnumAVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/learn/school/course/save', params, headers)
}

//获取学科显示状态
const getSubjectStatus = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//更改学科显示状态
const changeStatus = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//获取一级知识点学科信息
const getSubjectInfo = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//删除课后题
const deleteTopic = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//添加课后题
const addAfterClassTopic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/knowledge/exercises/mod', params, headers)
}

// 知识点个性化配置列表
const getPersonaliseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/video/subjectConfig/list', params, headers)
}

// 编辑课程的个性化课号和视频
const editPersonaliseCourseNumOrVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/subjectConfig/save', params, headers)
}

// 图片预签名， 获取AWS地址
const getPicAwsAddress = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/file/preSign', params, headers)
}

// 编辑课程封面
const editCourseCoverImg = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/graph/setSubjectPic', params, headers)
}

//---------录播课视频
//删除录播课视频
const delDelayedCourseVideo = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/video/recordVideo/del/${params.id}`, headers)
}

//---------视频数据统计
//获取视频数据统计列表
const getVideoDataStatistics = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/static', params, headers)
}
//----------------题库管理
//----------------题目列表
//获取操作人下拉列表
const getOperatorList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/userList', params, headers)
}

//获取教材选择下拉列表
const getTeachingMaterialList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/book/title', params, headers)
}

//获取章节下拉列表
const getChapterList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/book/chapter', params, headers)
}

//获取评价体系下拉列表
const getEvaluateList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/evaluation', params, headers)
}
//获取课号下拉列表
const getClassNumberList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/classNumber', params, headers)
}
//获取课号下拉列表
const getTopicSchoolList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/college', params, headers)
}
//获取题源学科下拉列表
const getTopicSourceList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/subject', params, headers)
}

//查询、获取题目列表
const getTopicsList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/label/list', params, headers)
}
// 导出题目列表
const exportTopicList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/question/export', params, headers)
}

//关联知识点
const connectKnowledge = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/label/add', params, headers)
}

//题目上/下线
const topicLineControl = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/set/status', params, headers)
}

//点击题目获取题目关联信息
const getTopicConnect = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//修改题目知识点标签
const changeTopicKnowledgePointTag = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/label/edit', params, headers)
}
// 搜索题干内容
const searchTopicContent = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/es/search/list', params, headers)
}

//修改题源标签
// const changeTopicTag = (params = {}, headers = {}) => {
//     return axios.post(baseURL + '/v1/question/source/edit', params, headers)
// }

//---------------题目详情编辑页
//保存
const saveTopic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/edit', params, headers)
}
//改变是否支持互动
const changeInteraction = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/question/setCanMock/${params.id}/${params.status}`, headers)
}
//插入 上传图片
const uploadPic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/file/up', params, headers)
}

//---------------新增题目页
//保存
const saveAddTopic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/save', params, headers)
}

//----------------题目批量上传
//上传zip文件
const bulkUploadZipFile = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/question/zipUpload', params, headers)
}

//----------------题库数据统计
//获取题库总体数据
const getQuestionBankTotalDataList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/static', params, headers)
}

// //获取操作人消息列表
const getQuestionBankEdit = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/question/operatorStatic', params, headers)
}
//---------------题源供应链管理
//获取题源供应链列表
const getSupplyChainList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/list', params, headers)
}
//获取年级列表
const getGradeList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/qs/grade', params, headers)
}
//获取学科列表
const getSupplyChainSubjectList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/qs/subject', params, headers)
}
//获取评价体系列表
const getSupplyChainEvaluationList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/qs/ec', params, headers)
}
//题源信息导出
const exportSupplyChainList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/export', params, headers)
}
//获取供应链经理列表
const getSupplyChainManageList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/qs/mg', params, headers)
}
//新建题源
const addTopicSource = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/add', params, headers)
}
//编辑题源
const editTopicSource = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/mod', params, headers)
}
//操作日志
const operationLog = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/log', params, headers)
}
//变更题源状态
const changeTopicSourceStatus = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/set/status', params, headers)
}
//处理题源
const processTopicSource = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/supplement', params, headers)
}
//分配题源
const distributeTopicSource = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/qs/assign', params, headers)
}

//---------------用户管理
//---------------用户权限
//获取部门列表
const getUserNameList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/users', params, headers)
}
//获取部门列表
const getDeparmentList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/department', params, headers)
}

//获取用户列表
const getUserList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/user/list', params, headers)
}

//获取当前员工未获得的角色列表
const getLeftPowerList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/role/list', params, headers)
}

//获取当前员工已拥有的角色列表
const getRightPowerList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/role/have', params, headers)
}

//分配角色
const allotRole = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/permission/role/mod', params, headers)
}

//-------------------人工解题工单
//-----------人工解题学科配置
// 获取学科(全部、支持、不支持)
const getSubject = (params = {}) => {
    return axios.get(baseURL + `/v1/graph/get/manualMark/${params.manualMark}`);
}
// 变更人工解题学科状态
const changeSubjectState = (params = {}) => {
    return axios.get(baseURL + `/v1/graph/set/manualMark/${params.id}/${params.status}`);
}

//-----------解题专家管理
//获取解题专家列表
const getExpertlist = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/solver/list', params, headers)
}

//获取解题专家下拉列表
const getExpertNamelist = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/solvers', params, headers)
}

//获取擅长学科下拉列表
const getGoodAtSublist = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/graph/get/manualMark/1', params, headers)
}

//获取解题专家信息
const getExpertInfo = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//修改解题专家岗位状态
const changeWoekStatus = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers)
}

//配置解题专家
const editExpertInfo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/manual/order/solver/save', params, headers)
}

//-----------解题专家时间管理
//获取解题专家工作时间段
const getTimeList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/workTime/info', params, headers)
}

//编辑解题专家工作时间段
const editTimeList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/manual/order/save/workTime', params, headers)
}

// 工单人力资源监控页面
const getOrderHumanReourseMonitorList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/manual/order/solver/workStatus`, params, headers)
}

//-----------解题工单
//获取工单列表
const getSolveOrdersList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/list', params, headers)
}

//aws上传图片获取预签名
const getUploadPicUrl = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/preSign', params, headers)
}

//编辑答案
const editOrderAnswer = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers);
}

//删除答案图片
const deleteAnswerImage = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers);
}

//关闭工单
const closeOrder = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/manual/order/closeManualOrder`, params, headers);
}

//修改学科
const changeSubject = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers);
}

//修改解题专家
const changeExpert = (url, params = {}, headers = {}) => {
    return axios.get(baseURL + url, params, headers);
}

//修改备注
const changeRemark = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/manual/order/editRemark', params, headers);
}

//导出解题工单
const exportOrder = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/manual/order/export?start=${params.start}&end=${params.end}&orderId=${params.orderId}&subId=${params.subId}&solverId=${params.solverId}&orderStatus=${params.orderStatus}&userId=${params.userId}&isPop=${params.isPop}&isRemark=${params.isRemark}&difficultyLevel=${params.difficultyLevel}&commentType=${params.commentType}`, params, headers);
}

//修改热门优质标记工单
const changePopGreatOrder = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/manual/order/mark/pop`, params, headers);
}

//修改工单难度
const changeOrderDifficulty = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/manual/order/set/difficulty/level/${params.id}/${params.level}`, params, headers);
}

//--------------工单质检
//获取质检工单列表
const getordersQualityTest = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/inspection', params, headers)
}

//学术质检操作
const changeLearningStatus = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/manual/order/setCorrect/${params.id}/${params.status}`, headers)
}

//可用性质检操作
const changeUsabilityStatus = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/manual/order/setAvailability/${params.id}/${params.status}`, headers)
}

//---------------工单数据统计
// 获取统计表格的数据
const getOrderStatisticsData = (params = {}) => {
    return axios.get(baseURL + '/v1/manual/order/static', params);
}

//----------------解题专家工单统计
//获取解题专家工单统计列表
const getExpertOrdersList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/manual/order/solver/static', params, headers);
}

//获取需要导出的解题专家工单统计列表
const getExportExpertOrdersList = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/manual/order/solverStatic/export?end=${params.end}&solverId=${params.solverId}&start=${params.start}`, params, headers);
}

//------------------备考课管理
//------------------备考课配置
//获取备考课列表
const getTestPrepareCourseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/courseList', params, headers);
}

//获取学校列表
const getSchoolList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/school', params, headers);
}

//新建、编辑备考课
const editTestPrepareCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/save/course', params, headers)
}

//----------备考课程大纲
//获取备考课程信息
const getCourseInfo = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/get/course/${params.id}`, headers);
}

//获取课程大纲列表
const getCourseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/courseOutline', params, headers);
}

//获取备考课ID以及title列表
const getPrepareCourseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/courseInfo', params, headers);
}

//删除大纲数据
const deleteCourse = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/delOutline/${params.id}`, headers);
}

//修改大纲资源试看属性
const changeCourseIsView = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/outline/tryViewVideo/${params.id}/${params.videoMarker}`, headers);
}

//获取直播课列表
const getLiveCourseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/liveCourseList', params, headers);
}

//获取课程资料列表
const getCourseMaterialsList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/materialList', params, headers);
}

//获取模拟考试列表
const getMockTestList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/mockExamList', params, headers);
}

//加入课程
const joinCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/outline/saveSource', params, headers)
}

//大纲排序
const courseSort = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/outline/sort', params, headers)
}
// 手动开通课程用户
const addUserToCourse = (params = {}, headers = {}) => {
  return axios.post(baseURL + '/v1/preExam/user', params, headers)
}

// 备考课程下的用户
const getUserListForCourse = (params = {}, headers = {}) => {
  return axios.get(baseURL + '/v1/preExam/user/list', params, headers)
}

//--------------直播课
//直播课课件上传
const uploadLiveCourseware = (url, params = {}, headers = {}) => {
    return axios.post(baseURL + url, params, headers);
}

//获取教师列表
const getTeacherList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/preExam/teacher', params, headers);
}

//新增、编辑直播课
const editLiveCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/save/live', params, headers)
}

//删除直播课
const deleteLiveCourse = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/delLiveCourse/${params.id}`, headers);
}

//获取已上传课件列表
const getUploadCoursewareList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/getLiveCourseFile/${params.id}`, headers);
}

//删除课件
const deleteCourseware = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/delUploadFile/${params.id}`, headers);
}

//----------课程资料
//资料上传aws 成功回调 / 编辑课程资料
const courseMaterialsNotice = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/saveMaterial', params, headers);
}

//删除课程资料
const deleteCourseMaterial = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/delMaterial/${params.id}`, headers);
}

//-------------模拟考试
//新建、编辑模拟考试
const editMockTest = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/saveMockExam', params, headers);
}

//复制拟考试
const copyMockTest = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/copyMockExam', params, headers);
}

//删除模拟考试
const deleteMockTest = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/delMockExam/${params.id}`, headers);
}

//---------------题目配置
//获取题目列表
const getTestTopicsList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/examQuestion/${params.id}`, headers);
}

//上传题目成功后保存数据
const saveMockTestTopic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/examQuestion/batchSave', params, headers);
}

//删除题目
const deleteMockTestTopic = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/delExamQuestion/${params.id}`, headers);
}

//编辑、新建题目
const editMockTestTopic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/examQuestion/saveQuestionInfo', params, headers);
}

//题目排序
const sortMockTestTopic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/preExam/examQuestion/sort', params, headers);
}

//---------------直播课统计
//获取直播课统计总计
const getLiveCourseData = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/preExam/liveStatic/${params.time}`, headers);
}

//--------------运营数据模块
//---------用户数据
//获取用户数据
const getUserData = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/data', params, headers);
}

//--------业务数据
//获取业务数据
const getServiceData = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/serviceData', params, headers);
}

//--------商业数据
const getBusinessData = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/businessData', params, headers);
}


//------------------用户和内容运营
//------------------lumist用户管理
//获取lumist用户列表
const getAppUserList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/list', params, headers);
}
//获取版本号信息
const getAppVersionList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/version', params, headers);
}
//批量权益赠送
const bulkGiveRight = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/batch/reward', params, headers);
}
//权益赠送
const giveRight = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/reward', params, headers);
}
//导出用户权益列表
const exporList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/userData/export', params, headers);
}

// 用户群条件保存
const saveUserGroup = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/behavior', params, headers);
}
// 用户群条件列表
const userGroupList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/behavior/get', params, headers);
}
// 用户群条件列表
const delUserGroupConfirm = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/appUser/behavior/del/${params.id}`, params, headers);
}
// 上传推送用户
const uploadPushGoal = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/push/user/data', params, headers);
}
//第二步中跳转目标列表
const getJumpLinkList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/push/jump/config', params, headers);
}
//发送测试推送
const sendTestPush = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/push/test', params, headers);
}
//发送正式推送
const sendPush = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/push/send', params, headers);
}
//------------------拍搜首页广告
//获取广告列表
const getAdvertisingList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/adList', params, headers);
}
//配置广告
const advertisingConfig = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/save/ad', params, headers);
}
//------------------课程首页广告
//获取课程广告列表
const getCourseAdvertisingList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/courseAdList', params, headers);
}
//添加课程广告
const addCourseAdvertising = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/save/CourseRec', params, headers);
}
//删除课程广告
const delCourseAdvertising = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/appUser/del/CourseRec/${params.id}`, headers);
}
//顺序移动课程广告
const moveCourseAdvertising = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/move/ad', params, headers);
}
//------------------推广码
//获取推广码列表
const getExtensionCodeList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/spreadCodeList', params, headers);
}
//获取渠道名称列表
const getChannelNameList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/appUser/channel', params, headers);
}
//获取生成人列表
const getCreatorList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/permission/operationUser', params, headers);
}
//保存推广码
const saveExtensionCode = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/appUser/spreadCode/save', params, headers);
}
//停用
const stopExtensionCode = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/appUser/setSpreadStatus/${params.id}`, headers);
}
//------------------学校管理
//获取学校列表
const getSchoolManageList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/school/list', params, headers);
}
//获取国家下拉列表
const getCountryList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/school/country', params, headers);
}
//批量添加学校
const bulkAddSchool = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/school/batch/add', params, headers);
}
//新增/编辑学校
const addEditSchool = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/school/save', params, headers);
}
//删除学校
const deleteSchool = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/school/del/${params.id}`, headers);
}


//------------------财务管理
//------------------订单管理
//获取订单列表
const getOrderList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/order/list', params, headers);
}
//获取订单列表
const orderExport = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/order/question/export', params, headers);
}
//获取商品名称列表
const getProductNameList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/order/vipProduct/${params.type}`, headers);
}

//------------------ shopify 课程订单
// 获取 shopify 订单列表  时间相关参数均为UTC时间 / ISO格式
const getShopifyOrderList = (params = {}, headers = {}) => {
  return axios.get(baseURL + '/v1/order/shopify/list', params, headers);
}
// 获取 shopify 订单统计
const getShopifyCount = (params = {}, headers = {}) => {
  return axios.get(baseURL + '/v1/order/shopify/count', params, headers);
}
// 获取 shopify 订单详情
const getShopifyOrderDetail = (params = {}, headers = {}) => {
  return axios.get(baseURL + '/v1/order/shopify/detail', params, headers);
}

//-----------------易维学院课程管理
//绑定易维学院导师账号
const bindEDUTeacher = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/bind/account', params, headers);
}
//---------------课程直播
//获取edu直播课列表
const getEduLiveCourseList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/live/course', params, headers);
}

//获取edu课程老师
const getEDUTeacherList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/teacher/list', params, headers);
}

//---------------课程资料
//获取课程所有信息
const getEduCourseInfo = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/course/list', params, headers);
}

//查询课程信息
const getEduLessonInfo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/course/detail', params, headers);
}

//添加课程封面、关键字
const addKeyword = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/course/cover', params, headers);
}

//------------资料详情

//删除物料
const deleteEDULessonMaterial = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/materials/del/${params.id}`, headers);
}

//上传pdf文件到后端添加水印
const uploadPFDToAddWatermark = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/pdf/watermark', params, headers);
}

//上传物料 回调
const uploadEDUFile = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/upload/file', params, headers);
}
//物料为视频时 回调
const uploadEDUVideoFile = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/video/material/save', params, headers)
}

//物料排序
const sortEDULessonMaterials = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/materials/sort', params, headers);
}
// 更新次数
const updateMaterialViewCount = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/save/viewCount', params, headers);
}
// 获取回放详情
const getReplayInfo = (params = {}) => {
    return axios.get(baseURL + '/v1/ea/materials/replay', params);
}
// 获取物料详情
const getMaterialInfo = (id) => {
    return axios.get(baseURL + `/v1/ea/materials/${id}`);
}
// 生成视频分享
const createVideoShare = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/share/genShare', params, headers);
}

//------------课程管理 CA
// 获取课程分配列表 - 符合条件的所有数据
const getEZA_CA_CourseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/courses/assignments', params, headers);
}
// 获取课程分配列表的数量 - 符合条件的所有数据的数量 Total
const getEZA_CA_CourseListTotalCount = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/courses/assignments/count', params, headers);
}
// 获取学校下边的相关配置 - 学期
const getEZA_CampusOptions = (campusId, params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/campuses/${campusId}/options`, params, headers);
}
// 获取学校下面的课程列表 - 下拉框 只返回名字
const getEZA_CA_CourseNameList = (campusId, params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/campuses/${campusId}/courses`, params, headers);
}
// 获取课程分配详情 - 单条数据详情
const getEZA_CA_CourseDetail = (caId, params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/courses/assignments/${caId}`, params, headers);
}
// 批量修改课程分配状态 - 激活状态修改
const updateEZA_CA_CourseActiveStatus = (params = {}, headers = {}) => {
    return axios.put(baseURL + `/v1/ea/courses/assignments/status`, params, headers);
}
// 获取当前学校下的老师
const getEZA_SchoolTeachers = (campusId, params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/campus/mentor/list/${campusId}`, params, headers);
}
// 创建课程分配 CA
const createEZA_CA_Course = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/courses/assignments`, params, headers);
}
// 修改课程分配 CA
const updateEZA_CA_Course = (caId, params = {}, headers = {}) => {
    return axios.put(baseURL + `/v1/ea/courses/assignments/${caId}`, params, headers);
}
//------------直播课管理 CAS
// 获取符合条件的直播课数据
const getEZA_CAS_CourseList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/courses/schedules', params, headers);
}
// 获取CAS列表的数量 Total
const getEZA_CAS_CourseListTotalCount = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/courses/schedules/count', params, headers);
}
// 添加排课 创建CAS
const createEZA_CAS_Course = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/courses/schedules`, params, headers);
}
// 删除CAS
const deleteEZA_CAS_Course = (params = {}, headers = {}) => {
    return axios.put(baseURL + `/v1/ea/courses/schedules`, params, headers);
}
// 修改CAS
const updateEZA_CAS_Course = (id, params = {}, headers = {}) => {
    return axios.put(baseURL + `/v1/ea/courses/schedules/${id}`, params, headers);
}


//------------课程数据统计
// 获取当前用户下边的校区名称列表
const getEduCampus = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/campus/list', params, headers);
}
// 获取当前校区下的导师列表
const getEduCampusMentors = (params = {}, headers = {}, campusId) => {
    return axios.get(baseURL + `/v1/ea/campus/mentor/list/${campusId}`, params, headers);
}
// 查询某校区下的课程列表
const getEduStatisticCourseList = (params = {}, headers = {}, campusId) => {
    return axios.get(baseURL + `/v1/ea/campus/course/list/${campusId}`, params, headers);
}
// 获取某校区某课程分配下的课程排期列表(week)
const getEduStatisticWeekList = (params = {}, headers = {}, courseAssignmentId) => {
    return axios.get(baseURL + `/v1/ea/course/schedule/list/${courseAssignmentId}`, params, headers);
}
// 查询EZ学生课程数据统计列表信息
const getEduStatisticCourseInfo = (params = {}, headers = {}, courseAssignmentId) => {
    return axios.get(baseURL + `/v1/ea/course/statistics/list/${courseAssignmentId}`, params, headers);
}
// 更新课程数据统计信息
const updateEduStatisticCourseInfo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/save/course/statistics', params, headers);
}
// -----------微信拉群
// 获取一级页面表格数据 - 订单详情
const getOrdersListDetail_EZA_Wechat = (caId, params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/operation/assignment/${caId}/orders`, params, headers);
}
// 获取课程分配统计 - 订单列表 - 一级页面表格数据
const getOrdersList_EZA_Wechat = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/ea/operation/group/statistics', params, headers);
}
// 详情表格页 - 订单状态数量统计
const getOrdersCount_EZA_Wechat = (caId, params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/operation/group/assignment/${caId}/order/count`, params, headers);
}
// 修改微信号
const updateWechat_EZA_Wechat = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/operation/save/group/wechat`, params, headers);
}
// 修改微信状态
const updateWechatStatus_EZA_Wechat = (orderId, statusId, params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/operation/order/${orderId}/wechat_status/${statusId}`, params, headers);
}
// 修改评论
const updateComment_EZA_Wechat = (orderId, params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/operation/order/${orderId}/comment`, params, headers);
}

// -----------微信解绑
// 获取解绑数据 - 搜索结果
const getWechatUnbindData_EZA_Wechat = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/operation/wechat/bindlogs', params, headers);
}
// 解绑微信绑定
const unBindWechat_EZA_Wechat = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/ea/operation/wechat/unBind', params, headers);
}


//------------------华人收付款订单
//------------------收款和订单
// 获取订单列表
const getChineseReceiveList = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/cis/order/list`, params, headers);
}
// 创建订单
const createChineseReceiveOrder = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/cis/save/order`, params, headers);
}
// 编辑订单
const editChineseReceiveOrder = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/cis/mod/order`, params, headers);
}
// 获取商品类型列表
const getChineseProductTypeList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/cis/product/list`, params, headers);
}
// 添加商品类型
const createChineseProductType = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/cis/save/product/type`, params, headers);
}
// 删除商品类型
const deleteChineseProductType = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/cis/ptype/del/${params.id}`, params, headers);
}
// 订单总金额
const sumChineseReceiveOrderPrice = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/cis/order/static', params, headers);
}
// 导出订单列表
const exportChineseReceiveOrder = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/cis/order/export', params, headers);
}
// 将网络图片转换为流
const changeInternetPic = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/cis/qrcode/stream', params, headers);
}

//------------------ap课程管理
//------------------ap课程配置
//获取课程列表
const getAPCourseList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/course/list', params, headers);
}
// 获取AP学科
const getAPSubjectList = (params = {}, headers = {}) => {
    return axios.get(baseURL + '/v1/lecture/subject/list', params, headers);
}
//保存课程配置信息
const saveCourseInfo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/save/info', params, headers);
}
// 获取课程简介视频
const getCourseIntroductVideoList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/video/des/list', params, headers);
}

//------------------课程资源配置
// 获取课程资源
const getCourseResourcesList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/contents/list', params, headers);
}
// 获取添加资源 课程资料
const searchAPCourseResourcesList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/material/list', params, headers);
}
// 获取添加资源 录播视频
const searchAPRecordResourcesList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/video/record/list', params, headers);
}
// 加入课程
const joinAPCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/contents/save', params, headers);
}
// 删除课程资源
const deleteCourseResources = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/contents/del/${params.id}`, params, headers);
}

//------------------直播课管理
// 获取直播课主题列表
const getAPLiveCourseList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/live/topic/list', params, headers);
}
// 新建直播课主题
const saveLiveCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/live/topic/save', params, headers);
}
// 删除直播课主题
const deleteAPLiveCourse = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/del/live/topic/${params.id}`, params, headers);
}

//------------------排课
// 获取直播课排课列表
const getAPLiveCourseLayoutList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/live/course/list', params, headers);
}
// 新建直播课
const saveLiveCourseLayout = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/live/course/save', params, headers);
}
// 删除直播课
const deleteAPLiveCourseLayout = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/del/live/course/${params.id}`, params, headers);
}

//------------------班级管理
// 获取班级列表
const getClassList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/session/list', params, headers);
}
// 获取直播课主题 下拉
const getLiveCourseSelect = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/live/topic/info/${params.id}`, null, headers);
}
// 获取直播课开始时间 下拉
const getLiveCourseBeginTimeSelect = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/live/time/${params.id}`, null, headers);
}
// 保存班级
const saveAPClass = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/session/save', params, headers);
}
// 关联直播课 加入班级
const linkAPLiveCourse = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/union/live', params, headers);
}
// 解除关联直播课
const relieveAPLiveCourse = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/live/untie/${params.courseId}/${params.classId}`, null, headers);
}

//------------------课程资料
// 获取课程资料列表
const getAPCourseMaterialsList = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/material/list', params, headers);
}
// 上传课程资料 回调 / 编辑
const saveAPCourseMaterial = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/material/save', params, headers);
}
// 删除课程资料
const deleteAPCourseMaterial = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/material/del/${params.id}`, null, headers);
}

//------------------课程简介视频
// 获取课程简介视频列表
// const getAPCourseIntroduceVideoList = (params = {}, headers = {}) => {
//     return axios.post(baseURL + '/v1/lecture/video/des/list', params, headers);
// }
// 上传视频简介 回调
const saveAPCourseIntroduceVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/video/des/save', params, headers);
}
// 删除视频简介
const deleteAPCourseIntroduceVideo = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/del/video/des/${params.id}`, null, headers);
}

//------------------录播视频
// 删除 ap 录播视频
const delAPDelayedVideo = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/lecture/video/record/del/${params.id}`, headers);
}
// 编辑 ap 录播视频
const editAPVideo = (params = {}, headers = {}) => {
    return axios.post(baseURL + '/v1/lecture/video/record/mod', params, headers);
}


// ------------------------- Leads 管理
// ------------------ 活动管理
// 查询未关联微信群
const getAvailableWechatGroup = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/leads/activity/availableWeChatGroups/list`, params, headers);
}
// 查看活动列表
const getActivityList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/leads/activity/list`, params, headers);
}
// 编辑新建活动
const editActivity = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/leads/activity/save`, params, headers);
}
// 获取参与活动所有标签
const getActivityTagList = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/leads/activity/tagExport/list`, params, headers);
}

// ------------------ 客户详情
// 获取客户详情列表
const getCustomerList_Leads = (params = {}, headers = {}) => {
    return axios.post(baseURL + `/v1/ea/leads/customer/list`, params, headers);
}
// 获取跟进销售人员
const getSalesMan_Leads = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/leads/customer/sale/user`, params, headers);
}
// 获取所有微信群名称
const getAllWechatGroups_Leads = (params = {}, headers = {}) => {
    return axios.get(baseURL + `/v1/ea/leads/customer/wechat/group`, params, headers);
}


export default {
    pageURL,
    websocket,
    loginUrl,
    title,
    login,
    getMenu,
    getDownloadURL,
    getPersionailizedConfigList,
    getSubjectList,
    getTreeData,
    addSubject,
    uploadCSV,
    saveCSV,
    knowledgeTreeSort,
    addNode,
    deleteNode,
    editSubject,
    uploadVideo,
    getAddress,
    uploadAWS,
    notice,
    getVideoList,
    getFirstKnowledge,
    getSecondKnowledge,
    editKnowledgeVideo,
    delKnowledgeVideo,
    getTopicVideoList,
    getTopicInfo,
    searchTopic,
    topicEditSubmit,
    delTopicVideo,
    getCourseConfigList,
    uploadCoursePic,
    deleteCoursePic,
    changeCourseStatus,
    saveCourse,
    chapterSort,
    lessonSort,
    getCourseChapterList,
    getLessonList,
    deleteChapter,
    chapterSE,
    addLesson,
    deleteLesson,
    configVideo,
    getPersonalizedList,
    editClassnumAVideo,
    getSubjectStatus,
    changeStatus,
    getSubjectInfo,
    deleteTopic,
    addAfterClassTopic,
    getOperatorList,
    getTeachingMaterialList,
    getChapterList,
    getEvaluateList,
    getClassNumberList,
    getTopicSchoolList,
    getTopicSourceList,
    getTopicsList,
    connectKnowledge,
    topicLineControl,
    getTopicConnect,
    changeTopicKnowledgePointTag,
    searchTopicContent,
    // changeTopicTag,
    saveTopic,
    changeInteraction,
    uploadPic,
    saveAddTopic,
    bulkUploadZipFile,
    getQuestionBankTotalDataList,
    getQuestionBankEdit,
    getSupplyChainList,
    getGradeList,
    getSupplyChainSubjectList,
    getSupplyChainEvaluationList,
    exportSupplyChainList,
    getSupplyChainManageList,
    addTopicSource,
    editTopicSource,
    distributeTopicSource,
    operationLog,
    changeTopicSourceStatus,
    processTopicSource,
    getUserNameList,
    getDeparmentList,
    getUserList,
    getLeftPowerList,
    getRightPowerList,
    allotRole,
    getExpertlist,
    getExpertNamelist,
    getGoodAtSublist,
    getExpertInfo,
    changeWoekStatus,
    editExpertInfo,
    getTimeList,
    editTimeList,
    getOrderHumanReourseMonitorList,
    getSolveOrdersList,
    getUploadPicUrl,
    editOrderAnswer,
    deleteAnswerImage,
    closeOrder,
    changeSubject,
    changeExpert,
    changeRemark,
    exportOrder,
    changePopGreatOrder,
    changeOrderDifficulty,
    getordersQualityTest,
    getSubject,
    changeSubjectState,
    getOrderStatisticsData,
    changeLearningStatus,
    changeUsabilityStatus,
    getExpertOrdersList,
    getExportExpertOrdersList,
    getTestPrepareCourseList,
    getSchoolList,
    editTestPrepareCourse,
    getCourseInfo,
    getCourseList,
    getPrepareCourseList,
    deleteCourse,
    changeCourseIsView,
    getLiveCourseList,
    getCourseMaterialsList,
    getMockTestList,
    joinCourse,
    courseSort,
    addUserToCourse,
    getUserListForCourse,
    uploadLiveCourseware,
    getTeacherList,
    editLiveCourse,
    deleteLiveCourse,
    getUploadCoursewareList,
    deleteCourseware,
    courseMaterialsNotice,
    deleteCourseMaterial,
    getPersonaliseList,
    getPicAwsAddress,
    editCourseCoverImg,
    delDelayedCourseVideo,
    getVideoDataStatistics,
    editPersonaliseCourseNumOrVideo,
    exportTopicList,
    editMockTest,
    copyMockTest,
    deleteMockTest,
    getTestTopicsList,
    saveMockTestTopic,
    deleteMockTestTopic,
    editMockTestTopic,
    sortMockTestTopic,
    getLiveCourseData,
    getUserData,
    getServiceData,
    getBusinessData,
    getAppUserList,
    getAppVersionList,
    bulkGiveRight,
    giveRight,
    exporList,
    saveUserGroup,
    userGroupList,
    delUserGroupConfirm,
    uploadPushGoal,
    getJumpLinkList,
    sendTestPush,
    sendPush,
    getAdvertisingList,
    advertisingConfig,
    getCourseAdvertisingList,
    addCourseAdvertising,
    delCourseAdvertising,
    moveCourseAdvertising,
    getExtensionCodeList,
    getChannelNameList,
    getCreatorList,
    saveExtensionCode,
    stopExtensionCode,
    getSchoolManageList,
    getCountryList,
    bulkAddSchool,
    addEditSchool,
    deleteSchool,
    getOrderList,
    orderExport,
    getProductNameList,
    getShopifyOrderList,
    getShopifyCount,
    getShopifyOrderDetail,
    bindEDUTeacher,
    getEduLiveCourseList,
    getEDUTeacherList,
    getEduCourseInfo,
    getEduLessonInfo,
    addKeyword,
    deleteEDULessonMaterial,
    uploadPFDToAddWatermark,
    uploadEDUFile,
    uploadEDUVideoFile,
    sortEDULessonMaterials,
    getChineseReceiveList,
    createChineseReceiveOrder,
    editChineseReceiveOrder,
    getChineseProductTypeList,
    createChineseProductType,
    deleteChineseProductType,
    sumChineseReceiveOrderPrice,
    exportChineseReceiveOrder,
    getEduCampus,
    getEduStatisticCourseList,
    getEduStatisticCourseInfo,
    updateEduStatisticCourseInfo,
    getEduStatisticWeekList,
    getEduCampusMentors,
    changeInternetPic,
    getAPCourseList,
    getAPSubjectList,
    saveCourseInfo,
    getCourseIntroductVideoList,
    getCourseResourcesList,
    searchAPRecordResourcesList,
    joinAPCourse,
    deleteCourseResources,
    searchAPCourseResourcesList,
    getAPLiveCourseList,
    saveLiveCourse,
    deleteAPLiveCourse,
    getAPLiveCourseLayoutList,
    saveLiveCourseLayout,
    deleteAPLiveCourseLayout,
    getClassList,
    getLiveCourseSelect,
    getLiveCourseBeginTimeSelect,
    saveAPClass,
    linkAPLiveCourse,
    relieveAPLiveCourse,
    getAPCourseMaterialsList,
    saveAPCourseMaterial,
    deleteAPCourseMaterial,
    // getAPCourseIntroduceVideoList,
    saveAPCourseIntroduceVideo,
    deleteAPCourseIntroduceVideo,
    updateMaterialViewCount,
    getEZA_CA_CourseList,
    getEZA_CampusOptions,
    getEZA_CA_CourseDetail,
    getEZA_CA_CourseNameList,
    getEZA_CA_CourseListTotalCount,
    updateEZA_CA_CourseActiveStatus,
    getEZA_SchoolTeachers,
    createEZA_CA_Course,
    updateEZA_CA_Course,
    getEZA_CAS_CourseList,
    getEZA_CAS_CourseListTotalCount,
    createEZA_CAS_Course,
    deleteEZA_CAS_Course,
    updateEZA_CAS_Course,
    getReplayInfo,
    getMaterialInfo,
    delAPDelayedVideo,
    editAPVideo,
    getAvailableWechatGroup,
    getActivityList,
    editActivity,
    getActivityTagList,
    getCustomerList_Leads,
    getSalesMan_Leads,
    getAllWechatGroups_Leads,
    getOrdersList_EZA_Wechat,
    getOrdersListDetail_EZA_Wechat,
    getOrdersCount_EZA_Wechat,
    updateWechat_EZA_Wechat,
    updateWechatStatus_EZA_Wechat,
    updateComment_EZA_Wechat,
    createVideoShare,
    getWechatUnbindData_EZA_Wechat,
    unBindWechat_EZA_Wechat,
}
