//项目入口文件
import React from 'react';
import ReactDOM from 'react-dom';
// import App from './App';
import App from './route';

import store from './store/store';
import { Provider } from 'react-redux';

//antd全局汉化
import zhCN from 'antd/es/locale/zh_CN';
import { ConfigProvider } from 'antd';
import 'moment/locale/zh-cn';

import axios from './utils/axios.js';

//redux-persist redux持久化
// import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/es/integration/react';// PersistGate将延迟应用程序UI的呈现，直到检索到您的持久状态并将其保存到Redux
//redux-persist redux持久化

import { LoadingOutlined } from '@ant-design/icons';

import * as serviceWorker from './serviceWorker';//渐进式网络应用（PWA） 离线网页缓存
// const persistor=persistStore(store);
// <React.StrictMode></React.StrictMode>//eslint严格模式
// console.log(store,store.persistor);
React.Component.prototype.$axios = axios;//在react原型下挂载$axios方法，使所有组件可以通过this.$axios使用axios
// console.log(process.env)
ReactDOM.render(
    <Provider store={store.store}>
        <PersistGate loading={<LoadingOutlined />} persistor={store.persistor}>
            <ConfigProvider locale={zhCN}>
                <App />
            </ConfigProvider>
        </PersistGate>
    </Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
