import React from 'react';
import {Result,Button} from 'antd';

const Notfound=(props)=>{
    return (
        <Result
            status="404"
            title="404"
            subTitle="程序员去答题了"
            extra={<Button type="primary" onClick={()=>{props.history.push('/login')}}>重新登录</Button>}
        />
    )
}

export default Notfound;