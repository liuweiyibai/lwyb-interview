import React, { useState, useEffect } from 'react';
import Style from './modalOfTree.module.less';
import { Card, Button, Divider } from 'antd';
import { CloseOutlined } from '@ant-design/icons';

const ModalOfTree = (props) => {
    const [inputVal, setInputVal] = useState('')
    let close = () => {
        props.close()
    }
    let actions = props.actions || []
    useEffect(() => {
        setInputVal(inputVal)
    }, [inputVal])
    return (
        <div className={Style.modalWrap}>
            <Card title={props.title} className={Style.card} extra={<Button icon={<CloseOutlined />} disabled={props.loading} onClick={close}></Button>}>
                {props.children}
                {actions.length > 0 ? <Divider className={Style.divider} /> : ''}
                <div className={Style.wrap}>
                    {actions.map((item, index) => {
                        return <span key={index}>{item}</span>;
                    })}
                </div>
            </Card>
        </div>
    )
}

export default ModalOfTree