import React from 'react';
import { Modal, Form, Table, Input, Button, Tooltip, message } from 'antd';
import api from '../../utils/api';
import funSum from '../../utils/funSum';
import Style from './userSelect.module.less';
const TextArea = Input.TextArea;
const emailPattern =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export default class UserSelect extends React.Component {
  columns = [
    funSum.getColumnItem('ID', 'id', '80px'),
    funSum.getColumnItem('邮箱', 'email', '160px'),
    funSum.getColumnItem('手机号', 'phoneNumber'),
    funSum.getColumnItem('昵称', 'nickname'),
    funSum.getColumnTimeItem('注册时间', 'createdAt', 1, 'auto'),
    {
      title: '会员状态',
      dataIndex: 'vipStatus',
      align: 'center',
      ellipsis: {
        showTitle: false,
      },
      render: (vipStatus) => {
        const label = vipStatus === 1 ? '已开通' : '未开通';
        return (
          <Tooltip placement='top' title={label}>
            {label}
          </Tooltip>
        );
      },
    },
  ];
  emailRules = [
    { required: true, message: '请输入您要查询的用户邮箱!' },
    {
      validator(rule, value) {
        const emails = value.split('\n');
        const index = emails.findIndex(
          (item) => item && !emailPattern.test(item)
        );
        if (index !== -1) {
          return Promise.reject(
            new Error(`第${index + 1}行数据${emails[index]}不是正确的邮箱!`)
          );
        }
        return Promise.resolve();
      },
    },
  ];
  formRef = React.createRef();
  constructor() {
    super();
    this.state = {
      columns: this.columns,
      loading: false,
      query: {
        email: '',
      },
      form: null,
      dataSource: [],
      selectedRowKeys: [],
      selectedRows: [],
    };
  }
  search() {
    this.setState(
      {
        loading: true,
      },
      () => {
        const { email } = this.state.query;
        let query = {};
        if (this.props.isMultiple) {
          query = { emails: email.split('\n').filter((item) => !!item) };
        } else {
          query = { email };
        }
        api.getAppUserList(query).then((res) => {
          const { data } = res.result;
          this.setState({
            dataSource: data,
            loading: false,
          });
        });
      }
    );
  }
  onFinish = (values) => {
    const { query } = this.state;
    query.email = values.email;
    this.setState({ query }, this.search);
  };
  resetValue = () => {
    this.formRef.current.resetFields();
    this.setState({
      selectedRowKeys: [],
      selectedRows: [],
      dataSource: [],
    });
  };

  onEnterSelected() {
    const { selectedRowKeys, selectedRows } = this.state;
    if (selectedRowKeys.length <= 0) {
      message.warning('请先选择用户!');
      return false;
    }
    this.props.onOk && this.props.onOk(selectedRowKeys, selectedRows);
  }
  render() {
    const { visible, isMultiple } = this.props;
    const { columns, loading, dataSource, from, selectedRowKeys } = this.state;
    return (
      <Modal
        width='50%'
        title='选择用户'
        visible={visible}
        afterClose={this.resetValue}
        onOk={(event) => this.onEnterSelected(event)}
        onCancel={(event) => {
          this.props.onCancel && this.props.onCancel(event);
        }}
      >
        <Form
          ref={this.formRef}
          form={from}
          layout='inline'
          onFinish={this.onFinish}
        >
          <Form.Item label='邮箱' name='email' rules={this.emailRules}>
            {isMultiple ? (
              <TextArea allowClear placeholder='请输入邮箱地址,以换行分割' />
            ) : (
              <Input
                allowClear
                placeholder='请输入邮箱地址'
                onPressEnter={() => this.search()}
              />
            )}
          </Form.Item>
          <Form.Item>
            <Button type='primary' htmlType='submit'>
              搜索
            </Button>
          </Form.Item>
        </Form>
        <Table
          pagination={false}
          className={Style.table}
          rowSelection={{
            type: isMultiple ? 'checkbox' : 'radio',
            selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({ selectedRowKeys, selectedRows });
            },
          }}
          onRow={(record) => ({
            onClick: (event) => {
              const { selectedRowKeys, selectedRows } = this.state;
              let keys = [...selectedRowKeys];
              let values = [...selectedRows];
              if (selectedRowKeys.includes(record.id)) {
                keys.splice(keys.indexOf(record.id), 1);
                values.splice(values.indexOf(record), 1);
              } else {
                keys.push(record.id);
                values.push(record);
              }
              this.setState({ selectedRowKeys: keys, selectedRows: values });
            },
          })}
          rowKey={(record) => record.id}
          loading={loading}
          columns={columns}
          dataSource={dataSource}
        />
      </Modal>
    );
  }
}
