import React, { useContext, useEffect } from 'react';
import { ColorContext } from './sum'
function Text() {
    let { value, dispatch } = useContext(ColorContext);
    useEffect(() => {
        dispatch({ type: 'initial', value: {topicName:''} })
    }, [])
    
    return (
        <div >
            <input value={value.topicName} onChange={(e) => {
                dispatch({ type: 'changeInput', value: e.target.value, name: 'topicName' })
            }}></input>
            {value.topicName}
        </div>
    )
}
export default Text;