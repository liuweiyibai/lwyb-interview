import React, { useContext } from 'react';
import { ColorContext } from './sum'
function Button() {
    let { dispatch,value } = useContext(ColorContext);
    return (
        <div>
            {value.topicName}{'button'}
            {/* <button onClick={() => { dispatch({ type: 'changeColor', value: 'red' }) }}>{value.topicName}</button>
            <button onClick={() => { dispatch({ type: 'changeColor', value: 'green' }) }}>green</button> */}
        </div>
    )
}
export default Button;