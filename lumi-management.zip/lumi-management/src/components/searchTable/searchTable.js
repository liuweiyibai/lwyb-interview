import React, { Fragment, useState, useEffect } from 'react';
import { Input, Table, message, Spin } from 'antd';
import api from '../../utils/api.js';
import { LoadingOutlined } from '@ant-design/icons';
import { Color } from './sum'
import Text from './text';
import Button from './button';

function SearchTable() {
    let [loading, setLoading] = useState(false);
    // let [topicSourceType, setTopicSourceType] = useState('');
    // let [gradeList, setGradeList] = useState([]);

    // useEffect(() => {
    //     //获取年级列表
    //     api.getGradeList()
    //         .then((data) => {
    //             if (data.ret === 20000) {
    //                 setGradeList(data.result)
    //                 setLoading(false)
    //             } else {
    //                 return Promise.reject(data);
    //             }

    //         })
    //         .catch((err) => {
    //             message.error(err.msg);
    //             setLoading(false)
    //         })

    // }, [])
    return (
        <div>
            <Fragment>
                <Spin spinning={loading} indicator={<LoadingOutlined />} tip='请稍候...' size="large">
                    <div>
                        <Color>
                            <Text></Text>
                            <Button></Button>
                        </Color>
                    </div>
                </Spin>
            </Fragment>
        </div >
    )
}

export default SearchTable