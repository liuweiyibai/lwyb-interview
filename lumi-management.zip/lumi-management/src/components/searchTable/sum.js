import React, { createContext, useReducer } from 'react';
export const ColorContext = createContext({});
function MyPromise(excutor) {
    let self = this;
    self.status = 'pending';
    self.success = undefined;
    self.error = undefined;
    self.callBackSuccessArray = [];
    self.callBackErrorArray = [];
    function resolve(success) {
        if (self.status === 'pending') {
            self.status = 'success';
            self.success = success;
            self.callBackSuccessArray.forEach(element => {
                element();
            });
        }
    }
    function reject(error) {
        if (self.status === 'pending') {
            self.status = 'error';
            self.error = error;
            self.callBackErrorArray.forEach(element => {
                element();
            })
        }
    }
    try {
        excutor(resolve, reject)
    } catch (error) {
        reject(error)
    }
}
MyPromise.prototype.then = (onResolve, onReject) => {
    let self = this
    onResolve = typeof onResolve === 'function' ? onResolve : (val) => val;
    onReject = typeof onReject === 'function' ? onReject : (error) => {
        throw TypeError(error)
    }
    let promiseAgain = new MyPromise((resolve, reject) => {
        if (self.status === 'pending') {
            self.callBackSuccessArray.push(() => {
                let x = onResolve(self.success);
                resolvePromise(x, promiseAgain, resolve, reject)
            })
            self.callBackErrorArray.push(() => {
                let x = onReject(self.error);
                resolvePromise(x, promiseAgain, resolve, reject)
            })
        }
        if (self.status === 'success') {
            let x = onResolve(self.success);
            resolvePromise(x, promiseAgain, resolve, reject)
        }
        if (self.status === 'error') {
            let x = onReject(self.error);
            resolvePromise(x, promiseAgain, resolve, reject)
        }
    })
}
function resolvePromise(x, promiseAgain, resolve, reject) {
    if (x === promiseAgain) {
        reject(TypeError('循环引用'))
    }
    if (x !== null && (typeof x === 'function' || typeof x === 'object')) {
        let then = x.then;
        if (typeof then === 'function') {
            then.call(x, (y) => {
                resolvePromise(y, promiseAgain, resolve, reject)
            }, error => {
                reject(error)
            })
        } else {
            resolve(x)
        }
    }
    else {
        resolve(x)
    }
}

function reducer(state, action) {
    switch (action.type) {
        case 'initial':
            return JSON.parse(JSON.stringify(action.value));
        case 'changeInput':
            let obj = state;
            obj[action.name] = action.value;
            return JSON.parse(JSON.stringify(obj));
        default:
            return state;
    }
}

export const Color = (props) => {
    let [value, dispatch] = useReducer(reducer, { topicName: '123' })
    return (
        <ColorContext.Provider value={{ value, dispatch }}>
            {props.children}
        </ColorContext.Provider>
    )
}