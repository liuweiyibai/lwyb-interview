import React, { Component } from 'react';
// import { connect } from 'react-redux';
import { HashRouter, Switch, Route, Redirect } from 'react-router-dom';
import Loadable from './utils/loadable.js';
// import Login from './pages/login/login';//同步加载
//封装loadable异步加载
// const Home = Loadable(()=>import('./pages/home/home.js'));
const Login = Loadable(() => import('./pages/login/login.js'));//登录页
const Admin = Loadable(() => import('./pages/admin/admin.jsx'));//主页
const Personal = Loadable(() => import('./pages/personal/personal.js'));//个人首页
const Error = Loadable(() => import('./pages/error/error.js'));//无权限
//----------------知识图谱
const KnowledgeTree = Loadable(() => import('./pages/v1/knowledgeGraphManage/knowledgeTree.js'));//知识树管理
//----------------视频管理
const KnowledgeVideo = Loadable(() => import('./pages/v1/videoManage/knowledgeVideo/knowledgeVideo.js'));//知识点视频页
const TopicExplanationVideo = Loadable(() => import('./pages/v1/videoManage/topicExplanationVideo/topicExplanationVideo.js'));//题目讲解视频页
const DelayedCourseVideo = Loadable(() => import('./pages/v1/videoManage/delayedCourseVideo/delayedCourseVideo.js'));//录播视频页
const VideoDataStatistics = Loadable(() => import('./pages/v1/videoManage/videoDataStatistics/videoDataStatistics.js'));//视频数据统计页
//----------------知识点课程管理模块
const CourseConfig = Loadable(() => import('./pages/v1/knowledgePointCourseManage/courseConfig/courseConfig.js'));//课程配置
const PersonalizedConfig = Loadable(() => import('./pages/v1/knowledgePointCourseManage/courseConfig/subPage/personalizedConfig/personalizedConfig.js'));//个性化配置页
const ContentConfig = Loadable(() => import('./pages/v1/knowledgePointCourseManage/courseConfig/subPage/contentConfig/contentConfig.js'));//课程内容配置页
// const ContentConfiguration = Loadable(() => import('./pages/v1/knowledgePointCourseManage/contentConfiguration/contentConfiguration.js'));//内容配置
// const PersonalizedConfiguration = Loadable(() => import('./pages/v1/knowledgePointCourseManage/personalizedConfiguration/personalizedConfiguration.js'));//个性化配置
// const KnowledgeCoursePersonaliseSet = Loadable(() => import('./pages/v1/knowledgePointCourseManage/knowledgeCoursePersonaliseSet/knowledgeCoursePersonaliseSet.js'));//知识点课程个性化配置页
//----------------题库管理
const TopicsList = Loadable(() => import('./pages/v1/questionBankManage/topicsListBox/topicsList/topicsList.js'));//题目列表页
const PreviewTopic = Loadable(() => import('./pages/v1/questionBankManage/topicsListBox/preview/preview.js'));//题目详情页
const AddTopic = Loadable(() => import('./pages/v1/questionBankManage/topicsListBox/addTopic/addTopic.js'));//新增题目页
const TopicsBulkUpload = Loadable(() => import('./pages/v1/questionBankManage/topicsBulkUpload/topicsBulkUpload.js'));//题目批量上传
const QuestionBankStatistics = Loadable(() => import('./pages/v1/questionBankManage/questionBankStatistics/questionBankStatistics.js'));//题库数据统计
const SupplyChainManage = Loadable(() => import('./pages/v1/questionBankManage/supplyChainManage/supplyChainManage.js'));//供应链管理
//----------------权限
const UserPower = Loadable(() => import('./pages/v1/userManage/userPower/userPower.js'));//用户权限页
//----------------人工解题工单
const SolveProExpertManage = Loadable(() => import('./pages/v1/artificialSolveProblem/solveProblemExpertManage/expertManage/expertManage.js'));//解题专家管理页
const ExpertTimeManage = Loadable(() => import('./pages/v1/artificialSolveProblem/solveProblemExpertManage/expertTimeManage/expertTimeManage.js'));//解题专家工作时间段展示和配置页
const OrderHumanResourceMonitor = Loadable(() => import('./pages/v1/artificialSolveProblem/solveProblemExpertManage/orderHumanResourceMonitor/orderHumanResourceMonitor.js'));//工单人力资源监控页面
const SolveProOrders = Loadable(() => import('./pages/v1/artificialSolveProblem/solveProblemOrders/solveProblemOrders.js'));//解题工单页
const OrdersQualityTest = Loadable(() => import('./pages/v1/artificialSolveProblem/ordersQualityTest/ordersQualityTest.js'));//工单质检页
const SolveProExpertDataStatistics = Loadable(() => import('./pages/v1/artificialSolveProblem/dataStatistics/solveProExpertDataStatistics/solveProExpertDataStatistics.js'));//解题专家数据统计页
const SubConfigure = Loadable(() => import('./pages/v1/artificialSolveProblem/subjectConfiguration/subjectConfigutation.js'));//人工解题学科配置页
const WorkOrdStatistical = Loadable(() => import('./pages/v1/artificialSolveProblem/dataStatistics/workOrderStatistics/workOrderStatistics.js'));//工单数据统计页
//----------------备考课程管理
const TestPrepareConfigure = Loadable(() => import('./pages/v1/testPrepareCourseManage/testPrepare/testPrepareConfigure/testPrepareConfigure.js'));//备考课配置
const CourseOutline = Loadable(() => import('./pages/v1/testPrepareCourseManage/testPrepare/courseOutline/courseOutline.js'));//备考课程大纲
const LiveCourse = Loadable(() => import('./pages/v1/testPrepareCourseManage/liveCourse/liveCourse.js'));//直播课
const CourseMaterials = Loadable(() => import('./pages/v1/testPrepareCourseManage/courseMaterials/courseMaterials.js'));//课程资料
const MockTest = Loadable(() => import('./pages/v1/testPrepareCourseManage/mockTestBox/mockTest/mockTest.js'));//模拟考试
const TopicConfigure = Loadable(() => import('./pages/v1/testPrepareCourseManage/mockTestBox/topicConfigure/topicConfigure.js'));//模拟考试题目配置
const LiveCourseStatistics = Loadable(() => import('./pages/v1/testPrepareCourseManage/liveCourseStatistics/liveCourseStatistics.js'));//直播课统计
//----------------运营数据
const UserData = Loadable(() => import('./pages/v1/operationalData/userData/userData.js'));//用户数据
const ServiceData = Loadable(() => import('./pages/v1/operationalData/serviceData/serviceData.js'));//业务数据
const BusinessData = Loadable(() => import('./pages/v1/operationalData/businessData/businessData.js'));//商业数据
//----------------用户和内容运营
const CustomerManage = Loadable(() => import('./pages/v1/userAcontentManage/customerManage/customerManage.js'));//lumist用户管理
const AdvertisingManage = Loadable(() => import('./pages/v1/userAcontentManage/advertisingManage/advertisingManage.js'));//拍搜首页广告
const CourseAdvertising = Loadable(() => import('./pages/v1/userAcontentManage/courseAdvertising/courseAdvertising.js'));//课程首页广告
const ExtensionCode = Loadable(() => import('./pages/v1/userAcontentManage/extensionCode/extensionCode.js'));//Lumist推广码
const SchoolManage = Loadable(() => import('./pages/v1/userAcontentManage/schoolManage/schoolManage.js'));//学校管理
//----------------财务管理
const OrderManage = Loadable(() => import('./pages/v1/financeManage/orderManage/orderManage.js'));//订单管理
const CoursesInOrder = Loadable(() => import('./pages/v1/financeManage/coursesInOrder/coursesInOrder.js'));//课程订单

//----------------易维学院课程管理
const EZACourseManagement = Loadable(() => import('./pages/v1/ezCollegeCourseManage/courseManagement/courseManagement'));//课程管理
const EZALiveCourseManagement = Loadable(() => import('./pages/v1/ezCollegeCourseManage/liveCourseManagement/liveCourseManagement'));//直播课管理
const CourseLive = Loadable(() => import('./pages/v1/ezCollegeCourseManage/courseLive/courseLive.js'));//课程直播
const EDUCourseMaterials = Loadable(() => import('./pages/v1/ezCollegeCourseManage/courseMaterials/courseMaterials.js'));//课程资料
const SchoolTimetable = Loadable(() => import('./pages/v1/ezCollegeCourseManage/courseMaterials/schoolTimetable/schoolTimetable.js'));//课程表
const Statistics = Loadable(() => import('./pages/v1/EZAOperationMgt/statistics/statistics.jsx'));//课程数据统计
const EZA_VideoRoom = Loadable(() => import('./pages/v1/ezCollegeCourseManage/videoRoom/videoRoom'));//录播
const EZA_WechatGroup = Loadable(() => import('./pages/v1/EZAOperationMgt/wechatGroup/wechatGroup'));//微信拉群
const EZA_WechatGroupDetail = Loadable(() => import('./pages/v1/EZAOperationMgt/wechatGroup/wechatGroupDetail/wechatGroupDetail'));//微信拉群
const EZA_WechatUnbind= Loadable(() => import('./pages/v1/EZAOperationMgt/wechatUnbind/wechatUnbind'));//微信拉群

//----------------易维学院leads管理
const LeadsActivityManagement = Loadable(() => import('./pages/v1/ezaLeads/activity/activity'));//活动管理
const LeadsCustomerManagement = Loadable(() => import('./pages/v1/ezaLeads/customer/customer'));//客户详情

//----------------华人业务管理
const ReceivablesOrder = Loadable(() => import('./pages/v1/chineseBusinessManagement/receivablesOrder/receivablesOrder.js'));//收款和订单
const OrderSaleStatistics = Loadable(() => import('./pages/v1/chineseBusinessManagement/orderSaleStatistics/orderSaleStatistics.js'));//销售成单统计

//----------------ap课程管理
const APCourseConfig = Loadable(() => import('./pages/v1/APCourseManage/APCourseConfig/APCourseConfig.jsx'));//ap课程配置
const APCourseResourcesConfig = Loadable(() => import('./pages/v1/APCourseManage/APCourseConfig/APCourseResourcesConfig/APCourseResourcesConfig.jsx'));//ap课程配置>>>课程资源管理
const APCourseClassMnage = Loadable(() => import('./pages/v1/APCourseManage/APCourseConfig/APCourseClassManage/APCourseClassManage.jsx'));//ap课程配置>>>班级管理
const APLiveCourseConfig = Loadable(() => import('./pages/v1/APCourseManage/APCourseConfig/APLiveCourseConfig/APLiveCourseConfig.jsx'));//ap课程配置>>>直播课管理
const APLiveCoursePlan = Loadable(() => import('./pages/v1/APCourseManage/APCourseConfig/APLiveCourseConfig/APLiveCoursePlan/APLiveCoursePlan.jsx'));//ap课程配置>>>直播课管理>>>排课
const APCourseMaterials = Loadable(() => import('./pages/v1/APCourseManage/APCourseMaterials/APCourseMaterials.jsx'));//课程资料
// const APMockCourseTest = Loadable(() => import('./pages/v1/APCourseManage/APMockCourseTest/APMockCourseTest.jsx'));//模拟课考试
const APCourseVideo = Loadable(() => import('./pages/v1/APCourseManage/APCourseVideo/APCourseVideo.jsx'));//课程简介视频
const APVideoManagement = Loadable(() => import('./pages/v1/APCourseManage/APVideoManagement/APVideoManagement.js'));//AP录播视频

const Notfound = Loadable(() => import('./components/notfound/notfound.js'));//404页面
class RootRouter extends Component {
    render () {
        return (
            <HashRouter>
                <Switch>
                    <Redirect exact from='/' to='/login'></Redirect>
                    <Route path='/login' component={Login}></Route>
                    <Route path='/admin' component={() => {
                        return (
                            <Admin>
                                {/* 个人首页 */}
                                <Route path='/admin/personal' component={Personal}></Route>
                                {/* 无权限页面 */}
                                <Route path='/admin/error' component={Error}></Route>
                                {/* 权限管理 */}
                                <Route path='/admin/v1/userManage/userPower' component={UserPower}></Route>
                                {/* 知识图谱 */}
                                <Route path='/admin/v1/knowledgeGraphManage/knowledgeTree' component={KnowledgeTree}></Route>
                                {/* 视频管理 */}
                                <Route path='/admin/v1/videoManage/knowledgeVideo' component={KnowledgeVideo}></Route>
                                <Route path='/admin/v1/videoManage/topicExplanationVideo' component={TopicExplanationVideo}></Route>
                                <Route path='/admin/v1/videoManage/delayedCourseVideo' component={DelayedCourseVideo}></Route>
                                <Route path='/admin/v1/videoManage/videoDataStatistics' component={VideoDataStatistics}></Route>
                                {/* 知识点课程管理 */}
                                <Route path='/admin/v1/knowledgePointCourseManage/courseConfig' component={CourseConfig}></Route>
                                <Route path='/admin/v1/knowledgePointCourseManage/personalizedConfig' component={PersonalizedConfig}></Route>
                                <Route path='/admin/v1/knowledgePointCourseManage/contentConfig' component={ContentConfig}></Route>
                                {/* <Route path='/admin/v1/knowledgePointCourseManage/contentConfiguration' component={ContentConfiguration}></Route> */}
                                {/* <Route path='/admin/v1/knowledgePointCourseManage/personalizedConfiguration' component={PersonalizedConfiguration}></Route> */}
                                {/* <Route path='/admin/v1/knowledgePointCourseManage/KnowledgeCoursePersonaliseSet' component={KnowledgeCoursePersonaliseSet}></Route> */}
                                {/* 题库管理 */}
                                <Route path='/admin/v1/questionBankManage/topicsList' component={TopicsList}></Route>
                                <Route path='/admin/v1/questionBankManage/preview' component={PreviewTopic}></Route>
                                <Route path='/admin/v1/questionBankManage/addTopic' component={AddTopic}></Route>
                                <Route path='/admin/v1/questionBankManage/topicsBulkUpload' component={TopicsBulkUpload}></Route>
                                <Route path='/admin/v1/questionBankManage/questionBankStatistics' component={QuestionBankStatistics}></Route>
                                <Route path='/admin/v1/questionBankManage/supplyChainManage' component={SupplyChainManage}></Route>
                                {/* <Route path='/admin/v1/questionBankManage/preview/:id' component={PreviewTopic}></Route>动态路由 */}
                                {/* 人工解题 */}
                                <Route path='/admin/v1/artificialSolveProblem/expertManage' component={SolveProExpertManage}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/expertTimeManage' component={ExpertTimeManage}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/solveProblemOrders' component={SolveProOrders}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/orderHumanResourceMonitor' component={OrderHumanResourceMonitor}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/ordersQualityTest' component={OrdersQualityTest}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/solveProExpertDataStatistics' component={SolveProExpertDataStatistics}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/subjectConfiguration' component={SubConfigure}></Route>
                                <Route path='/admin/v1/artificialSolveProblem/workOrdStatistical' component={WorkOrdStatistical}></Route>
                                {/* 备考课程管理 */}
                                <Route path='/admin/v1/testPrepareCourseManage/testPrepareConfigure' component={TestPrepareConfigure}></Route>
                                <Route path='/admin/v1/testPrepareCourseManage/courseOutline' component={CourseOutline}></Route>
                                <Route exact path='/admin/v1/testPrepareCourseManage/liveCourse' component={LiveCourse}></Route>
                                <Route path='/admin/v1/testPrepareCourseManage/courseMaterials' component={CourseMaterials}></Route>
                                <Route path='/admin/v1/testPrepareCourseManage/mockTest' component={MockTest}></Route>
                                <Route path='/admin/v1/testPrepareCourseManage/topicConfigure' component={TopicConfigure}></Route>
                                <Route path='/admin/v1/testPrepareCourseManage/classStatistics' component={LiveCourseStatistics}></Route>
                                {/* 运营数据 */}
                                <Route path='/admin/v1/operationalData/userData' component={UserData}></Route>
                                <Route path='/admin/v1/operationalData/serviceData' component={ServiceData}></Route>
                                <Route path='/admin/v1/operationalData/businessData' component={BusinessData}></Route>
                                {/* 用户和内容运营 */}
                                <Route path='/admin/v1/userAcontentManage/customerManage' component={CustomerManage}></Route>
                                <Route path='/admin/v1/userAcontentManage/advertisingManage' component={AdvertisingManage}></Route>
                                <Route path='/admin/v1/userAcontentManage/courseAdvertising' component={CourseAdvertising}></Route>
                                <Route path='/admin/v1/userAcontentManage/extensionCode' component={ExtensionCode}></Route>
                                <Route path='/admin/v1/userAcontentManage/schoolManage' component={SchoolManage}></Route>
                                {/* 财务管理 */}
                                <Route path='/admin/v1/financeManage/orderManage' component={OrderManage}></Route>
                                <Route path='/admin/v1/financeManage/coursesInOrder' component={CoursesInOrder}></Route>
                                {/* 易维学院课程管理 */}
                                <Route path='/admin/v1/ezCollegeCourseManage/courseMgt' component={EZACourseManagement}></Route>
                                <Route path='/admin/v1/ezCollegeCourseManage/liveCourseMgt' component={EZALiveCourseManagement}></Route>
                                <Route path='/admin/v1/ezCollegeCourseManage/courseLive' component={CourseLive}></Route>
                                <Route path='/admin/v1/ezCollegeCourseManage/EDUCourseMaterials' component={EDUCourseMaterials}></Route>
                                <Route path='/admin/v1/ezCollegeCourseManage/courseMaterials/schoolTimetable' component={SchoolTimetable}></Route>
                                <Route path='/admin/v1/EZAOperationMgt/statistics' component={Statistics}></Route>
                                <Route path='/admin/v1/ezCollegeCourseManage/courseMaterials/videoRoom' component={EZA_VideoRoom}></Route>
                                <Route path='/admin/v1/EZAOperationMgt/wechat-group' component={EZA_WechatGroup}></Route>
                                <Route path='/admin/v1/EZAOperationMgt/wechat-group-detail' component={EZA_WechatGroupDetail}></Route>
                                <Route path='/admin/v1/EZAOperationMgt/wechat-unbind' component={EZA_WechatUnbind}></Route>
                                {/* EZA - Leads 管理 */}
                                <Route path='/admin/v1/eza-leads/activity' component={LeadsActivityManagement} />
                                <Route path='/admin/v1/eza-leads/customer' component={LeadsCustomerManagement} />
                                {/* 华人业务管理 */}
                                <Route path='/admin/v1/chineseBusinessManagement/receivablesOrder' component={ReceivablesOrder}></Route>
                                <Route path='/admin/v1/chineseBusinessManagement/orderSaleStatistics' component={OrderSaleStatistics}></Route>
                                {/* ap课程管理 */}
                                <Route path='/admin/v1/ap-coursemanage/ap-courseconfig' component={APCourseConfig}></Route>
                                <Route path='/admin/v1/ap-coursemanage/ap-courseresourcesconfig' component={APCourseResourcesConfig}></Route>
                                <Route path='/admin/v1/ap-coursemanage/ap-livecourseconfig' component={APLiveCourseConfig}></Route>
                                <Route path='/admin/v1/ap-coursemanage/ap-livecourseplan' component={APLiveCoursePlan}></Route>
                                <Route path='/admin/v1/ap-coursemanage/ap-courseclassmanage' component={APCourseClassMnage}></Route>
                                <Route path='/admin/v1/ap-coursemanage/ap-coursematerials' component={APCourseMaterials}></Route>
                                {/* <Route path='/admin/v1/ap-coursemanage/ap-mockcoursetest' component={APMockCourseTest}></Route> */}
                                <Route path='/admin/v1/ap-coursemanage/ap-coursevideo' component={APCourseVideo}></Route>
                                <Route path='/admin/v1/ap-coursemanage/ap-videomanage' component={APVideoManagement}></Route>

                                {/* <Route component={Notfound}></Route> bug：无论子路由是否匹配，都显示*/}
                            </Admin>
                        )
                    }}></Route>
                    <Route component={Notfound}></Route>
                </Switch>
            </HashRouter>
        )
    }
}

export default RootRouter;
